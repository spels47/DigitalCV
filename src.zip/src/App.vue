<template>
  <v-app id="app">
    <v-main class="background">
      <InfoBanner v-if="showInfoBanner"></InfoBanner>
      <Navbar v-if="$route.name && ['signIn'].includes($route.name) === false"/>
      <v-container class="pa-0" fluid>
        <v-fade-transition hide-on-leave>
          <router-view :key="$route.fullPath"/>
        </v-fade-transition>
      </v-container>
    </v-main>
    <alert-message></alert-message>
  </v-app>
</template>

<script>
import * as signalR from "@microsoft/signalr";
import Navbar from "./components/navbar/Navbar";
import AlertMessage from "@/components/AlertMessage";
import InfoBanner from "@/components/InfoBanner";
import { setOidcToken } from "@/error-handler";

export default {
  name: "App",
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
    showInfoBanner() {
      const requiredRoles = this.$store.getters.infoBannerSettings?.userRoles ?? [];
      const userRoles = Object.keys(this.roles).filter(x => this.roles[x] === true);

      if (requiredRoles.length === 0)
        return this.$store.getters.infoBannerSettings?.show;
      else
        return this.$store.getters.infoBannerSettings?.show && requiredRoles.some(role => userRoles.indexOf(role) !== -1);
    },
    oidcToken() {
      return this.$store.state.oidcStore.access_token;
    }
  },
  watch: {
    oidcToken: {
      handler: function (newValue, oldValue) {
        setOidcToken(newValue);
      },
      deep: true
    }
  },
  mounted() {
    this.$store.dispatch("retrieveSiteSettings");
    if (window.localStorage.getItem("darkmode") === "true") {
      this.$vuetify.theme.dark = true;
      this.$store.commit("updateVuetifyDarkMode", true);
    } else {
      this.$store.commit("updateVuetifyDarkMode", false);
    }
    this.$store.dispatch("userSettings_Fetch");
    this.setUpWebSockets();
  },
  methods: {
    setUpWebSockets() {
      const connection = new signalR.HubConnectionBuilder()
        .withUrl("/api/websocket/eventhub", {
          transport: signalR.HttpTransportType.WebSockets,
          skipNegotiation: true
        })
        .configureLogging(signalR.LogLevel.Warning)
        .build();

      connection.on("ReceiveMessage", (type, data) => {
        if (window.developer) {
          console.log('(developer) websocket:', type, data)
        }

        switch (type) {
          case "infoBannerToggled": {
            this.$store.dispatch("changeInfoBannerSettingsFromWebSocket", data);
            break;
          }
          case "updateWorklistItem": {
            this.$store.dispatch("WorklistModule/updateWorkItemFromWebSocket", data);
            break;
          }
          case "removeWorklistItem": {
            this.$store.dispatch("WorklistModule/removeWorkListItem", data);
            break;
          }
        }

        // -- More websocket message types can be added here simply by adding more if-statement --
      });

      connection.start();
    }
  },
  components: {
    InfoBanner,
    AlertMessage,
    Navbar,
  }
};
</script>

<style lang="scss">
.background {
  /*padding-right: 0 !important;*/
}

@keyframes slowroll {
  0% {
  }
  60% {
    transform: translateY(10px) rotate(0deg);
  }
  100% {
    transform: translateY(1500px) rotate(90deg);
  }
}

/* Custom scrollbar -- start */
::-webkit-scrollbar {
  width: 10px;
}

::-webkit-scrollbar-track {
  background: #f1f1f1;
}

::-webkit-scrollbar-thumb {
  background: #888;
  border-radius: 100px;
}

::-webkit-scrollbar-thumb:hover {
  background: #555;
}

/* Custom scrollbar -- end */

/* Mark input fields -- start */
//.v-textarea textarea[readonly="readonly"] {
//  background-color: #f9f9f9;
//}
//.v-text-field input[readonly="readonly"] {
//  background-color: #f9f9f9;
//}
//.theme--dark .v-textarea textarea[readonly="readonly"]{
//  background-color: #282828;
//}
//.theme--dark .v-text-field input[readonly="readonly"] {
//  background-color: #282828;
//}
/* Mark input fields -- end */

</style>
