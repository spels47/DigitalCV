import Vue from "vue";
import Vuetify from "vuetify";
import "vuetify/dist/vuetify.min.css";
import AssetAddIconComponent from '../components/icons/assetAddIcon.vue'
import AssetRemoveIconComponent from '../components/icons/assetRemoveIcon.vue'
import AssetSettingsIconComponent from '../components/icons/assetSettingsIcon.vue'
import AssetMoveIconComponent from '../components/icons/assetMoveIcon.vue'
import AddDepartmentIcon from '../components/icons/AddDepartmentIcon.vue'
import MoveDepartmentIcon from '../components/icons/MoveDepartmentIcon.vue'
import DeleteDepartmentIcon from '../components/icons/DeleteDepartmentIcon.vue'

Vue.use(Vuetify);

export default new Vuetify({
  icons: {
    values: {
      assetAddIcon: {
        component: AssetAddIconComponent
      },
      assetRemoveIcon: {
        component: AssetRemoveIconComponent
      },
      assetSettingsIcon: {
        component: AssetSettingsIconComponent
      },
      assetMoveIcon: {
        component: AssetMoveIconComponent
      },
      addDepartment: {
        component: AddDepartmentIcon
      },
      moveDepartment: {
        component: MoveDepartmentIcon
      },
      deleteDepartment: {
        component: DeleteDepartmentIcon
      }
    }
  },
  theme: {
    themes: {
      light: {
        primary: "#707070",
        secondary: "#25BACA",
        accent: "#C800A1",
        error: "#E5043A",
        info: "#C800A1",
        success: "#4CAA71",
        warning: "#FF9A00",
        background: "#fafafa",
        highlight: "#e0e0e0",
        faded: "#BBBBBB",
        black: "#000000",
        cardbg: "#FFFFFF",
        marked: "#00b7bd",
        tablered: "#ffcdd2"
      },
      dark: {
        primary: "#00bcd4",
        secondary: "#009688",
        accent: "#C800A1",
        error: "#E5043A",
        warning: "#FF9A00",
        info: "#03a9f4",
        success: "#4CAA71",
        background: "#333333",
        cardbg: "#1E1E1E",
        marked: "#00b7bd",
        tablered: "#d32f2f"
      }
    }
  }
});
