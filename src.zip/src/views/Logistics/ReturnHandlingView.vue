<template>
  <v-container fluid>
    <v-tabs background-color="black" dark :value="tab">
      <v-tab v-for="t in tabs" :key="t.id" @click="setTabQuery(t.id)">{{ t.text }}</v-tab>
    </v-tabs>
    <v-tabs-items v-model="tab">
      <v-tab-item>
        <ReturnUnits v-if="tab === 0" />
      </v-tab-item>
      <v-tab-item>
        <PendingReturns v-if="tab === 1" />
      </v-tab-item>
      <v-tab-item>
        <SendReceiveBatch v-if="tab === 2" />
      </v-tab-item>
    </v-tabs-items>
  </v-container>
</template>

<script>
import ReturnUnits from "@/views/Logistics/ReturnHandling/ReturnUnits"
import SendReceiveBatch from "@/views/Logistics/ReturnHandling/SendReceiveBatch"
import PendingReturns from "@/views/Logistics/ReturnHandling/PendingReturns"
export default {
  name: "ReturnHandlingView",
  components: {PendingReturns, SendReceiveBatch, ReturnUnits},
  data() {
    return {
      tab: -1,
      tabs: [
        { id: 0, text: "Return units" },
        { id: 1, text: "Pending returns" },
        { id: 2, text: "Send receive batch" },
      ],
    }
  },
  async mounted() {
    let query = parseInt(this.$route.query?.tab??'');
    if (this.tabs.some(x => x.id === query)) this.tab = query
    else this.tab = this.tabs[0].id
    this.$forceUpdate();
  },
  methods: {
    async setTabQuery(tab) {
      await this.$store.dispatch("setUrlParameter", {name: "tab", value: tab});
      this.tab = tab
    }
  },
  computed:{
    roles() {
      return this.$store.state.currentUserRoles;
    },
  },
}
</script>

<style scoped>

</style>
