<template>
  <v-card class="pa-4">
    <v-toolbar flat>
      <v-toolbar-title>
        <div class="float-left">
          <v-icon class="pr-2">mdi-recycle</v-icon>
        </div>
        <div>
          <div>Return to tech</div>
          <div style="font-size: 14px" class="pr-4">Manage what units are to be returned to tech</div>
        </div>
      </v-toolbar-title>
    </v-toolbar>
    <v-row>
      <v-col cols="6" class=" mx-auto">
        <v-card class="pa-4 text-right">
          <v-card-title><div>Register new return request:</div></v-card-title>
          <v-text-field v-model="batchComment" label="Description"></v-text-field>
          <v-text-field v-model="serialNumbersToMatchCsv" label="Serial numbers to match as CSV" @change="serialNumbersToMatchCsvChanged"></v-text-field>
          <v-text-field v-model="amountRequested" label="Number of units requested"></v-text-field>
          <v-btn @click="registerRequestBatch">Request</v-btn>
        </v-card>

      </v-col>
    </v-row>
    <v-row class="mt-4">
      <v-col>
        <v-data-table
          :footer-props="{'items-per-page-options':[100, -1]}"
          :headers="listHeaders"
          :items="list"
          class="elevation-1"
          :loading="loading"
          loading-text="Loading list of requests "
          hide-default-footer
        >
          <template v-slot:item.actions="{ item }">
            <v-icon @click="deleteItem(item)">mdi-delete</v-icon>
          </template>
          <template v-slot:top>
            <v-toolbar flat>
              <v-toolbar-title>
                <div class="float-left">
                  <div class="mr-6" style="font-size: 14px"><v-icon class="pr-2">mdi-notebook-check</v-icon>Requested returns:</div>
                </div>
              </v-toolbar-title>
            </v-toolbar>
          </template>
        </v-data-table>
      </v-col>
    </v-row>
    <ConfirmDialog ref="confirm"></ConfirmDialog>
  </v-card>
</template>
<script>
import axios from "~/axios-client";
import ConfirmDialog from "@/components/widgets/dialogs/ConfirmDialog"
export default {
  name: 'ReturnToTech',
  components: {
    ConfirmDialog
  },
  data() {
    return {
      batchComment: '',
      serialNumbersToMatchCsv: '',
      serialNumbersToMatch: [],
      amountRequested: 0,
      list: [],
      listHeaders: [
        { text: 'Id', value: 'id' },
        { text: 'Description', value: 'batchComment' },
        { text: 'Requested by', value: 'requestedByUserName' },
        { text: 'Serial numbers count', value: 'serialNumbersToLookForCount' },
        { text: 'Amount requested', value: 'amountRequested' },
        { text: 'Amount returned', value: 'serialNumbersReturnedCount' },
        { text: '', value: 'actions' },
      ],
      loading: false,
    };
  },
  async mounted() {
    await this.refreshList()
  },
  methods: {
    resetReturnForm(){
      this.batchComment = ''
      this.serialNumbersToMatchCsv = ''
      this.serialNumbersToMatch = []
      this.amountRequested = 0
    },
    serialNumbersToMatchCsvChanged(){
      if(this.amountRequested !== 0) return
      let result = this.calculateAmountRequested()
      if(result.error) return
      this.amountRequested = result.values.length
    },
    calculateAmountRequested(){
      let result = {
        values: [],
        error: null
      }
      let temp = this.serialNumbersToMatchCsv.split(',')
      if(temp.length < 1){
        result.error = `Parse error: serialNumbersToMatchCsv not in correct format`
        return result
      }
      for (let x in temp){
        if(x.length > 10){
          result.error = `Parse error: serialNumbersToMatchCsv not in correct format`
          return result
        }
        x = x.toUpperCase().trim()
      }
      temp = temp.filter(x => !!x)
      result.values = [...new Set(temp)] // distinct
      return result
    },
    async registerRequestBatch() {
      if(this.loading) return

      let result = this.calculateAmountRequested()
      if(result.error) {
        this.$eventBus.$emit('alert', {text: result.error, type: 'error'});
        return
      }
      this.serialNumbersToMatch = result.values

      if(!this.amountRequested) {
        this.$eventBus.$emit('alert', {text: `Amount requested should be at least 1`, type: 'error'});
        return
      }
      if(this.serialNumbersToMatch.length < this.amountRequested) {
        this.$eventBus.$emit('alert', {text: `You are requesting more units than the CSV contains`, type: 'error'});
        return
      }
      if(this.amountRequested < 1) {
        this.$eventBus.$emit('alert', {text: `You are requesting less than 1 unit, you might as well just not`, type: 'error'});
        return
      }

      this.loading = true
      try {
        await axios.post(`/api/return-handling/warehouse/return-to-tech`, {
          batchComment: this.batchComment,
          serialNumbersToMatch: this.serialNumbersToMatch,
          amountRequested: this.amountRequested,
        })
        this.resetReturnForm()
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to register return to tech request`, type: 'error'});
      }
      this.loading = false
      await this.refreshList()
    },
    async deleteItem(item) {
      let confirmed = await this.$refs.confirm.open('Delete this batch', `Are you sure you want to delete batch <b>${item.id}</b>?`, { width: 700, preformatted: true, html: true })
      if(!confirmed) return

      this.loading = true
      try {
        await axios.delete(`/api/return-handling/warehouse/return-to-tech/${item.id}`)
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to delete item`, type: 'error'});
      }
      this.loading = false
      await this.refreshList()
    },
    async refreshList() {
      this.loading = true
      try{
        let res = await axios.get(`/api/return-handling/warehouse/return-to-tech`)
        this.list = res.data
      } catch (ex){
        this.$eventBus.$emit('alert', {text: `Failed to fetch return-to-tech list`, type: 'error'});
      }
      this.loading = false
    },
  },
};
</script>

<style scoped lang="scss">

</style>
