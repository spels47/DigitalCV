<template>
  <v-card>
    <v-toolbar flat>
      <v-toolbar-title>
        <div>
          <div><v-icon class="pr-2">mdi-cube-send</v-icon>Send / Receive batch</div>
          <div style="font-size: 14px" class="pr-4">Scan units into a batch to send, scan batch to receive. Keeping track of units between locations</div>
        </div>
        <v-spacer></v-spacer>
        <div style="position: absolute; right: 0; top: 0;" class="ma-6">
          <v-select
            :error="!currentLocation"
            :items="countries"
            v-model="currentLocation"
            label="Country to register in"
            data-cy="currentLocation"
            class="pl-3 pr-3"
            item-text="text"
            item-value="value"
            @change="countrySelected"
          ></v-select>
        </div>
      </v-toolbar-title>
    </v-toolbar>
    <v-row>
      <v-col>
        <v-card class="pa-4" v-if="modeToggleState" elevation="0">
          <v-btn class="mr-2" color="secondary">Send</v-btn>
          <v-btn color="primary" @click="toggleView(false)">Receive</v-btn>
        </v-card>
        <v-card class="pa-4" v-if="!modeToggleState" elevation="0">
          <v-btn class="mr-2" color="primary" @click="toggleView(true)">Send</v-btn>
          <v-btn color="secondary">Receive</v-btn>
        </v-card>
      </v-col>
    </v-row>
    <v-row class="pb-6">
      <v-col cols="12" md="6" class="mx-auto">
        <v-card class="pa-4" v-if="modeToggleState">
          <div v-if="!batchId">
            <v-card-title><div>Register new shipment</div></v-card-title>
            <v-input class="pa-4">
              <v-text-field v-model="serialNumber" label="Scan in serialNumber" @keyup.enter="addSerialNumber"></v-text-field>
              <v-btn class="ml-2"  small @click="addSerialNumber">Add</v-btn>
            </v-input>
            <v-card-actions>
              <v-btn @click="createShipment" :disabled="!canCreateShipment">Register shipment</v-btn>
            </v-card-actions>
          </div>
          <div v-if="batchId">
            <v-card-actions>
              <v-btn @click="resetForm">Reset form</v-btn>
            </v-card-actions>
          </div>
        </v-card>
        <v-card class="pa-4" v-if="!modeToggleState">
          <v-card-title><div>Receive shipment</div></v-card-title>
          <v-input class="pa-4">
            <v-text-field v-model="receivedBatchId" label="Scan in received shipment" @keyup.enter="getShipment"></v-text-field>
            <v-btn class="ml-2"  small @click="getShipment">Find</v-btn>
          </v-input>
          <v-card-actions>
            <v-btn v-if="receivedBatchId" @click="markAsReceived">Mark as received shipment</v-btn>
          </v-card-actions>
        </v-card>
      </v-col>
      <v-col cols="12" md="6">
        <div id="printable">
          <div v-if="batchId && modeToggleState">
            <div><b>Shipment Id:</b></div>
            <div>{{batchId}}</div>
            <img id="barcode" alt="barcode"/>
          </div>
          <div v-if="batchId && !modeToggleState">
            <div><b>Id of received shipment:</b></div>
            <div>{{batchId}}</div>
          </div>
          <div><b>Serial numbers:</b></div>
          <div v-for="serialNumber in serialNumbers" :key="serialNumber">{{serialNumber}}</div>
        </div>
        <v-btn v-if="batchId" @click="printShipment">Print shipment</v-btn>
      </v-col>
    </v-row>
    <ConfirmDialog ref="confirm"></ConfirmDialog>
  </v-card>
</template>
<script>
import axios from "~/axios-client";
import ConfirmDialog from "@/components/widgets/dialogs/ConfirmDialog"
import JsBarcode from 'jsbarcode'
import util from "@/helpers/util"
export default {
  name: 'SendReceiveBatch',
  components: {
    ConfirmDialog
  },
  data() {
    return {
      countries: [
        {value: "NO", text: 'Norway'},
        {value: "SE", text: 'Sweden'},
        {value: "DK", text: 'Denmark'},
        {value: "NL", text: 'Netherlands'},
        {value: "FI", text: 'Finland'},
        {value: "PL", text: 'Poland'},
        {value: "UK", text: 'UK'},
      ],
      currentLocation: null,
      batchId: '',
      serialNumbers: [],
      serialNumber: '',
      loading: false,
      receivedBatchId: '',
      modeToggleState: true
    };
  },
  async mounted() {
    if (window.localStorage.getItem("ReturnUnits--currentLocation")) {
      this.currentLocation = window.localStorage.getItem("ReturnUnits--currentLocation")
    }
  },
  computed:{
    canCreateShipment(){
      if(!this.currentLocation) return false
      if(this.serialNumbers.length < 1) return false
      if(this.loading) return false
      return true
    }
  },
  methods: {
    async createShipment() {
      if(!this.currentLocation) return
      if(this.serialNumbers.length < 1) return
      this.loading = true

      try {
        let res = await axios.post(`/api/return-handling/warehouse/shipment`, {
          shipFromLocation: this.currentLocation,
          serialNumbers: this.serialNumbers
        })
        this.batchId = res.data
        this.$nextTick(async () => {
          await util.sleep(500);
          JsBarcode("#barcode", this.batchId);
        })
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to register shipment`, type: 'error'});
      }
      this.loading = false
    },
    countrySelected(){
      window.localStorage.setItem("ReturnUnits--currentLocation", this.currentLocation)
    },
    addSerialNumber(){
      if(this.batchId) return
      if(this.serialNumbers.some(x => x === this.serialNumber.toUpperCase())){
        this.serialNumber = ''
        return
      }
      this.serialNumbers.push(this.serialNumber.toUpperCase())
      this.serialNumber = ''
    },
    async printShipment() {
      let html = `<html>${document.getElementById('printable').innerHTML}</html>`
      let printWin = window.open('', '', 'left=0,top=0,width=1,height=1,toolbar=0,scrollbars=0,status=0');
      printWin.document.write(html);
      printWin.document.close();
      printWin.focus();
      await util.sleep(100);
      printWin.print();
      printWin.close();
    },
    async getShipment() {
      if (!this.receivedBatchId) return
      this.loading = true
      try {
        let res = await axios.get(`/api/return-handling/warehouse/shipment/${this.receivedBatchId}`)
        this.batchId = res.data.batchId
        this.serialNumbers = res.data.serialNumbers
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to get batch by id`, type: 'error'});
      }
      this.loading = false
    },
    async markAsReceived() {
      if (!this.receivedBatchId) return
      this.loading = true
      try {
        await axios.post(`/api/return-handling/warehouse/shipment/${this.receivedBatchId}/receive/${this.currentLocation}`)
        this.batchId = ''
        this.serialNumbers = []
        this.receivedBatchId = ''
        this.$eventBus.$emit('alert', {text: `Marked shipment as received`, type: 'success'});
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to mark as received`, type: 'error'});
      }
      this.loading = false
    },
    toggleView(state){
      this.modeToggleState = state
      this.resetForm()
    },
    resetForm(){
      this.batchId = ''
      this.serialNumbers = []
      this.receivedBatchId = ''
    }
  },
};
</script>

<style scoped lang="scss">
</style>
