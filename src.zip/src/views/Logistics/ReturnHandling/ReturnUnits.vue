<template>
  <v-card>
    <v-toolbar flat>
      <v-toolbar-title>
          <div>
            <div><v-icon class="pr-2">mdi-barcode-scan</v-icon> Return of units</div>
            <div style="font-size: 14px">Returned units are scanned and recycled, sent to evaluation or marked for refurbishment</div>
          </div>
          <div style="position: absolute; right: 0; top: 0;" class="ma-6">
            <v-select
              :error="!currentLocation"
              :items="countries"
              v-model="currentLocation"
              label="Country to register return in"
              data-cy="currentLocation"
              class="pl-3 pr-3"
              item-text="text"
              item-value="value"
              @change="countrySelected"
            ></v-select>
          </div>
      </v-toolbar-title>
    </v-toolbar>
    <v-row no-gutters class="mt-4">
      <v-col cols="12">
        <v-stepper v-model="currentStep">
          <v-stepper-header>
            <v-stepper-step :complete="currentStep > 1" step="1">
              Scan the unit
            </v-stepper-step>
            <v-divider></v-divider>
            <v-stepper-step :complete="currentStep > 2" step="2">
              Inspect the unit
            </v-stepper-step>
            <v-divider></v-divider>
            <v-stepper-step step="3">
              Place in bucket
            </v-stepper-step>
          </v-stepper-header>

          <v-stepper-items>
            <v-progress-linear indeterminate color="primary" active v-if="loading"></v-progress-linear>
            <v-stepper-content step="1">
              <v-card class="mb-12" color="background" height="300px">
                <v-row justify="center">
                  <v-col cols="12" md="3" class="mt-12">
                    <div class="zoomable">
                      <v-text-field v-model="serialNumber"
                                    placeholder="Serial Number"
                                    prepend-icon="mdi-barcode"
                                    id="serialInput"
                                    @keyup.enter="registerUnit()"
                                    tabindex="0">
                      </v-text-field>

                    </div>
                  </v-col>
                </v-row>
              </v-card>
              <v-btn class="float-right" color="secondary" @click="registerUnit()" :disabled="!serialNumber || !currentLocation">Continue</v-btn>
              <v-btn small plain color="primary" @click="missingSerialNumber()" :disabled="!!serialNumber || !currentLocation">The serial number is missing</v-btn>
            </v-stepper-content>

            <v-stepper-content step="2">
              <v-card class="mb-12" color="background" height="300px" v-if="inspectionType === 'MissingSerialNumber'">
                <v-row justify="center">
                  <v-col cols="12" md="6" class="mt-12">
                    <v-img src="@/assets/not-able-to-scan.webp" contain height="140" class=""></v-img>
                    <div class="mt-4">If the unit cannot be scanned and has no serial number, then it should be sent to Tech for investigation</div>
                    <div>If the unit arrived with any customer information, for example return address, then attach that to the unit with a piece of tape</div>
                  </v-col>
                </v-row>
              </v-card>
              <v-card class="mb-12" color="background" height="300px" v-if="inspectionType !== 'MissingSerialNumber'">
                <v-row justify="center">
                  <v-col cols="12" md="6" class="mt-12">
                    <div>This unit is a candidate for refurbishment. Let's inspect it:</div>
                    <v-checkbox v-model="inspectionCheckLooksOk" id="inspectionInput" label="The housing of the unit is intact" color="secondary"></v-checkbox>
                    <v-checkbox v-model="inspectionCheckCableOk" v-if="inspectionType === 'CabledUnit'" label="The unit has an undamaged cable, that is at least 60cm long" color="secondary"></v-checkbox>
                  </v-col>
                </v-row>
              </v-card>
              <v-btn class="float-right" color="secondary" @click="inspectionCompleted()">Continue</v-btn>
            </v-stepper-content>

            <v-stepper-content step="3">
              <v-card class="mb-12" color="background" height="300px">
                <v-row justify="center">
                  <v-col cols="12" md="12" class="mt-12">
                    <div v-if="action === 'refurbish'" class="text-md-center relative-class">
                      <v-icon color="#4CAA71" size="150" class="wiggle">mdi-bucket</v-icon>
                      <div class="fly-by">
                        <v-icon>mdi-eraser-variant</v-icon>
                        <div>{{serialNumber}}</div>
                      </div>
                      <div>Put the unit in the <b>green</b> bucket. This unit will be <b>refurbished</b></div>
                    </div>
                    <div v-if="action === 'recycle'" class="text-md-center relative-class">
                      <v-icon color="#03a9f4" size="150" class="wiggle">mdi-bucket</v-icon>
                      <div class="fly-by">
                        <v-icon>mdi-eraser-variant</v-icon>
                        <div>{{serialNumber}}</div>
                      </div>
                      <div>Put the unit in the <b>blue</b> bucket. This unit will be <b>recycled</b></div>
                    </div>
                    <div v-if="action === 'tech'" class="text-md-center relative-class">
                      <v-icon color="#FF9A00" size="150" class="wiggle">mdi-bucket</v-icon>
                      <div class="fly-by">
                        <v-icon>mdi-eraser-variant</v-icon>
                        <div>{{serialNumber}}</div>
                      </div>
                      <div>Put the unit in the <b>yellow</b> bucket. This unit will be <b>sent to tech</b> for further analysis</div>
                    </div>
                    <div v-if="action === 'activeSubscription'" class="text-md-center relative-class">
                      <v-icon color="#E5043A" size="150" class="wiggle">mdi-bucket</v-icon>
                      <div class="fly-by">
                        <v-icon>mdi-eraser-variant</v-icon>
                        <div>{{serialNumber}}</div>
                      </div>
                      <div>Put the unit in the <b>red</b> bucket. This unit is part of an <b>active subscription</b></div>
                    </div>
                  </v-col>
                </v-row>
              </v-card>
              <v-btn class="float-right" color="secondary" @click="complete()" id="completeButton">Complete</v-btn>
            </v-stepper-content>
          </v-stepper-items>
        </v-stepper>
      </v-col>
    </v-row>
    <v-row class="mt-4">
      <v-col>
        <v-data-table
          :footer-props="{'items-per-page-options':[100, -1]}"
          :headers="returnLogHeaders"
          :items="returnLog"
          class="elevation-1"
          :loading="logLoading"
          loading-text="Loading list of processes... "
          hide-default-footer
        >
          <template v-slot:item.timeStamp="{ item }">
            <span>{{item.timeStamp | ntzDatetime}}</span>
          </template>
          <template v-slot:top>
            <v-toolbar flat>
              <v-toolbar-title>
                <div class="float-left">
                  <div class="mr-6" style="font-size: 14px"><v-icon class="pr-2">mdi-notebook-check</v-icon>Log of returned units for location: {{currentLocation}}</div>
                </div>
              </v-toolbar-title>
            </v-toolbar>
          </template>
        </v-data-table>
      </v-col>
    </v-row>
  </v-card>
</template>
<script>
import axios from "~/axios-client";
import util from "@/helpers/util"
export default {
  name: 'ReturnUnits',
  data() {
    return {
      countries: [
        {value: "NO", text: 'Norway'},
        {value: "SE", text: 'Sweden'},
        {value: "DK", text: 'Denmark'},
        {value: "NL", text: 'Netherlands'},
        {value: "FI", text: 'Finland'},
        {value: "PL", text: 'Poland'},
        {value: "UK", text: 'UK'},
      ],
      currentLocation: null,
      serialNumber: '',
      batchNumber: '',
      action: '',
      inspectionType: '',
      returnLog: [],
      returnLogHeaders: [
        { text: 'SerialNumber', value: 'serialNumber' },
        { text: 'Location', value: 'location' },
        { text: 'Batch number', value: 'batchNumber' },
        { text: 'State', value: 'state' },
        { text: 'TimeStamp', value: 'timeStamp' },
      ],
      currentStep: 1,
      loading: false,
      logLoading: false,
      inspectionCheckCableOk: false,
      inspectionCheckLooksOk: false
    };
  },
  async mounted() {
    if (window.localStorage.getItem("ReturnUnits--currentLocation")) {
      this.currentLocation = window.localStorage.getItem("ReturnUnits--currentLocation")
      await this.refreshReturnLog()
    }
    this.focusSerialInput()
  },
  methods: {
    focusSerialInput(){
      this.$nextTick(async () => {
        await util.sleep(500);
        document.getElementById("serialInput").focus();
      })
    },
    focusFirstCheckbox(){
      this.$nextTick(async () => {
        await util.sleep(500);
        document.getElementById("inspectionInput").focus(); // v-checkbox was not fan of vue refs
      })
    },
    focusCompleted(){
      this.$nextTick(async () => {
        await util.sleep(500);
        document.getElementById("completeButton").focus();
      })
    },
    missingSerialNumber(){
      this.action = 'tech'
      this.serialNumber = 'N/A'
      this.inspectionType = 'MissingSerialNumber'
      this.inspectionCheckCableOk = true
      this.inspectionCheckLooksOk = true
      this.currentStep = 2
    },
    async registerUnit() {
      if(this.loading) return
      if(!this.serialNumber) return
      if(!this.currentLocation) return
      this.serialNumber = this.serialNumber.toUpperCase().replaceAll(' ', '')

      if(!this.serialNumber.match(/^([A-Z][A-Z]+)/)){
        this.$eventBus.$emit('alert', {text: `Invalid serialNumber. Serial numbers should start with at least two chars`, type: 'error'});
        return
      }

      this.loading = true
      try {
        let res = await axios.post(`/api/return-handling/unitReturned/${this.serialNumber}/${this.currentLocation}`)
        this.action = res.data.unitReturnCategory
        this.inspectionType = res.data.inspectionType

        if(this.action === 'refurbish') {
          if(this.inspectionType !== 'CabledUnit') this.inspectionCheckCableOk = true
          this.currentStep = 2
          this.focusFirstCheckbox()
        }
        else if(this.action === 'activeSubscription') {
          if(this.inspectionType !== 'CabledUnit') this.inspectionCheckCableOk = true
          this.currentStep = 2
          this.focusFirstCheckbox()
        }
        else {
          this.currentStep = 3
          this.focusCompleted()
        }

      } catch (ex) {
        if(ex.response.status === 400) this.$eventBus.$emit("alert", {text: ex.response.data, type: "error"});
        else this.$eventBus.$emit('alert', {text: `Failed to register unit return`, type: 'error'});
      }
      this.loading = false
    },
    inspectionCompleted(){
      if(!this.inspectionCheckCableOk || !this.inspectionCheckLooksOk) this.action = 'recycle'
      this.currentStep = 3
      this.focusCompleted()
    },
    async complete() {
      if (this.loading) return
      if (!this.serialNumber) return
      if (!this.currentLocation) return
      this.serialNumber = this.serialNumber.toUpperCase()
      this.loading = true
      try {
        await axios.post(`/api/return-handling/warehouse`, {
          serialNumber: this.serialNumber,
          location: this.currentLocation,
          batchNumber: this.batchNumber,
          state: this.action
        })

        this.refreshReturnLog().then(_ => _).catch(_ => _)

        this.resetReturnForm()
        this.currentStep = 1
        this.focusSerialInput()
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to check the unit into warehouse log`, type: 'error'});
      }
      this.loading = false
    },
    resetReturnForm(){
      this.action = ''
      this.inspectionType = ''
      this.serialNumber = ''
      this.inspectionCheckCableOk = false
      this.inspectionCheckLooksOk = false
    },
    async refreshReturnLog() {
      this.logLoading = true
      try{
        let log = await axios.get(`/api/return-handling/warehouse/location/${this.currentLocation}/limit/100`)
        this.returnLog = log.data
      } catch (ex){
        this.$eventBus.$emit('alert', {text: `Failed to fetch warehouse log for current location`, type: 'error'});
      }
      this.logLoading = false
    },
    async countrySelected() {
      window.localStorage.setItem("ReturnUnits--currentLocation", this.currentLocation)
      await this.refreshReturnLog()
    }
  },
};
</script>

<style scoped lang="scss">
.focus-border:active{
  border: red 1px solid;
}
.wiggle{
  animation-name: wiggle;
  animation-duration: 0.3s;
  animation-delay: 1.8s;
  animation-iteration-count: 1;
}

.fly-by{
  text-align: center;
  position: absolute;
  animation-name: throw;
  animation-duration: 2s;
  animation-delay: 0.0s;
  animation-iteration-count: 1;
  opacity: 0;
  transition-timing-function: cubic-bezier(.29, 1.01, 1, -0.68);
}

.relative-class{
  position: relative;
  margin: auto;
  width: 400px;
}

@keyframes wiggle {
  0%   {rotate: 10deg; }
  25%   {rotate: -10deg; }
  50%   {rotate: 10deg; }
  75%   {rotate: -10deg; }
  100%   {rotate: 0deg; }
}

@keyframes throw {
  0%    {top: 20%; left: 0; opacity: 1;}
  50%   {top: -25%; left: 157px;}
  99%  {top: 45%; left: 157px; opacity: 1 }
  100%  {top: 45%; left: 157px;; opacity: 0 }
}

.zoomable{
  zoom: 150%;
}
</style>
