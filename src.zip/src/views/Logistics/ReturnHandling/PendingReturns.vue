<template>
  <v-card>
    <v-sheet elevation="0">
      <v-data-table
        :footer-props="{'items-per-page-options':[100, -1]}"
        :headers="headersProcesses"
        :items="processesView"
        class="elevation-1"
        :loading="loading"
        loading-text="Loading list of processes... "
        :search="search"
        :custom-filter="customFilter"
        @click:row="processClick"
      >
        <template v-slot:item.name="{ item }">
          <span class="clickable" @click.stop="openCustomer(item.aktorId)" style="color:#25BACA">{{item.name}}</span>
        </template>
        <template v-slot:item.serialNumber="{ item }">
          <div>{{item.serialNumber}}</div>
        </template>
        <template v-slot:item.currentState="{ item }">
          <span>{{item.currentState}}</span>
        </template>
        <template v-slot:item.registeredDate="{ item }">
          <span>{{item.registeredDate | ntzDatetime}}</span>
        </template>
        <template v-slot:top>
          <v-toolbar flat>
            <v-toolbar-title>
              <div class="float-left">
                <v-icon class="pr-2">mdi-clipboard-arrow-down</v-icon>
              </div>
              <div>
                <div>Pending returns</div>
                <div style="font-size: 14px">This list contains hardware that is expected to be returned to an ABAX office</div>
              </div>
            </v-toolbar-title>
            <v-spacer></v-spacer>
            <v-menu offset-y :close-on-content-click="false">
              <template v-slot:activator="{ on }">
                <v-icon class="filter-icon" :color="filterFinished ? 'marked' : ''" v-on="on">
                  mdi-filter
                </v-icon>
              </template>
              <v-list>
                <v-list-item>
                  <v-list-item-title>
                    <v-checkbox class="ml-2" dense label="Hide finished processes" v-model="filterFinished"></v-checkbox>
                  </v-list-item-title>
                </v-list-item>
              </v-list>
            </v-menu>
            <v-text-field v-model="search" append-icon="mdi-magnify" label="Search" single-line hide-details tabindex="0" ref="searchInput"></v-text-field>
          </v-toolbar>
        </template>
      </v-data-table>
    </v-sheet>

    <v-dialog v-model="processDialog" max-width="900px">
      <v-card :loading="processDialogLoading"  class="pb-0 pt-0 mb-0 mt-0">
        <v-card-text>
          <v-row>
            <v-col sm="12" md="12">
              <v-list>
                <v-list-item three-line>
                  <v-list-item-content>
                    <v-list-item-title class="headline">
                      <span>Return process info</span>
                    </v-list-item-title>
                    <v-list-item-subtitle>
                      {{processDialogItem.serialNumber}}
                    </v-list-item-subtitle>
                  </v-list-item-content>
                </v-list-item>
              </v-list>
              <v-card elevation="0" justify="center">
                <v-row justify="center" >
                  <v-col md="12" @click="infoExpanded = !infoExpanded" class="clickable pb-0 pt-0 mb-0 mt-0">
                    <v-alert v-if="processDialogItem.currentState === 'Registered'" type="info" color="secondary" class="py-2 mx-2" icon="mdi-information-outline">
                      <div>Current state: <b>{{processDialogItem.currentState}}</b></div>
                      <div v-if="infoExpanded">The <b>Registered</b> state is when we have received notification of a terminated subscription and we expect the unit to be returned from the customer</div>
                    </v-alert>
                    <v-alert v-if="processDialogItem.currentState === 'ReturnRequestSent'" type="info" color="secondary" class="py-2 mx-2" icon="mdi-information-outline">
                      <div>Current state: <b>{{processDialogItem.currentState}}</b></div>
                      <div v-if="infoExpanded">The <b>ReturnRequestSent</b> state is when we have sent the first notification to the customer telling them that they have to return their unit or they will be invoiced</div>
                    </v-alert>
                    <v-alert v-if="processDialogItem.currentState === 'ReminderSent'" type="info" color="secondary" class="py-2 mx-2" icon="mdi-information-outline">
                      <div>Current state: <b>{{processDialogItem.currentState}}</b></div>
                      <div v-if="infoExpanded">The <b>ReminderSent</b> state is when we have sent the <b>second</b> notification to the customer telling them that they have to return their unit or they will be invoiced</div>
                    </v-alert>
                    <v-alert v-if="processDialogItem.currentState === 'ShouldInvoiceOldUnitIfNotReturned'" type="info" color="primary" class="py-2 mx-2" icon="mdi-information-outline">
                      <div>Current state: <b>{{processDialogItem.currentState}}</b></div>
                      <div v-if="infoExpanded">The <b>ShouldInvoiceOldUnitIfNotReturned</b> state is when customer service has ordered a swap in Backstage. ABAX is sending the customer a replacement unit, the customer owns the unit, but the fault is with ABAX. The customer will be invoiced if they don't return their old unit </div>
                    </v-alert>
                    <v-alert v-if="processDialogItem.currentState === 'ShouldBeAbortedImmediately'" type="info" color="warning" class="py-2 mx-2" icon="mdi-information-outline">
                      <div>Current state: <b>{{processDialogItem.currentState}}</b></div>
                      <div v-if="infoExpanded">The <b>ShouldBeAbortedImmediately</b> state is when we know that this unit will be replaced at a future point, without invoking a return process. Processes in this state should <b>not</b> be deleted, as they will automatically be finalized correctly when the termination message is received.</div>
                    </v-alert>
                    <v-alert v-if="processDialogItem.currentState === 'ShouldInvoiceNewUnitImmediately'" type="info" color="info" class="py-2 mx-2" icon="mdi-information-outline">
                      <div>Current state: <b>{{processDialogItem.currentState}}</b></div>
                      <div v-if="infoExpanded">The <b>ShouldInvoiceNewUnitImmediately</b> state is when it is known that return of the unit is impossible, so reminder steps should be skipped, and invoice sent immediately</div>
                    </v-alert>
                    <v-alert v-if="processDialogItem.currentState === 'Final'" type="info" color="primary" class="py-2 mx-2" icon="mdi-information-outline">
                      <div>Current state: <b>{{processDialogItem.currentState}}</b></div>
                      <div v-if="infoExpanded">The <b>Final</b> state is when we have either invoiced the customer, the unit has been returned or the request is cancelled. This process is finished.</div>
                    </v-alert>
                  </v-col>
                </v-row>
              </v-card>
            </v-col>
            <v-col sm="12" md="7" class="pb-0 pt-0 mb-0 mt-0">
              <v-card elevation="0" class="">
                <v-card-title>Events</v-card-title>
                <div class="pl-4 pr-4">
                  <table>
                    <thead>
                    <tr>
                      <td><b>Date</b></td>
                      <td><b>Event type</b></td>
                    </tr>
                    </thead>
                    <tbody>
                    <tr v-for="(event, index) in processDialogItem.events" :key="index" class="py-4">
                      <td class="pr-4 py-1">{{ event.timeStamp | ntzDatetime }}</td>
                      <td>{{ event.event }}</td>
                    </tr>
                    </tbody>
                  </table>
                </div>
              </v-card>
            </v-col>
            <v-col sm="12" md="5" class="pb-0 pt-0 mb-0 mt-0">
              <v-card elevation="0">
                <v-card-title>Actions</v-card-title>
                <v-row v-if="processDialogItem.currentState === 'Final'" class="pb-4 pl-2">
                  <div class="ma-4">
                    <div>No actions available</div>
                    <div>Process is already in Final state</div>
                  </div>
                </v-row>
                <v-row v-if="processDialogItem.currentState !== 'Final'" class="pb-4 pl-2">
                  <v-btn class="ma-4" color="error" @click="deleteReturnProcessAction(processDialogItem)" :disabled="processDialogLoading"><span>Delete return process</span><v-icon class="ml-4">mdi-delete-variant</v-icon></v-btn>
                  <v-btn class="ma-4" color="success" @click="straightToInvoiceAction(processDialogItem)" :disabled="processDialogLoading"><span class="pr-7">Straight to invoice</span><v-icon class="ml-4">mdi-cash-register</v-icon></v-btn>
                  <v-btn class="ma-4" color="secondary" @click="hardwareReturnedAction(processDialogItem)" :disabled="processDialogLoading"><span class="pr-7">Hardware returned</span><v-icon class="ml-4">mdi-handball</v-icon></v-btn>
                </v-row>
              </v-card>
            </v-col>
          </v-row>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="primary" text @click="closeProcessDialog">Close</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <ConfirmDialog ref="confirm"></ConfirmDialog>
  </v-card>
</template>

<script>
import ConfirmDialog from "@/components/widgets/dialogs/ConfirmDialog"
import axios from "@/axios-client"

export default {
  name: "PendingReturns",
  components: {
    ConfirmDialog
  },
  data(){
    return {
      search: '',
      singleSelect: false,
      loading: false,
      processes:[],
      headersProcesses: [
        { text: 'Customer', value: 'name' },
        { text: 'ERP ClientId', value: 'clientId' },
        { text: 'ERP CustomerId', value: 'customerId' },
        { text: 'SerialNumber', value: 'serialNumber' },
        { text: 'Current State', value: 'currentState' },
        { text: 'Return initiated', value: 'registeredDate' },
      ],
      processDialog: false,
      processDialogItem: {},
      processDialogLoading: false,
      filterFinished: true,
      infoExpanded: false
    }
  },
  async mounted() {
    await this.getProcesses()
  },
  methods: {
    customFilter(value, search, item) {
      search = search.toString().toLowerCase();

      // Search for serialNumbers
      if(item?.processes?.length > 0 && item.processes.some(x => x.serialNumber.toLowerCase().includes(search))) return true

      // Search for all other stuff
      return Object.keys(item).some(propName => {
        if(item.departmentPath[0]?.name.toLowerCase().includes(search)) return true;

        return item[propName]
          ?.toString()
          .toLowerCase()
          .includes(search);
      });
    },
    async processClick(process) {
      this.processDialogItem = process
      this.processDialog = true
      this.processDialogLoading = true

      // Dialog is initialized with the item from the list, for speed, then we get the latest version in the background
      try {
        let res = await axios.get(`/api/return-handling/returnProcess/${process.correlationId}`)
        this.processDialogItem = res.data
        process.currentState = this.processDialogItem.currentState // Updating list item with the latest version
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to fetch current version of process`, type: 'warning'})
      }
      this.processDialogLoading = false
    },
    closeProcessDialog(){
      this.processDialog = false
      this.processDialogItem = {}
    },
    async deleteReturnProcessAction(process) {
      let confirmed = await this.$refs.confirm.open('Deleting return process', `Are you sure you want to delete the return process for unit: <b>${process.serialNumber}</b>? (This will cost us money)`, {width: 700, preformatted: true, html: true})
      if (!confirmed) return

      this.processDialogLoading = true
      try {
        await axios.delete(`/api/return-handling/returnProcess/${process.correlationId}`)
        process.currentState = 'Final'
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Action failed`, type: 'error'});
        this.processDialogLoading = false
        return
      }
      this.processDialogLoading = false
      this.closeProcessDialog()
    },
    async straightToInvoiceAction(process) {
      let confirmed = await this.$refs.confirm.open('Deleting package', `Are you sure you want to send return process for <b>${process.serialNumber}</b> straight to invoice?`, {width: 700, preformatted: true, html: true})
      if (!confirmed) return

      this.processDialogLoading = true
      try {
        await axios.put(`/api/return-handling/returnProcess/invoiceNow/${process.correlationId}`)
        process.currentState = 'Final'
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Action failed`, type: 'error'});
        this.processDialogLoading = false
        return
      }
      this.processDialogLoading = false
      this.closeProcessDialog()
    },
    async hardwareReturnedAction(process) {
      let confirmed = await this.$refs.confirm.open('Deleting package', `Are you sure the serial number returned is in fact: <b>${process.serialNumber}</b>?`, {width: 700, preformatted: true, html: true})
      if (!confirmed) return

      this.processDialogLoading = true
      try {
        await axios.put(`/api/return-handling/returnProcess/hardwareReturned/${process.correlationId}`)
        process.currentState = 'Final'
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Action failed`, type: 'error'});
        this.processDialogLoading = false
        return
      }
      this.processDialogLoading = false
      this.closeProcessDialog()
    },
    async getProcesses() {
      this.loading = true
      try {
        let res = await axios.get(`/api/return-handling/returnProcess/list`)
        this.processes = res.data;
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to fetch return process list`, type: 'error'});
      }
      this.loading = false
    },
    openCustomer(aktorId){
      this.$router.push({path: `/customer/${aktorId}`});
    },
  },
  computed:{
    roles() {
      return this.$store.state.currentUserRoles;
    },
    processesView(){
      if(this.filterFinished){
        return this.processes.filter(item => item.currentState !== 'Final')
      }
      return this.processes
    }
  }
}
</script>

<style scoped>
.row-pointer >>> tbody tr :hover {
  cursor: pointer;
}
.clickable:hover {
  cursor: pointer;
}
</style>
