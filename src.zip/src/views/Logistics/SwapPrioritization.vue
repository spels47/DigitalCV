<template>
  <v-card class="pr-10 pl-10 pb-10">
    <v-card-title>Swap hardware priority</v-card-title>
    <div class="d-flex flex-row justify-space-around">
      <v-card width="500" v-for="prioritization in prioritizations" :key="prioritization.countryCode" :loading="loading || countryLoading(prioritization.countryCode)" elevation="5" outlined>
        <v-card-title>{{prioritization.countryCode}}</v-card-title>
        <v-card-subtitle>Prioritized unit type from the {{country(prioritization.countryCode)}} stock</v-card-subtitle>
        <v-card-text>
          <v-select v-model="prioritization.unitType" bottom :hint="prioritization.itemNumber ? 'Item Number: ' + prioritization.itemNumber : ''" :persistent-hint="true" @change="changeItemNumber($event, prioritization.countryCode)" :loading="loading || countryLoading(prioritization.countryCode)" clearable prepend-icon="mdi-balloon" :items="optionsForCountry(prioritization.countryCode)" placeholder="No specific priority" label="No specific priority" solo></v-select>
        </v-card-text>
        <v-card-actions>
          <v-btn width="150px" class="mb-1 ml-2" color="secondary" @click="updateSwapPrioritization(prioritization.countryCode, prioritization.unitType)">
            Set priority
          </v-btn>
        </v-card-actions>
      </v-card>
    </div>
  </v-card>
</template>

<script>
import axios from '~/axios-client';
export default {
  name: "SwapPrioritization",
  components: {},
  data() {
    return {
      prioritizations: [],
      priorityOptions: [],
      prioritizationsLoading: false,
      priorityOptionsLoading: false,
      norwayLoading: false,
      ukLoading: false,
      netherlandsLoading: false
    }
  },
  methods: {
    async getSwapPrioritizations() {
      this.prioritizationsLoading = true;
      var result = await axios.get(`api/swap/prioritization`);
      this.prioritizations = result.data;
      this.prioritizationsLoading = false;
    },
    async getSwapPriorityForCountry(countryCode) {
      this.setCountryLoading(countryCode, true);
      var result = await axios.get(`api/swap/prioritization/${countryCode}`);
      this.prioritizations[this.prioritizations.indexOf(this.prioritizations.find(priority => priority.countryCode == countryCode))] = result.data;
      this.setCountryLoading(countryCode, false);
    },
    async updateSwapPrioritization(countryCode, unitType){
      this.setCountryLoading(countryCode, true);
      if(!unitType) await axios.post(`api/swap/prioritization/${countryCode}`)
      else await axios.post(`api/swap/prioritization/${countryCode}/${unitType}`)
      this.setCountryLoading(countryCode, false);
      await this.getSwapPriorityForCountry(countryCode);
    },
    async getPriorityOptions(){
      this.priorityOptionsLoading = true;
      var result = await axios.get(`api/swap/prioritization/hardware`)
      this.priorityOptions = result.data;
      this.priorityOptionsLoading = false;
    },
    country(countryCode){
      if(countryCode == 'NO') return 'Norwegian';
      else if(countryCode == 'UK') return 'English'
      else if(countryCode == 'NL') return 'Netherlands'
    },
    optionsForCountry(countryCode){
      var items = this.priorityOptions.find(item => item.countryCode == countryCode)?.hardwareChoices;
      if(items == null) return;
      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        item.text = this.optionText(item.itemName) + ' | ' + item.available + ' units';
        item.value = item.itemName;
      }
      return items;
    },
    changeItemNumber(event, countryCode){
      var currentIndex = this.prioritizations.indexOf(this.prioritizations.find(item => item.countryCode == countryCode));
      if(!event){
        this.prioritizations[currentIndex].itemNumber = null;
        return;
      }
      var itemNumber = this.optionsForCountry(countryCode).find(item => item.value == event).itemNumber;
      this.prioritizations[currentIndex].itemNumber = itemNumber;
    },
    optionText(text){
      return text.replaceAll('_',' ').trim();
    },
    countryLoading(countryCode){
      if(countryCode == "NO") return this.norwayLoading;
      else if(countryCode == "UK") return this.ukLoading;
      else if(countryCode == "NL") return this.netherlandsLoading;
    },
    setCountryLoading(countryCode, state){
      if(countryCode == "NO") this.norwayLoading = state;
      else if(countryCode == "UK") this.ukLoading = state;
      else if(countryCode == "NL") this.netherlandsLoading = state;
    }
  },
  async mounted() {
    await this.getSwapPrioritizations();
    await this.getPriorityOptions();
  },
  computed:{
    roles() {
      return this.$store.state.currentUserRoles;
    },
    loading() {
      return this.prioritizationsLoading || this.priorityOptionsLoading;
    }
  },
}
</script>

<style scoped>

</style>
