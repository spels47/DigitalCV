<template>
  <v-card>
    <v-card-title>
      <span>Geofence import</span>
    </v-card-title>
    <v-card-subtitle>
      <div class="description">
        <div>Import geofences from an Excel or CSV file.</div>
      </div>
    </v-card-subtitle>
    <v-divider></v-divider>
    <v-card elevation="2" class="ma-4">
      <v-card-text>
        <v-form ref="form">
          <v-row>
            <v-col>
              <v-autocomplete
                v-model="input.tenantId"
                :rules="[validateId]"
                :items="input.tenants"
                :search-input.sync="input.tenantsSearch"
                :loading="input.isTenantsLoading"
                item-value="id"
                item-text="name"
                :readonly="inputLoad.completed"
                :disabled="inputLoad.completed"
                label="Tenant">
                <template v-slot:item="data">
                  <v-row>
                    <v-col cols="10">{{data.item.name}}</v-col>
                    <v-col cols="2">{{data.item.id}}</v-col>
                  </v-row>
                </template>
              </v-autocomplete>
            </v-col>
            <v-col>
              <v-autocomplete
                v-model="input.departmentId"
                :rules="[validateId]"
                :items="input.departments"
                :search-input.sync="input.departmentsSearch"
                :loading="input.isDepartmentsLoading"
                item-value="id"
                item-text="name"
                :readonly="inputLoad.completed"
                :disabled="inputLoad.completed"
                label="Department">
                <template v-slot:item="data">
                  <v-row>
                    <v-col cols="10"><v-chip x-small class="mr-2">{{data.item.level-3}}</v-chip>{{data.item.name}}</v-col>
                    <v-col cols="2">{{data.item.id}}</v-col>
                  </v-row>
                </template>
              </v-autocomplete>
            </v-col>
            <v-col>
              <v-autocomplete
                v-model="input.userId"
                :rules="[validateId]"
                :items="input.users"
                :search-input.sync="input.usersSearch"
                :loading="input.isUsersLoading"
                item-value="id"
                item-text="name"
                :readonly="inputLoad.completed"
                :disabled="inputLoad.completed"
                label="User">
                <template v-slot:item="data">
                  <v-row>
                    <v-col cols="10">{{data.item.name}}</v-col>
                    <v-col cols="2">{{data.item.id}}</v-col>
                  </v-row>
                </template>
              </v-autocomplete>
            </v-col>
          </v-row>
          <v-select v-model="input.textFormat" :readonly="inputLoad.completed" :disabled="inputLoad.completed" label="Geofence shape specification" :items="textFormats"></v-select>
          <template v-if="!inputLoad.completed && selectedTextFormat">
            <v-card class="highlight" :class="{ darkMode: darkMode }">
              <v-card-title class="d-flex justify-space-between">
                <span><v-icon class="mr-2">mdi-information-outline</v-icon>Input format</span>
                <v-btn icon @click="input.textFormatInfoExpanded = !input.textFormatInfoExpanded"><v-icon>{{input.textFormatInfoExpanded ? "mdi-chevron-up" : "mdi-chevron-down"}}</v-icon></v-btn>
              </v-card-title>
              <v-card-text v-if="input.textFormatInfoExpanded">
                Lines should have these TAB-separated fields: <code v-html="selectedTextFormat.fieldsDescription"></code>
              </v-card-text>
              <v-card-actions v-if="input.textFormatInfoExpanded">
                <v-btn small :href="selectedTextFormat.sampleFile">Example Excel sheet</v-btn>
              </v-card-actions>
            </v-card>
          </template>
          <v-textarea v-model="input.text" v-if="!inputLoad.started && !inputLoad.completed" label="Paste into this text area 🙂" :rules="[validateText]"></v-textarea>
          <v-data-table
            v-else
            dense
            :headers="headers"
            :items="items"
            :loading="isInProgress"
            hide-default-footer>
            <template v-slot:top>
              <span class="summary">Processed {{items.length}} lines</span>
              <v-chip
                v-for="x in legend"
                :key="x.class"
                :class="x.class"
                class="ml-2"
                small>
                {{x.text}} ({{x.count}})
              </v-chip>
            </template>
            <template v-slot:progress>
              <v-progress-linear :value="currentProgress"></v-progress-linear>
            </template>
            <template v-slot:body>
              <tbody>
                <tr v-for="(item, index) in items"
                  :key="index"
                  :class="itemStatus(item)">
                  <td>{{item.lineNr}}</td>
                  <template v-if="item.geofence">
                    <td>{{item.geofence.Name}}</td>
                    <td>{{item.geofence.Purpose}}</td>
                    <td>{{item.geofence.AddressOverride}}</td>
                    <td>{{item.geofence.Polygon.length - 1}}</td>
                    <td>{{item.geofence.Id}}</td>
                    <td>
                      <template v-if="item.importError">
                        {{item.importError}}
                        <v-btn @click="retryImport(index)" :disabled="isInProgress" x-small class="ml-2">Retry</v-btn>
                      </template>
                    </td>
                  </template>
                  <template v-else-if="item.ignore">
                    <td colspan="6">{{item.ignore}}</td>
                  </template>
                  <template v-else>
                    <td colspan="6">{{item.error}}</td>
                  </template>
                </tr>
              </tbody>
            </template>
          </v-data-table>
        </v-form>
      </v-card-text>
      <v-card-actions>
        <v-btn v-if="!inputLoad.completed" @click="parseInput()" id="btn-convert">Show on map</v-btn>
        <template v-else>
          <v-btn @click="clear()" id="btn-clear">Clear</v-btn>
          <v-btn v-if="geofences.length > 0 && !importCompleted" @click="importGeofences()" id="btn-import">Import geofences</v-btn>
        </template>
      </v-card-actions>
    </v-card>
    <v-card elevation="2" class="map-card ma-0">
      <MapWithGeofences :geofences="geofences"></MapWithGeofences>
    </v-card>
  </v-card>
</template>

<script>
import axios from "@/axios-client";
import qs from "qs";
import debounce from "lodash/debounce";
import mapboxgl from "mapbox-gl/dist/mapbox-gl.js";
import MapWithGeofences from "@/components/map/MapWithGeofences";

export default {
  name: "GeofenceImport",
  components: { MapWithGeofences },
  data() {
    return {
      headers: [
        { text: 'Line #', sortable: false },
        { text: 'Geofence name', sortable: false },
        { text: 'Purpose', sortable: false },
        { text: 'Address override', sortable: false },
        { text: 'Polygon points #', sortable: false },
        { text: 'Imported geofence id', sortable: false },
        { text: 'Errors', sortable: false }
      ],
      legendAll: [
        { class: 'ready', text: 'Ready for import' },
        { class: 'ignore', text: 'Ignored' },
        { class: 'error', text: 'Invalid line' },
        { class: 'imported', text: 'Imported successfully' },
        { class: 'importError', text: 'Import failed' }
      ],
      textFormats: [
        {
          value: "CENTER",
          text: "Rectangle (center lat/lon and dimensions in meters)",
          fieldsDescription: "Geofence name, Purpose, Address override, Center latitude, Center longitude, Meters south-to-north, Meters west-to-east",
          headerRow: "Geofence name,Purpose,Address override,Center latitude,Center longitude,Meters south-to-north,Meters west-to-east",
          sampleFile: "/files/geofence_import_example_1.xlsx"
        },
        {
          value: "MINMAX",
          text: "Rectangle (min and max lat/lon)",
          fieldsDescription: "Geofence name, Purpose, Address override, Min latitude, Max latitude, Min longitude, Max longitude",
          headerRow: "Geofence name,Purpose,Address override,Min latitude,Max latitude,Min longitude,Max longitude",
          sampleFile: "/files/geofence_import_example_2.xlsx"
        },
        {
          value: "POLYGON",
          text: "Any polygon (series of lat/lon points)",
          fieldsDescription: "Geofence name, Purpose, Address override, Latitude 1, Longitude 1, Latitude 2, Longitude 2, Latitude 3, Longitude 3, <i>...(more lat/lon pairs)...</i>",
          headerRow: "Geofence name,Purpose,Address override,Latitude 1,Longitude 1,Latitude 2,Longitude 2,Latitude 3,Longitude 3",
          sampleFile: "/files/geofence_import_example_3.xlsx"
        }
      ],
      input: {
        tenantsSearch: "",
        isTenantsLoading: false,
        tenants: [],
        tenantId: "",

        departmentsSearch: "",
        isDepartmentsLoading: false,
        departments: [],
        departmentId: "",

        userSearch: "",
        isUsersLoading: false,
        users: [],
        userId: "",

        textFormat: "MINMAX",
        textFormatInfoExpanded: true,
        text: ""
      },
      inputLoad: {
        started: false,
        completed: false
      },
      importCompleted: false,
      items: [],
      currentProgress: 0,

      loadTenants: debounce(async () => {
        if (this.input.isTenantsLoading) {
          this.loadTenants.cancel();
          this.input.isTenantsLoading = false;
        }
        if (!this.input.tenantsSearch || this.input.tenantsSearch.trim() === "") return;
        this.input.isTenantsLoading = true;
        await axios.get(`/api/geofence/tenants?${qs.stringify({ "searchQuery": this.input.tenantsSearch.trim()})}`)
          .then(x => this.input.tenants = x.data)
          .catch(() => this.input.tenants = [])
          .finally(() => this.input.isTenantsLoading = false);
      }, 200),
      loadDepartments: debounce(async () => {
        if (this.input.isDepartmentsLoading) this.loadDepartments.cancel();
        this.input.isDepartmentsLoading = true;
        await axios.get(`/api/geofence/departments?${qs.stringify({ "tenantId": this.input.tenantId})}`)
          .then(x => this.input.departments = x.data)
          .catch(() => this.input.departments = [])
          .finally(() => this.input.isDepartmentsLoading = false);
      }, 200),
      loadUsers: debounce(async () => {
        if (this.input.isUsersLoading) this.loadUsers.cancel();
        this.input.isUsersLoading = true;
        await axios.get(`/api/geofence/users?${qs.stringify({ "tenantId": this.input.tenantId})}`)
          .then(x => this.input.users = x.data)
          .catch(() => this.input.users = [])
          .finally(() => this.input.isUsersLoading = false);
      }, 200)
    }
  },
  computed: {
    selectedTextFormat() {
      return this.textFormats.find(tf => tf.value == this.input.textFormat);
    },
    darkMode() {
      return this.$store.getters.darkMode;
    },
    geofences() {
      return this.items.filter(item => item.geofence).map(item => item.geofence);
    },
    isInProgress() {
      return this.currentProgress > 0 && this.currentProgress < 100;
    },
    legend() {
      const statuses = {};
      this.items.forEach(item => {
        const itemStatus = this.itemStatus(item);
        if (statuses.hasOwnProperty(itemStatus))
          statuses[itemStatus]++;
        else
          statuses[itemStatus] = 1;
      });
      return this.legendAll.filter(x => statuses.hasOwnProperty(x.class)).map(x => { return {
        ...x,
        count: statuses[x.class]
      }});
    }
  },
  watch: {
    async "input.tenantsSearch"() {
      this.loadTenants();
    },
    "input.tenantId"(newValue, oldValue) {
      if (newValue === oldValue) return;
      this.input.departmentId = "";
      this.input.departments = [];
      this.input.userId = "";
      this.input.users = [];
      this.loadDepartments();
      this.loadUsers();
    }
  },
  methods: {
    validateId(value) {
      const id = (typeof value === "number") ? value : this.stringtoUInt(value);
      return !Number.isNaN(id) && Number.isInteger(id) && id > 0;
    },
    validateText(value) {
      return value.trim().length > 0;
    },
    clear() {
      this.items = [];
      this.inputLoad.started = false;
      this.inputLoad.completed = false;
      this.importCompleted = false;
      this.currentProgress = 0;
    },
    parseInput() {
      if (!this.$refs.form.validate()) return;
      this.clear();
      this.inputLoad.started = true;
      const lines = this.input.text.split('\n');
      let currentLine = 0;
      lines.forEach(line => {
        currentLine++;
        const lineTrimmed = line.trim();
        if (lineTrimmed === "") {
          this.items.push({ lineNr: currentLine, line: line, ignore: "Empty line" });
        } else {
          const lineSplit = lineTrimmed.split('\t');
          const { geofence, error, ignore } = this.parseLine(lineSplit);
          if (geofence)
            this.items.push({ lineNr: currentLine, line: line, geofence });
          else if (ignore)
            this.items.push({ lineNr: currentLine, line: line, ignore });
          else
            this.items.push({ lineNr: currentLine, line: line, error: `${error} (line: ${lineSplit})` });
        }
        this.currentProgress = Math.ceil(currentLine / lines.length * 100);
      });

      this.inputLoad.completed = true;
      this.inputLoad.started = false;
      
      if (this.geofences.length === 0) {
        this.$eventBus.$emit('alert', { text: `Found no geofences to process`, type: 'warning'});
      }
    },
    parseLine(fields) {
      switch (this.input.textFormat) {
        case 'CENTER':
          return this.parseCenter(fields);
        case 'MINMAX':
          return this.parseMinMax(fields);
        case 'POLYGON':
          return this.parsePolygon(fields);
        default:
          return { error: `Unsupported input format: ${this.input.textFormat}` };
      }
    },
    parseCenter(fields) {
      if (fields.length !== 7)
        return { error: `Expected 7 fields, but found ${fields.length}` };
      if (`${fields}`.toLowerCase() === this.selectedTextFormat.headerRow.toLowerCase())
        return { ignore: "Header" };
      
      const centerLat = this.stringToLatitude(fields[3]);
      const centerLng = this.stringToLatitude(fields[4]);
      const sizeSN = this.stringtoUInt(fields[5]);
      const sizeWE = this.stringtoUInt(fields[6]);
      const error = centerLat.error || centerLng.error || sizeSN.error || sizeWE.error;
      if (error)
        return { error: error };
      if (sizeSN < 25 || sizeWE < 25)
        return { error: `Geofence dimensions must be at least 25m x 25m` };
      
      const center = { lat: centerLat, lng: centerLng };
      const coords = [
        this.shiftCoord(center, -sizeSN / 2, -sizeWE / 2),
        this.shiftCoord(center, sizeSN / 2, -sizeWE / 2),
        this.shiftCoord(center, sizeSN / 2, sizeWE / 2),
        this.shiftCoord(center, -sizeSN / 2, sizeWE / 2)
      ];
      coords.push(coords[0]);
      
      return { geofence: {
        TenantId: this.input.tenantId,
        DepartmentId: this.input.departmentId,
        UserId: this.input.userId,
        Name: fields[0],
        Purpose: fields[1],
        AddressOverride: fields[2],
        Polygon: coords
      }};
    },
    parseMinMax(fields) {
      if (fields.length !== 7)
        return { error: `Expected 7 fields, but found ${fields.length}` };
      if (`${fields}`.toLowerCase() === this.selectedTextFormat.headerRow.toLowerCase())
        return { ignore: "Header" };
      
      const minLat = this.stringToLatitude(fields[3]);
      const maxLat = this.stringToLatitude(fields[4]);
      const minLng = this.stringToLongitude(fields[5]);
      const maxLng = this.stringToLongitude(fields[6]);
      const coordError = minLat.error || maxLat.error || minLng.error || maxLng.error;
      if (coordError)
        return { error: coordError };
      if (minLat >= maxLat)
        return { error: `Min latitude must be smaller than max latitude` };
      if (minLng >= maxLng)
        return { error: `Min longitude must be smaller than max longitude` };
      
      return { geofence: {
        TenantId: this.input.tenantId,
        DepartmentId: this.input.departmentId,
        UserId: this.input.userId,
        Name: fields[0],
        Purpose: fields[1],
        AddressOverride: fields[2],
        Polygon: [
          { lat: minLat, lng: minLng },
          { lat: maxLat, lng: minLng },
          { lat: maxLat, lng: maxLng },
          { lat: minLat, lng: maxLng },
          { lat: minLat, lng: minLng }
        ]
      }};
    },
    parsePolygon(fields) {
      if (fields.length < 9)
        return { error: `Expected at least 9 fields, but found ${fields.length}` };
      if ((fields.length - 3) % 2 !== 0)
        return { error: "Expected fields that represent (lat, lon) pairs" };
      if (`${fields}`.toLowerCase().startsWith(this.selectedTextFormat.headerRow.toLowerCase()))
        return { ignore: "Header" };
      
      const coords = [];
      let previousCoord = null;
      let currentCoord = null;
      for (var i = 3; i < fields.length - 1; i += 2) {
        const lat = this.stringToLatitude(fields[i]);
        const lng = this.stringToLongitude(fields[i + 1]);
        const coordError = lat.error || lng.error;
        if (coordError)
          return { error: coordError };
        currentCoord = { lat, lng };
        if (!this.equalCoords(currentCoord, previousCoord))
          coords.push(currentCoord);
        previousCoord = currentCoord;
      }
      const firstCoord = coords[0];
      const lastCoord = coords[coords.length - 1];
      if (!this.equalCoords(firstCoord, lastCoord))
        coords.push(firstCoord);

      return { geofence: {
        TenantId: this.input.tenantId,
        DepartmentId: this.input.departmentId,
        UserId: this.input.userId,
        Name: fields[0],
        Purpose: fields[1],
        AddressOverride: fields[2],
        Polygon: coords
      }};
    },
    equalCoords(coord1, coord2) {
      if (!coord1 || !coord2)
        return !coord1 && !coord2;
      else
        return coord1.lat === coord2.lat && coord1.lng === coord2.lng;
    },
    shiftCoord(center, distanceSN, distanceWE) {
      const c = mapboxgl.MercatorCoordinate.fromLngLat(center);
      const s = new mapboxgl.MercatorCoordinate(c.x + c.meterInMercatorCoordinateUnits() * distanceWE, c.y + c.meterInMercatorCoordinateUnits() * distanceSN);
      return s.toLngLat();
    },
    stringtoUInt(str) {
      const num = Number.parseInt(str);
      return !Number.isNaN(num) && /^[0-9]*$/.test(`${str}`.trim()) ? num : { error: `Invalid unsigned integer: ${str}` };
    },
    stringToFloat(str) {
      const str2 = str.replace(',', '.').trim();
      const num = Number.parseFloat(str2);
      return !Number.isNaN(num) && /^[-0-9.]*$/.test(`${str2}`) ? num : { error: `Invalid number: ${str}` };
    },
    stringToLatitude(str) {
      const num = this.stringToFloat(str);
      if (num.error)
        return num;
      if (num < -90 || num > 90)
        return { error: `Latitude must be between -90 and 90, but was ${num}` };
      return num;
    },
    stringToLongitude(str) {
      const num = this.stringToFloat(str);
      if (num.error)
        return num;
      if (num < -180 || num > 180)
        return { error: `Longitude must be between -180 and 180, but was ${num}` };
      return num;
    },
    async importGeofence(geofence) {
      try {
        const res = await axios.post(`/api/geofence/import`, geofence);
        //await this.$store.dispatch("audit", { source: "GeofenceImport", entityId: res.data.geofenceId, message: "GeofenceCreated from import" });
        if (res.data.success)
          return { geofenceId: res.data.geofenceId };
        else
          return { geofenceId: res.data.geofenceId, error: res.data.message || "Unknown error occurred" };
      } catch (ex) {
        return { error: ex };
      }
    },
    async importGeofences() {
      this.importCompleted = false;
      this.currentProgress = 0;

      for (let i = 0; i < this.items.length; i++) {
        const item = this.items[i];
        const itemStatus = this.itemStatus(item);
        if (itemStatus === 'ready') {
          const importResult = await this.importGeofence(item.geofence);
          if (importResult.geofenceId)
            item.geofence.Id = importResult.geofenceId;
          if (importResult.success)
            delete item.importError;
          else
            item.importError = importResult.error;
        }
        this.currentProgress = Math.ceil((i + 1) / this.geofences.length * 100);
      }

      this.forceTableUpdate();
      this.importCompleted = true;
      this.$eventBus.$emit('alert', { text: 'Finished! ✔', icon: 'mdi-information', type: 'success' });
    },
    async retryImport(index) {
      const item = this.items[index];
      const itemStatus = this.itemStatus(item);
      if (itemStatus === 'importError') {
        this.currentProgress = 50;
        const importResult = await this.importGeofence(item.geofence);
        if (importResult.geofenceId)
          item.geofence.Id = importResult.geofenceId;
        if (importResult.success)
          delete item.importError;
        else
          item.importError = importResult.error;
        this.currentProgress = 100;
        this.forceTableUpdate();
      }
    },
    forceTableUpdate() {
      this.items = this.items.filter(item => true); // stupid hack to force table refresh - it sometimes fails to update last 1-2 changed rows
    },
    itemStatus(item) {
      if (item.ignore)
        return 'ignore';
      else if (item.error)
        return 'error';
      else if (item.importError)
        return 'importError';
      else if (item.geofence && item.geofence.Id)
        return 'imported';
      else if (item.geofence && !item.geofence.Id)
        return 'ready';
      else
        return '';
    }
  }
};
</script>

<style lang="scss" scoped>
@use "sass:map";

.v-textarea {
  font-family: monospace;
  font-size: medium;
}
.v-data-table {
  .summary {
    vertical-align: middle;
  }

  $status-colors: (
    "ready": white,
    "ignore": khaki,
    "error": lightcoral,
    "imported": lightgreen,
    "importError": red
  );
  
  @mixin row-status($status) {
    tr.#{$status} {
      background-color: map.get($status-colors, $status) !important;
      &:hover {
        background-color: darken(map.get($status-colors, $status), 6%) !important;
      }
    }
  }

  @include row-status('ignore');
  @include row-status('error');
  @include row-status('imported');
  @include row-status('importError');

  @mixin chip-status($status) {
    .v-chip.#{$status} {
      background-color: map.get($status-colors, $status) !important;
    }
  }

  .v-chip {
    color: rgba(0, 0, 0, 0.87);
    &.ready {
      border: 1px solid rgba(0, 0, 0, 0.87);
      &:hover {
        border-color: rgba(0, 0, 0, 0.0);
      }
    }
  }

  @include chip-status('ready');
  @include chip-status('ignore');
  @include chip-status('error');
  @include chip-status('imported');
  @include chip-status('importError');
}
</style>