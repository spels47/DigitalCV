<template>
  <v-card>
    <v-sheet elevation="0">
      <v-data-table
        :footer-props="{'items-per-page-options':[100, -1]}"
        :headers="headersPackages"
        :items="packages"
        class="elevation-1"
        :loading="loadingPackages"
        loading-text="Loading list of packages... "
        :search="search"
      >
        <template v-slot:item.actions="{ item }">
          <v-btn class="mx-2" fab dark x-small color="primary" @click="packageRowClick(item)">
            <v-icon dark>mdi-pencil</v-icon>
          </v-btn>
          <v-btn class="mx-2" fab dark x-small color="primary" @click="deletePackage(item.id)">
            <v-icon dark color="red">mdi-delete</v-icon>
          </v-btn>
        </template>
        <template v-slot:top>
          <v-toolbar flat>
            <v-toolbar-title>Packages</v-toolbar-title>
            <v-spacer></v-spacer>
            <v-text-field v-model="search" append-icon="mdi-magnify" label="Search" single-line hide-details></v-text-field>
            <v-spacer></v-spacer>
            <v-dialog v-model="dialogPackages" max-width="80%">
              <template v-slot:activator="{ on, attrs }">
                <v-btn color="primary" dark class="mb-2" @click="packageNewItemClick()">New Item</v-btn>
              </template>
              <v-card>
                <v-card-title><span class="text-h5">Edit package</span></v-card-title>
                <v-card-text>
                  <v-container>
                    <v-row>
                      <v-col cols="12" sm="12" md="12" >
                        <v-textarea v-model="dialogPackageItemJson" rows="15"></v-textarea>
                      </v-col>
                    </v-row>
                  </v-container>
                </v-card-text>

                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="blue darken-1" text @click="closePackageDialog">Cancel</v-btn>
                  <v-btn color="blue darken-1" text @click="savePackageDialog">Save</v-btn>
                </v-card-actions>
              </v-card>
            </v-dialog>
          </v-toolbar>
        </template>
      </v-data-table>
    </v-sheet>

    <v-spacer></v-spacer>

    <v-sheet elevation="0" class="mt-4">
      <v-data-table
        :footer-props="{'items-per-page-options':[100, -1]}"
        :headers="headersPartnerSettings"
        :items="partnerSettings"
        class="elevation-1"
        :loading="loadingPartnerSettings"
        loading-text="Loading list of packages... "
        :search="search2"
      >
        <template v-slot:item.packagePrices="{ item }">
          <div>
            <div v-for="(value, key) in item.packagePrices" :key="key">
              <span>{{ key }} : {{value}}</span><br/>
            </div>
          </div>
        </template>
        <template v-slot:item.actions="{ item }">
          <v-btn class="mx-2" fab dark x-small color="primary" @click="partnerSettingsRowClick(item)">
            <v-icon dark>mdi-pencil</v-icon>
          </v-btn>
          <v-btn class="mx-2" fab dark x-small color="primary" @click="deletePartnerSettings(item.id)">
            <v-icon dark color="red">mdi-delete</v-icon>
          </v-btn>
        </template>
        <template v-slot:top>
          <v-toolbar flat>
            <v-toolbar-title>Partner settings</v-toolbar-title>
            <v-spacer></v-spacer>
            <v-text-field v-model="search2" append-icon="mdi-magnify" label="Search" single-line hide-details></v-text-field>
            <v-spacer></v-spacer>
            <v-dialog v-model="dialogPartnerSettings" max-width="80%">
              <template v-slot:activator="{ on, attrs }">
                <v-btn color="primary" dark class="mb-2" @click="partnerSettingsNewItemClick()">New Item</v-btn>
              </template>
              <v-card>
                <v-card-title><span class="text-h5">Edit partner settings</span></v-card-title>
                <v-card-text>
                  <v-container>
                    <v-row>
                      <v-col cols="12" sm="12" md="12" >
                        <v-textarea v-model="dialogPartnerSettingsItemJson" rows="25"></v-textarea>
                      </v-col>
                    </v-row>
                  </v-container>
                </v-card-text>

                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="blue darken-1" text @click="closePartnerSettingsDialog">Cancel</v-btn>
                  <v-btn color="blue darken-1" text @click="savePartnerSettingsDialog">Save</v-btn>
                </v-card-actions>
              </v-card>
            </v-dialog>
          </v-toolbar>
        </template>
      </v-data-table>
    </v-sheet>

    <v-spacer></v-spacer>

    <v-sheet elevation="0" class="mt-4 col-12 col-md-6 ma-0 pa-0 float-right">
      <v-data-table
        :footer-props="{'items-per-page-options':[100, -1]}"
        :headers="headersPartnerSettingsMappings"
        :items="partnerSettingsMappings"
        class="elevation-1"
        :loading="loadingPartnerSettingsMappings"
        loading-text="Loading list of packages... "
        :search="search3"
      >
        <template v-slot:item.countryCodeToPartnerSettingsId="{ item }">
          <div>
            <div v-for="(value, key) in item.countryCodeToPartnerSettingsId" :key="key">
              <span>{{ key }} : {{value}}</span><br/>
            </div>
          </div>
        </template>
        <template v-slot:item.actions="{ item }">
          <v-btn class="mx-2" fab dark x-small color="primary" @click="partnerSettingsMappingsRowClick(item)">
            <v-icon dark>mdi-pencil</v-icon>
          </v-btn>
          <v-btn class="mx-2" fab dark x-small color="primary" @click="deletePartnerSettingsMappings(item.partnerId)">
            <v-icon dark color="red">mdi-delete</v-icon>
          </v-btn>
        </template>
        <template v-slot:top>
          <v-toolbar flat>
            <v-toolbar-title>Partner settings mappings</v-toolbar-title>
            <v-spacer></v-spacer>
            <v-text-field v-model="search3" append-icon="mdi-magnify" label="Search" single-line hide-details></v-text-field>
            <v-spacer></v-spacer>
            <v-dialog v-model="dialogPartnerSettingsMappings" max-width="80%">
              <template v-slot:activator="{ on, attrs }">
                <v-btn color="primary" dark class="mb-2" @click="partnerSettingsMappingsNewItemClick()">New Item</v-btn>
              </template>
              <v-card>
                <v-card-title><span class="text-h5">Edit partner settings mappings</span></v-card-title>
                <v-card-text>
                  <v-container>
                    <v-row>
                      <v-col cols="12" sm="12" md="12" >
                        <v-textarea v-model="dialogPartnerSettingsMappingsItemJson" rows="25"></v-textarea>
                      </v-col>
                    </v-row>
                  </v-container>
                </v-card-text>

                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="blue darken-1" text @click="closePartnerSettingsMappingsDialog">Cancel</v-btn>
                  <v-btn color="blue darken-1" text @click="savePartnerSettingsMappingsDialog">Save</v-btn>
                </v-card-actions>
              </v-card>
            </v-dialog>
          </v-toolbar>
        </template>
      </v-data-table>
    </v-sheet>
    <ConfirmDialog ref="confirm"></ConfirmDialog>
  </v-card>
</template>

<script>
import ConfirmDialog from "@/components/widgets/dialogs/ConfirmDialog"
import axios from "@/axios-client"

export default {
  name: "AutoSaleManagement",
  components: {
    ConfirmDialog
  },
  data(){
    return {
      search: '',
      search2: '',
      search3: '',
      singleSelect: false,
      loading: false,
      loadingPackages: false,
      dialogPackages: false,
      dialogPackageItem: {},
      dialogPackageItemJson: '',
      loadingPartnerSettings: false,
      dialogPartnerSettings: false,
      dialogPartnerSettingsItem: {},
      dialogPartnerSettingsItemJson: '',
      loadingPartnerSettingsMappings: false,
      dialogPartnerSettingsMappings: false,
      dialogPartnerSettingsMappingsItem: {},
      dialogPartnerSettingsMappingsItemJson: '',
      packages:[],
      headersPackages: [
        { text: 'Id', value: 'id' },
        { text: 'Name', value: 'name' },
        { text: 'Deactivated', value: 'deactivated' },
        { text: 'MinimumMonthlyPrice', value: 'minimumMonthlyPrice' },
        { text: 'RecommendedMonthlyPrice', value: 'recommendedMonthlyPrice' },
        { text: 'RecommendedStartupPrice', value: 'recommendedStartupPrice' },
        { text: 'PriceBearingItem', value: 'priceBearingItem' },
        { text: 'AddonItems', value: 'addonItems' },
        { text: 'Actions', value: 'actions',  align: 'right' },
      ],
      partnerSettings:[],
      headersPartnerSettings: [
        { text: 'Id', value: 'id' },
        { text: 'Name', value: 'name' },
        { text: 'ClientId', value: 'clientId' },
        { text: 'InternalContactId', value: 'internalContactId' },
        { text: 'Source', value: 'source' },
        { text: 'Category', value: 'category' },
        { text: 'NaceSicCode', value: 'naceSicCode' },
        { text: 'RequiresGetAccept', value: 'requiresGetAccept' },
        { text: 'PackagePrices', value: 'packagePrices' },
        { text: 'Actions', value: 'actions',  align: 'right' },
      ],
      partnerSettingsMappings:[],
      headersPartnerSettingsMappings: [
        { text: 'PartnerId', value: 'partnerId' },
        { text: 'CountryCodeToPartnerSettingsId', value: 'countryCodeToPartnerSettingsId' },
        { text: 'Actions', value: 'actions',  align: 'right' },
      ],
      fetchingTenantIds: false
    }
  },
  async mounted() {
    await this.getPackages()
    await this.getPartnerSettings()
    await this.getPartnerSettingsMappings()
  },
  methods: {
    packageNewItemClick(){
      this.dialogPackageItem =
        {
          "id": null,
          "name": "name of item",
          "deactivated": false,
          "priceBearingItem": 2001,
          "addonItems": [
            5050
          ],
        }
      this.dialogPackageItemJson = JSON.stringify(this.dialogPackageItem, null, 4)
      this.dialogPackages = true
    },
    packageRowClick(row){
      this.dialogPackageItem = row
      this.dialogPackageItemJson = JSON.stringify(this.dialogPackageItem, null, 4)
      this.dialogPackages = true
    },
    closePackageDialog(){
      this.dialogPackages = false
    },
    async deletePackage(packageId) {
      let confirmed = await this.$refs.confirm.open('Deleting package', `Are you sure you want to delete this package: ${packageId} forever?`, { width: 700, preformatted: true, html: true })
      if(!confirmed) return

      try {
        await axios.delete(`/api/auto-sale/packages/${packageId}`)
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Action failed`, type: 'error'});
      }
      await this.getPackages()
    },
    async savePackageDialog() {
      this.loadingPackages = true
      let obj = JSON.parse(this.dialogPackageItemJson)

      try {
        if(!obj.id) await axios.post(`/api/auto-sale/packages`, obj)
        else await axios.put(`/api/auto-sale/packages`, obj)
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to save packages`, type: 'error'});
      }
      this.dialogPackages = false
      await this.getPackages()
    },
    async getPackages() {
      this.loadingPackages = true
      try {
        let res = await axios.get(`/api/auto-sale/packages`)
        this.packages = res.data;
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to fetch packages`, type: 'error'});
      }
      this.loadingPackages = false
    },
    partnerSettingsNewItemClick(){
      this.dialogPartnerSettingsItem =
        {
          "id": null,
          "name": "name of item",
          "clientId": 22880,
          "internalContactId": "an id",
          "source": "the source",
          "defaultContractDurationInMonths": 1,
          "defaultInvoiceIntervalInMonths": 2,
          "defaultPaymentMethod": "some string",
          "defaultPaymentTerms": "some string",
          "category": "some category",
          "naceSicCode": "1211",
          "requiresGetAccept": true,
          "packagePrices": {
            "key-1" : {
              "monthlyPrice": 100.0,
              "startupCost": 200.0
            }
          }
        }
      this.dialogPartnerSettingsItemJson = JSON.stringify(this.dialogPartnerSettingsItem, null, 4)
      this.dialogPartnerSettings = true
    },
    partnerSettingsRowClick(row){
      this.dialogPartnerSettingsItem = row
      this.dialogPartnerSettingsItemJson = JSON.stringify(this.dialogPartnerSettingsItem, null, 4)
      this.dialogPartnerSettings = true
    },
    closePartnerSettingsDialog(){
      this.dialogPartnerSettings = false
    },
    async savePartnerSettingsDialog() {
      this.loadingPartnerSettings = true
      let obj = JSON.parse(this.dialogPartnerSettingsItemJson)

      try {
        if(!obj.id) await axios.post(`/api/auto-sale/partner-settings`, obj)
        else await axios.put(`/api/auto-sale/partner-settings`, obj)
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to save partner-settings`, type: 'error'});
      }
      this.dialogPartnerSettings = false
      await this.getPartnerSettings()
    },
    async deletePartnerSettings(partnerSettingsId) {
      let confirmed = await this.$refs.confirm.open('Deleting partner settings', `Are you sure you want to delete this partner-setting: ${partnerSettingsId} forever?`, { width: 700, preformatted: true, html: true })
      if(!confirmed) return

      try {
        await axios.delete(`/api/auto-sale/partner-settings/${partnerSettingsId}`)
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Action failed`, type: 'error'});
      }
      await this.getPartnerSettings()
    },
    async getPartnerSettings() {
      this.loadingPartnerSettings = true
      try {
        let res = await axios.get(`/api/auto-sale/partner-settings`)
        this.partnerSettings = res.data;
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to fetch partner settings`, type: 'error'});
      }
      this.loadingPartnerSettings = false
    },
    partnerSettingsMappingsNewItemClick(){
      this.dialogPartnerSettingsMappingsItem =
        {
          "partnerId": null,
          "countryCodeToPartnerSettingsId": {
            "country_code" : "partner_settings_id"
          }
        }
      this.dialogPartnerSettingsMappingsItemJson = JSON.stringify(this.dialogPartnerSettingsMappingsItem, null, 4)
      this.dialogPartnerSettingsMappings = true
    },
    partnerSettingsMappingsRowClick(row){
      this.dialogPartnerSettingsMappingsItem = row
      this.dialogPartnerSettingsMappingsItemJson = JSON.stringify(this.dialogPartnerSettingsMappingsItem, null, 4)
      this.dialogPartnerSettingsMappings = true
    },
    closePartnerSettingsMappingsDialog(){
      this.dialogPartnerSettingsMappings = false
    },
    async savePartnerSettingsMappingsDialog() {
      this.loadingPartnerSettingsMappings = true
      let obj = JSON.parse(this.dialogPartnerSettingsMappingsItemJson)

      try {
        await axios.put(`/api/auto-sale/partner-settings-mappings`, obj)
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to save partner-settings-mappings`, type: 'error'});
      }
      this.dialogPartnerSettingsMappings = false
      await this.getPartnerSettingsMappings()
    },
    async deletePartnerSettingsMappings(partnerId) {
      let confirmed = await this.$refs.confirm.open('Deleting partner settings mapping', `Are you sure you want to delete partner settings mapping for partnerId: ${partnerId} forever?`, { width: 700, preformatted: true, html: true })
      if(!confirmed) return

      try {
        await axios.delete(`/api/auto-sale/partner-settings-mappings/${partnerId}`)
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Action failed`, type: 'error'});
      }
      await this.getPartnerSettingsMappings()
    },
    async getPartnerSettingsMappings() {
      this.loadingPartnerSettingsMappings = true
      try {
        let res = await axios.get(`/api/auto-sale/partner-settings-mappings`)
        this.partnerSettingsMappings = res.data;
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to fetch partner settings mappings`, type: 'error'});
      }
      this.loadingPartnerSettingsMappings = false
    },
  },
  computed:{
    roles() {
      return this.$store.state.currentUserRoles;
    },
  }
}
</script>

<style scoped>

</style>
