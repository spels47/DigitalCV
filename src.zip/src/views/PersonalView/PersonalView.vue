<template>
  <v-container fluid>
    <v-tabs background-color="black" dark :value="tab">
      <v-tab v-for="t in availableTabs" :key="t.id" @click="setTabQuery(t.id)">{{ t.text }}</v-tab>
    </v-tabs>

    <v-tabs-items v-model="tab">
      <v-tab-item>
        <ErpCleanupHelpers v-if="tab === 0" />
      </v-tab-item>
      <v-tab-item>
        <BcErrorList v-if="tab === 1" />
      </v-tab-item>
      <v-tab-item>
        <VersionManagement v-if="tab === 2" />
      </v-tab-item>
      <v-tab-item>
        <UsageLogCleaner v-if="tab === 3" />
      </v-tab-item>
      <v-tab-item>
        <GeofenceImport v-if="tab === 4" />
      </v-tab-item>
      <v-tab-item>
        <AutoSaleManagement v-if="tab === 5" />
      </v-tab-item>
    </v-tabs-items>
  </v-container>
</template>

<script>
import BcErrorList from "@/views/PersonalView/BcErrorList";
import ErpCleanupHelpers from "@/views/PersonalView/ErpCleanupHelpers"
import VersionManagement from "@/views/PersonalView/VersionManagement"
import UsageLogCleaner from "@/views/Ted/UsageLogCleaner";
import GeofenceImport from "@/views/PersonalView/GeofenceImport";
import AutoSaleManagement from "@/views/PersonalView/AutoSaleManagement"
export default {
  components: {
    AutoSaleManagement,
    GeofenceImport,
    UsageLogCleaner,
    ErpCleanupHelpers,
    BcErrorList,
    VersionManagement
  },
  name: "PersonalView",
  data() {
    return {
      tab: -1,
      tabs: [
        { id: 0, text: "ERP Cleanup Helper", userRight: "ERP_CLEANUP_HELPER" },
        { id: 1, text: "BC error-list", userRight: "BCS_ERROR_LIST" },
        { id: 2, text: "Version management", userRight: "VERSION_MANAGEMENT" },
        { id: 3, text: "Usage log cleaner", userRight: "USAGE_LOG_CLEANER" },
        { id: 4, text: "Geofence import", userRight: "AREA_IMPORT" },
        { id: 5, text: "AutoSale management", userRight: "AUTO_SALE" },
      ],
      availableTabs: []
    }
  },
  async mounted() {
    await this.$store.dispatch("waitForRolesLoaded");
    let tabs = this.getTabs()
    let query = parseInt(this.$route.query?.tab??'');
    if (tabs.some(x => x.id === query)) this.tab = query
    else if (tabs.length > 0) this.tab = tabs[0].id
    else this.tab = -1
    this.availableTabs = tabs
    this.$forceUpdate();
  },
  methods: {
    getTabs() {
      let allowedTabs = [];
      this.tabs.forEach(x => {
        if (x.userRight === "" || this.roles[x.userRight]) {
          allowedTabs.push(x);
        }
      });
      return allowedTabs;
    },
    async setTabQuery(tab) {
      await this.$store.dispatch("setUrlParameter", {name: "tab", value: tab});
      this.tab = tab
    }
  },
  computed:{
    roles() {
      return this.$store.state.currentUserRoles;
    },
  },
};
</script>

<style lang="scss" scoped>
.pointer-cursor {
  cursor: pointer;
}
</style>
