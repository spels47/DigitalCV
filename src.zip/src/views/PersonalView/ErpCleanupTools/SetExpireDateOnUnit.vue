<template>
  <v-card>
    <v-progress-linear indeterminate :active="loading"></v-progress-linear>
    <v-card-title>
      <span>Set expire date on unit</span>
    </v-card-title>
    <v-card-actions>
      <v-text-field label="Serial number of the unit" v-model="serialNumber" clearable clear-icon="mdi-close-circle-outline"></v-text-field>
      <v-btn-toggle v-model="expired" tile group>
        <v-btn value="true">Expire</v-btn>
        <v-btn value="false">Un-expire</v-btn>
      </v-btn-toggle>
      <v-btn @click="updateIt" class="secondary" :disabled="updateButtonDisabled">Update it</v-btn>
    </v-card-actions>
  </v-card>
</template>

<script>
import axios from "@/axios-client"

export default {
  name: "SetExpireDateOnUnit",
  data(){
    return {
      serialNumber : '',
      expired: false,
      loading: false
    }
  },
  methods: {
    async updateIt() {
      this.loading = true
      try {
        await axios.put(`/api/erp/cleanup/unit/${this.serialNumber}/expire/${this.expired}`)
        this.$eventBus.$emit('alert', {text: 'Expire-state updated ✔', icon: 'mdi-information', type: 'success'});
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Expire-state update failed 🤕', icon: 'mdi-alert-circle', type: 'error'});
      }
      this.loading = false
    }
  },
  computed: {
    updateButtonDisabled(){
      if(this.loading) return true;
      if(!this.serialNumber) return true;
      return false;
    }
  }
}
</script>

<style scoped>

</style>
