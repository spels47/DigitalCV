<template>
  <v-card>
    <v-progress-linear indeterminate :active="loading"></v-progress-linear>
    <v-card-title>
      <span>Update department path for units in BC for all units below a department</span>
    </v-card-title>
    <v-card-actions>
      <v-text-field label="DepartmentId of where the units are located" v-model="departmentId" clearable clear-icon="mdi-close-circle-outline"></v-text-field>
      <v-btn @click="updateIt" class="secondary ml-4 mr-4" :disabled="updateButtonDisabled">Update</v-btn>
    </v-card-actions>
  </v-card>
</template>

<script>
import axios from "@/axios-client"

export default {
  name: "ReEvaluateDatasourceDepartmentInfoForErp",
  data(){
    return {
      departmentId : '',
      loading: false,
      lastSearchedDepartmentId: '',
    }
  },
  methods: {
    async updateIt() {
      this.loading = true
      try {
        let res = await axios.post(`/api/erp/cleanup/department/${this.departmentId}/re-evaluate-department-info-for-erp`)
        this.$eventBus.$emit('alert', {text: `Updated department path sent to BC for ${res.data} units`, icon: 'mdi-information', type: 'success'});
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Update failed 🤕', icon: 'mdi-alert-circle', type: 'error'});
      }
      this.loading = false
    }
  },
  computed: {
    updateButtonDisabled(){
      if(this.loading) return true;
      if(this.departmentId === this.lastSearchedDepartmentId) return true;
      return false;
    }
  }
}
</script>

<style scoped>

</style>
