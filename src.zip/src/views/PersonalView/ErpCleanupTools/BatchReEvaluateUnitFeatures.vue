<template>
  <v-card>
    <v-progress-linear indeterminate :active="loading"></v-progress-linear>
    <v-card-title>
      <span>Batch re-evaluate unit features</span>
    </v-card-title>
    <v-card-actions>
      <v-text-field label="Serial numbers of the units" v-model="serialNumbersText" @change="createSerialNumberList" clearable clear-icon="mdi-close-circle-outline"></v-text-field>
      <v-btn @click="createSerialNumberList" class="primary ml-4">Read text</v-btn>
      <v-btn @click="updateIt" class="secondary ml-4" :disabled="updateButtonDisabled">Batch Update</v-btn>
    </v-card-actions>
    <div v-if="serialNumbersList.length > 0">
      <v-list-item>
        <v-simple-table dense>
          <template v-slot:default>
            <thead>
            <tr>
              <th>Serial number</th>
              <th>State</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="(unit, index) in serialNumbersList" :key="index">
              <td>{{ unit.serialNumber }}</td>
              <td v-tooltippy="unit.state">
                <v-icon v-if="unit.state === 'ready'" color="primary">mdi-baguette</v-icon>
                <v-icon v-if="unit.state === 'completed'" color="secondary">mdi-bread-slice</v-icon>
                <v-icon v-if="unit.state === 'failed'" color="error">mdi-alert-circle-outline</v-icon>
              </td>
            </tr>
            </tbody>
          </template>
        </v-simple-table>
      </v-list-item>
    </div>
  </v-card>
</template>

<script>
import axios from "@/axios-client"

export default {
  name: "BatchReEvaluateUnitFeatures",
  data(){
    return {
      serialNumbersText : '',
      serialNumbersList: [],
      loading: false
    }
  },
  methods: {
    createSerialNumberList(){
      this.serialNumbersList = []
      if(!this.serialNumbersText) return

      let splitChar = ' '
      if(this.serialNumbersText.includes(';')) splitChar = ';'
      else if(this.serialNumbersText.includes(',')) splitChar = ','

      if(splitChar !== ' ') this.serialNumbersList = this.serialNumbersList.replaceAll(' ','')

      this.serialNumbersList = this.serialNumbersText.split(splitChar).map(sn => { return { serialNumber: sn, state: 'ready' }});
    },
    async updateIt() {
      this.loading = true
      let failedCount = 0

      for (const unit of this.serialNumbersList) {
        try {
          await axios.put(`/api/subscription/ReEvaluateUnitFeatures/${unit.serialNumber}`)
          unit.state = 'completed'
        } catch (ex) {
          failedCount++;
          unit.state = 'failed'
        }
      }
      this.loading = false
      this.$eventBus.$emit('alert', {text: `ReEvaluated all ${this.serialNumbersList.length} units, ${failedCount} requests failed`, icon: 'mdi-information', type: failedCount > 0 ? 'warning' : 'success'});
    }
  },
  computed: {
    updateButtonDisabled(){
      if(this.loading) return true;
      if(this.serialNumbersList.length < 1) return true;
      return false;
    }
  }
}
</script>

<style scoped>

</style>
