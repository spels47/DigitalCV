<template>
  <v-card>
    <v-progress-linear indeterminate :active="loading"></v-progress-linear>
    <v-card-title>
      <span>Set new tenantId on assets</span>
    </v-card-title>
    <v-card-actions>
      <v-text-field class="mr-4" label="DepartmentId of assets" v-model="departmentId" clearable clear-icon="mdi-close-circle-outline" @click:clear="clearDepartmentIdInput"></v-text-field>
      <v-text-field class="mx-4" label="New tenantId" v-model="newTenantId" clearable clear-icon="mdi-close-circle-outline"></v-text-field>
      <v-btn @click="listAssets" :disabled="!departmentId || loading" class="primary ml-4">List assets</v-btn>
      <v-btn @click="updateIt" class="secondary ml-4" :disabled="updateButtonDisabled">Update tenantId</v-btn>
    </v-card-actions>
    <div v-if="assetsList.length > 0">

      <v-sheet elevation="0">
        <v-card-actions>
          <v-text-field
            class=""
            v-model="search"
            append-icon="mdi-magnify"
            label="Search"
            single-line
            hide-details
            colspan="6"
          ></v-text-field>
          <v-btn colspan="6" @click="toggleSelected" class="ml-4">Toggle selected</v-btn>
          <v-checkbox v-model="filter_ShowOnlyFucked" class="ml-4" v-if="!fetchingTenantIds" label="Show only mismatch"></v-checkbox>
          <v-btn colspan="6" @click="stopLoading" class="ml-4" v-if="fetchingTenantIds">Stop loading tenantIds</v-btn>
        </v-card-actions>

        <v-data-table
          :footer-props="{'items-per-page-options':[100, -1]}"
          :headers="headers"
          :items="filteredAssetsList"
          class="elevation-1"
          :loading="loading"
          loading-text="Loading list of hot-swaps pending... "
          :search="search"
          :custom-filter="customFilter"
          :item-class="getCustomItemClass"
        >
          <template v-slot:item.assetId="{ item }">
            <span>{{ item.assetId }}</span>
          </template>
          <template v-slot:item.alias="{ item }">
            <span>{{ item.alias }}</span>
          </template>
          <template v-slot:item.type="{ item }">
            <span>{{ item.type }}</span>
          </template>
          <template v-slot:item.id="{ item }">
            <v-btn class="elevation-0" @click="openCustomerOnUnitInNewTab(item)">
              <span v-if="item.type === 'vehicle'">{{item.vehicleId}}</span>
              <span v-if="item.type === 'equipment'">{{item.simcardId}}</span>
              <span v-if="item.type === 'mini'">{{item.primaryDatasourceId}}</span>
              <v-icon right>mdi-open-in-new</v-icon></v-btn>
          </template>
          <template v-slot:item.assetTenantId="{ item }">
            <span v-tooltippy="`AssetCustomerId: ${item.assetCustomerId} <br/> AssetClientId: ${item.assetClientId}`">{{ item.assetTenantId }}</span>
          </template>
          <template v-slot:item.ssTenantId="{ item }">
            <span v-tooltippy="`SsCustomerId: ${item.ssCustomerId} <br/> SsClientId: ${item.ssClientId}`">{{ item.ssTenantId }}</span>
          </template>
          <template v-slot:item.etsTenantId="{ item }">
            <span v-tooltippy="`EtsCustomerId: ${item.etsCustomerId} <br/> EtsClientId: ${item.etsClientId}`">{{ item.etsTenantId }}</span>
          </template>
          <template v-slot:item.departmentPath="{ item }">
            <DepartmentPath :department-path="item.departmentPath"></DepartmentPath>
          </template>
          <template v-slot:item.state="{ item }">
            <v-btn v-tooltippy="item.state" @click="toggleItemState(item)" class="px-4 elevation-0">
              <v-icon v-show="item.state === 'ready'" color="primary">mdi-baguette</v-icon>
              <v-icon v-show="item.state === 'deselected'" color="primary">mdi-checkbox-blank-outline</v-icon>
              <v-icon v-show="item.state === 'completed'" color="secondary">mdi-bread-slice</v-icon>
              <v-icon v-show="item.state === 'failed'" color="error">mdi-alert-circle-outline</v-icon>
            </v-btn>
          </template>
        </v-data-table>
      </v-sheet>
    </div>
    <ConfirmDialog ref="confirm"></ConfirmDialog>
  </v-card>
</template>
<script>
import axios from "@/axios-client"
import DepartmentPath from "@/components/DepartmentPath"
import ConfirmDialog from "@/components/widgets/dialogs/ConfirmDialog"
import util from "@/helpers/util"

export default {
  name: "SetNewTenantIdOnAssets",
  components: {
    ConfirmDialog,
    DepartmentPath
  },
  data(){
    return {
      search: '',
      departmentId: '',
      newTenantId: '',
      assetsList: [],
      selected: [],
      singleSelect: false,
      loading: false,
      filter_ShowOnlyFucked: false,
      headers: [
        { text: 'AssetId', value: 'assetId' },

        { text: 'Alias', value: 'alias' },
        { text: 'Type', value: 'type' },
        { text: 'Id', value: 'id' },
        { text: 'PrimaryDatasourceId', value: 'primaryDatasourceId' },
        { text: 'AssetTenantId', value: 'assetTenantId' },
        { text: 'SsTenantId', value: 'ssTenantId' },
        { text: 'EtsTenantId', value: 'etsTenantId' },
        { text: 'Department path', value: 'departmentPath' },
        { text: 'State', value: 'state' },
      ],
      fetchingTenantIds: false
    }
  },
  mounted() {
    this.departmentId = localStorage.getItem('SetNewTenantIdOnAssets_departmentId')
  },
  methods: {
    clearDepartmentIdInput(){
      this.departmentId = ''
      localStorage.setItem('SetNewTenantIdOnAssets_departmentId', this.departmentId)
    },
    customFilter(value, search, item) {
      search = search.toString().toLowerCase();
      return Object.keys(item).some(propName => {
        if(item.departmentPath[0]?.name.toLowerCase().includes(search)) return true;

        return item[propName]
          ?.toString()
          .toLowerCase()
          .includes(search);
      });
    },
    getCustomItemClass(item) {
      if (item.ssTenantId !== item.etsTenantId && item.type != 'mini') {
        return "tablered";
      }
    },
    async listAssets() {
      this.fetchingTenantIds = false
      this.assetsList = []
      this.loading = true

      try {
        let res = await axios.get(`/api/erp/cleanup/asset/tenant-id-update/list/${this.departmentId}`)
        this.assetsList = res.data;
        this.assetsList.forEach(x => {
          if(!x.assetId) x.state = 'deselected'
          else x.state = 'ready'
        })
      } catch (ex) {
        this.$eventBus.$emit('alert', { text: `Failed to fetch all assets for this tenant`, type: 'error'});
      }
      localStorage.setItem('SetNewTenantIdOnAssets_departmentId', this.departmentId)
      this.loading = false

      this.fetchingTenantIds = true
      this.fetchTenantIDs().then(_ => _) // background task
    },
    async fetchTenantIDs() {
      for (const unit of this.assetsList) {
        if (!this.fetchingTenantIds) return

        try {
          if (!unit.assetId && !unit.primaryDatasourceId) continue;                       // Impossible lookup
          if (unit.assetTenantId || unit.ssTenantId || unit.etsTenantId) continue;        // Already done
          let res = await axios.post(`/api/erp/cleanup/asset-tenant-info`, { assetId: unit.assetId, serialNumber: unit.primaryDatasourceId })
          unit.assetTenantId = res.data.assetTenantId
          unit.assetCustomerId = res.data.assetCustomerId
          unit.assetClientId = res.data.assetClientId
          unit.ssTenantId = res.data.ssTenantId
          unit.ssCustomerId = res.data.ssCustomerId
          unit.ssClientId = res.data.ssClientId
          unit.etsTenantId = res.data.etsTenantId
          unit.etsCustomerId = res.data.etsCustomerId
          unit.etsClientId = res.data.etsClientId
          this.$set(this.assetsList, this.assetsList.indexOf(unit), unit)
        } catch (ex) {
          console.log(`Tenant info fetch failed for an asset`)
        }
      }
      this.fetchingTenantIds = false
    },
    stopLoading(){
      this.fetchingTenantIds = false
    },
    toggleItemState(item){
      if(item.state === 'ready') item.state = 'deselected'
      else if(item.state === 'deselected' || item.state === 'failed') item.state = 'ready'

      if(!item.assetId) item.state = 'deselected'

      this.$set(this.assetsList, this.assetsList.indexOf(item), item)
    },
    toggleSelected(){
      this.assetsList.forEach(x => {
        if(x.state === 'ready') x.state = 'deselected'
        else if(x.state === 'deselected') x.state = 'ready'

        if(!x.assetId) x.state = 'deselected'
        this.$set(this.assetsList, this.assetsList.indexOf(x), x)
      })
    },
    async updateIt() {
      let result = await this.$refs.confirm.open('Start update?', `This will update ${this.readyCount} assets with tenantId ${this.newTenantId}`, { width: 500, confirmLabel: `Lets go! 😃`});
      if(!result) return

      this.loading = true
      let failedCount = 0

      let unitsToUpdate = this.filteredAssetsList.filter(x => x.state === 'ready')

      for (const unit of unitsToUpdate) {
        try {
          if(!unit.departmentId) throw 'Oy! No departmentId on this one :/'

          await axios.post(`/api/erp/cleanup/asset/tenant-id-update`, {
            AssetId: unit.assetId,
            DepartmentId: unit.departmentId,
            NewTenantId: this.newTenantId
          })
          unit.state = 'completed'
        } catch (ex) {
          failedCount++;
          unit.state = 'failed'
        }
        this.$set(this.assetsList, this.assetsList.indexOf(unit), unit)
      }
      this.loading = false
      this.$eventBus.$emit('alert', {text: `Updated ${unitsToUpdate.length} assets. ${failedCount} requests failed`, icon: 'mdi-information', type: failedCount > 0 ? 'warning' : 'success'});
    },
    openCustomerOnUnitInNewTab(item){
      if(item.type === 'vehicle'){
        let routeData = this.$router.resolve({ name: "customer", params: { id: item.departmentPath[0].id }, query: { activeTab: '2', type: 'vehicle', id: item.vehicleId } })
        window.open(routeData.href, '_blank');
      }
      else if (item.type === 'equipment'){
        let routeData = this.$router.resolve({ name: "customer", params: { id: item.departmentPath[0].id }, query: { activeTab: '3', type: 'eq', id: item.simcardId } })
        window.open(routeData.href, '_blank');
      }
      else if (item.type === 'mini'){
        let routeData = this.$router.resolve({ name: "customer", params: { id: item.departmentPath[0].id }, query: { activeTab: '5', type: 'mini', id: item.primaryDatasourceId } })
        window.open(routeData.href, '_blank');
      }
    },
  },
  computed: {
    updateButtonDisabled(){
      if(this.loading) return true;
      if(this.assetsList.length < 1) return true;
      if(!this.newTenantId) return true
      return false;
    },
    readyCount(){
      return this.filteredAssetsList.filter(x => x.state === 'ready').length
    },
    filteredAssetsList() {
      return this.assetsList.filter(
        (i) => {
          return ((i.ssTenantId !== i.etsTenantId && i.type != 'mini') || !this.filter_ShowOnlyFucked)
        }
      )
    },
  }
}
</script>

<style scoped>

</style>
