<template>
  <v-card>
    <v-progress-linear indeterminate :active="loading"></v-progress-linear>
    <v-card-title>
      <span>Batch move assets</span>
    </v-card-title>
    <v-card-actions>
      <v-textarea label="Serial numbers and departmentId's" v-model="serialNumbersText" @change="createSerialNumberList" clearable clear-icon="mdi-close-circle-outline"></v-textarea>
      <v-btn @click="createSerialNumberList" class="primary ml-4">Read text</v-btn>
      <v-btn @click="moveAllAssets" class="secondary ml-4" :disabled="updateButtonDisabled">Move all assets</v-btn>
    </v-card-actions>
    <div v-if="serialNumbersList.length > 0">
      <v-list-item>
        <v-simple-table dense>
          <template v-slot:default>
            <thead>
            <tr>
              <th>Serial number</th>
              <th>DepartmentId</th>
              <th>State</th>
              <th>Remove</th>
              <th>AssetIds</th>
            </tr>
            </thead>
            <tbody>
            <tr v-for="(unit, index) in serialNumbersList" :key="index">
              <td>{{ unit.serialNumber }}</td>
              <td>{{ unit.departmentId }}</td>
              <td v-tooltippy="unit.state">
                <v-icon v-if="unit.state === 'ready'" color="primary">mdi-baguette</v-icon>
                <v-icon v-if="unit.state === 'completed'" color="secondary">mdi-bread-slice</v-icon>
                <v-icon v-if="unit.state === 'failed'" color="error">mdi-alert-circle-outline</v-icon>
              </td>
              <td @click="removeFromList(unit)"><v-icon>mdi-trash-can</v-icon></td>
              <td>{{unit.assetIds}}</td>
            </tr>
            </tbody>
          </template>
        </v-simple-table>
      </v-list-item>
    </div>
  </v-card>
</template>

<script>
import axios from "@/axios-client"
import util from "@/helpers/util"

export default {
  name: "BatchMoveAssets",
  data(){
    return {
      serialNumbersText : '',
      serialNumbersList: [],
      loading: false
    }
  },
  methods: {
    async createSerialNumberList() {
      this.serialNumbersList = []
      if (!this.serialNumbersText) return

      let lines = this.serialNumbersText.split('\n')
      if (lines.length < 1) return

      let splitChar = '\t'
      if (this.serialNumbersText.includes(';')) splitChar = ';'
      else if (this.serialNumbersText.includes(',')) splitChar = ','

      if (splitChar !== '\t') this.serialNumbersText = this.serialNumbersText.replaceAll('\t', '')

      lines.forEach(line => {
        let temp = line.split(splitChar)

        if (temp.length < 2) return;
        this.serialNumbersList.push({
          serialNumber: temp[0],
          departmentId: temp[1],
          state: 'ready'
        })
      })

      await this.getAssetIdsForList()
    },
    async getAssetIdsForList() {
      this.loading = true
      let failedCount = 0

      for (const unit of this.serialNumbersList) {
        try {
          let res = await axios.get(`/api/erp/cleanup/batch-move-assets/status/device/${unit.serialNumber}`)
          unit.assetIds = res.data.assetIds
          this.$set(this.serialNumbersList, this.serialNumbersList.indexOf(unit), unit)
        } catch (ex) {
          failedCount++;
          unit.state = 'failed'
        }
      }
      this.loading = false
      this.$eventBus.$emit('alert', {text: `Got assetIds for ${this.serialNumbersList.length} units, ${failedCount} requests failed`, icon: 'mdi-information', type: failedCount > 0 ? 'warning' : 'success'});
    },
    removeFromList(unit){
      this.serialNumbersList.splice(this.serialNumbersList.indexOf(unit), 1)
    },
    async moveAllAssets() {
      this.loading = true
      let failedCount = 0

      for (const unit of this.serialNumbersList) {
        if(!unit.assetIds) continue;

        for (const assetId of unit.assetIds) {
          try {
            await util.sleep(500);
            await axios.post(`/api/asset/${assetId}/move/${unit.departmentId}`)
            unit.state = 'completed'
          } catch (ex) {
            failedCount++;
            unit.state = 'failed'
          }
        }
      }
      this.loading = false
      this.$eventBus.$emit('alert', {text: `Moved ${this.serialNumbersList.length} assets, ${failedCount} requests failed`, icon: 'mdi-information', type: failedCount > 0 ? 'warning' : 'success'});
    }
  },
  computed: {
    updateButtonDisabled(){
      if(this.loading) return true;
      if(this.serialNumbersList.length < 1) return true;
      return false;
    }
  }
}
</script>

<style scoped>

</style>
