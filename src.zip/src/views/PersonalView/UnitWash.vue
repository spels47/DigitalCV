<template>
  <v-container fluid>
    <v-card>
      <v-card-title>
        <v-icon class="mr-2">mdi-wiper-wash</v-icon>
        Unit wash
      </v-card-title>
      <v-card-subtitle>
        This is a tool for deleting all data on a unit so that it can be re-used on another customer.
        This tool deletes all data associated to the unit, including trips and positions.
      </v-card-subtitle>
      <v-card-actions>
        <v-text-field class="ml-4 mr-4" v-model="serialNumberSearchText" label="Input the serial number" clearable clear-icon="mdi-close-circle-outline"></v-text-field>
        <v-btn class="primary ml-4 mr-4" @click="getUnitWashStatusBySerialNumber()" :disabled="loading || !validSearchString">Get unit status</v-btn>
      </v-card-actions>
      <v-progress-linear indeterminate v-if="loading"></v-progress-linear>
      <v-sheet v-if="unitStatus && currentSelectedSerialNumber" elevation="6">
        <v-subheader v-if="actionResultUnitStatus">Unit was washed, the status of the unit {{unitStatus.serialNumber}} is now this:</v-subheader>
        <v-subheader v-if="!actionResultUnitStatus">The status of the unit {{unitStatus.serialNumber}} is now this:</v-subheader>
        <v-row class="ma-4">
          <v-col cols="6">
            <v-checkbox dense class="mr-5" label="Has trips" v-model="unitStatus.hasTrips" readonly> </v-checkbox>
            <v-checkbox dense class="mr-5" label="Has gpsTripSettings" v-model="unitStatus.hasGpsTripSettings" readonly> </v-checkbox>
            <v-checkbox dense class="mr-5" label="Has positions" v-model="unitStatus.hasPositions" readonly> </v-checkbox>
            <v-checkbox dense class="mr-5" label="Has customer Id" v-model="unitStatus.hasCustomerId" readonly> </v-checkbox>
            <v-checkbox dense class="mr-5" label="Has contract number" v-model="unitStatus.hasContractNumber" readonly> </v-checkbox>
            <v-checkbox dense class="mr-5" label="Has pending hot-swap" v-model="unitStatus.hasPendingHotSwap" readonly> </v-checkbox>
            <v-checkbox dense class="mr-5" label="Is terminated" v-model="unitStatus.isTerminated" readonly> </v-checkbox>
            <v-checkbox dense class="mr-5" label="Is ready to be sold" :color="unitStatus.isReadyToBeSold ? 'success' : 'warning'" v-model="unitStatus.isReadyToBeSold" readonly> </v-checkbox>
          </v-col>
          <v-col cols="6">
            <v-text-field v-model="unitStatus.numberOfTrips" label="Number of trips" readonly></v-text-field>
            <v-text-field v-model="unitStatus.currentCustomerId" label="Current customer id" readonly></v-text-field>
            <v-text-field v-model="unitStatus.currentContractNumber" label="Current contract number" readonly></v-text-field>

            <v-btn class="warning mt-8"
                   v-if="!loading && !actionResultUnitStatus"
                   @click="displayWarning = true"
                   :disabled="loading || !canPerformUnitWash(unitStatus)">Perform unit wash</v-btn>
            <div
              class="warning--text"
              v-if="!actionResultUnitStatus && !loading && !canPerformUnitWash(unitStatus)">
              <span v-if="unitStatus.hasPendingHotSwap">You can not perform unit wash on a unit with pending hot-swap <br/></span>
              You can only perform unit wash on units that are terminated or where contract number is null or ETS-SWAP</div>
          </v-col>
        </v-row>

        <SimpleDialog
          v-if="displayWarning"
          :title="'Perform unit wash'"
          :text="getWarningText()"
          preformatted="true"
          preformattedWidth="700"
          :confirmLabel="'Yes'"
          :cancelLabel="'Cancel'"
          @confirm="performFullUnitWashOnSerialNumber()"
          @cancel="displayWarning = false"
        ></SimpleDialog>
      </v-sheet>
    </v-card>
  </v-container>
</template>
<script>
import axios from "~/axios-client";
import SimpleDialog from "~/components/widgets/dialogs/simpleDialog";

export default {
  name: "UnitWash",
  components: {
    SimpleDialog
  },
  data() {
    return {
      loading: false,
      unitStatus: null,
      actionResultUnitStatus: null,
      serialNumberSearchText: '',
      currentSelectedSerialNumber: null,
      displayWarning: false,

    }
  },
  methods: {
    async getUnitWashStatusBySerialNumber(){
      this.unitStatus = null
      this.actionResultUnitStatus = null
      this.currentSelectedSerialNumber = null
      if(!this.serialNumberSearchText) return

      this.loading = true
      try{
        let res = await axios.get(`/api/unitWash/status/${this.serialNumberSearchText}`)
        this.unitStatus = res.data
        this.currentSelectedSerialNumber = this.serialNumberSearchText
      } catch (ex){
        if(ex?.response?.status === 400) this.$eventBus.$emit('alert', {text: 'Did not find any unit with that serial number 🤕', icon: 'mdi-alert-circle', type: 'warning'});
        else this.$eventBus.$emit('alert', { template: 'api-error', errorMessage: 'Unit not found or an error in the API' })
      }finally {
        this.loading = false
      }
    },
    async performFullUnitWashOnSerialNumber(){
      this.displayWarning = false
      if(!this.currentSelectedSerialNumber) return
      this.actionResultUnitStatus = null

      this.loading = true
      try{
        let res = await axios.post(`/api/unitWash/wash-full/${this.currentSelectedSerialNumber}`)
        this.unitStatus = res.data
        this.actionResultUnitStatus = true
      } catch (ex){
        this.$eventBus.$emit('alert', { template: 'api-error' })
      }finally {
        this.loading = false
        await this.$store.dispatch("audit", { source: "datasource", entityId: this.currentSelectedSerialNumber, message: "Full unit wash performed", oldValue: "", newValue: "" });
      }
    },
    getWarningText(){
      return `
Are you sure you want to perform wash of the unit with serial number:
${this.unitStatus.serialNumber}?
This action is final.
All data will be deleted (trips, positions etc.)`
    },
    canPerformUnitWash(unitStatus){
      if(unitStatus.hasPendingHotSwap) return false
      return unitStatus.isTerminated || !unitStatus.currentContractNumber || unitStatus.currentContractNumber === 'ETS-SWAP'
    }
  },
  computed:{
    validSearchString(){
      if(!this.serialNumberSearchText) return false;
      if(this.serialNumberSearchText.includes(' ')) return false;
      return true;
    }
  }
};
</script>

<style lang="scss" scoped>
.assigned-to-someone-else{
  background-color: #555555;
}
.preformat1{
  line-height: 1;
}
</style>
