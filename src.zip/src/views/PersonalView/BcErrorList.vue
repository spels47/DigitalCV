﻿<template>
  <v-card>
    <v-card-title><v-icon class="mr-2">mdi-format-list-checkbox</v-icon>Business Central Error Messages</v-card-title>
    <v-card-subtitle>
      <v-row>
        <v-col cols="lg-4">
          <v-text-field prepend-icon="mdi-magnify" v-model="searchText" label="Search"></v-text-field>
        </v-col>
        <v-col cols="lg-4">
          <v-checkbox dense label="Show Fixed" v-model="filter_showFixed"></v-checkbox>
        </v-col>
        <v-col cols="lg-4">
          <div>
            <span>Errors: {{ totalErrors }}</span>
          </div>
          <div>
            <span>Fixed: {{ totalFixed }}</span>
          </div>
        </v-col>
      </v-row>
    </v-card-subtitle>
    <v-row no gutters>
      <v-col cols="lg-4">
        <v-container>
          <v-card class="overflow-auto" height="250px">
            <template v-for="(item, index) in errorMessages">
              <v-card :key="item.id" @click="selectItem(item, index)" class="ma-2" v-if="showItem(item)"
                      :color="fixedColor(item)">
                <div class="text-center">
                  <h3>Contract number: {{ item.contractNumber }}</h3>
                </div>
                <div class="text-center">
                  <span>Customer: {{ getDepartmentName(item) }}</span>
                </div>
                <div class="text-center">
                  <span>QueueName: {{ item.queueName }}</span>
                </div>
              </v-card>
            </template>
          </v-card>
        </v-container>
      </v-col>
      <v-col cols="lg-3">
        <v-container>
          <v-card height="250px" v-if="isSelected">
            <v-card-title>
              Customer Info
            </v-card-title>
            <v-card-subtitle>
              Contract Number: {{ selectedItem.contractNumber }}
            </v-card-subtitle>
            <v-card-text>
              <div>
                <span>First Registered: {{selectedItem.firstRegistered | ntzDate}}</span>
              </div>
              <div>
                <span>Last Registered: {{selectedItem.lastRegistered | ntzDate}}</span>
              </div>
              <div>
                <span>Erp Customer Id: {{ selectedItem.customerId }}</span>
              </div>
              <div>
                <span>Erp Client Id: {{ selectedItem.clientId }}</span>
              </div>
              <div>
                <span>Department: {{ currentDepartmentName }}</span>
              </div>
              <div>
                <span>Ets Customer Id: {{ currentDepartmentId }}</span>
              </div>
              <div>
                <span>Queue: {{ selectedItem.queueName }}</span>
              </div>
            </v-card-text>
          </v-card>
        </v-container>
      </v-col>
      <v-col cols="lg-5">
        <v-container>
          <v-card height="250px" v-if="isSelected" class="overflow-auto">
            <v-card-title>Error Messages</v-card-title>
            <div>
              <v-list v-for="(item, i) in selectedItem.messages"
                      :key="i" dense>
                <v-list-item>
                  {{ item }}
                </v-list-item>
              </v-list>
            </div>
          </v-card>
        </v-container>
      </v-col>

    </v-row>
  </v-card>
</template>

<script>
import axios from "@/axios-client";

export default {
  name: "BcErrorList",
  data() {
    return {
      errorMessages: [],
      loading: false,
      selectedIndex: "",
      selectedItem: {},
      isSelected: false,
      currentPath: [],
      searchText: "",
      filter_showFixed: false,
    }
  },
  mounted() {
    axios.get(`/api/bcs/errorMessages/true`).then(res => {
      this.errorMessages = res.data
        .sort((a, b) => a.queueName.localeCompare(b.queueName))
        .sort((a, b) => a.contractNumber.localeCompare(b.contractNumber))
    });
  },
  methods: {
    getDepartmentName: function(item){
      if(item.departmentPath[0] === undefined) return "";
      return item.departmentPath[0].name;
    },
    selectItem: function (item, index) {
      if(index.toString() !== this.selectedIndex) {
        this.currentPath = [];
        this.selectedIndex = index.toString();
        this.selectedItem = item;
        this.isSelected = true;
      }

    },
    fixedColor: function (item) {
      if (item.fixedDate !== null) return "#4CAA71";

    },
    showItem: function (item) {
      let correctFilter = false;
      if (this.filter_showFixed && item.fixedDate !== null) correctFilter = true;
      if (!this.filter_showFixed && item.fixedDate === null) correctFilter = true;
      if (this.searchText === "" && correctFilter) return true;
      if (item.contractNumber.toLowerCase().includes(this.searchText.toLowerCase()) && correctFilter) return true;
      if (item.queueName.toLowerCase().includes(this.searchText.toLowerCase()) && correctFilter) return true;
      if (item.customerId.toLowerCase().includes(this.searchText.toLowerCase()) && correctFilter) return true;
      if (item.departmentPath[0]?.name.toLowerCase().includes(this.searchText.toLowerCase()) && correctFilter) return true;
      if (item.departmentPath[0]?.id.toString().includes(this.searchText) && correctFilter) return true;
      if (this.searchText.length && item.messages.some(x => x.toLowerCase().includes(this.searchText))) return true;
      return false;
    },
  },
  computed: {
    currentDepartmentName: function () {
      if(this.selectedItem.departmentPath.length < 1) return "";
      return this.selectedItem.departmentPath[0].name;
    },
    currentDepartmentId: function () {
      if(this.selectedItem.departmentPath.length < 1) return "";
      return this.selectedItem.departmentPath[0].id
    },
    totalFixed: function () {
      if (this.errorMessages.length < 1) return "";
      return this.errorMessages.filter(x => x.fixedDate !== null).length
    },
    totalErrors: function () {
      if (this.errorMessages.length < 1) return "";
      return this.errorMessages.filter(x => x.fixedDate === null).length;
    },
  },
}
</script>

<style scoped>

</style>
