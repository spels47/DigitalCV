<template>
  <v-card :loading="loading">
    <v-card-title>
      <v-icon class="mr-2" color="red">mdi-handshake</v-icon>
      ERP cleanup helper
      <v-spacer />
    </v-card-title>
    <v-card-subtitle>This tool lets you to check the status of a contract number in BusinessCentral, SubscriptionService and ETS in one view</v-card-subtitle>
    <v-card-actions>
      <div>
        <v-progress-linear indeterminate color="black" v-if="snSearchLoading"></v-progress-linear>
        <v-text-field class="ml-4 mr-4 d-inline-flex" v-model="serialNumberToSearchFor" label="Find contracts by SN" clearable clear-icon="mdi-close-circle-outline"></v-text-field>
        <v-btn class="primary ml-4 mr-4 d-inline-flex" @click="getSubscriptionsBySerialNumber()" :disabled="snSearchLoading">Find subscriptions</v-btn>
        <div v-if="contractsForSerialNumber" class="d-inline-flex">
          <v-chip v-for="contract in contractsForSerialNumber"
                  :key="contract.subscriptionId"
                  :color="contract.terminationDate ? 'error' : 'success'"
                  @click="contractNoToSearchFor = contract.subscriptionId"
                  v-tooltippy="`TerminationDate: ${contract.terminationDate} <br/> SubscriptionDate: ${contract.subscriptionStartDate}`"
                  class="ml-2"
          >
            {{contract.subscriptionId}}
          </v-chip>
        </div>
        <div v-if="contractsForSerialNumber && contractsForSerialNumberIsInsane()" class="ml-2 d-inline-flex" v-tooltippy="'More than one active subscription on a serial number is usually wrong <br/> but it can be okay if it is a Kubota subscription'">🤔</div>
        <div v-if="contractsForSerialNumber && contractsForSerialNumber.length === 0" class="ml-2 d-inline-flex">No subscriptions found</div>
      </div>
    </v-card-actions>
    <v-divider></v-divider>
    <v-card-actions>
        <v-text-field class="ml-4 mr-4" v-model="contractNoToSearchFor" label="Input the contract number" clearable clear-icon="mdi-close-circle-outline"></v-text-field>
        <v-btn class="primary ml-4 mr-4" @click="getContractNoInformation()" :disabled="loading">Get info</v-btn>
    </v-card-actions>
    <v-spacer></v-spacer>
    <v-sheet elevation="0" class="ma-4" v-if="hasData">
      <v-row>
        <v-col :sm="12" :md="12" :lg="12" v-if="obviousErrors">
          <v-subheader class="error--text">Obvious errors:</v-subheader>
          <json-pretty-printer class="max-and-scroll" :object="obviousErrors"></json-pretty-printer>
        </v-col>
        <v-col :sm="12" :md="6" :lg="6" v-if="minis">
          <v-subheader>Minis</v-subheader>
          <json-pretty-printer class="max-and-scroll" :object="minis"></json-pretty-printer>
          <div v-for="posObj in miniPositions" :key="posObj.serialNumber">
            <a @click="openMap(posObj.lat, posObj.lng)">Open in map: {{posObj.serialNumber}} last pos: {{posObj.lat}}/{{posObj.lng}}</a>
          </div>
        </v-col>
        <v-col :sm="12" :md="6" :lg="6">
          <v-subheader>ETS contract information</v-subheader>
          <json-pretty-printer class="max-and-scroll" :object="etsContractInformation"></json-pretty-printer>
        </v-col>
        <v-col :sm="12" :md="6" :lg="6">
          <v-subheader>ETS customer information (based on BC clientId/customerId)</v-subheader>
          <json-pretty-printer class="max-and-scroll" :object="etsCustomerInformation"></json-pretty-printer>
        </v-col>
        <v-col :sm="12" :md="12" :lg="12" class="elevation-4">
          <v-subheader>SS information:</v-subheader>
          <v-subheader v-if="!ssObject.subscriptionLog" class="error--text">0 lines</v-subheader>
          <v-text-field
            class="mr-4 ml-4 mb-2"
            v-model="searchSs"
            append-icon="mdi-magnify"
            label="Search"
            single-line
            hide-details
            v-if="ssObject.subscriptionLog"
          ></v-text-field>
          <v-data-table
            v-if="ssObject.subscriptionLog"
            :headers="ssHeaders"
            :items="ssObject.subscriptionLog"
            :items-per-page="100"
            class="elevation-1"
            :loading="loading"
            :search="searchSs"
          >
            <template v-slot:item.createdDate="{ item }"> {{ item.createdDate | datetime }}</template>
            <template v-slot:item.expiredDate="{ item }"> {{ item.expiredDate | datetime }}</template>
          </v-data-table>
        </v-col>
        <v-col :sm="12" :md="12" :lg="12">

        </v-col>
        <v-col :sm="12" :md="12" :lg="12" class="elevation-4">
          <v-subheader>BC information: <span class="ml-4" v-if="bcObject">( CustomerId: {{ bcObject.customerId }}  ClientId: {{ bcObject.clientId }} )</span> </v-subheader>
          <v-subheader v-if="!bcObject.extendedInformations" class="error--text">0 lines</v-subheader>
          <v-text-field
            class="mr-4 ml-4 mb-2"
            v-model="searchBc"
            append-icon="mdi-magnify"
            label="Search"
            single-line
            hide-details
            v-if="bcObject.extendedInformations"
          >
          </v-text-field>
          <v-data-table
            v-if="bcObject.extendedInformations"
            :headers="bcHeaders"
            :items="bcObject.extendedInformations"
            :items-per-page="100"
            class="elevation-1"
            :loading="loading"
            :search="searchBc"
          >
            <template v-slot:item.custom_departmentPlate="{ item }"> {{ item.department }}/{{ item.licensePlateNumber }}</template>
            <template v-slot:item.terminationDate="{ item }"> {{ item.terminationDate | datetime }}</template>
          </v-data-table>
        </v-col>

        <v-col :sm="12" :md="6" :lg="6" v-if="bcScenarioItems">
          <v-subheader>BC scenario information by serial number on current customer</v-subheader>
          <json-pretty-printer class="max-and-scroll" :object="bcScenarioItems"></json-pretty-printer>
        </v-col>

      </v-row>
    </v-sheet>
    <div v-if="roles.DEVELOPER_ASAP" class="pb-4">
      <v-row wrap no-gutters class="ma-0">
        <v-divider class="mt-3"/>
        <span class="mb-4 mr-4 ml-4">Developer tools:</span>
        <v-divider class="mt-3"/>
      </v-row>
      <SetExpireDateOnUnit class="ma-4"/>
      <ReEvaluateDatasourceDepartmentInfoForErp class="ma-4"/>
      <BatchReEvaluateUnitFeatures class="ma-4"/>
      <SetNewTenantIdOnAssets class="ma-4"/>
      <BatchMoveAssets class="ma-4"/>
    </div>
  </v-card>
</template>

<script>
import axios from "@/axios-client";
import JsonPrettyPrinter from "@/components/JsonPrettyPrinter"
import SetExpireDateOnUnit from "@/views/PersonalView/ErpCleanupTools/SetExpireDateOnUnit"
import ReEvaluateDatasourceDepartmentInfoForErp from "@/views/PersonalView/ErpCleanupTools/ReEvaluateDatasourceDepartmentInfoForErp"
import BatchReEvaluateUnitFeatures from "@/views/PersonalView/ErpCleanupTools/BatchReEvaluateUnitFeatures"
import SetNewTenantIdOnAssets from "@/views/PersonalView/ErpCleanupTools/SetNewTenantIdOnAssets"
import BatchMoveAssets from "@/views/PersonalView/ErpCleanupTools/BatchMoveAssets"
export default {
  name: "ErpCleanupHelpers",
  components: {
    BatchMoveAssets,
    SetNewTenantIdOnAssets,
    BatchReEvaluateUnitFeatures,
    ReEvaluateDatasourceDepartmentInfoForErp,
    SetExpireDateOnUnit,
    JsonPrettyPrinter
  },
  data(){
    return {
      snSearchLoading: false,
      loading: false,
      searchSs: '',
      searchBc: '',
      contractNoToSearchFor: '',
      bcObject: null,
      ssObject: null,
      etsContractInformation: null,
      etsCustomerInformation: null,
      errorLogItems: null,
      ssHeaders: [
        { text: "clientId", value: "clientId" },
        { text: "customerId", value: "customerId" },
        { text: "contractNumber", value: "contractNumber" },
        { text: "serialNumber", value: "serialNumber" },
        { text: "subscriptionName", value: "subscriptionName" },
        { text: "addonSerialNumber", value: "addonSerialNumber" },
        { text: "createdDate", value: "createdDate" },
        { text: "creationTrigger", value: "creationTrigger" },
        { text: "expiredDate", value: "expiredDate" },
        { text: "expirationTrigger", value: "expirationTrigger" },
      ],
      bcHeaders: [
        { text: "itemNumber", value: "itemNumber" },
        { text: "itemDescription", value: "itemDescription" },
        { text: "extendedInformationId", value: "extendedInformationId" },
        { text: "subscriptionId", value: "subscriptionId" },
        { text: "serialNumber", value: "serialNumber" },
        { text: "department/plate", value: "custom_departmentPlate" },
        { text: "linkedId", value: "linkedId" },
        { text: "terminationDate", value: "terminationDate" },
        { text: "scenarioCounter", value: "scenarioCounter" },
        { text: "rdyForBackendSync", value: "rdyForBackendSync" },
      ],
      bcScenarioItems: null,
      obviousErrors: null,
      contractsForSerialNumber: null,
      serialNumberToSearchFor: '',
      pendingHotSwaps: null,
      minis: null,
      miniPositions: []
    }
  },
  mounted() {
    let lastSearchedForContractNo = window.localStorage.getItem("erp-cleanup-helpers-last-searched-for-contractNo")
    if(lastSearchedForContractNo){
      this.contractNoToSearchFor = lastSearchedForContractNo
    }
    let lastSearchedForSerialNumber = window.localStorage.getItem("erp-cleanup-helpers-last-searched-for-serialNumber")
    if(lastSearchedForSerialNumber){
      this.serialNumberToSearchFor = lastSearchedForSerialNumber
    }
  },
  computed: {
    hasData(){
      return !this.loading && (this.bcObject || this.ssObject || this.etsContractInformation || this.etsCustomerInformation)
    },
    canExpandView(){
      return !this.$route.path.includes('erp-cleanup-helpers')
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
  },
  methods : {
    async getContractNoInformation() {
      this.loading = true
      this.resetData()

      window.localStorage.setItem("erp-cleanup-helpers-last-searched-for-contractNo", this.contractNoToSearchFor)

      let bcPromise = this.getBcSubscriptionInfo(this.contractNoToSearchFor)
      let ssPromise = this.getSsSubscriptionInfo(this.contractNoToSearchFor)
      let etsPromise = this.getEtsContractInformation(this.contractNoToSearchFor)
      let errorLogItemsPromise = this.getErrorLogItems(this.contractNoToSearchFor)

      try{
        await Promise.all([bcPromise, ssPromise, etsPromise, errorLogItemsPromise])
      }catch (ex){
        this.loading = false
        return;
      }

      if(this.bcObject?.clientId && this.bcObject?.customerId){
        await this.getEtsCustomerInformation(this.bcObject.clientId, this.bcObject.customerId)
      }
      this.loading = false
      // Do stuff with the data now
      if(this.bcObject?.clientId && this.bcObject?.customerId){
        let distinctSerialNumbers = this.getDistinctSerialNumbersFromBcObject(this.bcObject)
        await this.evaluatePendingHotSwapsForSerialNumbers(distinctSerialNumbers)
        await this.evaluateMinisForSerialNumbers(distinctSerialNumbers)
        await this.getBcScenarioItemsForSerialNumbers(this.bcObject.clientId, this.bcObject.customerId, distinctSerialNumbers)
      }
      this.findObviousErrors()

    },
    resetData(){
      this.bcObject = null;
      this.ssObject = null;
      this.etsContractInformation = null;
      this.etsCustomerInformation = null
      this.bcScenarioItems = null
      this.pendingHotSwaps = null
      this.minis = null
      this.miniPositions = []
      this.obviousErrors = null
      this.errorLogItems = null
    },
    async getBcSubscriptionInfo(contractNo) {
      try {
        let res = await axios.get(`/api/erp/cleanup/bc/${contractNo}`)
        this.bcObject = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Call to get BC data failed', icon: 'mdi-alert-circle', type: 'error'});
      }
    },
    async getSsSubscriptionInfo(contractNo) {
      try {
        let res = await axios.get(`/api/erp/cleanup/ss/${contractNo}`)
        this.ssObject = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Call to get SS data failed', icon: 'mdi-alert-circle', type: 'error'});
      }
    },
    async getEtsContractInformation(contractNo) {
      try {
        let res = await axios.get(`/api/erp/cleanup/ets/contract/${contractNo}`)
        if(res.status === 204){
          this.etsContractInformation = null
          return
        }
        this.etsContractInformation = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Call to get ETS contract data failed', icon: 'mdi-alert-circle', type: 'error'});
      }

    },
    async getEtsCustomerInformation(clientId, customerId) {
      try {
        let res = await axios.get(`/api/erp/cleanup/ets/customer/${clientId}/${customerId}`)
        this.etsCustomerInformation = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Call to get ETS customer data failed', icon: 'mdi-alert-circle', type: 'error'});
      }
    },
    async getErrorLogItems(contractNo) {
      try {
        let res = await axios.get(`/api/erp/cleanup/error-queues/contract/${contractNo}`)
        this.errorLogItems = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Call to get error log items failed', icon: 'mdi-alert-circle', type: 'error'});
      }
    },
    findObviousErrors(){
      let bcErrors = []
      if(this.bcObject?.extendedInformations){
        this.bcObject.extendedInformations.forEach(line => {
          if(line.itemDescription?.startsWith('Line not found')){
            bcErrors.push(line.itemDescription)
          }
        })
        if(this.bcObject.extendedInformations.some(line => line.rdyForBackendSync === false)){
          bcErrors.push('Contains lines where rdyForBackendSync == false')
        }
      }
      if(bcErrors.length > 0) {
        if(this.obviousErrors == null) this.obviousErrors = {}
        this.obviousErrors.bcErrors = bcErrors
      }

      let etsErrors = []
      if(this.etsContractInformation && this.etsCustomerInformation?.length > 0){
        let topLevelCustomer = this.etsCustomerInformation.sort((a,b) => a.aktorLevel - b.aktorLevel)[0]
        if(this.etsContractInformation.navClientId !== topLevelCustomer.navClientId || this.etsContractInformation.navisionCustomerId !== topLevelCustomer.navisionCustomerId){
          etsErrors.push('Unit is not on the correct customer in ETS (navClientId/navisionCustomerId)')
          if(!this.etsContractInformation.aktorCpath.includes(topLevelCustomer.aktorCpath)){
            etsErrors.push('Unit cPath is not within from customer cPath')
          }
        }
      }
      if(!this.etsCustomerInformation || this.etsCustomerInformation.length === 0){
        etsErrors.push('No customer found in ETS matching this ERP customer')
      }
      if(etsErrors.length > 0) {
        if(this.obviousErrors == null) this.obviousErrors = {}
        this.obviousErrors.etsErrors = etsErrors
      }

      if(this.pendingHotSwaps?.length > 0){
        if(this.obviousErrors == null) this.obviousErrors = {}
        this.obviousErrors.pendingHotSwaps = this.pendingHotSwaps.map(x => `Pending HotSwap: ${x.oldSerialNumber} -> ${x.newSerialNumber}`)
      }

      if(this.errorLogItems?.length > 0){
        if(this.obviousErrors == null) this.obviousErrors = {}
        this.obviousErrors.errorLogItems = this.errorLogItems.map(x => `${x.queueName}: ${x.messages.join(';')}`)
      }
    },
    async getSubscriptionsBySerialNumber() {
      window.localStorage.setItem("erp-cleanup-helpers-last-searched-for-serialNumber", this.serialNumberToSearchFor)
      this.contractsForSerialNumber = null
      this.snSearchLoading = true
      try {
        let res = await axios.get(`/api/erp/cleanup/bc/subscriptions/${this.serialNumberToSearchFor}`)
        this.contractsForSerialNumber = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {
          text: 'Call to get BC subscriptions by serialNumber failed',
          icon: 'mdi-alert-circle',
          type: 'error'
        });
      }
      this.snSearchLoading = false
    },
    getDistinctSerialNumbersFromBcObject(bcObject){
      let distinctSerialNumbers = []
      bcObject?.extendedInformations.forEach(line => {
        if(!line.serialNumber) return
        if(!distinctSerialNumbers.includes(line.serialNumber)){
          distinctSerialNumbers.push(line.serialNumber)
        }
      })
      return distinctSerialNumbers
    },
    async evaluatePendingHotSwapsForSerialNumbers(distinctSerialNumbers){
      this.pendingHotSwaps = []
      for (const sn of distinctSerialNumbers) {
        let res = await this.getPendingHotSwapsForSerialNumber(sn)
        if(res) this.pendingHotSwaps.push(res)
      }
    },
    async getPendingHotSwapsForSerialNumber(serialNumber){
      try {
        let res = await axios.get(`/api/erp/cleanup/ss/hotSwaps/${serialNumber}`)
        return res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {
          text: 'Call to get pending HotSwaps failed',
          icon: 'mdi-alert-circle',
          type: 'error'
        });
      }
      return null
    },
    async evaluateMinisForSerialNumbers(distinctSerialNumbers){
      let minilist = []
      for (const sn of distinctSerialNumbers) {
        if(sn?.startsWith('MUM') || sn?.startsWith('AM')){
          let res = await this.getMini(sn)
          if(res) {
            minilist.push(res)
            this.miniPositions.push({
              serialNumber: res.abaxMiniSerialNo,
              lat: res.positionLat,
              lng: res.positionLon
            })
          }
        }
      }
      if(minilist.length > 0){
        this.minis = minilist
      }
    },
    async getMini(serialNumber){
      try {
        let res = await axios.get(`/api/erp/cleanup/mini/${serialNumber}`)
        return res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {
          text: 'Call to get mini failed',
          icon: 'mdi-alert-circle',
          type: 'error'
        });
      }
      return null
    },
    openMap(lat, lng) {
      window.open(`https://www.google.com/maps/place/${lat},${lng}`);
    },
    async getBcScenarioItemsForSerialNumbers(clientId, customerId, distinctSerialNumbers) {
      try {
        let res = await axios.get(`/api/erp/cleanup/bc/scenarios/${clientId}/${customerId}`)
        if(!res.data || res.data.length === 0) return;

        let temp = []
        res.data.forEach(item => {
          if(distinctSerialNumbers.includes(item.oldSerialNumber) || distinctSerialNumbers.includes(item.newSerialNumber)){
            if(temp.some(x => x.id === item.id)) return
            temp.push(item)
          }
        })

        if(temp.length === 0) return
        this.bcScenarioItems = temp
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Call to get ETS customer data failed', icon: 'mdi-alert-circle', type: 'error'});
      }
    },
    contractsForSerialNumberIsInsane(){
      if(this.contractsForSerialNumber.length <= 1) return false
      let activeCount = 0
      this.contractsForSerialNumber.forEach(x => {
        if(!x.terminationDate) activeCount++
      })
      if(activeCount > 1) return true
      return false
    }
  }
}
</script>

<style scoped>
.max-and-scroll{
  max-height: 1000px;
  overflow-y: auto;
}
.expand-icon{
  position: absolute;
  top: 0;
  right: 0;
  margin: 4px;
}
</style>
