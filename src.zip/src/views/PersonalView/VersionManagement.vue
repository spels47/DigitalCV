<template>
  <v-card class="ma-8">
    <v-card-title>
      <span>App version management</span>
    </v-card-title>
    <v-divider></v-divider>
    <v-row>
      <v-col cols="12">
        <v-list-item>
          <v-list-item-subtitle>
            <div>Current highest app versions in production:</div>
          </v-list-item-subtitle>
        </v-list-item>
        <v-list-item class="ml-4">
          <v-list-item-subtitle>
            <div>Android: {{productionAppVersions.androidVersion}}</div>
          </v-list-item-subtitle>
        </v-list-item>
        <v-list-item class="ml-4">
          <v-list-item-subtitle>
          <div>Apple: {{productionAppVersions.appleVersion}}</div>
          </v-list-item-subtitle>
        </v-list-item>
      </v-col>
    </v-row>
    <v-divider></v-divider>
    <v-sheet elevation="0">
      <v-subheader>App version rules</v-subheader>
      <v-data-table
        :headers="headers"
        :items="rulesList"
        :items-per-page="15"
        class="elevation-1"
        :loading="loading"
        loading-text="Loading usage log list"
        :search="search"
        :custom-filter="customFilter"
      >
        <template v-slot:item.createdAt="{ item }">
          <span>{{ item.createdAt | datetime }}</span>
        </template>
        <template v-slot:item.remove="{ item }" >
          <div @click="rowClickDelete(item)" class="hover-class">
            <v-icon color="error">mdi-delete-forever</v-icon>
          </div>
        </template>
      </v-data-table>
      <v-list-item v-if="!dialog">
        <v-btn class="secondary mx-auto" @click="dialog = true">Create a new rule</v-btn>
      </v-list-item>
    </v-sheet>

    <ConfirmDialog ref="confirm"></ConfirmDialog>

    <v-dialog v-model="dialog" v-if="dialog" max-width="700px">
      <v-row no-gutters>
        <v-col cols="lg-12">
          <v-list>
            <v-list-item>
              <v-list-item-content>
                <v-list-item-title class="headline">
                  <span>Create a new app version rule</span>
                </v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </v-list>
        </v-col>
        <v-col cols="lg-12">
          <v-list>
            <v-row wrap no-gutters class="ma-0">
              <v-divider class="mt-3"/>
              <span class="mb-4 mr-4 ml-4">Fill in the details</span>
              <v-divider class="mt-3"/>
            </v-row>
            <v-list-item>
              <v-list-item-subtitle>
                <div>App type</div>
              </v-list-item-subtitle>
              <v-btn-toggle color="secondary" label="App type" v-model="newRule.appType" tile group>
                <v-btn value="android">Android</v-btn>
                <v-btn value="apple">Apple</v-btn>
              </v-btn-toggle>
            </v-list-item>
            <v-list-item>
              <v-list-item-subtitle>
                <div>Rule type</div>
              </v-list-item-subtitle>
              <v-btn-toggle color="secondary" v-model="newRule.ruleType" tile group>
                <v-btn value="forceUpgrade">ForceUpgrade</v-btn>
                <v-btn value="suggestUpgrade">SuggestUpgrade</v-btn>
              </v-btn-toggle>
            </v-list-item>
            <v-list-item>
              <v-text-field label="Version from" v-model="newRule.appVersionFrom"/>
            </v-list-item>
            <v-list-item>
              <v-text-field label="Version to" v-model="newRule.appVersionTo"/>
            </v-list-item>
            <v-list-item>
              <v-text-field label="Reason" v-model="newRule.reason"/>
            </v-list-item>
            <v-list-item>
              <div>
                <div class="mb-2"><v-icon class="mr-2">mdi-information</v-icon>Information:</div>
                <ul>
                  <li>The rules will be applied to all versions between from/to, including the from/to versions</li>
                  <li>In the case there are a SuggestUpdate and a ForceUpdate rule for the same version, the force update rule will win</li>
                  <li>The rules are cached for 10 minutes in the mobile API (in-memory cache)</li>
                  <li>If possible you should wait with adding the rules for some days after releasing a new version, thus allowing the appstore's auto-update to update the app without any user intervention</li>
                </ul>
              </div>
            </v-list-item>
            <v-list-item class="mt-4">
              <v-btn class="secondary mx-auto" :disabled="!isValidNewRule" @click="createNewRule">Create it</v-btn>
            </v-list-item>
          </v-list>
        </v-col>
      </v-row>
    </v-dialog>
  </v-card>
</template>

<script>
import ConfirmDialog from "@/components/widgets/dialogs/ConfirmDialog"
import axios from "@/axios-client"

export default {
  name: "VersionManagement",
  components: {
    ConfirmDialog
  },
  data(){
    return {
      productionAppVersions: {},
      rulesList: [],
      data: [],
      search: '',
      loading: false,
      headers: [
        { text: 'AppType', value: 'appType' },
        { text: 'RuleType', value: 'ruleType' },
        { text: 'AppVersionFrom', value: 'appVersionFrom' },
        { text: 'AppVersionTo', value: 'appVersionTo' },
        { text: 'CreatedAt', value: 'createdAt' },
        { text: 'CreatedBy', value: 'createdBy' },
        { text: 'Reason', value: 'reason' },
        { text: '', value: 'remove' },
      ],
      dialog: false,
      newRule: {}
    }
  },
  async mounted() {
    await this.GetVisitorsHighestAppVersion();
    await this.GetAppVersionRules();
  },
  methods: {
    async GetVisitorsHighestAppVersion(){
      try {
        let res = await axios.get(`/api/version-management/highest-app-versions`)
        this.productionAppVersions = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Call to get current app versions failed', icon: 'mdi-alert-circle', type: 'error'});
      }
    },
    async GetAppVersionRules(){
      try {
        let res = await axios.get(`/api/version-management/rules`)
        this.rulesList = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Call to get app version rules failed', icon: 'mdi-alert-circle', type: 'error'});
      }
    },
    async AddAppVersionRule(newRule){
      try {
        await axios.post(`/api/version-management/rules`, newRule)
        this.newRule = {}
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Failed to create new app version rule', icon: 'mdi-alert-circle', type: 'error'});
      }
    },
    async DeleteAppVersionRule(id){
      try {
        await axios.delete(`/api/version-management/rules/${id}`)
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Call to get app version rules failed', icon: 'mdi-alert-circle', type: 'error'});
      }
    },
    async rowClickDelete(item){
      let result = await this.$refs.confirm.open('Delete rule?', 'Are you sure? 😅', { width: 500, confirmLabel: `Confirm`});
      if(result){
        await this.DeleteAppVersionRule(item.id)
        await this.GetAppVersionRules()
      }
    },
    async createNewRule() {
      await this.AddAppVersionRule(this.newRule)
      await this.GetAppVersionRules()
      this.dialog = false
    },
    IsValidVersionNumber(versionNumber) {
      if(!versionNumber || versionNumber.length < 5) return false;
      let splitNr = versionNumber.split('.');
      if(splitNr.length !== 3) return false;
      splitNr.forEach(function (entry) {
        if(isNaN(entry))return false;
        if(parseInt(entry) < 0 || parseInt(entry) > 999) return false;
      });
      return true;
    },
    customFilter(value, search, item) {
      search = search.toString().toLowerCase();
      return Object.keys(item).some(propName => {
        return item[propName]
          ?.toString()
          .toLowerCase()
          .includes(search);
      });
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
    isValidNewRule(){
      if(!this.newRule) return false;
      if(!this.newRule.appType) return false;
      if(!this.newRule.ruleType) return false;
      if(!this.newRule.appVersionFrom) return false;
      if(!this.newRule.appVersionTo) return false;
      if(!this.IsValidVersionNumber(this.newRule.appVersionFrom) || !this.IsValidVersionNumber(this.newRule.appVersionTo)) return false;
      return true;
    }
  },
}
</script>

<style scoped>
.hover-class{
  cursor: pointer;
}
</style>
