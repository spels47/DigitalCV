<template>
  <v-container fluid>
    <v-card>
      <v-card-title>
        <v-icon class="mr-2" color="red">mdi-swap-horizontal-circle</v-icon>
        Hot-swaps pending
        <v-spacer />
      </v-card-title>
      <v-card-subtitle>This list shows the current hot-swaps that are pending, waiting for the new unit to deliver position</v-card-subtitle>
      <v-sheet elevation="0">
        <v-text-field
          class="mr-4 ml-4"
          v-model="search"
          append-icon="mdi-magnify"
          label="Search"
          single-line
          hide-details
        ></v-text-field>
        <v-data-table
          :headers="headers"
          :items="data"
          :items-per-page="5"
          class="elevation-1"
          :loading="loading"
          loading-text="Loading list of hot-swaps pending... "
          :search="search"
          :custom-filter="customFilter"
        >
          <template v-slot:item.swapReceivedDate="{ item }">
            <span>{{ item.swapReceivedDate | datetime }}</span>
          </template>
          <template v-slot:item.departmentPath="{ item }">
            <div class="clickable" @click="openCustomerOnUnit(item)">
              <DepartmentPath :department-path="item.departmentPath"></DepartmentPath>
            </div>
          </template>
          <template v-slot:item.delete="{ item }">
            <v-btn color="error" @click.stop="deleteHotSwap(item)">Delete</v-btn>
          </template>
          <template v-slot:item.force="{ item }">
            <v-btn color="warning" @click.stop="forceHotSwap(item)">Force</v-btn>
          </template>
        </v-data-table>
      </v-sheet>
      <ConfirmDialog ref="confirm"></ConfirmDialog>
    </v-card>
  </v-container>
</template>

<script>
import axios from "@/axios-client"
import DepartmentPath from "@/components/DepartmentPath"
import ConfirmDialog from "@/components/widgets/dialogs/ConfirmDialog"
export default {
  name: "PendingHotSwaps",
  data(){
    return {
      search: '',
      loading: true,
      data: [],
      headers: [
        { text: 'Id', value: 'id' },
        { text: 'Swap received date', value: 'swapReceivedDate' },
        { text: 'Days passed', value: 'daysSinceReceived' },
        { text: 'Old serial number', value: 'oldSerialNumber' },
        { text: 'New serial number', value: 'newSerialNumber' },
        { text: 'Customer', value: 'departmentPath' },
        { text: 'Erp customer Id', value: 'customerId' },
        { text: 'Erp client Id', value: 'clientId' },
      ],
      intervalHolder: null
    }
  },
  async mounted() {
    if(this.$store.state.currentUserRoles['DEVELOPER_ASAP']) {
      this.headers.push({ text: 'Delete', value: 'delete' })
      this.headers.push({ text: 'Force', value: 'force' })
    }
    await this.refreshData()
    this.intervalHolder = setInterval(() => {
      this.refreshData()
    }, 60000)
  },
  beforeDestroy() {
    clearInterval(this.intervalHolder)
  },
  methods: {
    async refreshData(){
      this.loading = true
      let res = await axios.get("/api/subscription/PendingHotSwaps")
      this.data = res.data
      this.loading = false
    },
    openCustomerOnUnit(item){
      this.$router.push({ name: "customer", params: { id: item.departmentPath[0].id }, query: { activeTab: '4', type: 'simcard', id: item.oldSerialNumber } })
    },
    customFilter(value, search, item) {
      search = search.toString().toLowerCase();
      return Object.keys(item).some(propName => {
        if(item.departmentPath[0]?.name.toLowerCase().includes(search)) return true;

        return item[propName]
          ?.toString()
          .toLowerCase()
          .includes(search);
      });
    },
    async deleteHotSwap(item) {
      let result = await this.$refs.confirm.open('Delete hot-swap?', 'This is not recommended 😄', { width: 500, confirmLabel: `I know what i'm doing`});
      if(result) {
        this.loading = true;
        try {
          await axios.delete(`/api/subscription/PendingHotSwaps/${item.id}`)
          await this.$store.dispatch("audit", { source: "PendingHotSwaps", entityId: item.id, message: "PendingHotSwap deleted", oldValue: JSON.stringify(item) });
        } catch (ex) {
          this.$eventBus.$emit('alert', {template: 'api-error'})
        }
        await this.refreshData();
      }
    },
    async forceHotSwap(item) {
      let result = await this.$refs.confirm.open('Force hot-swap?', 'This is not recommended 😄', { width: 500, confirmLabel: `I know what i'm doing`});
      if(result) {
        this.loading = true;
        try {
          await axios.post(`/api/subscription/PendingHotSwaps/${item.id}/force`)
          await this.$store.dispatch("audit", { source: "PendingHotSwaps", entityId: item.id, message: "PendingHotSwap forced", oldValue: JSON.stringify(item) });
        } catch (ex) {
          this.$eventBus.$emit('alert', {template: 'api-error'})
        }
        await this.refreshData();
      }
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
  },
  components: {
    ConfirmDialog,
    DepartmentPath
  }
}
</script>

<style scoped>
.clickable{
  cursor: pointer;
}
</style>
