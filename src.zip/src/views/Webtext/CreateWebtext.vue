<template>
  <v-row no-gutters>
    <v-progress-linear indeterminate color="black" v-if="sidebarLoading"></v-progress-linear>
    <v-col cols="12">
      <v-list>
        <v-list-item>
          <v-list-item-content>
            <v-list-item-title class="headline">
              <span>Create a new webtext</span>
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-col>
    <v-col cols="12" v-if="!created">
      <v-list>
        <v-row wrap no-gutters class="ma-0">
          <v-divider class="mt-3"/>
          <span class="mb-4 mr-4 ml-4">Fill in the details</span>
          <v-divider class="mt-3"/>
        </v-row>
        <v-list-item>
          <v-text-field label="Name of the new webtext" v-model="name"/>
        </v-list-item>
        <v-list-item>
          <v-text-field label="Text in english" v-model="textInEnglish"/>
        </v-list-item>
        <v-list-item>
          <v-textarea label="Description" v-model="description" />
        </v-list-item>
        <v-list-item>
          <v-btn class="secondary mx-auto" @click="createText">Create it!</v-btn>
        </v-list-item>
      </v-list>
    </v-col>
    <v-col cols="12" v-if="created">
      <v-row wrap no-gutters class="ma-0">
        <v-divider class="mt-3"/>
        <span class="mb-4 mr-4 ml-4">The webtext is being created</span>
        <v-divider class="mt-3"/>
      </v-row>
      <v-list>
        <v-list-item>
          <v-btn class="secondary mx-auto" @click="resetView">Need to create another</v-btn>
        </v-list-item>
      </v-list>
    </v-col>
  </v-row>
</template>

<script>
import axios from "@/axios-client"

export default {
  name: "CreateWebtext",
  data() {
    return {
      name: '',
      textInEnglish: '',
      description: '',
      created: false,
      sidebarLoading: false
    }
  },
  methods: {
    async createText() {
      if(this.loading) return;
      this.sidebarLoading = true;
      try {
        await axios.post(`/api/webtext/module/create`, { name: this.name, textInEnglish: this.textInEnglish, description: this.description });
        await this.$store.dispatch("audit", { source: "webtext", entityId: this.name, message: "Webtext created", newValue: this.textInEnglish });
        this.created = true;
      } catch (ex) {
        if (ex?.response?.status === 400) {
          this.$eventBus.$emit('alert', {
            text: `Create webtext failed (might be that a text with that name already exists) `,
            icon: 'mdi-alert-circle',
            type: 'error'
          });
        } else {
          this.$eventBus.$emit('alert', {text: `Create webtext failed`, icon: 'mdi-alert-circle', type: 'error'});
        }
      } finally {
        this.sidebarLoading = false;
      }
    },
    resetView(){
      this.created = false
      this.name = ''
      this.textInEnglish = ''
      this.description = ''
    }
  }
}
</script>

<style scoped>

</style>
