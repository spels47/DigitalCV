<template>
  <v-row no-gutters>
    <v-progress-linear indeterminate color="black" v-if="sidebarLoading"></v-progress-linear>
    <v-col cols="12">
      <v-list>
        <v-list-item>
          <v-list-item-content>
            <v-list-item-title class="headline">
              <span>Edit webtext</span>
            </v-list-item-title>
            <v-list-item-subtitle>
              {{ selectedModule }}
            </v-list-item-subtitle>
            <v-list-item-subtitle class="mt-1" v-if="moduleOwner">
              Created by: {{ moduleOwner }}
            </v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-col>
    <v-col cols="12">
      <v-list v-if="sidebarData">
        <v-row wrap no-gutters class="ma-0">
          <v-divider class="mt-3"/>
          <span class="mb-4 mr-4 ml-4">Texts</span>
          <v-divider class="mt-3"/>
        </v-row>
        <v-list-item v-for="webtext in sidebarData.moduleTexts" :key="webtext.language">
          <v-text-field @change="updateText(webtext.id, webtext.text)"
                        :readonly="!roles.WEBTEXT_EDIT"
                        :label="getTextInputLabelText(webtext.language)"
                        v-model="webtext.text"
          />
          <v-icon v-if="currentPage === 'todo-webtext' && webtext.language === selectedTodoLanguage" @click="updateApproval(webtext.id, true)" v-tooltippy="`Approve text`">mdi-check-decagram</v-icon>
          <v-icon v-if="currentPage === 'edit-webtext'" @click="updateApproval(webtext.id, false)" v-tooltippy="`Send to review`">mdi-help-rhombus</v-icon>
        </v-list-item>
        <v-row wrap no-gutters class="ma-0">
          <v-divider class="mt-3"/>
          <span class="mb-4 mr-4 ml-4">Description</span>
          <v-divider class="mt-3"/>
        </v-row>
        <v-list-item>
          <v-textarea @change="updateDescription(sidebarData.module, sidebarData.description)"
                      :readonly="!roles.WEBTEXT_EDIT"
                      v-model="sidebarData.description"
                      class="ma-0 pa-0"
          />
        </v-list-item>
      </v-list>
    </v-col>
  </v-row>
</template>

<script>
import axios from "@/axios-client"

export default {
  name: "EditWebtext",
  props: {
    selectedModule: String,
    availableLanguages: Array,
    selectedTodoLanguage: String,
    currentPage: String
  },
  data() {
    return {
      sidebarLoading: false,
      sidebarData: null,
      sidebarDataDescription: null,
      moduleOwner: null
    }
  },
  mounted() {
    this.openModuleForEdit(this.selectedModule)
    this.getModuleOwner(this.selectedModule)
  },
  methods: {
    async openModuleForEdit(module) {
      this.sidebarLoading = true
      this.sidebarData = null
      this.selectedModule = module
      try {
        let res = await axios.post(`/api/webtext/module/get`, { module: module})
        this.sidebarData = res.data
        this.sidebarData.module = module
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Getting webtext module failed', icon: 'mdi-alert-circle', type: 'error'});
      } finally {
        this.sidebarLoading = false
      }
    },
    async getModuleOwner(module){
      this.moduleOwner = null
      try {
        let res = await axios.post(`/api/webtext/lookup/module/owner`, { module: module });
        this.moduleOwner = res.data
      } catch (ex) {
        // Suppressing this error
      } finally {
        this.sidebarLoading = false
      }
    },
    async updateText(userInterfaceTextId, text) {
      this.sidebarLoading = true
      try {
        await axios.post(`/api/webtext/module/edit/text`, { userInterfaceTextId: userInterfaceTextId, newText: text})
        await this.$store.dispatch("audit", { source: "webtext", entityId: userInterfaceTextId, message: "Webtext edited", newValue: text });
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Editing webtext failed', icon: 'mdi-alert-circle', type: 'error'});
      } finally {
        this.sidebarLoading = false
      }
    },
    async updateDescription(module, description) {
      this.sidebarLoading = true;
      try {
        await axios.post(`/api/webtext/module/edit/description`, { module: module, description: description })
        await this.$store.dispatch("audit", { source: "webtext", entityId: module, message: "Webtext description edited", newValue: description });
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Editing webtext description failed', icon: 'mdi-alert-circle', type: 'error'});
      } finally {
        this.sidebarLoading = false
      }
    },
    async updateApproval(userInterfaceTextId, approved) {
      this.sidebarLoading = true
      try {
        await axios.post(`/api/webtext/module/update-approval`, { userInterfaceTextId: userInterfaceTextId, isApproved: approved })
        await this.$store.dispatch("audit", { source: "webtext", entityId: userInterfaceTextId, message: "Webtext approval updated", newValue: approved });
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Updating approval state failed', icon: 'mdi-alert-circle', type: 'error'});
      } finally {
        this.sidebarLoading = false
      }
    },
    getTextInputLabelText(languageCode){
      let language = this.availableLanguages.find(x => x.languageCode === languageCode)
      return `${language.languageName} (${language.languageCode})`
    },
  },
  watch: {
    selectedModule(){
      this.openModuleForEdit(this.selectedModule)
      this.getModuleOwner(this.selectedModule)
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
  }
}
</script>

<style scoped>

</style>
