<template>
  <v-container fluid class="pt-0 pl-7 mt-2">
    <BaseSidebar :menuItems="sidebarMenuItems">
      <EditWebtext v-if="currentPage === 'edit-webtext' || currentPage === 'todo-webtext'" :currentPage="currentPage" :available-languages="availableLanguages" :selected-module="selectedModule" :selectedTodoLanguage="selectedTodoLanguage"></EditWebtext>
      <CreateWebtext v-if="currentPage === 'create-webtext'"></CreateWebtext>
    </BaseSidebar>
  <v-card>
    <v-card-title>
      <v-icon class="mr-2">mdi-text-box-search</v-icon>
      Webtexts
      <v-spacer />
    </v-card-title>
    <v-card-text>
      <div></div>
    </v-card-text>
    <v-divider></v-divider>
    <v-card-actions>
      <v-btn-toggle
        v-model="searchBy"
        tile
        group
      >
        <v-btn value="module">
          Module
        </v-btn>
        <v-btn value="text">
          Text
        </v-btn>
      </v-btn-toggle>
      <v-text-field class="ml-4 mr-4" v-on:keyup.enter="search(searchBy, searchString)" v-model="searchString" :label="searchBy === 'text' ? 'Search for a text' : 'Lookup a module'" clearable clear-icon="mdi-close-circle-outline"></v-text-field>
      <v-btn class="primary ml-4 mr-4" @click="search(searchBy, searchString)" :disabled="loading">Search</v-btn>
    </v-card-actions>
    <v-spacer></v-spacer>
    <v-sheet elevation="0" class="ma-4">
      <v-row>
        <v-col :sm="12" :md="12" :lg="12" v-if="searchBy === 'module'">
          <v-data-table
            :headers="moduleSearchResultHeaders"
            :items="moduleSearchResults"
            :items-per-page="15"
            class="elevation-1"
            :loading="loading"
            @click:row="rowClickModule"
          >
          </v-data-table>
        </v-col>
        <v-col :sm="12" :md="12" :lg="12" v-if="searchBy === 'text'">
          <v-data-table
            :headers="textSearchResultHeaders"
            :items="textSearchResults"
            :items-per-page="15"
            class="elevation-1"
            :loading="loading"
            @click:row="rowClickText"
          >
          </v-data-table>
        </v-col>
      </v-row>
      <v-btn color="secondary" fab small class="ma-2 elevation-1" @click="openSidebarForCreate" v-tooltippy="`Create a new webtext`">
        <v-icon>mdi-text-box-plus</v-icon>
      </v-btn>
    </v-sheet>
  </v-card>
  <v-card v-if="todoListShown">
    <v-card-title>
      <v-icon class="mr-2">mdi-text-box-check</v-icon>
      Webtext approval list
      <v-spacer />
    </v-card-title>
    <v-card-text>
      <div></div>
    </v-card-text>
    <v-divider></v-divider>
    <v-card-actions>
      <v-select
        v-model="selectedTodoLanguage"
        :items="todoListLanguages"
        @change="todoListLanguageChanged(selectedTodoLanguage)"
        item-text="languageName"
        item-value="languageCode"
        label="Language"
        class="ml-4 mr-4"
      ></v-select>
    </v-card-actions>
    <v-spacer></v-spacer>
    <v-sheet elevation="0" class="ma-4">
      <v-row>
        <v-col :sm="12" :md="12" :lg="12">
          <v-data-table
            :headers="todoListHeaders"
            :items="todoListItems"
            :items-per-page="15"
            class="elevation-1"
            :loading="todoListLoading"
            @click:row="rowClickTodo"
          >
          </v-data-table>
        </v-col>
      </v-row>
    </v-sheet>
  </v-card>
  </v-container>
</template>

<script>
import axios from "@/axios-client"
import BaseSidebar from "@/components/sidebars/BaseSidebar"
import EditWebtext from "@/views/Webtext/EditWebtext"
import CreateWebtext from "@/views/Webtext/CreateWebtext"

export default {
  name: "WebtextView",
  components: {
    BaseSidebar,
    EditWebtext,
    CreateWebtext
  },
  data() {
    return {
      searchBy: 'module',
      searchString: '',
      hasData: false,
      moduleSearchResults: [],
      moduleSearchResultHeaders: [
        { text: "Id", value: "id" },
        { text: "ApplicationIdent", value: "applicationIdent" },
        { text: "NewWebModulIdent", value: "newWebModulIdent" },
        { text: "WebModul", value: "webModul" },
      ],
      textSearchResults: [],
      textSearchResultHeaders: [
        { text: "Module", value: "module" },
        { text: "Text", value: "text" },
        { text: "Language", value: "defaultLanguage" },
        { text: "Text in English", value: "textEnglish" },
      ],
      todoListItems: [],
      todoListHeaders: [
        { text: "Id", value: "userInterfaceTextId" },
        { text: "Module", value: "module" },
        { text: "Text", value: "text" },
        { text: "Language", value: "defaultLanguage" },
        { text: "Description", value: "description" },
      ],
      loading: false,
      sidebarState: true,
      sidebarMenuItems: [],
      expanded: true,
      selectedModule: null,
      sidebarData: null,
      sidebarDataDescription: null,
      availableLanguages: [],
      currentPage: 'edit-webtext',
      todoListShown: false,
      todoListLanguages: [],
      selectedTodoLanguage: '',
      todoListLoading: false
    }
  },
  async mounted() {
    this.searchString = window.localStorage.getItem("webtext-view-last-searched-for-searchString")
    this.searchBy = window.localStorage.getItem("webtext-view-last-searched-for-searchBy") ?? 'module'
    await this.getAvailableLanguages()
    if(this.roles.WEBTEXT_EDIT) { // Might want to hide this and only show a certain language for certain people
      this.todoListShown = true
      this.todoListLanguages = this.availableLanguages
      this.selectedTodoLanguage = window.localStorage.getItem("webtext-view-last-selected-todoList-languageCode") ?? this.todoListLanguages[0].languageCode
      await this.todoListLanguageChanged(this.selectedTodoLanguage)
    }
  },
  methods: {
    search(searchBy, searchString){
      window.localStorage.setItem("webtext-view-last-searched-for-searchString", searchString)
      if(!searchString || searchString.length < 4) {
        this.moduleSearchResults = []
        this.textSearchResults = []
        return
      }
      this.hasData = false
      this.searchResults = []
      if(searchBy === 'module') this._lookupByModule(searchString)
      if(searchBy === 'text') this._searchByText(searchString)
    },
    async _lookupByModule(searchString) {
      this.loading = true
      try {
        let res = await axios.post(`/api/webtext/lookup/module`, {searchString: searchString})
        this.moduleSearchResults = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Search by module failed', icon: 'mdi-alert-circle', type: 'error'});
      } finally {
        this.loading = false
      }
    },
    async _searchByText(searchString) {
      this.loading = true
      try {
        let res = await axios.post(`/api/webtext/search/text`, {searchString: searchString})
        this.textSearchResults = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Search by text failed', icon: 'mdi-alert-circle', type: 'error'});
      } finally {
        this.loading = false
      }
    },
    async rowClickModule(row) {
      this.$store.commit("updateSidebarState", true);
      await this.openSidebarForModule(row.webModul)
    },
    async rowClickText(row) {
      this.$store.commit("updateSidebarState", true);
      await this.openSidebarForModule(row.module)
    },
    async rowClickTodo(row) {
      this.$store.commit("updateSidebarState", true);
      await this.openSidebarForModule(row.module, true)
    },
    async openSidebarForModule(module, isTodoList = null) {
      this.currentPage = isTodoList ? 'todo-webtext' : 'edit-webtext';
      this.sidebarData = null
      this.selectedModule = module
    },
    async getAvailableLanguages() {
      try {
        let res = await axios.get(`/api/webtext/languages/available`)
        this.availableLanguages = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Unable to get list of available languages', icon: 'mdi-alert-circle', type: 'error'});
      }
    },
    getTextInputLabelText(languageCode){
      let language = this.availableLanguages.find(x => x.languageCode === languageCode)
      return `${language.languageName} (${language.languageCode})`
    },
    openSidebarForCreate(){
      this.currentPage = 'create-webtext';
      this.$store.commit("updateSidebarState", true);
    },
    async todoListLanguageChanged(languageCode) {
      window.localStorage.setItem("webtext-view-last-selected-todoList-languageCode", languageCode)
      this.todoListLoading = true
      this.todoListItems = []
      try {
        let res = await axios.get(`/api/webtext/approval/${languageCode}`)
        this.todoListItems = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Unable to get todo-list', icon: 'mdi-alert-circle', type: 'error'});
      } finally {
        this.todoListLoading = false
      }
    }
  },
  watch: {
    searchBy(){
      window.localStorage.setItem("webtext-view-last-searched-for-searchBy", this.searchBy)
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    }
  }
}
</script>

<style scoped>

</style>
