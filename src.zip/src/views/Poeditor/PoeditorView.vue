<template>
  <v-container fluid class="pt-0 pl-7 mt-2">
    <BaseSidebar :menuItems="sidebarMenuItems">
      <EditPoeditor v-if="currentPage === 'edit-poeditor'" 
        :currentPage="currentPage" 
        :availableLanguages="availableLanguages" 
        :selectedTerm="selectedTerm" 
        :selectedTermId="selectedTermId"
        :selectedTermName="selectedTermName"
        :selectedTermContext="selectedTermContext">
      </EditPoeditor>
    </BaseSidebar>
    <v-card>
      <v-card-title>
        <v-icon class="mr-2">mdi-text-box-search</v-icon>
        POEditor
      </v-card-title>
      <v-divider></v-divider>
      <v-card-actions>
        <v-btn-toggle
          v-model="searchBy"
          tile
          group
        >
          <v-btn value="term">
            Term
          </v-btn>
          <v-btn value="text">
            Text
          </v-btn>
          <v-btn value="project">
            Project
          </v-btn>
        </v-btn-toggle>
        <v-text-field class="ml-4 mr-4" v-on:keyup.enter="search(searchBy, searchString)" v-model="searchString" :label="'Search by ' + searchBy" clearable
                      clear-icon="mdi-close-circle-outline"></v-text-field>
        <v-btn class="primary ml-4 mr-4" @click="search(searchBy, searchString)" :disabled="loading">Search</v-btn>
      </v-card-actions>
      <v-spacer></v-spacer>
      <v-sheet elevation="0" class="ma-4">
        <v-row>
          <v-col :sm="12" :md="12" :lg="12" v-if="searchBy === 'term'">
            <v-data-table
              item-key="index"
              :headers="termSearchResultHeaders"
              :items="termSearchResults"
              :items-per-page="15"
              class="elevation-1"
              :loading="loading"
              @click:row="rowClickTerm"
            >
            </v-data-table>
          </v-col>
          <v-col :sm="12" :md="12" :lg="12" v-if="searchBy === 'text'">
            <v-data-table
              item-key="index"
              :headers="textSearchResultHeaders"
              :items="textSearchResults"
              :items-per-page="15"
              class="elevation-1"
              :loading="loading"
              @click:row="rowClickText"
            >
            </v-data-table>
          </v-col>
          <v-col :sm="12" :md="12" :lg="12" v-if="searchBy === 'project'">
            <v-data-table
              item-key="index"
              :headers="projectSearchResultHeaders"
              :items="projectSearchResults"
              :items-per-page="15"
              class="elevation-1"
              :loading="loading"
              @click:row="rowClickProject"
            >
            </v-data-table>
          </v-col>
        </v-row>
      </v-sheet>
    </v-card>
  </v-container>
</template>

<script>
import axios from "@/axios-client"
import BaseSidebar from "@/components/sidebars/BaseSidebar"
import EditPoeditor from "@/views/Poeditor/EditPoeditor"

export default {
  name: "Poeditor",
  components: {
    BaseSidebar,
    EditPoeditor
  },
  data() {
    return {
      searchBy: 'term',
      searchString: '',
      hasData: false,
      termSearchResults: [],
      termSearchResultHeaders: [
        { text: "Project name", value: "name" },
        { text: "Project id", value: "id" },
        { text: "Context", value: "context" },
        { text: "Term", value: "term" },
      ],
      textSearchResults: [],
      textSearchResultHeaders: [
        { text: "Project name", value: "name" },
        { text: "Project id", value: "id" },
        { text: "Context", value: "context" },
        { text: "Term", value: "term" },
      ],
      projectSearchResults: [],
      projectSearchResultHeaders: [
        { text: "Project name", value: "name" },
        { text: "Project id", value: "id" },
        { text: "Context", value: "context" },
        { text: "Term", value: "term" },
      ],
      loading: false,
      sidebarState: true,
      sidebarMenuItems: [],
      expanded: true,
      selectedTerm: null,
      selectedTermId: null,
      selectedTermName: null,
      selectedTermContext: null,
      sidebarData: null,
      sidebarDataDescription: null,
      availableLanguages: [],
      currentPage: 'edit-poeditor',
    }
  },
  async mounted() {
    this.searchString = window.localStorage.getItem("poeditor-view-last-searched-for-searchString")
    this.searchBy = window.localStorage.getItem("poeditor-view-last-searched-for-searchBy") ?? 'term'
    await this.getAvailableLanguages()
  },
  methods: {
    search(searchBy, searchString) {
      window.localStorage.setItem("poeditor-view-last-searched-for-searchString", searchString)
      if (!searchString) {
        this.termSearchResults = []
        this.textSearchResults = []
        return
      }
      this.hasData = false
      this.searchResults = []
      if (searchBy === 'term') this.lookupByTerm(searchString)
      else if (searchBy === 'text') this.searchByText(searchString)
      else if (searchBy === 'project') this.searchByProject(searchString)
    },
    async lookupByTerm(searchString) {
      this.loading = true
      try {
        let res = await axios.get(`/api/poeditor/search/term/${searchString}`)
        this.termSearchResults = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', { text: 'Search by term failed', icon: 'mdi-alert-circle', type: 'error' })
      } finally {
        this.loading = false
      }
    },
    async searchByText(searchString) {
      this.loading = true
      try {
        let res = await axios.get(`/api/poeditor/search/text/${searchString}`)
        this.textSearchResults = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', { text: 'Search by text failed', icon: 'mdi-alert-circle', type: 'error' })
      } finally {
        this.loading = false
      }
    },
    async searchByProject(searchString) {
      this.loading = true
      try {
        let res = await axios.get(`/api/poeditor/search/project/${searchString}`)
        this.projectSearchResults = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', { text: 'Search by project failed', icon: 'mdi-alert-circle', type: 'error' })
      } finally {
        this.loading = false
      }
    },
    async rowClickTerm(row) {
      this.$store.commit("updateSidebarState", row.term)
      await this.openSidebarForTerm(row.term, row.id, row.name, row.context)
    },
    async rowClickText(row) {
      this.$store.commit("updateSidebarState", row.term)
      await this.openSidebarForTerm(row.term, row.id, row.name, row.context)
    },
    async rowClickProject(row) {
      this.$store.commit("updateSidebarState", row.term)
      await this.openSidebarForTerm(row.term, row.id, row.name, row.context)
    },
    async openSidebarForTerm(term, id, name, context) {
      this.currentPage = 'edit-poeditor'
      this.sidebarData = null
      this.selectedTerm = term
      this.selectedTermId = id
      this.selectedTermName = name
      this.selectedTermContext = context
    },
    async getAvailableLanguages() {
      try {
        let res = await axios.get(`/api/poeditor/languages/list`)
        this.availableLanguages = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', { text: 'Unable to get list of available languages', icon: 'mdi-alert-circle', type: 'error' });
      }
    },
    getTextInputLabelText(languageCode) {
      let language = this.availableLanguages.find(x => x.Code === languageCode)
      return `${language.Name} (${language.Code})`
    },
  },
  watch: {
    searchBy() {
      window.localStorage.setItem("poeditor-view-last-searched-for-searchBy", this.searchBy)
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    }
  }
}
</script>
