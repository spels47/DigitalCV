<template>
  <v-row no-gutters>
    <v-progress-linear indeterminate color="black" v-if="sidebarLoading"></v-progress-linear>
    <v-col cols="12">
      <v-list>
        <v-list-item>
          <v-list-item-content>
            <v-list-item-title class="headline">
              <span>Edit Translations</span>
            </v-list-item-title>
            <v-list-item-subtitle>
              {{ selectedTerm }}
            </v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-col>
    <v-col cols="12">
      <v-list v-if="sidebarData">
        <v-row wrap no-gutters class="ma-0">
          <v-divider class="mt-3"/>
          <span class="mb-4 mr-4 ml-4">Texts</span>
          <v-divider class="mt-3"/>
        </v-row>
        <v-list-item v-for="translation in sidebarData.termTranslations" :key="translation.language">
          <v-text-field :readonly="!roles.DEVELOPER_ASAP"
                        :label="getTextInputLabelText(translation.language)"
                        v-model="translation.text"
                        @blur="updateText(translation.text, translation.language)"
          />
        </v-list-item>
        <v-row wrap no-gutters class="ma-0">
          <v-divider class="mt-3"/>
          <span class="mb-4 mr-4 ml-4">Description</span>
          <v-divider class="mt-3"/>
        </v-row>
        <v-list-item>
          <v-textarea 
            :readonly="!roles.DEVELOPER_ASAP"
            v-model="sidebarDataDescription"
            class="ma-0 pa-0"
            @blur="updateDescription()"
          />
        </v-list-item>
      </v-list>
    </v-col>
  </v-row>
</template>

<script>
import axios from "@/axios-client"

export default {
  name: "EditPoeditor",
  props: {
    selectedTerm: String,
    selectedTermId: String,
    selectedTermName: String,
    selectedTermContext: String,
    availableLanguages: Array,
    currentPage: String
  },
  data() {
    return {
      sidebarLoading: false,
      sidebarData: null,
      sidebarDataDescription: null
    }
  },
  methods: {
    async openTermForEdit(term, projectId, name, context) {
      this.sidebarLoading = true
      this.sidebarData = {termTranslations: []}
      this.selectedTerm = term
      this.selectedTermId = projectId
      this.selectedTermName = name
      this.selectedTermContext = context
      try {
        let res = await axios.get(`/api/poeditor/translations/get/${term}/${projectId}`)
        this.sidebarData.termTranslations = res.data
        this.sidebarDataDescription = res.data[0].description
        this.sidebarData.term = term
      } catch (ex) {
        this.$eventBus.$emit('alert', { text: 'Getting poeditor translation failed', icon: 'mdi-alert-circle', type: 'error' });
      } finally {
        this.sidebarLoading = false
      }
    },
    async updateText(text, languageCode) {
      this.sidebarLoading = true
      try {
        await axios.post(`/api/poeditor/term/edit/translation`, { name: this.selectedTermName, context: this.selectedTermContext, term: this.selectedTerm, languageCode: languageCode, termId: this.selectedTermId, newText: text })
        await this.$store.dispatch("audit", { source: "poeditor", entityId: this.selectedTermId, message: "poeditor edited", newValue: text });
      } catch (ex) {
        this.$eventBus.$emit('alert', { text: 'Editing poeditor failed', icon: 'mdi-alert-circle', type: 'error' });
      } finally {
        this.sidebarLoading = false
      }
    },
    async updateDescription() {
      this.sidebarLoading = true;
      try {
        await axios.post(`/api/poeditor/term/edit/description`, { name: this.selectedTermName, term: this.selectedTerm, termId: this.selectedTermId, language: this.sidebarData.termTranslations[0].language, description: this.sidebarDataDescription })
        await this.$store.dispatch("audit", { source: "poeditor", entityId: this.selectedTerm, message: "poeditor description edited", newValue: this.sidebarDataDescription });
      } catch (ex) {
        this.$eventBus.$emit('alert', { text: 'Editing poeditor description failed', icon: 'mdi-alert-circle', type: 'error' });
      } finally {
        this.sidebarLoading = false
      }
    },
    getTextInputLabelText(languageCode) {
      let language = this.availableLanguages.find(x => x.code === languageCode)
      return `${language.name} (${language.code})`
    },
  },
  watch: {
    selectedTerm() {
      this.openTermForEdit(this.selectedTerm, this.selectedTermId, this.selectedTermName, this.selectedTermContext)
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
  }
}
</script>

<style scoped>

</style>
