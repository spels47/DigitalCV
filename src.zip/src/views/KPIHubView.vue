﻿<template>
  <v-container fluid>
  <v-card>
    <v-tabs background-color="black" dark>
      <v-tab
        v-for="t in getTabs()"
        :key="t.id"
        :data-cy="t.data-cy"
        @click="currentTab = t"
      >
        {{ t.text }}
      </v-tab>
      <v-spacer></v-spacer>

      <v-icon v-tooltippy="'Download report'" v-if="showDownloadReportButton" class="pr-2 pl-2" data-cy="kpi-hub-download-report" @click="downloadReport">
        mdi-download-circle
      </v-icon>

      <CountrySelector v-if="selectedTab.selector === 'country'"></CountrySelector>
      <PortfolioTeamSelector v-if="selectedTab.selector !== 'country' && selectedTab.selector !== 'none'" :includeCountry="true"></PortfolioTeamSelector>
    </v-tabs>

    <v-tabs-items v-model="currentTabId">
      <v-tab-item v-for="tab in tabs" :key="tab.id" :value="tab.id">
        <CustomerKPI v-if="tab.id === 0"></CustomerKPI>
        <BasePortfolioStatistics v-if="tab.id === 1" :showTeamDetails="true"></BasePortfolioStatistics>
        <BaseWorklistStatistics v-if="tab.id > 1" :worklistType="worklistType" ></BaseWorklistStatistics>
      </v-tab-item>
    </v-tabs-items>
  </v-card>
  </v-container>
</template>

<script>
import CustomerKPI from "@/components/KPI Hub/CustomerKPI";
import BaseWorklistStatistics from "@/components/KPI Hub/BaseWorklistStatistics";
import CountrySelector from "@/components/widgets/CountrySelector";
import PortfolioTeamSelector from "@/components/widgets/PortfolioTeamSelector";
import BasePortfolioStatistics from "@/components/KPI Hub/BasePortfolioStatistics";
import axios from "@/axios-client";

export default {
  name: "KPIHubView",
  components: {
    BasePortfolioStatistics,
    PortfolioTeamSelector,
    CountrySelector,
    BaseWorklistStatistics,
    CustomerKPI,
  },
  data() {
    return {
      tabs: [
        { id: 0, text: "Customer", userRight: "KPI_HUB_CUSTOMER", "data-cy": "kpi-hub-customer-tab", selector: "country" },
        { id: 1, text: "Portfolio", userRight: "PORTFOLIO_ADMIN", "data-cy": "kpi-hub-portfolio-tab", selector: "portfolio" },
        { id: 2, text: "Welcome Call", userRight: "KPI_HUB_WORKLISTS", "data-cy": "kpi-hub-employee-tab", selector: "country", worklistType: "WelcomeCall"},
        { id: 3, text: "Churn Prevention", userRight: "KPI_HUB_PORTFOLIO_WORKLISTS", "data-cy": "kpi-hub-churn-prediction-tab", selector: "portfolio", worklistType: "ChurnPreventionCall"},
        { id: 4, text: "Renewal Call", userRight: "KPI_HUB_PORTFOLIO_WORKLISTS", "data-cy": "kpi-hub-churn-prediction-tab", selector: "portfolio", worklistType: "RenewalCall" },
        { id: 5, text: "Termination Call", userRight: "KPI_HUB_PORTFOLIO_WORKLISTS", "data-cy": "kpi-hub-churn-prediction-tab", selector: "portfolio", worklistType: "YellowFlaggedCall" },
        { id: 6, text: "New Subscription", userRight: "KPI_HUB_PORTFOLIO_WORKLISTS", "data-cy": "kpi-hub-churn-prediction-tab", selector: "portfolio", worklistType: "NewSubscription" },
        { id: 7, text: "Swap Requests", userRight: "KPI_HUB_WORKLISTS", "data-cy": "kpi-hub-churn-prediction-tab", selector: "none", worklistType: "Swap" }
      ],
      countrySelector: [
        { text: "All", value: "ALL" },
        { text: "Norway", value: "NO" },
        { text: "Sweden", value: "SE" },
        { text: "Finland", value: "FI" },
        { text: "Denmark", value: "DK" },
        { text: "UK", value: "GB" },
        { text: "France", value: "FR"},
        { text: "Belgium", value: "BE" },
        { text: "Netherlands", value: "NL" },
        { text: "Poland", value: "PL" }
      ],
      currentTab: {},
      teamStatistics: {},
      portfolioTeams : [],
      keyAccountTeams : [],

    };
  },
  async mounted() {
    await this.$store.dispatch("PortfolioTeamModule/retrieveAllTeams")
  },
  methods: {
    async downloadReport() {
      let file = await axios.get(`api/customerStatistics/downloadReport?country=${this.defaultCountry}`)
      const anchor = document.createElement('a');
      anchor.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(file.data);
      anchor.target = '_blank';
      anchor.download = 'Report ' + this.defaultCountry + '.csv';
      anchor.click();
    },

    getTabs() {
      let allowedTabs = [];
      this.tabs.forEach(x => {
        if (x.userRight === "" || this.roles[x.userRight]) {
          allowedTabs.push(x);
          if (this.tab === -1) this.tab = x.id
        }
      });
      return allowedTabs;
    }
  },
  computed: {
    showDownloadReportButton() {
      return (this.selectedTab.text === 'Customer' || this.selectedTab.text === 'Portfolio') && this.defaultCountry !== "ALL";
    },
    currentTeam() {
      return this.$store.state.PortfolioTeamModule.currentTeam;
    },
    selectedTab() {
      if(!this.currentTab.id) return this.tabs[0]
      return this.currentTab;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    defaultCountry() {
      return !this.$store.state.userSettings.defaultCountry ? "NO" : this.$store.state.userSettings.defaultCountry;
    },
    username() {
      return this.$store.getters.currentUser?.username;
    },
    worklistType() {
      if(this.tabs[this.currentTabId]?.worklistType)
        return this.tabs[this.currentTabId].worklistType;
      return ""
    },
    currentTabId() {
      if(!this.currentTab.id) return 0;
      return this.currentTab.id;
    },
  }
}
</script>

<style scoped>

</style>
