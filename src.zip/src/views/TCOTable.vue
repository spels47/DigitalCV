﻿<template>
  <v-container fluid>
    <v-card :loading="fetching">
      <v-card-title>
        <span>State of TCO for all countries</span>
        <v-spacer></v-spacer>

        <v-icon v-tooltippy="'Download report'" @click="downloadCsv" class="ml-5">mdi-download-circle</v-icon>
      </v-card-title>

      <v-card-text>
        <v-data-iterator
          :items="items"
          :items-per-page="items.length"
          hide-default-footer
        >
          <template v-slot:default="props">
            <v-row>
              <v-col
                v-for="item in props.items"
                :key="item.name"
                sm="6"
                md="4"
                lg="4"
              >
                <v-card>
                  <v-card-title class="subheading font-weight-bold">
                    <v-icon class="mr-2">mdi-flag-variant</v-icon>
                    {{ mapCountryCodeToName(item.name) }}
                  </v-card-title>

                  <v-divider></v-divider>

                  <v-list>
                    <v-list-item>
                      <v-list-item-avatar>
                        <v-icon>mdi-office-building</v-icon>
                      </v-list-item-avatar>
                      <v-list-item-content>
                        <v-list-item-title>Informed customers:</v-list-item-title>
                      </v-list-item-content>
                      <v-list-item-action-text class="subtitle-1">{{ item.countShowed }}</v-list-item-action-text>
                    </v-list-item>

                    <v-list-item>
                      <v-list-item-avatar>
                        <v-icon>mdi-car</v-icon>
                      </v-list-item-avatar>
                      <v-list-item-content>
                        <v-list-item-title>Cars:</v-list-item-title>
                      </v-list-item-content>
                      <v-list-item-action-text class="subtitle-1">{{ item.carAmount }}</v-list-item-action-text>
                    </v-list-item>

                    <v-list-item>
                      <v-list-item-avatar>
                        <v-icon>mdi-check-circle</v-icon>
                      </v-list-item-avatar>

                      <v-list-item-content>
                        <v-list-item-title>Agreed:</v-list-item-title>
                        <v-list-item-subtitle class="mt-2">
                          <v-icon class="mb-1 mr-1" small>mdi-car</v-icon>
                          <span>Cars: {{ item.carAmountAgreed }}</span>
                        </v-list-item-subtitle>
                      </v-list-item-content>
                      <v-list-item-action-text class="subtitle-1">{{ item.amountAgreed }}</v-list-item-action-text>
                    </v-list-item>

                    <v-list-item>
                      <v-list-item-avatar>
                        <v-icon>mdi-close-circle</v-icon>
                      </v-list-item-avatar>
                      <v-list-item-content>
                        <v-list-item-title>Declined:</v-list-item-title>
                        <v-list-item-subtitle class="mt-2">
                          <v-icon class="mb-1 mr-1" small>mdi-car</v-icon>
                          <span>Cars: {{ item.carAmountDeclined }}</span>
                        </v-list-item-subtitle>
                      </v-list-item-content>
                      <v-list-item-action-text class="subtitle-1">{{ item.amountDeclined }}</v-list-item-action-text>
                    </v-list-item>
                  </v-list>
                </v-card>
              </v-col>
            </v-row>
          </template>
        </v-data-iterator>
      </v-card-text>
    </v-card>
  </v-container>
</template>

<script>
import axios from "~/axios-client";

export default {
  name: "TCOTable",
  data() {
    return {
      fetching: true,
      items: [],
    }
  },
  async mounted() {
    try {
      const { data } = await axios.get("api/customerStatistics/tco-stats");
      this.items = data;
    } finally {
      this.fetching = false;
    }
  },
  methods: {
    downloadCsv(){
      window.open(`https://backoffice-customer-statistics.svc.gcp.abax.services/api/tco/stats/download`, "_blank");
    },
    mapCountryCodeToName(code) {
      switch (code.toLowerCase()) {
        case "no":
          return "Norway";
        case "se":
          return "Sweden";
        case "pl":
          return "Poland";
        case "fi":
          return "Finland";
        case "gb":
          return "UK";
        case "dk":
          return "Denmark";
        case "nl":
          return "Netherlands";
        case "be":
          return "Belgium";
        case "fr":
          return "France";
        case "de":
          return "Deutschland";
        default:
          return code.toUpperCase()
      }
    }
  }
}
</script>

<style scoped>

</style>
