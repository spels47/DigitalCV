<template>
  <div class="release-management">
    <v-container fluid>
      <v-card>
        <v-progress-linear indeterminate color="primary" :active="loading"></v-progress-linear>
        <v-card-title>
          <v-col cols="12" class="d-flex justify-space-between">
            <div>
              <div><v-icon class="mr-2">mdi-calendar</v-icon>Release Schedule</div>
              <h5 v-if="cal">{{ months[cal.lastStart.month - 1] }} {{ cal.lastStart.day }} - {{ months[cal.lastEnd.month - 1] }} {{ cal.lastEnd.day }}</h5>
            </div>
            <div>
              <v-icon small class="mr-2">mdi-account</v-icon>
              <span class="mr-2 subtitle-2">Your releases this week</span>
              <v-chip small class="mr-1" v-if="yourReleasesThisWeek.pending">{{yourReleasesThisWeek.pending}} Pending</v-chip>
              <v-chip small class="mr-1" color="#25BACA">{{yourReleasesThisWeek.published}} Published</v-chip>
              <v-chip small class="mr-1" color="#E5043A">{{yourReleasesThisWeek.aborted}} Aborted</v-chip>
              <v-chip small class="mr-1 chippy" color="#4CAA71">{{yourReleasesThisWeek.completed}} Completed</v-chip>
            </div>
            <div>
              <v-btn icon class="ma-2" @click="$refs.calendar.prev()">
                <v-icon>mdi-chevron-left</v-icon>
              </v-btn>
              <span v-if="cal">Week {{ week }}</span>
              <v-btn icon class="ma-2" @click="$refs.calendar.next()">
                <v-icon>mdi-chevron-right</v-icon>
              </v-btn>
            </div>
          </v-col>
          <v-col cols="md-12 lg-8" class="ma-0 pa-0">
          <v-combobox
            v-model="visibleCategories"
            :items="categories"
            prepend-icon="mdi-shape"
            label="Filter by project"
            @change="visibleCategoriesSearch = ''"
            :search-input.sync="visibleCategoriesSearch"
            max-width="80%"
            multiple
            chips
            deletable-chips>
            <template v-slot:no-data>
              <v-list-item>
                <v-list-item-content>
                  <v-list-item-title>
                    Press
                    <kbd color="primary">enter</kbd> to add " <strong>{{ visibleCategoriesSearch }}</strong
                    >".
                  </v-list-item-title>
                </v-list-item-content>
              </v-list-item>
            </template>
            <template v-slot:selection="{ item, parent }">
              <v-chip small close @click:close="parent.selectItem(item)" dark v-bind:color="getColorBasedOnProject(item)">
                {{ item }}
              </v-chip>
            </template>
          </v-combobox>
          </v-col>
        </v-card-title>

        <v-sheet height="750">
          <v-calendar
            ref="calendar"
            type="week"
            v-model="value"
            :events="sortedEvents"
            :event-color="getEventColor"
            :weekdays="[1, 2, 3, 4, 5, 6, 0]"
            :interval-format="intervalFormat"
            :interval-height="70"
            @mousedown:event="startDrag"
            @mousedown:time="startTime"
            @mousemove:time="mouseMove"
            @mouseup:time="endDrag"
            @mouseleave.native="cancelDrag"
            @change="setFirstWeekDay"
          >
            <template #day-body="{ date, week }">
              <div class="v-current-time" :class="{ first: date === week[0].date }" :style="{ top: nowY }"></div>
            </template>
            <template #event="{ event, eventParsed }">
              <v-container v-on:click="dialog = true">
                <div>{{ event.name }}</div>
                <div>{{ eventParsed.start.time }} - {{ eventParsed.end.time }}</div>
                <div class="d-flex flex-wrap">
                  <v-chip color="black" dark small v-for="product in event.gitlabProjectsAffected" v-bind:key="product" class="mt-1 ml-1">{{ product }}</v-chip>
                </div>
                <div class="mt-2">Booked by:</div>
                <div>{{ event.manager }}</div>
              </v-container>
            </template>
          </v-calendar>
        </v-sheet>
      </v-card>
      <v-dialog v-model="dialog" v-if="dialog" persistent  max-width="700px">
        <ReleaseManagementDialog
          :from="fromDate"
          :to="toDate"
          :release="release"
          @cancel="cancelRelease"
          @releaseCreated="releaseCreated"
          @releaseUpdated="releaseUpdated"
          @releaseDeleted="releaseDeleted"
        ></ReleaseManagementDialog>
      </v-dialog>
    </v-container>
  </div>
</template>

<script>
import ReleaseManagementDialog from "~/components/widgets/ReleaseManagementDialog.vue";
import moment from "moment";

export default {
  data() {
    return {
      months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
      value: null,
      events: [],
      dragEvent: null,
      dragStart: null,
      createEvent: null,
      createStart: null,
      extendOriginal: null,
      ready: false,
      dialog: false,
      from: null,
      to: null,
      release: null,
      visibleCategories: null,
      visibleCategoriesInitialized: false,
      visibleCategoriesSearch: '',
      loading: false,
      pollReleasesInterval: null,
      updateTimeInterval: null
    };
  },
  components: {
    ReleaseManagementDialog
  },
  computed: {
    yourReleasesThisWeek(){
      let userEvents = this.allEvents.filter(x => x.manager === this.$store.getters.currentUser?.username)
      return {
        pending: userEvents.filter(x => x.state === 'Pending').length,
        published: userEvents.filter(x => x.state === 'Published').length,
        aborted: userEvents.filter(x => x.state === 'Aborted').length,
        completed: userEvents.filter(x => x.state === 'Completed').length,
      }
    },
    allEvents() {
      return this.events.concat(this.$store.state.ReleaseManagementModule.releases);
    },
    sortedEvents() {
      return this.events.concat(this.$store.state.ReleaseManagementModule.releases).filter(e => {
        if (e.gitlabProjectsAffected) {
          return e.gitlabProjectsAffected.some(c => this.visibleCategories.includes(c));
        } else {
          return e;
        }
      });
    },
    categories() {
      let projects = [...new Set(this.allEvents.map(e => e.gitlabProjectsAffected).flat())];
      projects = projects.sort();
      if (!this.visibleCategoriesInitialized) this.initProjects(projects);
      return this.$store.state.ReleaseManagementModule.gitlabProjects;
    },
    cal() {
      return this.ready ? this.$refs.calendar : null;
    },
    nowY() {
      return this.cal ? this.cal.timeToY(this.cal.times.now) + "px" : "-10px";
    },
    fromDate() {
      return this.from;
    },
    toDate() {
      return this.to;
    },
    week() {
      return moment(this.cal.lastStart.date).week() - 1;
    }
  },
  async mounted() {
    this.ready = true;
    this.scrollToTime();
    this.updateTime();
    this.loading = true
    await this.$store.dispatch("getGitlabProjects");
    this.pollReleasesInterval = setInterval(async () => {
      await this.$store.dispatch("getReleases");
    }, 60 * 1000);
    this.loading = false
  },
  beforeDestroy(){
    clearInterval(this.pollReleasesInterval);
    clearInterval(this.updateTimeInterval);
  },
  methods: {
    intervalFormat(interval) {
      return interval.time;
    },
    initProjects(categories) {
      this.visibleCategories = categories;
    },
    async setFirstWeekDay(payload) {
      this.loading = true
      await this.$store.commit("setFirstWeekDay", payload.start.date);
      this.loading = false
    },
    releaseCreated() {
      this.dialog = false;
      this.release = null;
      this.events = [];
    },
    releaseUpdated() {
      this.dialog = false;
      this.release = null;
      this.events = [];
    },
    releaseDeleted() {
      this.dialog = false;
      this.release = null;
      this.events = [];
    },
    cancelRelease() {
      this.dialog = false;
      this.release = null;
      this.events = [];
    },
    getCurrentTime() {
      return this.cal ? this.cal.times.now.hour * 60 + this.cal.times.now.minute : 0;
    },
    scrollToTime() {
      const time = this.getCurrentTime();
      const first = Math.max(0, time - (time % 30) - 120);

      this.cal.scrollToTime("07:30");
    },
    updateTime() {
      this.updateTimeInterval = setInterval(() => this.cal.updateTimes(), 60 * 1000);
    },
    startDrag({ event, timed }) {
      if (event && timed) {
        this.dragEvent = event;
        this.dragTime = null;
        this.extendOriginal = null;
      }
      this.release = event;
    },
    startTime(tms) {
      const mouse = this.toTime(tms);

      if (this.dragEvent && this.dragEvent.draggable && this.dragTime === null) {
        const start = this.dragEvent.start;

        this.dragTime = mouse - start;
      } else if (!this.dragEvent) {
        this.createStart = this.roundTime(mouse);
        if (new Date(this.createStart) < new Date()) return;
        this.createEvent = {
          name: ``,
          color: "#C800A1",
          start: this.createStart,
          end: this.createStart,
          timed: true
        };
        this.events.push(this.createEvent);
      }
    },
    extendBottom(event) {
      this.createEvent = event;
      this.createStart = event.start;
      this.extendOriginal = event.end;
    },
    mouseMove(tms) {
      const mouse = this.toTime(tms);
      if (new Date(this.createStart) < new Date()) return;
      if (this.dragEvent && this.dragTime !== null) {
        const start = this.dragEvent.start;
        const end = this.dragEvent.end;
        const duration = end - start;
        const newStartTime = mouse - this.dragTime;
        const newStart = this.roundTime(newStartTime);
        const newEnd = newStart + duration;

        this.dragEvent.start = newStart;
        this.dragEvent.end = newEnd;
      } else if (this.createEvent && this.createStart !== null) {
        const mouseRounded = this.roundTime(mouse, false);
        const min = Math.min(mouseRounded, this.createStart);
        const max = Math.max(mouseRounded, this.createStart);

        this.createEvent.start = min;
        this.createEvent.end = max;
        this.from = min;
        this.to = max;
      }
    },
    endDrag(event) {
      if (new Date(this.from) < new Date()) {
        this.cancelDrag();
        return;
      }
      if (this.createEvent || this.extendOriginal) {
        this.dialog = true;
      }
      this.dragTime = null;
      this.dragEvent = null;
      this.createEvent = null;
      this.createStart = null;
      this.extendOriginal = null;
    },
    cancelDrag() {
      if (this.createEvent) {
        if (this.extendOriginal) {
          this.createEvent.end = this.extendOriginal;
        } else {
          const i = this.events.indexOf(this.createEvent);
          if (i !== -1) {
            this.events.splice(i, 1);
          }
        }
      }
      this.createEvent = null;
      this.createStart = null;
      this.dragTime = null;
      this.dragEvent = null;
    },
    roundTime(time, down = true) {
      const roundTo = 15; // minutes
      const roundDownTime = roundTo * 60 * 1000;

      return down ? time - (time % roundDownTime) : time + (roundDownTime - (time % roundDownTime));
    },
    toTime(tms) {
      return new Date(tms.year, tms.month - 1, tms.day, tms.hour, tms.minute).getTime();
    },
    getEventColor(event) {
      var color = "";
      if (event.state == "Completed") color = "#4CAA71";
      else if (event.state == "Aborted") color = "#E5043A";
      else color = "#25BACA";

      const rgb = parseInt(color.substring(1), 16);
      const r = (rgb >> 16) & 0xff;
      const g = (rgb >> 8) & 0xff;
      const b = (rgb >> 0) & 0xff;

      return event === this.dragEvent ? `rgba(${r}, ${g}, ${b}, 0.7)` : event === this.createEvent ? `rgba(${r}, ${g}, ${b}, 0.7)` : color;
    },
    getColorBasedOnProject(project) {
      return this.$utils.projectToColor(project);
    }
  }
};
</script>

<style>
.release-management .v-event-timed{
  overflow: hidden !important;
}
</style>

<style lang="scss" scoped>
.v-current-time {
  height: 3px;
  background-color: #c800a1;
  position: absolute;
  left: -1px;
  right: 0;
  pointer-events: none;

  &.first::before {
    content: "";
    position: absolute;
    background-color: #c800a1;
    width: 12px;
    height: 12px;
    border-radius: 50%;
    margin-top: -5px;
    margin-left: -6.5px;
  }
}

.v-event-draggable {
  padding-left: 6px;
}

.v-event-timed {
  user-select: none;
  -webkit-user-select: none;
}

.v-event-drag-bottom {
  position: absolute;
  left: 0;
  right: 0;
  bottom: 4px;
  height: 4px;
  cursor: ns-resize;

  &::after {
    display: none;
    position: absolute;
    left: 50%;
    height: 4px;
    border-top: 1px solid white;
    border-bottom: 1px solid white;
    width: 16px;
    margin-left: -8px;
    opacity: 0.8;
    content: "";
  }

  &:hover::after {
    display: block;
  }
}
</style>
