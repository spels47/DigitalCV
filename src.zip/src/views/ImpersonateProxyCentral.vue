<template>
  <div>
    <v-layout class="justify-center mt-12">
      <v-alert
        border="bottom"
        colored-border
        type="warning"
        color="black"
        elevation="2"
        max-width="800"
        class="text-center"
      >
        <span v-if="$route.query.userId">Creating an impersonation session for user: <b>{{ $route.query.userId }}</b> - <b>{{ $route.query.username }}</b></span>
        <br/>
        Just hang on a second, you are being redirected 🙂
        <br/>
      </v-alert>
    </v-layout>
  </div>
</template>

<script>
import {mapActions} from "vuex";
import {getTriplogConfig} from "@/config/config-service";

export default {
  methods: {
    ...mapActions("oidcStore", ["authenticateOidc"])
  },
  mounted() {
    let userId = "";
    userId = this.$route.query.userId;
    if (!userId) {
      let configTriplog = getTriplogConfig();
      window.location.replace(configTriplog.newClientUrl)
      return;
    }
    this.$store.dispatch("audit", { source: "account", entityId: userId, message: "Impersonated Account", oldValue: "", newValue: "" });
    this.authenticateOidc({
      options: {
        acr_values: `abax:impersonate:end`
      },

    });
    this.authenticateOidc({
      options: {
        acr_values: `abax:impersonate:sub:electronic_tracking_systems:${userId}`
      },
      redirectPath: "/start-impersonation-central"
    });
  }
};
</script>

<style>
</style>
