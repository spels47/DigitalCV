<template>
  <div>
    <div class="relative">
      <div v-if="customerStatistics === '' || customerStatistics.isTerminated" class="terminated-text">TERMINATED</div>
      <div v-if="customer.erpClientId === 1337" class="demo-text">DEMO</div>
      <div v-if="customerStatistics.hasZego" class="zego-text">PARTNER</div>
      <div v-if="customerStatistics.hasAccess" class="access-text">ACCESS</div>
      <div v-if="customerStatistics.hasAutomile" class="automile-text">AUTOMILE</div>
      <div v-if="customerStatistics.hasRam" class="ram-text">RAM BY ABAX</div>
      <div v-if="customerStatistics.hasInsuranceEnabler" class="insurance-text">INSURANCE</div>
      <v-img class="mb-n4" height="250px" src="@/assets/customer-header.png" style="z-index: 0" />
    </div>
    <v-main>
      <v-row>
        <v-col>
          <v-card>
            <v-progress-linear indeterminate color="black" v-if="isLoading"></v-progress-linear>
            <v-list>
              <v-list-item class="mt-5">
                <v-text-field @change="updateDepartmentInfo" :readonly="!roles.DEVELOPER_ASAP" prepend-icon="mdi-domain" label="Name" v-model="customer.name" />
              </v-list-item>
              <v-list-item>
                <v-icon left> mdi-flag-variant</v-icon>
                <v-text-field readonly label="Country" :value="customer.country" />
              </v-list-item>
              <v-list-item v-if="portfolioTeam">
                <v-icon left>mdi-folder-account</v-icon>
                <v-text-field readonly label="Portfolio team" :value="portfolioTeam.teamName" />
              </v-list-item>
            </v-list>
          </v-card>
        </v-col>
      </v-row>

      <v-row>
        <v-col>
          <v-expansion-panels v-model="openPanel" class="elevation-2">
            <v-expansion-panel>
              <v-expansion-panel-header>
                Customer info
              </v-expansion-panel-header>
              <v-expansion-panel-content>
                <v-list>
                  <v-list-item>
                    <v-text-field data-cy="customer-info-customer-id" prepend-icon="mdi-numeric" :readonly="true" label="Customer ID" v-model="customer.id"> </v-text-field>
                  </v-list-item>
                  <v-list-item v-if="roles.DEVELOPER_ASAP">
                    <v-text-field data-cy="customer-info-navision-client-id" prepend-icon="mdi-numeric" @change="setNavisionCustomerId" label="ERP Client ID" v-model="customer.erpClientId"> </v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-text-field prepend-icon="mdi-numeric" data-cy="customer-info-erp-customer-id" :readonly="!roles.DEVELOPER_ASAP" @change="setNavisionCustomerId" label="ERP Customer ID" v-model="newNavisionCustomerId"> </v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-text-field prepend-icon="mdi-numeric" data-cy="customer-info-so-contact-id" :readonly="!roles.CUSTOMER_EDIT" @change="setSuperOfficeContactId" label="Super Office Contact ID" v-model="superOfficeContactId"> </v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-text-field prepend-icon="mdi-numeric" @change="updateMainOfficeId" :readonly="!roles.CUSTOMER_EDIT" label="Main Office ID" :value="customer.mainOfficeId === customer.id ? '' : customer.mainOfficeId"></v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-text-field prepend-icon="mdi-calendar" readonly label="Customer Created" :value="customer.created | ntzDate"></v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-text-field
                      :readonly="!roles.CUSTOMER_EDIT"
                      :rules="[rules.required, rules.emailRules, rules.emailLength]"
                      prepend-icon="mdi-email"
                      label="Email"
                      data-cy="customer-info-email"
                      v-model="customer.email"
                      @change="updateDepartmentInfo"
                    ></v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-icon left @click="openMap(customer.address, customer.zip, customer.city)">mdi-map-marker</v-icon>
                    <v-text-field data-cy="customer-info-address" @change="updateDepartmentInfo" :readonly="!roles.CUSTOMER_EDIT" label="Address" v-model="customer.address" />
                  </v-list-item>
                  <v-list-item>
                    <v-text-field data-cy="customer-info-zip-code" @change="updateDepartmentInfo" prepend-icon="mdi-map-marker" :readonly="!roles.CUSTOMER_EDIT" label="Zip Code" v-model="customer.zip"> </v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-text-field data-cy="customer-info-city" @change="updateDepartmentInfo" prepend-icon="mdi-map-marker" :readonly="!roles.CUSTOMER_EDIT" label="City" v-model="customer.city"> </v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-icon left v-if="customer.country === 'NO'" @click="openBReg(customer.organizationNumber)">
                      mdi-counter
                    </v-icon>
                    <v-icon left v-else>mdi-counter</v-icon>
                    <v-text-field @change="updateDepartmentInfo" :readonly="!roles.CUSTOMER_EDIT" label="Org. No" v-model="customer.organizationNumber" />
                  </v-list-item>
                  <v-list-item>
                    <v-icon left @click="openOpenNaceCodeSite(customerStatistics.naceCode)">mdi-numeric</v-icon>
                    <v-text-field readonly label="NACE Code" :value="customerStatistics.naceCode"></v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-text-field
                      :readonly="!roles.CUSTOMER_EDIT"
                      :rules="[rules.required, rules.phoneRules, rules.phoneLength]"
                      prepend-icon="mdi-phone"
                      data-cy="customer-info-phone"
                      label="Telephone"
                      v-model="customer.telephone"
                      @change="updateDepartmentInfo"
                    ></v-text-field>
                  </v-list-item>
                </v-list>
              </v-expansion-panel-content>
            </v-expansion-panel>
          </v-expansion-panels>
        </v-col>
      </v-row>

      <v-row>
        <v-col>
          <v-bottom-navigation :background-color="'cardbg'" class="elevation-2" height="60">
            <v-btn @click="toggleFavorite" data-cy="add-to-favorites-button">
              <span v-if="isFavorite">Favorite</span>
              <span v-if="!isFavorite">Add to favorites</span>
              <v-icon :color="isFavorite ? 'marked' : ''">mdi-heart</v-icon>
            </v-btn>
            <v-btn v-if="roles.CUSTOMER_SETTINGS_EDIT" @click="openCustomerSidebar">
              <span>Customer Settings</span>
              <v-icon>mdi-cog</v-icon>
            </v-btn>
            <v-btn @click="openContactLogSidebar">
              <span>Logs</span>
              <v-icon>mdi-stack-exchange</v-icon>
            </v-btn>
          </v-bottom-navigation>
        </v-col>
      </v-row>

      <v-row v-if="roles.CUSTOMER_EDIT || roles.CUSTOMER_MOVE">
        <v-col>
          <v-bottom-navigation :background-color="'cardbg'" class="elevation-2" height="60">
            <v-btn @click="addDepartmentDialog = true" v-if="roles.CUSTOMER_EDIT" data-cy="add-department-button">
              <span>Add department</span>
              <v-icon>$vuetify.icons.addDepartment</v-icon>
            </v-btn>
            <v-dialog v-model="addDepartmentDialog" max-width="30%" persistent>
              <v-card>
                <v-form ref="addDepartmentForm" v-model="addFormValid">
                <v-card-title class="headline">
                  <span>Add Department</span>
                </v-card-title>
                <v-card-text>
                  <label>Select Department to create a new department under</label>
                    <v-card v-if="customer.id" class="pt-2 pb-2">
                      <HierarchyWithSearch @itemClicked="selectCustomerToAddUnder" :items="customerHierarchyArray"></HierarchyWithSearch>
                    </v-card>

                    <v-text-field prepend-icon="mdi-domain" label="Name" v-model="newDepName" :rules="[rules.required]" />
                    <v-text-field prepend-icon="mdi-domain" label="Address" v-model="newDepAddress" />
                    <v-text-field prepend-icon="mdi-domain" label="Email" v-model="newDepEmail" />
                    <v-text-field prepend-icon="mdi-domain" label="Phone" v-model="newDepPhone" />

                </v-card-text>
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="primary" text @click="closeDepartmentDialog">
                    Cancel
                  </v-btn>
                  <v-btn color="primary" text @click="addDepartment">
                    <v-icon>mdi-account-arrow-right</v-icon>
                    Add
                  </v-btn>
                </v-card-actions>
                </v-form>
              </v-card>
            </v-dialog>
            <v-btn @click="moveDepartmentDialog = true" v-if="roles.CUSTOMER_MOVE && !isDepartmentTopLevel" data-cy="move-department-button">
              <span>Move department</span>
              <v-icon>$vuetify.icons.moveDepartment</v-icon>
            </v-btn>
            <v-dialog v-model="moveDepartmentDialog" max-width="30%" persistent>
              <v-card>
                <v-card-title class="headline">
                  <span>Move Department</span>
                </v-card-title>
                <v-card-text>
                  <label>Select Department to move a current department under</label>
                  <v-form ref="moveDepartmentForm">
                    <v-card class="pt-2 pb-2">
                      <HierarchyWithSearch @itemClicked="selectCustomerToMoveUnder" :items="mainOfficeHierarchyWithoutCurrentDepartmentBranch"></HierarchyWithSearch>
                    </v-card>
                  </v-form>
                </v-card-text>
                <v-card-actions>
                  <v-spacer></v-spacer>
                  <v-btn color="primary" text @click="moveDepartmentDialog = false">
                    Cancel
                  </v-btn>
                  <v-btn color="primary" text @click="moveDepartmentConfirmatonDialog = true">
                    <v-icon>mdi-account-arrow-right</v-icon>
                    Move
                  </v-btn>
                  <SimpleDialog
                    v-if="moveDepartmentConfirmatonDialog"
                    :title="'Move department'"
                    :text="'Are you sure you want to move this department? This will also move all entities related to the department'"
                    :confirmLabel="'Yes'"
                    :cancelLabel="'No'"
                    @confirm="moveDepartment"
                    @cancel="moveDepartmentConfirmatonDialog = false"
                  ></SimpleDialog>
                </v-card-actions>
              </v-card>
            </v-dialog>
            <v-btn @click="deleteDepartmentDialog = true" v-if="roles.CUSTOMER_EDIT" data-cy="delete-department-button">
              <span>Delete department</span>
              <v-icon>$vuetify.icons.deleteDepartment</v-icon>
            </v-btn>
            <SimpleDialog
              v-if="deleteDepartmentDialog"
              :title="'Delete department'"
              :text="'Are you sure you want to delete this department?'"
              :confirmLabel="'Yes'"
              :cancelLabel="'No'"
              @confirm="deleteDepartment"
              @cancel="deleteDepartmentDialog = false"
            ></SimpleDialog>
          </v-bottom-navigation>
        </v-col>
      </v-row>
    </v-main>
  </div>
</template>

<script>
import axios from "~/axios-client";
import { mapActions } from 'vuex';
import HierarchyWithSearch from "@/components/HierarchyWithSearch";
import SimpleDialog from "@/components/widgets/dialogs/simpleDialog";
import { findCustomerHierarchy } from "~/helpers/customer-hierarchy-utils.js"
import utils from "~/helpers/util.js";


export default {
  name: "CustomerDetails",
  components: { HierarchyWithSearch, SimpleDialog },
  props: {
    customer: Object,
    customerHierarchy: Object,
    mainOfficeHierarchy: Object,
    portfolioTeam: {type : [Object, String]},
    customerStatistics: {
      type: [Object, String] // If empty, endpoint returns 204, parsed as empty string in this case, just added string type here to suppress warning
    }
  },
  data: function() {
    return {
      openPanel: false,
      isLoading: false,
      newNavisionCustomerId: this.customer.erpCustomerId,
      superOfficeContactId: this.customer.superOfficeId,

      addDepartmentDialog: false,
      addFormValid: false,
      customerToAddUnderId: this.customer.id,
      newDepName: "",
      newDepAddress: "",
      newDepEmail: "",
      newDepPhone: "",
      rules: {
        required: value => !!value || 'Required.',
        emailRules: v => !v || /\S+@\S+\.\S+/.test(v) || "E-mail must be valid",
        emailLength: v => (v && v.length) < 256 || "E-mail is too long",
        phoneRules: v => !v || /^\+[0-9]+$/.test(v) || "Must be a valid number containing country code",
        phoneLength: v => !v || (v && v.length > 6) || (v && v.length < 16) || "Number has invalid length",
      },
      moveDepartmentDialog: false,
      moveDepartmentConfirmatonDialog: false,
      customerToMoveUnderId: this.customer.id,

      deleteDepartmentDialog: false
    };
  },
  methods: {
    ...mapActions('customerStore', ['fetchCustomer']),
    ...mapActions(['refreshFetchedEntities']),
    selectCustomerToAddUnder: function(ids) {
      this.customerToAddUnderId = ids[0];
    },
    selectCustomerToMoveUnder: function(ids) {
      this.customerToMoveUnderId = ids[0];
    },
    openCustomerSidebar() {
      this.$emit("openCustomerSidebar");
    },
    openContactLogSidebar() {
      this.$emit("openContactLogSidebar")
    },
    closeDepartmentDialog() {
      this.newDepEmail = "";
      this.newDepName = "";
      this.newDepAddress = "";
      this.newDepPhone = "";
      this.addDepartmentDialog = false;
    },
    async addDepartment() {
      if (!this.$refs.addDepartmentForm.validate() || !this.customerToAddUnderId){
        return;
      }

      this.isLoading = true;

      let newDepartment = {
        Name: this.newDepName,
        Address: this.newDepAddress,
        Email: this.newDepEmail,
        Telephone: this.newDepPhone,
        LinkedId: this.customerToAddUnderId
      };

      try{
        var res = await axios.post("/api/customer/addDepartment", newDepartment);
        const newCustomerId = res.data.id;

        await this.$store.dispatch("audit", {
          source: "customer",
          entityId: this.customer.id,
          message: "Created new department",
          oldValue: "",
          newValue: newCustomerId
        });

        this.$router.push({ path: `/customer/${newCustomerId}` });
      }
      catch{
        this.$eventBus.$emit("alert", { template: "api-error" });
      }

      this.isLoading = false;
      this.addDepartmentDialog = false;
    },
    async moveDepartment() {
      if (!this.customerToMoveUnderId || this.customerToMoveUnderId === this.customer.id)
        return;

      this.isLoading = true;

      try{
        await axios.post(`/api/customer/moveDepartment/${this.customer.id}`, { NewParentDepartmentId: this.customerToMoveUnderId })
        const parentDepartmentId = this.customer.linkedId;

        await this.$store.dispatch("audit", {
          source: "customer",
          entityId: this.customer.id,
          message: `Customer ${this.customer.id} moved from ${parentDepartmentId} to ${this.customerToMoveUnderId} customer`,
          oldValue: this.customer.id,
          newValue: ""
        });

        await Promise.all([this.fetchCustomer(this.customer.id), this.refreshFetchedEntities(this.customer.id)])
      }
      catch(error) {
        switch (error.response.status) {
          case 400:
            this.$eventBus.$emit("alert", { text: error.response.data, type: "error" });
            break;
          default:
            this.$eventBus.$emit("alert", { template: "api-error" });
            break;
        }
      }

      this.isLoading = false;
      this.moveDepartmentDialog = false;
      this.moveDepartmentConfirmatonDialog = false;
    },
    async deleteDepartment() {
      this.isLoading = true;

      try{
        await axios.delete(`/api/customer/deleteDepartment/${this.customer.id}`)
        const parentDepartmentId = this.customer.linkedId;

        await this.$store.dispatch("audit", {
          source: "customer",
          entityId: parentDepartmentId,
          message: `Department ${this.customer.id} deleted`,
          oldValue: this.customer.id,
          newValue: ""
        });

        this.$router.push({ path: `/customer/${parentDepartmentId}` });
      }
      catch(error){
        if (error.response.status === 404) {
          this.$eventBus.$emit("alert", { text: "Department doesn't exist", type: "error" });
        } else if (error.response.status === 403) {
          this.$eventBus.$emit("alert", { text: error.response.data, type: "error" });
        } else {
          this.$eventBus.$emit("alert", { template: "api-error" });
        }
      }

      this.isLoading = false;
      this.deleteDepartmentDialog = false;
    },
    updateMainOfficeId(value) {
      if (value === "") {
        this.customer.mainOfficeId = 0;
      } else {
        this.customer.mainOfficeId = parseInt(value);
      }
      this.updateDepartmentInfo("MainOfficeId");
    },
    updateDepartmentInfo(changeType) {
      clearTimeout(this._timerId);

      this._timerId = setTimeout(async () => {
        this.isLoading = true;
        try {
          await axios.put(`/api/customer`, this.customer);
          await this.$store.dispatch("audit", {source: "customer", entityId: this.customer.id, message: "Department info updated", oldValue: '', newValue: ''});
        } catch (ex) {
          this.$eventBus.$emit('alert', {text: `Failed to update department info`, type: 'error'});
          this.newNavisionCustomerId = this.customer.erpCustomerId; // Something failed, not updated
        }
        this.isLoading = false;
        if (changeType === "MainOfficeId") location.reload();
      }, 500);
    },
    setNavisionCustomerId() {
      clearTimeout(this._timerId2);

      this._timerId2 = setTimeout(async () => {
        this.isLoading = true;
        try {
          await axios.put(`/api/customer/${this.customer.id}/navisionCustomerId`, { NavisionCustomerId: this.newNavisionCustomerId });
          await this.$store.dispatch("audit", { source: "customer", entityId: this.customer.id, message: "NavisionCustomerId changed", oldValue: this.customer.erpCustomerId, newValue: this.newNavisionCustomerId });
        } catch (ex) {
          this.$eventBus.$emit('alert', { text: `Failed to set NavisionCustomerId`, type: 'error'});
          this.newNavisionCustomerId = this.customer.erpCustomerId; // Something failed, not updated
        }
        this.isLoading = false;
      }, 500);
    },
    setSuperOfficeContactId() {
      clearTimeout(this._timerId2);

      this._timerId2 = setTimeout(async () => {
        this.isLoading = true;
        try {
          await axios.put(`/api/customer/${this.customer.id}/${this.superOfficeContactId}/superofficeId`);
          await this.$store.dispatch("audit", { source: "customer", entityId: this.customer.id, message: "SuperOfficeId changed", oldValue: this.customer.superOfficeId, newValue: this.superOfficeContactId });
        } catch (ex) {
          this.$eventBus.$emit('alert', { text: `Failed to set SuperOfficeId`, type: 'error'});
          this.newNavisionCustomerId = this.customer.erpCustomerId; // Something failed, not updated
        }
        this.isLoading = false;
      }, 500);
    },
    async toggleFavorite() {
      let favorite = {
        departmentPath: this.customer.departmentPath,
        id: this.customer.id.toString(),
        name: this.customer.name,
        subName: null,
        type: this.customer.isMainOffice ? "MainOfficeCustomer" : "Customer"
      };
      await this.$store.dispatch("toggleFavorite", favorite);
    },
    openMap(address, zip, city) {
      window.open(`https://maps.google.com/?q=${address},${zip},${city}`);
    },
    openBReg(organizationNumber) {
      window.open(`https://w2.brreg.no/enhet/sok/detalj.jsp?orgnr=${organizationNumber}`);
    },
    openOpenNaceCodeSite(naceCode) {
      if(naceCode.includes('.')) window.open(`https://nacev2.com/en/search?q=${naceCode}`)
      else window.open(`https://nacev2.com/en`);
    }
  },
  watch: {
    customer: function() {
      this.newNavisionCustomerId = this.customer.erpCustomerId;
      this.superOfficeContactId = this.customer.superOfficeId;
      this.customerToAddUnderId = this.customer.id;
    },
  },
  computed: {
    isFavorite() {
      return this.$store.state.userSettings?.favorites?.some(x => ["MainOfficeCustomer", "Customer"].includes(x.type) && x.id === this.customer.id?.toString());
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    customerHierarchyArray() {
      return [this.customerHierarchy]
    },
    isDepartmentTopLevel() {
      const topDepartmentLevel = 3;
      return this.customer.customerLevel ? this.customer.customerLevel <= topDepartmentLevel : false
    },
    mainOfficeHierarchyWithoutCurrentDepartmentBranch() {
      if(utils.isEmpty(this.mainOfficeHierarchy) || this.mainOfficeHierarchy.id === this.customer.id) return []

      const hierarchy = utils.deepClone(this.mainOfficeHierarchy)

      const parentDepartmentHierarchy = findCustomerHierarchy(hierarchy, this.customer.linkedId)
      if(parentDepartmentHierarchy)
        parentDepartmentHierarchy.children = parentDepartmentHierarchy.children.filter(x => x.id !== this.customer.id)

      return [hierarchy]
    },
    isDarkMode() {
      return this.$vuetify.theme.dark;
    }
  }
};
</script>

<style scoped>
.relative{
  position: relative;
}
.terminated-text {
  color: #E5043A;
  font-family: "Roboto", sans-serif;
  font-size: 20px;
  font-weight: 800;
  transform: rotate(15deg);
  position: absolute;
  bottom: 20px;
  right: 10px;
  z-index: 5;
}
.demo-text {
  color: #C800A1;
  font-family: "Roboto", sans-serif;
  font-size: 20px;
  font-weight: 800;
  transform: rotate(15deg);
  position: absolute;
  bottom: 20px;
  right: 10px;
  z-index: 5;
}
.access-text {
  color: #C800A1;
  font-family: "Roboto", sans-serif;
  font-size: 20px;
  font-weight: 800;
  transform: rotate(15deg);
  position: absolute;
  bottom: 40px;
  right: 10px;
  z-index: 5;
}
.zego-text {
  color: #C800A1;
  font-family: "Roboto", sans-serif;
  font-size: 20px;
  font-weight: 800;
  transform: rotate(15deg);
  position: absolute;
  bottom: 60px;
  right: 10px;
  z-index: 5;
}
.automile-text {
  color: #C800A1;
  font-family: "Roboto", sans-serif;
  font-size: 20px;
  font-weight: 800;
  transform: rotate(15deg);
  position: absolute;
  bottom: 80px;
  right: 10px;
  z-index: 5;
}
.ram-text {
  color: #C800A1;
  font-family: "Roboto", sans-serif;
  font-size: 20px;
  font-weight: 800;
  transform: rotate(15deg);
  position: absolute;
  bottom: 100px;
  right: 10px;
  z-index: 5;
}
.insurance-text {
  color: #C800A1;
  font-family: "Roboto", sans-serif;
  font-size: 20px;
  font-weight: 800;
  transform: rotate(15deg);
  position: absolute;
  bottom: 120px;
  right: 10px;
  z-index: 5;
}
</style>
