<template>
  <v-container>
    <v-expansion-panels>
      <v-row>
        <v-col cols="4">
          <v-expansion-panel
            :disabled="!customerStatistics.data"
            data-cy="customer-score-panel"
            class="elevation-0"
          >
            <v-expansion-panel-header
              class="elevation-2"
              @click="showCustomerScore = !showCustomerScore; showCustomerStatistics = false; showCustomerSatisfaction = false"
            >
              <v-progress-circular
                v-if="loading"
                color="primary"
                size="30"
                indeterminate
              ></v-progress-circular>
              <v-fade-transition>
                <v-icon v-if="!loading">mdi-podium-gold</v-icon>
              </v-fade-transition>
              <span class="headline font-weight-bold primary--text pl-2">Score: {{ customerScore }}%</span>
            </v-expansion-panel-header>
          </v-expansion-panel>
        </v-col>
        <v-col cols="4">
          <v-expansion-panel
            :disabled="loadingCustomerStatistics || !hasCustomerStatistics"
            data-cy="customer-statistics-panel"
            class="elevation-0"
          >
            <v-expansion-panel-header
              class="elevation-2"
              @click="showCustomerStatistics = !showCustomerStatistics; showCustomerScore = false; showCustomerSatisfaction = false"
            >
              <v-progress-circular
                v-if="loadingCustomerStatistics"
                color="primary"
                size="30"
                indeterminate
              ></v-progress-circular>
              <v-fade-transition>
                <v-icon v-if="!loadingCustomerStatistics">mdi-finance</v-icon>
              </v-fade-transition>
              <span class="headline font-weight-bold primary--text pl-2">Statistics</span>
            </v-expansion-panel-header>
          </v-expansion-panel>
        </v-col>
        <v-col cols="4">
          <v-expansion-panel
            :disabled="loadingCustomerSatisfaction"
            data-cy="customer-statistics-panel"
            class="elevation-0"
          >
            <v-expansion-panel-header
              class="elevation-2"
              @click="showCustomerSatisfaction = !showCustomerSatisfaction; showCustomerScore = false; showCustomerStatistics = false"
            >
              <v-progress-circular
                v-if="loadingCustomerSatisfaction"
                color="primary"
                size="30"
                indeterminate
              >
              </v-progress-circular>
              <v-fade-transition>
                <v-icon v-if="!loadingCustomerSatisfaction">mdi-emoticon-happy-outline</v-icon>
              </v-fade-transition>
              <span class="headline font-weight-bold primary--text pl-2">Satisfaction: {{latestChurnValue}}</span>
            </v-expansion-panel-header>
          </v-expansion-panel>
        </v-col>
      </v-row>
    </v-expansion-panels>

    <v-row v-if="showCustomerScore">
      <v-col cols="12">
        <v-card>
          <v-container fluid>
            <v-row justify="center">
              <v-col cols="2">
                <ScoreCard
                  :title="deviceInstallStatusCard.header"
                  :description="deviceInstallStatusCard.desc"
                  :list-items="deviceInstallStatusCard.details"
                  :totalScore="deviceInstallStatusCard.result"
                />
              </v-col>
              <v-col cols="2">
                <ScoreCard
                  :title="onboardingCard.header"
                  :description="onboardingCard.desc"
                  :list-items="onboardingCard.details"
                  :totalScore="onboardingCard.result"
                />
              </v-col>
              <v-col cols="2">
                <ScoreCard
                  :title="usageCard.header"
                  :description="usageCard.desc"
                  :list-items="usageCard.details"
                  :totalScore="usageCard.result"
                />
              </v-col>
              <v-col cols="2">
                <ScoreCard
                  :title="reportsCard.header"
                  :description="reportsCard.desc"
                  :list-items="reportsCard.details"
                  :totalScore="reportsCard.result"
                />
              </v-col>
              <v-col cols="2">
                <ScoreCard
                  :title="vehiclesCard.header"
                  :description="vehiclesCard.desc"
                  :list-items="vehiclesCard.details"
                  :totalScore="vehiclesCard.result"
                />
              </v-col>
              <v-col cols="2">
                <ScoreCard
                  :title="driversCard.header"
                  :description="driversCard.desc"
                  :list-items="driversCard.details"
                  :totalScore="driversCard.result"
                />
              </v-col>
            </v-row>
          </v-container>
        </v-card>
      </v-col>
    </v-row>

    <v-row v-if="showCustomerStatistics">
      <v-col cols="12">
        <v-row>
          <v-col cols="4">
            <ApexTimeChart
              :name="'MRR'"
              :xAxis="{ label: 'Week', format: 'w' }"
              :statistic="this.mrr"
              :format-as-currency="{ value: true, country: this.customer.country }"
            ></ApexTimeChart>
          </v-col>
          <v-col cols="4">
            <ApexTimeChart
              :name="'Avg price pr. main subscription'"
              :statistic="this.averagePricePerMainSub"
              :xAxis="{ label: 'Week', format: 'w' }"
              :format-as-currency="{ value: true, country: this.customer.country }"
            ></ApexTimeChart>
          </v-col>
          <v-col cols="4">
            <ApexTimeChart
              :name="'Active main subscriptions'"
              :statistic="this.noOfMainSubscriptions"
              :xAxis="{ label: 'Week', format: 'w' }"
            ></ApexTimeChart>
          </v-col>
        </v-row>
      </v-col>
    </v-row>

    <v-row v-if="showCustomerSatisfaction">
      <v-col cols="12">
        <v-row>
          <v-col cols="12">
            <ChurnPredictionChart
              :churn-prediction="churnData"
            ></ChurnPredictionChart>
          </v-col>
        </v-row>
      </v-col>
    </v-row>
  </v-container>
</template>
<script>
import ScoreCard from "~/components/ScoreCard";
import ApexTimeChart from "@/components/widgets/Charts/ApexTimeChart";
import axios from "~/axios-client";
import ChurnPredictionChart from "@/components/widgets/Charts/ChurnPredictionChart";

export default {
  name: "CustomerStatistics",
  props: {
    customerStatistics: Object,
    customer: Object,
    loading: Boolean
  },
  components: {
    ChurnPredictionChart,
    ApexTimeChart,
    ScoreCard
  },
  data: function () {
    return {
      loadingCustomerStatistics: true,
      loadingCustomerSatisfaction: true,
      showCustomerScore: false,
      showCustomerStatistics: false,
      showCustomerSatisfaction: false,
      averagePricePerMainSub: {},
      noOfMainSubscriptions: {},
      mrr: {},
      churnData: {}
    };
  },
  watch: {
    customerStatistics() {
      this.getStatistics();
      this.getChurnPrediction();
    }
  },
  methods: {
    async getStatistics() {
      try {
        const { data } = await axios.get(`api/customerStatistics/${this.customerStatistics._id}?values=AveragePricePerMainSub&values=MainSubscriptions&values=MRR`);
        if(data.length > 0){
          this.averagePricePerMainSub = data[0].valueSet;
          this.noOfMainSubscriptions = data[1].valueSet;
          this.mrr = data[2].valueSet;
        }
      } finally {
        this.loadingCustomerStatistics = false;
      }
    },
    async getChurnPrediction() {
      try {
        const { data } = await axios.get(`api/customerStatistics/churn-prediction/${this.customerStatistics._id}/${this.customer.superOfficeId}`);
        this.churnData = data;
      } finally {
        this.loadingCustomerSatisfaction = false;
      }
    }
  },
  computed: {
    latestChurnValue() {
      let churnValue = this.customerStatistics.churnPredictionScore;
      if(churnValue == null) return "";
      return (100 - churnValue) + "%";
    },
    customerScore() {
      return this.customerStatistics?.data?.score ?? 0;
    },
    deviceInstallStatusCard() {
      return this.customerStatistics.data.cards.find(card => card.header === "Installed");
    },
    onboardingCard() {
      return this.customerStatistics.data.cards.find(card => card.header === "Onboarding");
    },
    usageCard() {
      return this.customerStatistics.data.cards.find(card => card.header === "Usage");
    },
    reportsCard() {
      return this.customerStatistics.data.cards.find(card => card.header === "Reports");
    },
    vehiclesCard() {
      return this.customerStatistics.data.cards.find(card => card.header === "Vehicles");
    },
    driversCard() {
      return this.customerStatistics.data.cards.find(card => card.header === "Drivers");
    },
    hasCustomerStatistics() {
      return !(this.mrr === {} || this.noOfMainSubscriptions === {} || this.averagePricePerMainSub === {});
    },
    roles() {
      return this.$store.state.currentUserRoles;
    }
  }
};
</script>

<style scoped></style>
