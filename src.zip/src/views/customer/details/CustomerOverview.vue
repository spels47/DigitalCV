﻿<template>
  <v-container fluid>
    <v-row justify-md="center">
      <v-col cols="2">
        <ScoreCard :title="'Last Activity'" :description="(latestCustomerActivity? latestCustomerActivity.type : '')" :totalScore="latestCustomerActivity ? latestCustomerActivity.date.split('T')[0] : ''"
                   :showValuesAsPercentage="false"></ScoreCard>
      </v-col>
      <v-col cols="2">
        <ScoreCard :title="'Requests'" :description="'Open/Total'" :totalScore="customerTicketsComputed.filter(x => x.ticketStatusName !== 'Closed').length + '/' + customerTicketsComputed.length" :showValuesAsPercentage="false"
                   :resultColor="customerTicketsComputed.filter(x => x.ticketStatusName !== 'Closed').length > 0 ? 'error--text' : 'success--text'"></ScoreCard>
      </v-col>
      <v-col cols="2">
        <ScoreCard :title="'Consignments'" :description="'Open/Delivered'" :total-score="openConsignments.toString() + '/' + deliveredConsignments.toString()" :showValuesAsPercentage="false"></ScoreCard>
      </v-col>
      <v-col cols="2">
        <ScoreCard v-if="subscriptionsCard" :card="subscriptionsCard" :showValuesAsPercentage="false"></ScoreCard>
      </v-col>
    </v-row>
    <v-row justify="center">
      <v-col cols="2">
        <ScoreCard v-if="deviceOverviewCard" :card="deviceOverviewCard" :showValuesAsPercentage="false"/>
      </v-col>
      <v-col cols="2">
        <ScoreCard v-if="installedCard" :card="installedCard"/>
      </v-col>
      <v-col cols="2">
        <ScoreCard v-if="accountsCard" :card="accountsCard" :showValuesAsPercentage="false"></ScoreCard>
      </v-col>
      <v-col cols="2">
        <ScoreCard v-if="vehicleTypesCard" :card="vehicleTypesCard" :showValuesAsPercentage="false"></ScoreCard>
      </v-col>
      <v-col cols="2">
        <ScoreCard v-if="featuresCard" :card="featuresCard" :featuresList="true" :showValuesAsPercentage="false"></ScoreCard>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "@/axios-client";
import logger from "@/logger";
import ScoreCard from "@/components/ScoreCard";

export default {
  name: "CustomerOverview",
  components: { ScoreCard },
  props: {
    customerId: String,
  },
  data() {
    return {
      customerTickets: [],
      customerActivities: [],
      customerConsignments: [],
      customerConsignmentsLoading: false,
      customer: {},
      customerStatisticsCards: [],
      customerStatisticsFetchId: 0,
    }
  },
  async created() {
    try {
      let res = await axios.get(`/api/customer?customerId=${this.customerId}`).then(response => {
        this.customer = response.data;
      });
    } catch (ex) {
      this.$eventBus.$emit("alert", { template: "api-error" });
    }
    let promises = [];
    this.isLoading = true;
    let superOfficeId = this.customer.superOfficeId;
    if (!superOfficeId) {
      await logger.log('info', 'getCustomerOverview', `Missing SO ContactId for customerId: ${this.customer.id}`);
      // this.$eventBus.$emit('alert', {text: 'This customer does not have SuperOffice contactId', icon: 'mdi-alert-circle', type: 'warning'});
    } else {
      promises.push(this.getCustomerTickets(superOfficeId))
      promises.push(this.getCustomerActivities(superOfficeId))
    }
    if (!this.customer.isMainOfficeId) {
      this.customerStatisticsFetchId = this.customer.mainOfficeId;
    } else {
      this.customerStatisticsFetchId = this.customer.id
    }
    promises.push(this.getCustomerConsignments())
    promises.push(this.getCustomerStatisticsCards())

    try {
      await Promise.all(promises)
    } finally {
      this.isLoading = false;
    }
  },
  methods: {
    async getCustomerTickets(superOfficeId) {
      this.customerTicketsLoading = true;
      await axios.get(`/api/ticket/customer/${superOfficeId}`)
        .then(x => this.customerTickets = x.data)
        .finally(() => this.customerTicketsLoading = false)
    },
    async getCustomerActivities(superOfficeId) {
      this.customerActivitiesLoading = true;
      await axios.get(`/api/so/customer/activities/${superOfficeId}`)
        .then(x => this.customerActivities = x.data)
        .finally(() => this.customerActivitiesLoading = false)
    },
    async getCustomerStatisticsCards() {
      await axios.get(`/api/customerStatistics/backstage?customerId=${this.customerStatisticsFetchId}`).then(response => {
        this.customerStatisticsCards = response.data.data.cards
      })
    },
    async getCustomerConsignments() {
      this.customerConsignmentsLoading = true;
      try {
        const { data } = await axios.get(`/api/parcel/${this.customer.id}/customer-shipments`);
        this.customerConsignments = data;
      } finally {
        this.customerConsignmentsLoading = false;
      }
    },
  },
  computed: {
    deviceOverviewCard() {
      return this.customerStatisticsCards.find(x => x.header === "Devices")
    },
    installedCard() {
      return this.customerStatisticsCards.find(x => x.header === "Installed")
    },
    accountsCard() {
      return this.customerStatisticsCards.find(x => x.header === "Accounts")
    },
    vehicleTypesCard() {
      return this.customerStatisticsCards.find(x => x.header === "Types")
    },
    subscriptionsCard() {
      return this.customerStatisticsCards.find(x => x.header === "Main Subs")
    },
    featuresCard() {
      return this.customerStatisticsCards.find(x => x.header === "Features")
    },
    customerTicketsComputed() {
      return this.customerTickets ?? [];
    },
    latestCustomerActivity() {
      return this.customerActivities[this.customerActivities.length - 1];
    },
    openConsignments() {
      return this.customerConsignments?.filter(consignment => !consignment.delivered).length ?? 0;
    },
    deliveredConsignments() {
      return this.customerConsignments?.filter(consignment => consignment.delivered).length ?? 0;
    },
  }
}
</script>

<style scoped>

</style>
