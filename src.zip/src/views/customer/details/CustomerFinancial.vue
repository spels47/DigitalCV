﻿<template>
  <v-container fluid>
    <v-row>
      <v-col>
        <CardWithHeader
          title="Contracts"
          :loading="customerInformationLoading"
          remove-padding
        >
          <template v-slot:content>
            <ContractInfo :currentContract="currentContract"></ContractInfo>
            <v-container class="py-0">
              <v-select
                :items="customerInformation"
                v-model="selected"
                item-text="contractNumber"
                @change="changeContract"
              >
                <template slot="selection" slot-scope="data">
                  {{ data.item.contractNumber }} - Expires {{ data.item.lastRenewalDate | ntzDate }}
                </template>
                <template slot="item" slot-scope="data">
                  {{ data.item.contractNumber }} - Expires {{ data.item.lastRenewalDate | ntzDate }}
                </template>
              </v-select>
            </v-container>
          </template>
        </CardWithHeader>
      </v-col>
      <v-col>
        <CardWithHeader
          title="Prices (ex. VAT)"
          :loading="customerInformationLoading"
          remove-padding
        >
          <template v-slot:content>
            <PricesInfo
              :customer="customer"
              :customerInformation="customerInformation"
            ></PricesInfo>
          </template>
        </CardWithHeader>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <CardWithHeader
          title="Invoices"
          :loading="customerLedgerLoading"
          remove-padding
        >
          <template v-slot:content>
            <Invoice
              :customerLedger="customerLedger"
              :customer="customer"
            ></Invoice>
          </template>
        </CardWithHeader>
      </v-col>
      <v-col>
        <CardWithHeader
          title="Consignments"
          remove-padding
        >
          <template v-slot:content>
            <Consignments></Consignments>
          </template>
        </CardWithHeader>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "@/axios-client";
import ContractInfo from "@/components/widgets/CustomerOverview/ContractInfo";
import PricesInfo from "@/components/widgets/CustomerOverview/PricesInfo";
import Invoice from "@/components/widgets/CustomerOverview/Invoice";
import Consignments from "@/components/widgets/CustomerOverview/Consignments";
import CardWithHeader from "@/components/cards/CardWithHeader";

export default {
  name: "CustomerFinancial",
  components: { CardWithHeader, Invoice, PricesInfo, ContractInfo, Consignments },
  props: {
    customer: Object,
  },
  data() {
    return {
      selected: [],
      customerInformation: [],
      groupedSubscriptions: [],
      customerLedger: [],
      currentContract: {},
      customerConsignments: [],
      customerLedgerLoading: false,
      customerInformationLoading: false,
    }
  },
  async created() {
    if (!this.customer.erpCustomerId)
      return;

    await this.getCustomerOverview();
  },
  watch: {
    customer: {
      handler: async function (newValue, oldValue) {
        if (!newValue.erpCustomerId)
          return;

        await this.getCustomerOverview()
      },
      deep: true
    }
  },
  methods: {
    changeContract(item) {
      if (this.customerInformation !== undefined) {
        this.currentContract = this.customerInformation.find(x => x.contractNumber === item);
      }
    },
    async getCustomerOverview() {
      await Promise.all([this.getCustomerInformation(), this.getCustomerLedger()]);
    },
    async getCustomerInformation() {
      this.customerInformationLoading = true;

      try {
        const { data } = await axios.get(`/api/bcs/CustomerInformation?customerId=${this.customer.erpCustomerId}&clientId=${this.customer.erpClientId}`);
        this.customerInformation = data;
        this.customerInformation.sort((a, b) => a.endDate === b.endDate ? 0 : a.endDate < b.endDate ? -1 : 1)
        this.currentContract = this.customerInformation[0];
        this.selected = this.currentContract;
      } finally {
        this.customerInformationLoading = false;
      }
    },
    async getCustomerLedger() {
      this.customerLedgerLoading = true;

      try {
        const { data } = await axios.get(`/api/bcs/CustomerLedger?customerId=${this.customer.erpCustomerId}&clientId=${this.customer.erpClientId}`);
        this.customerLedger = data;
      } finally {
        this.customerLedgerLoading = false;
      }
    },
  }
}
</script>

<style scoped>

</style>
