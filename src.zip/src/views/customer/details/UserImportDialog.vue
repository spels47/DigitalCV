﻿<template>
  <v-row no-gutters>
    <v-col cols="3">
      <v-card color="black" class="pa-4">

        <v-text-field placeholder="Name" prepend-icon="mdi-account" dark></v-text-field>

        <v-text-field placeholder="Username" prepend-icon="mdi-account" dark></v-text-field>

        <v-text-field placeholder="Email" prepend-icon="mdi-account" dark></v-text-field>

        <v-text-field placeholder="Mobile" prepend-icon="mdi-account" dark></v-text-field>

        <v-text-field placeholder="RCID" prepend-icon="mdi-account" dark></v-text-field>

        <v-text-field placeholder="Department" prepend-icon="mdi-account" dark></v-text-field>

        <v-text-field placeholder="Employee Number" prepend-icon="mdi-account" dark></v-text-field>
        <v-text-field placeholder="Title" prepend-icon="mdi-account" dark></v-text-field>|
        <v-checkbox dense label="Send password to user" dark></v-checkbox>
        <v-row class="justify-center">
          <v-btn color="secondary" class="elevation-1 mb-5" width="200">
            <v-icon color="white">mdi-plus</v-icon>
            <span>Add User</span>
          </v-btn>
        </v-row>
        <v-row class="justify-center">
          <v-btn class="elevation-1 mb-3" color="secondary" width="200" outlined>
            <v-icon color="secondary"> mdi-file-excel</v-icon>
            <span class="secondary--text">Import Excel</span>
          </v-btn>
        </v-row>
        <v-row class="justify-center">
          <v-btn color="white" text x-small>
            Download template
          </v-btn>
        </v-row>
      </v-card>
    </v-col>
    <v-col cols="9">
      <v-card height="100%">
        <v-data-table :headers="headers" :items="items" :footer-props="{ 'items-per-page-options': [13] }">
        </v-data-table>
        <div class="float-right pa-5">
          <v-btn text small @click="cancel()">Cancel</v-btn>
          <v-btn class="pa-4" prepend-icon="mdi-file-excel" color="secondary" @click="save()">
            <v-icon left>mdi-content-save-edit</v-icon> Save Users
          </v-btn>
        </div>
      </v-card>
    </v-col>
  </v-row>
</template>

<script>
export default {
  data() {
    return {
      name: "UserImportDialog",
      items: [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1],
      headers: [
        {text: 'Name', value: 'name'},
        {text: 'E-mail', value: 'email'},
        {text: 'Mobile', value: 'mobile'},
        {text: 'RCID', value: 'rcid'},
        {text: 'Title', value: 'title'},
        {text: 'Department', value: 'department'},
        {text: 'Employee number', value: 'employeeNumber'},
        {text: 'Send user/pass', value: 'sendUsernameAndPassword'},
        {text: 'Delete', value: 'delete'}
      ],
    }
  },
  methods: {
    cancel(){
      this.$emit('closeUserImport')
    },
    save(){

    }
  }
}
  </script>

<style lang="css" scoped>
.bottom-right{
  margin-top: 30px;
  position: absolute;
  right: 20px;
  bottom: 20px;
}
.fill-height{
  height: 100%;
}
</style>
