<template>
  <div>
    <div class="relative">
      <v-img class="mb-n4" height="250px" src="@/assets/customer-header.png" style="z-index: 0" />
    </div>
    <v-main>
      <v-row>
        <v-col>
          <v-card>
            <v-list>
              <v-list-item class="mt-5">
                <v-text-field :readonly="true" prepend-icon="mdi-domain" label="Name" />
              </v-list-item>
              <v-list-item>
                <v-icon left> mdi-flag</v-icon>
                <v-text-field readonly label="Country" />
              </v-list-item>
            </v-list>
          </v-card>
        </v-col>
      </v-row>

      <v-row>
        <v-col>
          <v-expansion-panels class="elevation-2">
            <v-expansion-panel>
              <v-expansion-panel-header>
                Customer info
              </v-expansion-panel-header>
              <v-expansion-panel-content>
                <v-list>
                  <v-list-item>
                    <v-text-field prepend-icon="mdi-numeric" :readonly="true" label="Customer ID"> </v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-text-field prepend-icon="mdi-numeric" label="Navision Client ID"> </v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-text-field prepend-icon="mdi-numeric" label="ERP Customer ID"> </v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-text-field prepend-icon="mdi-numeric" label="Super Office Contact ID"> </v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-text-field prepend-icon="mdi-numeric" label="Main Office ID"></v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-text-field prepend-icon="mdi-calendar" readonly label="Customer Created"></v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-text-field prepend-icon="mdi-email" label="Email" />
                  </v-list-item>
                  <v-list-item>
                    <v-icon left>mdi-map-marker</v-icon>
                    <v-text-field label="Address" />
                  </v-list-item>
                  <v-list-item>
                    <v-text-field prepend-icon="mdi-map-marker" label="Zip Code"> </v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-text-field prepend-icon="mdi-map-marker" label="City"> </v-text-field>
                  </v-list-item>
                  <v-list-item>
                    <v-icon>mdi-counter</v-icon>
                    <v-text-field label="Org. Nr" />
                  </v-list-item>
                  <v-list-item>
                    <v-text-field prepend-icon="mdi-phone" label="Telephone" />
                  </v-list-item>
                </v-list>
              </v-expansion-panel-content>
            </v-expansion-panel>
          </v-expansion-panels>
        </v-col>
      </v-row>

      <v-row>
        <v-col>
          <v-bottom-navigation :background-color="'cardbg'" class="elevation-2" height="60">
            <v-btn>
              <span>Add to favorites</span>
              <v-icon>mdi-heart</v-icon>
            </v-btn>
            <v-btn>
              <span>Customer Settings</span>
              <v-icon>mdi-cog</v-icon>
            </v-btn>
            <v-btn>
              <span>Contact Log</span>
              <v-icon>mdi-stack-exchange</v-icon>
            </v-btn>
          </v-bottom-navigation>
        </v-col>
      </v-row>
    </v-main>
  </div>
</template>

<script>
export default {
  name: "CustomerDetailsPlaceholder",
}
</script>

<style scoped></style>

