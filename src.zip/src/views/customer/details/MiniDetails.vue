<template>
  <v-card
    outlined
    class="fill-width"
  >
    <v-row cols="12">
      <v-list>
        <v-progress-linear indeterminate color="black" v-if="isLoading"></v-progress-linear>
        <v-list-item three-line>
          <v-list-item-content>
            <v-list-item-subtitle>
              <DepartmentPath clickable :department-path="dataSource.departmentPath"></DepartmentPath>
            </v-list-item-subtitle>
            <v-list-item-title class="headline">
              <v-icon class="px-2">mdi-account</v-icon>
              <span>Account info</span>
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-row>
    <v-row cols="12" class="ml-5" no-gutters>
      <v-row>
        <v-list width="80%">
          <v-list-item>
            <v-text-field @change="updateDataSourceInfo" prepend-icon="mdi-domain" label="Data Source ID" v-model="dataSource.name" />
          </v-list-item>
          <v-list-item>
            <v-text-field @change="updateDataSourceInfo" prepend-icon="mdi-domain" label="Username" v-model="dataSource.username" />
          </v-list-item>
          <v-list-item>
            <v-text-field @change="updateDataSourceInfo" prepend-icon="mdi-domain" label="UserId" v-model="dataSource.userId" />
          </v-list-item>
          <v-list-item>
            <v-text-field @change="updateDataSourceInfo" prepend-icon="mdi-phone" label="Telephone" v-model="dataSource.telephone" />
          </v-list-item>
          <v-list-item>
            <v-text-field @change="updateDataSourceInfo" prepend-icon="mdi-email" label="Email" v-model="dataSource.email"/>
          </v-list-item>
        </v-list>
      </v-row>
    </v-row>
  </v-card>
</template>

<script>
  import axios from "~/axios-client"
  import DepartmentPath from "~/components/DepartmentPath"
  export default {
    name: "MiniDetails",
    components: {DepartmentPath},
    props: {
      id: String,
      type: String,
      expanded: Boolean
    },
    data: function () {
      return {
        dataSource: {},
        isLoading:true
      }
    },
    mounted() {
      this.getDataSourceInfo()
    },
    watch: {
      id: function () {
        this.getDataSourceInfo()
      }
    },
    methods:{
      getDataSourceInfo(){
        this.dataSource = {}
        this.isLoading = true
        if(!this.type) return
        axios.get(`/api/datasource/${this.type}/${this.id}`)
          .then((res) => this.dataSource = res.data)
          .catch(() => { this.$eventBus.$emit('alert', {template: 'api-error'}) })
          .finally(() => this.isLoading = false)
      },
      updateDataSourceInfo(){
        clearTimeout(this._timerId);

        this._timerId = setTimeout(() => {
          this.isLoading = true
          axios.put(`/api/datasource/${this.type}`, this.dataSource)
            .catch(() => { this.$eventBus.$emit('alert', {template: 'api-error'}) })
            .finally(() => this.isLoading = false)
        }, 500);
      },
    }
  }
</script>

<style scoped>
  .fill-width{
    width: 100%;
  }
</style>
