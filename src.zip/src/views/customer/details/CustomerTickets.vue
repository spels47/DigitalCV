﻿<template>
  <v-sheet>
    <EntityListTable
      :items="tickets"
      :headers="headers"
      :customer="customer"
      :sort-desc="true"
      :multi-sort="false"
      :show-select="false"
      sort-by="createdAt"
      @rowClicked="rowClicked"
    >
      <template #table-header>
        <MassHandleButton
          icon="mdi-plus"
          tooltip="Create ticket"
          buttonColor="success"
          @buttonClicked="showCreateTicketDialog = true"
        ></MassHandleButton>
      </template>
    </EntityListTable>

    <CreateTicket
      :show="showCreateTicketDialog"
      :key="showCreateTicketDialog"
      @createdTicket="addCreatedTicket"
      @close="showCreateTicketDialog = false"
    ></CreateTicket>
  </v-sheet>
</template>

<script>
import EntityListTable from "@/components/entityLists/EntityListTable";
import MassHandleButton from "@/components/MassHandleButton";
import CreateTicket from "@/components/sidebars/tickets/CreateTicket";

export default {
  name: "CustomerTickets",
  components: { CreateTicket, MassHandleButton, EntityListTable },
  props: {
    customer: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      showCreateTicketDialog: false,
      headers: [
        { text: "ID", value: "ticketId" },
        { text: 'Title', value: 'title' },
        { text: 'Priority', value: 'priorityName' },
        { text: 'Status', value: 'ticketStatusName' },
        { text: 'Category', value: 'categoryFullName' },
        { text: 'Created', value: 'createdAt' },
        { text: 'Closed', value: 'closedAt' }
      ]
    }
  },
  watch: {
    customer: {
      handler: function (newValue, oldValue) {
        if (!newValue.superOfficeId)
          return;

        this.$store.dispatch("CustomerTicketsModule/retrieveCustomerTickets", newValue.superOfficeId);
      },
      deep: true,
      immediate: true
    }
  },
  methods: {
    addCreatedTicket(ticket) {
      this.$store.dispatch("CustomerTicketsModule/addTicketToList", ticket);
    },
    rowClicked(row) {
      this.$emit("rowClicked", row);
    }
  },
  computed: {
    tickets() {
      return this.$store.state.CustomerTicketsModule.tickets;
    }
  }
}
</script>

<style scoped>

</style>
