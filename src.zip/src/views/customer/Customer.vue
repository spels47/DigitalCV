<template>
  <v-container fluid class="pt-0 pl-7">
    <template>
      <DepartmentSidebar v-if="customer" class="floaty-boxy" :department="customer" :main-office-hierarchy="mainOfficeHierarchy"></DepartmentSidebar>
      <VehicleSidebar v-if="sidebarState && selectedItem.type === 'vehicle'" :id="selectedItem.id" :customer="customer" :main-office-hierarchy="mainOfficeHierarchy"></VehicleSidebar>
      <AccountSidebar v-if="sidebarState && selectedItem.type === 'account'" :id="selectedItem.id" :department-id="departmentId" :customer="customer"></AccountSidebar>
      <EquipmentSidebar v-if="sidebarState && selectedItem.type === 'eq'" :id="selectedItem.id" :department-id="departmentId" :customer="customer"></EquipmentSidebar>
      <DataSourceSidebar v-if="sidebarState && ['simcard', 'mini'].includes(selectedItem.type)" :id="selectedItem.id" :customer="customer"></DataSourceSidebar>
      <DataSourceOemSidebar v-if="sidebarState && selectedItem.type === 'oem'" :id="selectedItem.id" :customer="customer"></DataSourceOemSidebar>
      <SubscriptionSidebar v-if="sidebarState && selectedItem.type === 'subscription'" :id="selectedItem.id" :customer="customer"></SubscriptionSidebar>
      <CustomerSidebar v-if="sidebarState && selectedItem.type === 'customer'" :customer="customer"></CustomerSidebar>
      <CustomerLogSidebar v-if="sidebarState && selectedItem.type === 'contactLog'" :customer="customer"></CustomerLogSidebar>
      <CustomerTicketSidebar
        v-if="sidebarState && selectedItem.type === 'ticket'"
        :customer="customer"
        :ticket="selectedItem.data.data"
        @closeSidebar="closeSidebar"
      ></CustomerTicketSidebar>
    </template>
    <v-row>
      <v-list-item>
        <v-list-item-content>
          <v-list-item-subtitle>
            <DepartmentPath clickable :department-path="customer.departmentPath"></DepartmentPath>
          </v-list-item-subtitle>
        </v-list-item-content>
      </v-list-item>
      <v-col :lg="3" :md="3" :sm="12">
        <CustomerDetails :customer="customer" :customerStatistics="customerStatistics" :portfolioTeam="portfolioTeam" :customer-hierarchy="customerHierarchy" :main-office-hierarchy="mainOfficeHierarchy" @openCustomerSidebar="openCustomerSidebar" @openContactLogSidebar="openContactLogSidebar"></CustomerDetails>
      </v-col>
      <v-col :lg="9" :md="9" :sm="12">
        <v-col>
          <v-fade-transition>
            <CustomerStatistics
              v-if="customerStatistics.data || customerStatisticsLoading"
              :customer-statistics="customerStatistics"
              :customer="customer"
              :loading="customerStatisticsLoading"
            ></CustomerStatistics>
          </v-fade-transition>
        </v-col>
        <v-col>
          <EntityList :customerId="customerId" :customer="customer" @openSidebar="openSidebar"></EntityList>
        </v-col>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import { mapGetters, mapActions } from 'vuex'

import CustomerDetails from "./details/CustomerDetails";
import CustomerStatistics from "./details/CustomerStatistics";
import DepartmentPath from "~/components/DepartmentPath";
import DepartmentSidebar from "~/components/widgets/DepartmentSidebar";

//sidebars
import VehicleSidebar from "~/components/sidebars/vehicle/VehicleSidebar";
import AccountSidebar from "~/components/sidebars/account/AccountSidebar";
import EquipmentSidebar from "~/components/sidebars/equipment/EquipmentSidebar";
import DataSourceSidebar from "~/components/sidebars/datasource/DataSourceSidebar";
import DataSourceOemSidebar from "~/components/sidebars/datasource-oem/DataSourceOemSidebar";
import SubscriptionSidebar from "@/components/sidebars/subscription/SubscriptionSidebar";
import CustomerSidebar from "@/components/sidebars/customer/CustomerSidebar";
import EntityList from "@/components/widgets/EntityList";
import CustomerLogSidebar from "@/components/sidebars/CustomerLog/CustomerLogSidebar.vue";
import CustomerTicketSidebar from "@/components/sidebars/tickets/CustomerTicketSidebar";

export default {
  data() {
    return {
      tab: null,
      openPanels: 0,
      customerStatistics: {},
      portfolioTeam: null,
      customerStatisticsLoading: true,
      sidebarTrigger: 0,
      selectedItem: {},
      customerStatisticsFetchId: 0,
    };
  },
  async created() {
    await this.$store.dispatch("userSettings_Fetch");
    if (!this.customerId)
      return;
    await this.fetchCustomer(this.customerId);

    let type = this.queryType;
    let id = this.queryId?.toString();
    if (type) {
      let row = { type: type, id: id };
      await this.openSidebar(row);
    }
    await this.getPortfolioTeam(this.customerId);
    await this.getCustomerStatistics(this.customerId);
  },
  computed: {
    ...mapGetters('customerStore', ['customer', 'customerHierarchy', 'mainOfficeHierarchy']),

    departmentId() {
      return this.selectedItem?.data?.data?.departmentId ?? 0;
    },
    customerId: function() {
      return this.$route.params.id;
    },
    queryType: function() {
      return this.$route.query.type;
    },
    queryId: function() {
      return this.$route.query.id;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    sidebarState: {
      get: function() {
        return this.$store.state.SidebarModule.sidebarState;
      },
      set: function(value) {
        this.$store.commit("updateSidebarState", value);
      }
    },
    menuItems() {
      return [
        { page: "vehicle-details", icon: "mdi-information", id: 0 },
        { page: "vehicle-trips", icon: "mdi-vector-polyline", id: 1 },
        { page: "audit-details", icon: "mdi-history", id: 4 }
      ];
    }
  },
  methods: {
    ...mapActions('customerStore', ['fetchCustomer']),
    async getPortfolioTeam(customerId) {
      await axios.get(`/api/portfolio/teamForCustomer/${customerId}`).then(response => {
        this.portfolioTeam = response.data;
      })
    },
    async getCustomerStatistics(customerId) {
      this.customerStatisticsLoading = true;
      await axios
        .get("/api/customerStatistics/backstage?customerId=" + customerId)
        .then(response => {
          this.customerStatistics = response.data;
          this.customerStatisticsLoading = false;
        })
        .catch(() => {
          this.customerStatisticsLoading = false;
          this.customerStatistics = {};
          this.$eventBus.$emit('alert', { text: `Failed to load customer statistics for this customer`, type: 'warning'});
        });
    },
    async closeSidebar() {
      this.sidebarState = false;
      await this.$store.dispatch("setUrlParameter", { name: "type", value: null });
      await this.$store.dispatch("setUrlParameter", { name: "id", value: null });
    },
    async openSidebar(row) {
      this.selectedItem = { type: row.type, id: row.id?.toString(), data: row };
      this.sidebarState = true;
      await this.$store.dispatch("setUrlParameter", { name: "type", value: row.type });
      await this.$store.dispatch("setUrlParameter", { name: "id", value: this.selectedItem.id });
    },
    openCustomerSidebar() {
      this.selectedItem = { type: "customer", id: null, data: null };
      this.sidebarState = true;
    },
    openContactLogSidebar() {
      this.selectedItem = { type: "contactLog", id: null, data: null };
      this.sidebarState = true;
    },
  },
  components: {
    CustomerTicketSidebar,
    CustomerLogSidebar,
    EntityList,
    SubscriptionSidebar,
    CustomerStatistics,
    CustomerDetails,
    DepartmentPath,
    VehicleSidebar,
    AccountSidebar,
    EquipmentSidebar,
    DataSourceSidebar,
    DataSourceOemSidebar,
    DepartmentSidebar,
    CustomerSidebar
  }
};
</script>

<style lang="scss">
.v-expansion-panel::before {
  box-shadow: none;
}
</style>
