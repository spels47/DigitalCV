<template>
  <v-container fluid class="pt-0 pl-7">
    <template>
      <DataSourceSidebar v-if="sidebarState" :id="this.queryId" :stateless="true"></DataSourceSidebar>
    </template>
    <v-row>
      <v-col :lg="3" :md="3" :sm="12">
        <CustomerDetailsPlaceholder></CustomerDetailsPlaceholder>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import DataSourceSidebar from "~/components/sidebars/datasource/DataSourceSidebar";
import CustomerDetailsPlaceholder from "@/views/customer/details/CustomerDetailsPlaceholder";

export default {
  components: {
    CustomerDetailsPlaceholder,
    DataSourceSidebar,
  },
  data() {
    return {
      tab: null,
      openPanels: 0,
      sidebarTrigger: 0,
      selectedItem: {},
    };
  },
  async created() {
    await this.$store.dispatch("userSettings_Fetch");

    let id = this.queryId?.toString();
    let row = { type: "dataSource", id: id };
    await this.openSidebar(row);
  },
  methods: {
    async openSidebar() {
      this.sidebarState = true;
    },
  },
  computed: {
    queryId: function() {
      return this.$route.query.dataSourceId;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    sidebarState: {
      get: function() {
        return this.$store.state.SidebarModule.sidebarState;
      },
      set: function(value) {
        this.$store.commit("updateSidebarState", value);
      }
    },
  },
};
</script>

<style lang="scss">
.v-expansion-panel::before {
  box-shadow: none;
}
</style>
