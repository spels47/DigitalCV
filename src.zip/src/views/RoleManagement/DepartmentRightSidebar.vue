﻿<template>
  <v-navigation-drawer color="cardbg" right temporary app v-model="shown" :width="expanded ? 800 : 500" class="pe-15"
                       hide-overlay>
    <v-row class="fill-height" no-gutters>
      <v-navigation-drawer stateless temporary color="black" dark app right mini-variant v-model="shown"
                           mini-variant-width="60" hide-overlay>
        <v-list-item>
          <v-list-item-avatar>
            <UserAvatar></UserAvatar>
          </v-list-item-avatar>
        </v-list-item>

        <v-divider></v-divider>

        <v-list dense nav>
          <v-list-item-group :value="getIndex()">
            <v-list-item v-for="item in menuItems" :key="item.id" @click="navigate(item.page)">
              <v-list-item-icon>
                <v-icon v-text="item.icon"></v-icon>
              </v-list-item-icon>
              <v-list-item-content @click="navigate(item.page)">
                <v-list-item-title v-text="item.page"></v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </v-list-item-group>
        </v-list>
        <template v-slot:append>
          <v-list-item link @click="expanded = !expanded">
            <v-list-item-icon v-if="expanded">
              <v-icon>mdi-arrow-bottom-right</v-icon>
            </v-list-item-icon>
            <v-list-item-icon v-if="!expanded">
              <v-icon>mdi-arrow-top-left</v-icon>
            </v-list-item-icon>
          </v-list-item>
        </template>

      </v-navigation-drawer>
      <DepartmentRightDetails  v-if="currentPage === 'departmentright-details'" :department="department" :expanded="expanded"></DepartmentRightDetails>
    </v-row>
  </v-navigation-drawer>
</template>

<script>
import UserAvatar from "~/components/UserAvatar";
import DepartmentRightDetails from "@/views/RoleManagement/DepartmentRightDetails";

export default {
  name: "DepartmentRightSidebar",
  props: {
    trigger: Number,
    department: Object
  },
  data() {
    return {
      sidebarTrigger: 0,
      shown: false,
      expanded: false,
      currentPage: 'departmentright-details',
      menuItems: [{
        page: 'departmentright-details',
        icon: 'mdi-home'
      }]
    }
  },
  methods: {
    getIndex() {
      return this.menuItems.findIndex(x => x.page === this.currentPage);
    },
    async navigate(page) {
      if (this.user === '' && page === "departmentright-details") {
        //todo display empty page
      }
    },
  },
  mounted() {
  },
  watch: {
    trigger: function () {
      this.shown = true;
    },
  },
  components: {
    DepartmentRightDetails,
    UserAvatar,
  }
}
</script>

<style scoped>
.fill-width {
  width: 100%;
}

.icon-button-wrap {
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
