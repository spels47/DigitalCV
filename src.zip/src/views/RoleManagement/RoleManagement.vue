<template>
  <v-container fluid>
    <UserRightSidebar :userName="userName" :trigger="userSidebarTrigger"></UserRightSidebar>
    <DepartmentRightSidebar :department="department" :trigger="depSidebarTrigger"></DepartmentRightSidebar>

    <v-row>
      <v-col>
        <v-card :loading="loading">
          <v-card-text>
            <v-text-field
              style="width:40%"
              v-model="searchUser"
              append-icon="mdi-magnify"
              label="Search"
              single-line
              hide-details
              data-cy="role-management-users-table-search"
            ></v-text-field>
          </v-card-text>

          <v-data-table
            :headers="[{text:'Username', value:'name'}, {text:'Department', value: 'departmentAdherence'}]"
            :items="userTableData"
            :search="searchUser"
            :custom-filter="customSearch"
            :sort-by="['name']"
            :sort-asc="['true', 'false']"
            data-cy="role-management-users-table"
            :items-per-page="15"
            :footer-props="{ 'items-per-page-options': (items_per_page = [5, 10, 15]) }"

            @click:row="userClick"
          >
            <template v-slot:item.name="{ item }">
              <strong>{{ item.name }}</strong>
            </template>
          </v-data-table>
        </v-card>
      </v-col>

      <v-col :xl="4" :lg="4" :md="4" :sm="4">
        <v-card :loading="loading">
          <v-tabs
            background-color="black"
            dark
          >
            <v-tab>Departments</v-tab>
          </v-tabs>
          <v-card-text>
            <v-text-field style="width:100%" data-cy="role-management-departments-search" v-model="searchDepartment" single-line hide-details append-icon="mdi-magnify" label="Search..."></v-text-field>
          </v-card-text>
          <v-list
            class="hide-scrollbar"
            max-height="780"
          >
            <v-list-item
              v-for="(department, index) in departmentFilter"
              :key="index"
              :search="searchDepartment"
              data-cy="role-management-departments-sidebar"
              @click="openDepartmentRole(department)"
            >
              <span>{{ department.name === '' || department.name === null ? "External Department" : department.name }}</span>
            </v-list-item>
          </v-list>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import UserRightSidebar from './UserRightSidebar';
import DepartmentRightSidebar from './DepartmentRightSidebar';

export default {
  name: "RoleManagement",
  components: {
    UserRightSidebar,
    DepartmentRightSidebar
  },
  data() {
    return {
      searchUser: null,
      searchDepartment: null,
      loading: false,
      departmentRoles: [],
      userRoles: [],
      dialog: false,
      expanded: {},
      userName: '',
      department: {},
      userSidebarTrigger: 0,
      depSidebarTrigger: 0,
    };
  },
  async mounted() {
    await this.getRoles();
  },
  methods: {
    customSearch(value, search, item) {
      const hasName = item.name.toLowerCase().includes(search);
      const hasRole = item.roles.some(role => role.toLowerCase() === search.toLowerCase());
      return hasName || hasRole;
    },
    userClick(item) {
      this.userName = item.name;
      this.userSidebarTrigger++;
    },
    async getRoles() {
      this.loading = true;
      await axios
        .get("/api/RoleManagement")
        .then(res => {
          this.departmentRoles = res.data.departmentRoles.sort(
            (a, b) => a.name - b.name
          );
          this.userRoles = res.data.userRoles.sort((a, b) => {
            if (a.departmentAdherence > b.departmentAdherence) return 1;
            else if (a.departmentAdherence < b.departmentAdherence) return -1;
            if (a.name < b.name) return -1;
            else if (a.name > b.name) return 1;
            return 0;
          });
        })
        .catch(() => {
          this.$eventBus.$emit('alert', { text: 'Failed to retrieve user roles', icon: 'mdi-alert-circle', type: 'error' });
        })
        .finally(() => {
          this.loading = false;
        });
    },
    openDepartmentRole(item) {
      this.department = item;
      this.depSidebarTrigger++;
    },
    expand(index) {
      this.$set(this.expanded, index, !this.expanded[index]);
    },
    close() {
      this.dialog = false;
    }
  },
  computed: {
    departmentFilter() {
      if (this.searchDepartment) {
        return this.departmentRoles?.filter(x => x.name?.toLowerCase()?.includes(this.searchDepartment.toLowerCase()));
      } else {
        return this.departmentRoles;
      }
    },
    userTableData() {
      return this.userRoles.map(x => {
        return {
          name: x.name,
          departmentAdherence: x.departmentAdherence,
          roles: x.roles.map(z => z.roleName)
        }
      })
    }
  },
};
</script>

<style scoped>
.hide-scrollbar {
  overflow-y: auto;
}
</style>
