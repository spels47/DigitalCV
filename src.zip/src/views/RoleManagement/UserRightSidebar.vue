﻿<template>
  <v-navigation-drawer color="cardbg" right temporary app v-model="shown" :width="expanded ? 800 : 500" class="pe-15"
                       hide-overlay>
    <v-row class="fill-height" no-gutters>
      <v-navigation-drawer stateless temporary color="black" dark app right mini-variant v-model="shown"
                           mini-variant-width="60" hide-overlay>
        <v-list-item>
          <v-list-item-avatar>
            <UserAvatar></UserAvatar>
          </v-list-item-avatar>
        </v-list-item>

        <v-divider></v-divider>

        <v-list dense nav>
          <v-list-item-group :value="getIndex()">
            <v-list-item v-for="item in menuItems" :key="item.id" @click="navigate(item.page)">
              <v-list-item-icon>
                <v-icon v-text="item.icon"></v-icon>
              </v-list-item-icon>
              <v-list-item-content @click="navigate(item.page)">
                <v-list-item-title v-text="item.page"></v-list-item-title>
              </v-list-item-content>
            </v-list-item>
          </v-list-item-group>
        </v-list>
        <template v-slot:append>
          <v-list-item link @click="expanded = !expanded">
            <v-list-item-icon v-if="expanded">
              <v-icon>mdi-arrow-bottom-right</v-icon>
            </v-list-item-icon>
            <v-list-item-icon v-if="!expanded">
              <v-icon>mdi-arrow-top-left</v-icon>
            </v-list-item-icon>
          </v-list-item>
        </template>

      </v-navigation-drawer>
      <UserRightDetails  v-if="currentPage === 'userright-details'" :userName="userName" :expanded="expanded"></UserRightDetails>
    </v-row>
  </v-navigation-drawer>
</template>

<script>
import axios from "~/axios-client";
import UserAvatar from "~/components/UserAvatar";
import UserRightDetails from "./UserRightDetails";

export default {
  name: "UserRightSidebar",
  props: {
    trigger: Number,
    userName: String,
  },
  data() {
    return {
      shown: false,
      expanded: false,
      currentPage: 'userright-details',
      menuItems: [{page: 'userright-details', icon: 'mdi-account-key', id: 0}]
    }
  },
  methods: {
    getIndex() {
      return this.menuItems.findIndex(x => x.page === this.currentPage);
    },
    async navigate(page) {
      if (this.user === '' && page === "userright-details") {
        //todo display empty page
      }
    },
  },
  mounted() {
  },
  watch: {
    trigger: function () {
      this.shown = true;
    },
    userName: function() {

    }
  },
  components: {
    UserRightDetails,
    UserAvatar,
  }
}
</script>

<style scoped>
.fill-width {
  width: 100%;
}

.icon-button-wrap {
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
