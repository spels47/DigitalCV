﻿<template>
  <v-container fluid>
    <v-progress-linear absolute indeterminate v-if="isLoading"></v-progress-linear>
    <v-row>
      <v-col class="py-0">
        <v-list class="py-0">
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <v-text-field label="User" prepend-icon="mdi-account" disabled :value="this.user.name"></v-text-field>
              </v-list-item-subtitle>
              <v-list-item-subtitle>
                <v-text-field label="Department" prepend-icon="mdi-domain" disabled :value="this.user.departmentAdherence"></v-text-field>
              </v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col class="py-0 mb-2">
        <v-list class="py-0">
          <v-list-item>
            <v-icon color="#C800A1">mdi-checkbox-blank-circle</v-icon>
            <span class="ml-2">Rights inherited by department</span>
          </v-list-item>
          <v-list-item>
            <v-icon color="#25BACA">mdi-checkbox-blank-circle</v-icon>
            <span class="ml-2">Rights inherited by user</span>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row dense>
      <v-col>
        <RoleGroup
          :title="'User'"
          :is-department="false"
          :roles="userRoles"
          :department-rights="departmentRights"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
      <v-col>
        <RoleGroup
          :title="'Customer'"
          :is-department="false"
          :roles="customerRoles"
          :department-rights="departmentRights"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
    </v-row>
    <v-row dense>
      <v-col>
        <RoleGroup
          :title="'Asset'"
          :is-department="false"
          :roles="assetRoles"
          :department-rights="departmentRights"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
      <v-col>
        <RoleGroup
          :title="'Role Management'"
          :is-department="false"
          :roles="roleManagementRoles"
          :department-rights="departmentRights"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
    </v-row>
    <v-row dense>
      <v-col>
        <RoleGroup
          :title="'Logistics'"
          :is-department="false"
          :roles="logisticsRoles"
          :department-rights="departmentRights"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
      <v-col>
        <RoleGroup
          :title="'KPI Hub'"
          :is-department="false"
          :roles="kpiHubRoles"
          :department-rights="departmentRights"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
    </v-row>
    <v-row dense>
      <v-col>
        <RoleGroup
          :title="'Development'"
          :is-department="false"
          :roles="developmentRoles"
          :department-rights="departmentRights"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
    </v-row>
    <v-row dense>
      <v-col>
        <RoleGroup
          :title="'Data Source'"
          :is-department="false"
          :roles="dataSourceRoles"
          :department-rights="departmentRights"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
    </v-row>
    <v-row dense>
      <v-col>
        <RoleGroup
          :title="'Portfolio'"
          :is-department="false"
          :roles="portfolioRoles"
          :department-rights="departmentRights"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
      <v-col>
        <RoleGroup
          :title="'Workhub'"
          :is-department="false"
          :roles="workhubRoles"
          :department-rights="departmentRights"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
    </v-row>
    <v-row>
      <v-col class="text-center">
        <v-btn v-if="roles.ROLE_MANAGEMENT_EDIT_USER" color="secondary" class="mb-2" @click.stop="confirmReset = true">
          Reset user rights
        </v-btn>
        <v-dialog v-model="confirmReset" max-width="30%">
          <v-card>
            <v-card-title class="headline">
              Are you sure you wish to reset?
            </v-card-title>
            <v-card-text>
              By resetting user rights, the user will default back to the rights of its department.
            </v-card-text>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="primary" text @click="confirmReset = false">
                Cancel
              </v-btn>
              <v-btn
                color="primary"
                text
                @click="
                  confirmReset = false;
                  resetUser();
                "
              >
                Reset
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "@/axios-client";
import RoleGroup from "@/components/role-management/RoleGroup";

export default {
  name: "UserRightDetails",
  components: { RoleGroup },
  props: {
    userName: String
  },
  data() {
    return {
      userRoles: [
        { text: "Create User", role: "USER_CREATE" },
        { text: "Edit User", role: "USER_EDIT" },
        { text: "Impersonate", role: "USER_IMPERSONATE" },
        { text: "Reset Password", role: "USER_RESET" },
        { text: "Edit User Settings", role: "USER_SETTINGS_EDIT" }
      ],
      customerRoles: [
        { text: "Edit Customer", role: "CUSTOMER_EDIT" },
        { text: "Edit Customer Settings", role: "CUSTOMER_SETTINGS_EDIT" },
        { text: "Move Customer", role: "CUSTOMER_MOVE" }
      ],
      assetRoles: [
        { text: "Edit Asset", role: "ASSET_EDIT" },
        { text: "Move Asset", role: "ASSET_MOVE" },
        { text: "Revision", role: "ASSET_REVISION" }
      ],
      roleManagementRoles: [
        { text: "General Access", role: "ROLE_MANAGEMENT_VIEW" },
        { text: "Edit Template", role: "ROLE_MANAGEMENT_EDIT" },
        { text: "Edit BS User", role: "ROLE_MANAGEMENT_EDIT_USER" }
      ],
      logisticsRoles: [
        { text: "Stock Status", role: "LOGISTICS_STOCK_STATUS" },
        { text: "Pending hot-swaps list", role: "PENDING_HOT_SWAPS_LIST" },
        { text: "Unit Wash", role: "UNIT_WASH" },
        { text: "Jasper List", role: "WORKHUB_JASPER" },
        { text: "ReturnHandling", role: "RETURN_HANDLING" },
        { text: "Swap Prioritization", role: "SWAP_PRIORITIZATION" }
      ],
      workhubRoles: [
        { text: "Welcome Call", role: "WORKHUB_WELCOME_CALL" },
        { text: "Renewal Call", role: "WORKHUB_RENEWAL_CALL" },
        { text: "Termination Call", role: "WORKHUB_TERMINATION_CALL" },
        { text: "Product Ordered Call", role: "WORKHUB_PRODUCTORDERED_CALL" },
        { text: "New subscriptions", role: "WORKHUB_NEW_SUBSCRIPTIONS" },
        { text: "Workhub Admin", role: "WORKHUB_ADMIN" },
        { text: "Churn Prediction", role: "WORKHUB_CHURN_PREDICTION" },
        { text: "Swap Request", role: "WORKHUB_SWAP_REQUEST"},
        { text: "Return handling", role: "WORKHUB_RETURN_HANDLING"},
      ],
      developmentRoles: [
        { text: "Release management", role: "DEVELOPER_RELEASE_MANAGEMENT" },
        { text: "BCS Error List", role: "BCS_ERROR_LIST" },
        { text: "ERP cleanup helper", role: "ERP_CLEANUP_HELPER" },
        { text: "ASAP Dev (temp)", role: "DEVELOPER_ASAP" },
        { text: "Usage-log cleaner", role: "USAGE_LOG_CLEANER" },
        { text: "Area import", role: "AREA_IMPORT" },
        { text: "Webtext edit", role: "WEBTEXT_EDIT" },
        { text: "Version management", role: "VERSION_MANAGEMENT" },
        { text: "View TCO", role: "VIEW_TCO" },
        { text: "AutoSale", role: "AUTO_SALE" },
        { text: "Return to tech", role: "RETURN_TO_TECH" },
      ],
      dataSourceRoles: [
        { text: "Unit diagnostic", role: "DATASOURCE_DIAGNOSTICS" },
        { text: "Update firmware", role: "DATASOURCE_FIRMWARE_UPDATE" },
        { text: "Swap", role: "DATASOURCE_SWAP" }
      ],
      portfolioRoles: [
        { text: "Portfolio", role: "PORTFOLIO_ACCESS" },
        { text: "Portfolio key account", role: "PORTFOLIO_KEY_ACCOUNT" },
        { text: "Portfolio Key-Account Add Customer", role: "PORTFOLIO_KEY_ADD_CUSTOMER" },
        { text: "Portfolio Key-Account Remove Customer", role: "PORTFOLIO_KEY_REMOVE_CUSTOMER" },
        { text: "Portfolio admin", role: "PORTFOLIO_ADMIN" }
      ],
      kpiHubRoles: [
        { text: "Customer", role: "KPI_HUB_CUSTOMER" },
        { text: "Portfolio", role: "KPI_HUB_PORTFOLIO" },
        { text: "Portfolio worklists", role: "KPI_HUB_PORTFOLIO_WORKLISTS" },
        { text: "Worklists", role: "KPI_HUB_WORKLISTS" }
      ],

      selectedRights: [],
      originalRights: [],
      departmentRights: [],
      user: {},
      isLoading: false,
      confirmReset: false
    };
  },
  watch: {
    userName: async function () {
      this.isLoading = true;
      await axios
        .get(`/api/RoleManagement/${this.userName}`)
        .then(res => (this.user = res.data))
        .catch(() => {
          this.$eventBus.$emit("alert", { template: "api-error" });
        })
        .finally(() => (this.isLoading = false));
    },
    user: async function () {
      this.isLoading = true;
      await axios
        .get(`/api/RoleManagement/department/${this.user.departmentAdherence}`)
        .then(res => (this.departmentRights = res.data))
        .catch(error => {
          this.$eventBus.$emit("alert", { template: error });
        })
        .finally(() => {
          this.isLoading = false;
          this.setSelectedRights();
        });
    },
    selectedRights: async function () {
      if (this.selectedRights !== this.originalRights) {
        let roleList = [];
        this.selectedRights.forEach(x => {
          roleList.push({ RoleName: x, Trigger: "" });
        });
        let input = {
          Name: this.user.name,
          DepartmentAdherence: this.user.departmentAdherence,
          Roles: roleList
        };
        this.isLoading = true;
        await axios
          .put(`/api/RoleManagement/user`, input)
          .then(res => (this.user.roles = res.data.roles))
          .catch(error => {
            this.$eventBus.$emit("alert", { template: error });
          })
          .finally(() => {
            this.isLoading = false;
            this.setSelectedRights();
          });
      }
    }
  },
  methods: {
    updateUserRight(updatedRights) {
      this.selectedRights = updatedRights;
    },
    async resetUser() {
      this.isLoading = false;
      await axios
        .put(`/api/RoleManagement/reset/${this.user.name}`)
        .then(res => (this.selectedRights = res.data))
        .catch(error => {
          this.$eventBus.$emit("alert", { template: error });
        })
        .finally(() => this.isLoading = false);
    },
    getUserRightOriginColor(userRight) {
      let trigger = "";
      trigger = this.user?.roles?.find(x => x.roleName === userRight)?.trigger;
      if (trigger?.toLowerCase() === "department" || this.departmentRights.roles?.includes(userRight)) {
        return "#C800A1";
      } else return "#25BACA";
    },
    setSelectedRights() {
      this.selectedRights = [];
      this.user.roles.forEach(role => {
        this.selectedRights.push(role.roleName);
      });
      this.originalRights = this.selectedRights;
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    }
  }
};
</script>

<style scoped></style>
