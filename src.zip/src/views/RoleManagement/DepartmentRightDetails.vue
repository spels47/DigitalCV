﻿<template>
  <v-container fluid>
    <v-progress-linear absolute v-if="isLoading" indeterminate></v-progress-linear>
    <v-row dense>
      <v-col>
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <v-text-field
                  label="Department"
                  prepend-icon="mdi-domain"
                  disabled
                  :value='this.department.name'
                ></v-text-field>
              </v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row dense>
      <v-col>
        <RoleGroup
          :title="'User'"
          :is-department="true"
          :roles="userRoles"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
      <v-col>
        <RoleGroup
          :title="'Customer'"
          :is-department="true"
          :roles="customerRoles"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
    </v-row>
    <v-row dense>
      <v-col>
        <RoleGroup
          :title="'Asset'"
          :is-department="true"
          :roles="assetRoles"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
      <v-col>
        <RoleGroup
          :title="'Role Management'"
          :is-department="true"
          :roles="roleManagementRoles"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
    </v-row>
    <v-row dense>
      <v-col>
        <RoleGroup
          :title="'Logistics'"
          :is-department="true"
          :roles="logisticsRoles"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
      <v-col>
        <RoleGroup
          :title="'KPI Hub'"
          :is-department="true"
          :roles="kpiHubRoles"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
    </v-row>
    <v-row dense>
      <v-col>
        <RoleGroup
          :title="'Development'"
          :is-department="true"
          :roles="developmentRoles"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
    </v-row>
    <v-row dense>
      <v-col>
        <RoleGroup
          :title="'Data Source'"
          :is-department="true"
          :roles="dataSourceRoles"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
    </v-row>
    <v-row dense>
      <v-col>
        <RoleGroup
          :title="'Portfolio'"
          :is-department="true"
          :roles="portfolioRoles"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
      <v-col>
        <RoleGroup
          :title="'Workhub'"
          :is-department="true"
          :roles="workhubRoles"
          :selected-rights="selectedRights"
          @updateUserRight="updateUserRight"
        ></RoleGroup>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "@/axios-client";
import RoleGroup from "@/components/role-management/RoleGroup";

export default {
  name: "DepartmentRightDetails",
  components: { RoleGroup },
  props: {
    department: Object
  },
  data() {
    return {
      userRoles: [
        { text: "Create User", role: "USER_CREATE" },
        { text: "Edit User", role: "USER_EDIT" },
        { text: "Impersonate", role: "USER_IMPERSONATE" },
        { text: "Reset Password", role: "USER_RESET" },
        { text: "Edit User Settings", role: "USER_SETTINGS_EDIT" }
      ],
      customerRoles: [
        { text: "Edit Customer", role: "CUSTOMER_EDIT" },
        { text: "Edit Customer Settings", role: "CUSTOMER_SETTINGS_EDIT" },
        { text: "Move Customer", role: "CUSTOMER_MOVE" }
      ],
      assetRoles: [
        { text: "Edit Asset", role: "ASSET_EDIT" },
        { text: "Move Asset", role: "ASSET_MOVE" },
        { text: "Revision", role: "ASSET_REVISION" }
      ],
      roleManagementRoles: [
        { text: "General Access", role: "ROLE_MANAGEMENT_VIEW" },
        { text: "Edit Template", role: "ROLE_MANAGEMENT_EDIT" },
        { text: "Edit BS User", role: "ROLE_MANAGEMENT_EDIT_USER" }
      ],
      logisticsRoles: [
        { text: "Stock Status", role: "LOGISTICS_STOCK_STATUS" },
        { text: "Pending hot-swaps list", role: "PENDING_HOT_SWAPS_LIST" },
        { text: "Unit Wash", role: "UNIT_WASH" },
        { text: "Jasper List", role: "WORKHUB_JASPER" },
        { text: "ReturnHandling", role: "RETURN_HANDLING" },
      ],
      workhubRoles: [
        { text: "Welcome Call", role: "WORKHUB_WELCOME_CALL" },
        { text: "Renewal Call", role: "WORKHUB_RENEWAL_CALL" },
        { text: "Termination Call", role: "WORKHUB_TERMINATION_CALL" },
        { text: "Product Ordered Call", role: "WORKHUB_PRODUCTORDERED_CALL" },
        { text: "New subscriptions", role: "WORKHUB_NEW_SUBSCRIPTIONS" },
        { text: "Churn Prediction", role: "WORKHUB_CHURN_PREDICTION" },
        { text: "Workhub Admin", role: "WORKHUB_ADMIN" },
        { text: "Swap Request", role: "WORKHUB_SWAP_REQUEST"},
        { text: "Return handling", role: "WORKHUB_RETURN_HANDLING"},
      ],
      developmentRoles: [
        { text: "Release management", role: "DEVELOPER_RELEASE_MANAGEMENT" },
        { text: "BCS Error List", role: "BCS_ERROR_LIST" },
        { text: "ERP cleanup helper", role: "ERP_CLEANUP_HELPER" },
        { text: "ASAP Dev (temp)", role: "DEVELOPER_ASAP" },
        { text: "Usage-log cleaner", role: "USAGE_LOG_CLEANER" },
        { text: "Area import", role: "AREA_IMPORT" },
        { text: "Webtext edit", role: "WEBTEXT_EDIT" },
        { text: "Version management", role: "VERSION_MANAGEMENT" },
        { text: "View TCO", role: "VIEW_TCO" },
        { text: "AutoSale", role: "AUTO_SALE" },
        { text: "Return to tech", role: "RETURN_TO_TECH" },
      ],
      dataSourceRoles: [
        { text: "Unit diagnostic", role: "DATASOURCE_DIAGNOSTICS" },
        { text: "Update firmware", role: "DATASOURCE_FIRMWARE_UPDATE" },
        { text: "Swap", role: "DATASOURCE_SWAP" }
      ],
      portfolioRoles: [
        { text: "Portfolio", role: "PORTFOLIO_ACCESS" },
        { text: "Portfolio key account", role: "PORTFOLIO_KEY_ACCOUNT" },
        { text: "Portfolio Key-Account Add Customer", role: "PORTFOLIO_KEY_ADD_CUSTOMER" },
        { text: "Portfolio Key-Account Remove Customer", role: "PORTFOLIO_KEY_REMOVE_CUSTOMER" },
        { text: "Portfolio admin", role: "PORTFOLIO_ADMIN" }
      ],
      kpiHubRoles: [
        { text: "Customer", role: "KPI_HUB_CUSTOMER" },
        { text: "Portfolio", role: "KPI_HUB_PORTFOLIO" },
        { text: "Portfolio worklists", role: "KPI_HUB_PORTFOLIO_WORKLISTS" },
        { text: "Worklists", role: "KPI_HUB_WORKLISTS" }
      ],

      selectedRights: [],
      originalRights: [],
      isLoading: false,
      departmentColor: '#C800A1'
    };
  },
  watch: {
    department: function () {
      this.selectedRights = [];
      this.department.roles.forEach(role => {
        this.selectedRights.push(role);
      });
      this.originalRights = this.selectedRights;
    },
    selectedRights: async function () {
      if (this.selectedRights !== this.originalRights) {
        this.department.roles = this.selectedRights;
        this.isLoading = true;
        await axios
          .put("/api/RoleManagement/department", this.department)
          .then(res => this.originalRights = res.data.roles)
          .catch(error => this.$eventBus.$emit("alert", { template: error }))
          .finally(() => {
            this.isLoading = false;
            this.applyChanges();
          });
      }
    }
  },
  methods: {
    updateUserRight(updatedRights) {
      this.selectedRights = updatedRights;
    },
    applyChanges() {
      this.selectedRights = this.originalRights;
    }
  }
};

</script>

<style scoped>

</style>
