﻿<template>
  <v-container fluid>
    <PortfolioView :portfolioTeam="currentPortfolioTeam"></PortfolioView>
  </v-container>
</template>

<script>
import PortfolioView from "@/components/Portfolio/PortfolioView";

export default {
  name: "PortfolioTeamOverview",
  components: {PortfolioView },
  data() {
    return {
      loadingCustomers: false,
      portfolioStats: {},
      portfolioCustomers: [],
    }
  },
  async mounted() {
    await this.$store.dispatch("PortfolioTeamModule/retrieveAllTeams")
  },
  computed: {
    allTeams() {
      return this.$store.state.PortfolioTeamModule.allTeams;
    },
    currentPortfolioTeam() {
      if(!this.roles.PORTFOLIO_ADMIN){
        let team = this.$store.state.PortfolioTeamModule.allTeams.find(x => x.teamMembers.find(member => member.username === this.username))
        if(!team) return null
        return team;
      }
      return this.$store.state.PortfolioTeamModule.currentTeam;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    username() {
      return this.$store.getters.currentUser?.username;
    }
  }
}
</script>

<style scoped>

</style>
