﻿<template>
  <v-container fluid>
    <v-row>
      <v-col>
        <v-card>
          <v-card-title>
            <v-btn :class="!checkShowCompleted ? 'secondary' : 'primary'" @click="checkShowCompleted = false">Active</v-btn>
            <v-btn :class="checkShowCompleted ? 'secondary' : 'primary'" @click="checkShowCompleted = true">Completed</v-btn>
            <v-spacer></v-spacer>
            <v-text-field class="mt-0 pt-0" v-model="search" append-icon="mdi-magnify" label="Search" single-line hide-details></v-text-field>
          </v-card-title>
          <CompletedWorklistTable :visible="checkShowCompleted" :search="search"></CompletedWorklistTable>
          <BaseWorklistLayout v-if="!checkShowCompleted" :worklistType="'JasperStateNotOk'" :filter="filter"></BaseWorklistLayout>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import BaseWorklistLayout from "@/components/Workhub/BaseWorklistLayout";
import CompletedWorklistTable from "@/components/Workhub/CompletedWorklistTable";
export default {
  name: "JasperStateNotOkView",
  components: {BaseWorklistLayout, CompletedWorklistTable },
  data() {
    return {
      search: "",
      checkShowCompleted: false,
    }
  },
  async mounted() {
    await this.$store.dispatch("WorklistModule/retrieveWorkItems", {worklistType: "JasperStateNotOk"});
  },
  methods: {
    filter(value, search, item) {
      return this.filter_active(item);
    },
    filter_active(item) {
      return item.workItem.dateCompleted === null;
    },
  },
}
</script>

<style scoped>

</style>
