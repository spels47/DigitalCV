<template>
  <div></div>
</template>

<script>
import { mapActions } from "vuex";
export default {
  name: "OidcCallback",
  methods: {
    ...mapActions("oidcStore", ["oidcSignInCallback"])
  },
  created() {
    this.oidcSignInCallback()
      .then(redirectPath => {
        this.$router.push(redirectPath);
      })
      .catch(() => {
        this.$router.push("/signin-oidc-error"); // Handle errors any way you want
      });
  }
};
</script>
