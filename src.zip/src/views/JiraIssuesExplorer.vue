﻿<template>
  <v-sheet>
    <JiraIssueList @issueClicked="issueClicked" @fetchIssueList="fetchIssueList($event)"/>
    <JiraIssueSidebar
      v-if="sidebarState"
      :issueKey="selectedIssueKey"
      :isDevelopmentIssue="isADevelopmentIssue"
      :hasGitlabTask="hasGitlabTask"
      :currentPage="currentPage"
      @modifiedGitlabLink="modifiedGitlabLink($event)"
      @pageChanged="pageChanged"
      @fetchIssueList="fetchIssueList"
      @fetchJiraIssue="fetchJiraIssue" />
  </v-sheet>
</template>

<script>
import JiraIssueList from '@/components/entityLists/JiraIssueList';
import JiraIssueSidebar from "@/components/sidebars/jira/JiraIssueSidebar";
import axios from "~/axios-client";

export default {
  components: {
    JiraIssueList, JiraIssueSidebar
  },
  data() {
    return {
      currentPage: "",
      issueKey: "ASAPSD",
      selectedIssueKey: "",
      isADevelopmentIssue: false,
      hasGitlabTask: false,
      forceExpanded: false,
      issueListIntervalId: 0,
    }
  },
  async mounted() {
    await this.fetchIssueList();

    this.issueListIntervalId = setInterval(async () => {
     await this.fetchIssueList(true);
    }, 30 * 1000);
  },
  destroyed() {
    clearInterval(this.issueListIntervalId);
  },
  methods: {
    modifiedGitlabLink(removed) {
      this.sidebarState = false;
      setTimeout(async () => {
        const issue = this.currentJiraIssue;
        await this.issueClicked({ issue, action: removed ? "" : "gitlab" })
        await this.fetchIssueList(true);
      }, 250);
    },
    pageChanged(page) {
      this.currentPage = page;
    },
    async fetchIssueList(silentFetch) {
      await this.$store.dispatch("retrieveIssueList", { key: "ASAPSD", silentFetch: silentFetch ?? false})
        .catch(() =>  this.$eventBus.$emit("alert", { template: "api-error"}));
    },
    async fetchJiraIssue(issueKey) {
      await this.$store.dispatch("retrieveJiraIssue", { key: issueKey ?? this.getCurrentJiraIssue.key });
    },
    async issueClicked(issue) {
      this.sidebarState = false;

      this.$store.commit("updateLinkedGitlabIssue", {});
      this.$store.commit("updateJiraIssue", issue.issue);
      this.$store.commit("updateIssueIsMoved", false);

      await this.fetchJiraIssue(issue.issue.key);

      try {
        this.isADevelopmentIssue = this.currentJiraIssue.fields.isDevelopmentIssue[0].value === "Development issue";
      } catch { this.isADevelopmentIssue = false }

      this.hasGitlabTask = this.currentJiraIssue.fields.gitlabLink !== null && this.currentJiraIssue.fields.gitlabLink.includes("gitlab");
      this.selectedIssueKey = this.currentJiraIssue.key;

      const gitlabLink = this.currentJiraIssue.fields.gitlabLink;
      if (this.hasGitlabTask) {
        try {
          await this.$store.dispatch("fetchGitlabIssueFromUrl", { url: gitlabLink }).catch(() => {
            this.$eventBus.$emit("alert", { text: "There is something wrong with the linked Gitlab task.", type: "error" });
          }).then(async () => {
            if (this.gitlabIssueHasBeenMoved) {
              // gitlab issue has been moved, therefore get the new issue link
              // and update JIRA ticket to the newest

              const { data } = await axios.get(`/api/gitlab/issues/${this.getMovedGitlabIssueId}`);
              this.$store.commit("updateLinkedGitlabIssue", data);

              const jiraData  = (await axios.put(`/api/jira/issue/${issue.issue.key}/edit/gitlablink`, {
                "fields": {
                  "customfield_12900": this.getLinkedGitlabIssue.source
                }
              })).data;

              if (jiraData === true) {
                this.$eventBus.$emit("alert", { text: "Original Gitlab issue moved, updated SD ticket with new issue URL", type: "success"});
              } else {
                this.$eventBus.$emit("alert", { text: "Original Gitlab issue moved, tried to update SD ticket with new URL, but an error occured", type: "warning"});
              }
            }
          });
        } catch {
          this.$eventBus.$emit("alert", {text: "Something is wrong with the linked GitLab issue.", type: "error"});
        } // TODO: add better error handling both on API level and frontend
      }

      switch (issue.action) {
        case "gitlab": {
          this.sidebarState = true;
          this.currentPage = "issue-links";
          break;
        }
        case "comments": {
          this.sidebarState = true;
          this.currentPage = "issue-comments";
          break;
        }
        default: {
          this.currentPage = "issue-details";
          this.sidebarState = true;
        }
      }
    },
  },
  computed: {
    currentJiraIssue() {
      return this.$store.state.JiraModule.currentJiraIssue;
    },
    sidebarState: {
      get: function () {
        return this.$store.state.SidebarModule.sidebarState;
      },
      set: function (value) {
        this.$store.commit("updateSidebarState", value);
      }
    },
    jiraUserToUse() {
      return this.$store.state.JiraModule.jiraUserToUse;
    },
    getViewingAssignee() {
      return this.$store.state.JiraModule.chosenAssignee;
    },
    getCurrentJiraIssue() {
      return this.$store.state.JiraModule.currentJiraIssue;
    },
    getLinkedGitlabIssue() {
      return this.$store.state.GitlabModule.linkedGitlabIssue;
    },
    gitlabIssueHasBeenMoved() {
      return this.$store.state.GitlabModule.issueIsMoved;
    },
    getMovedGitlabIssueId() {
      return this.$store.state.GitlabModule.linkedGitlabIssue.movedToId;
    },
    currentSidebarPage() {
      return this.$store.state.SidebarModule.currentPage;
    }
  }
};
</script>

<style scoped>
</style>
