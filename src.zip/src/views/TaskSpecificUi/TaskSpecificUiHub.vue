﻿<template>
  <v-container fluid>
    <v-row>
      <v-col>
        <CustomerInfo :customer="customer" :workItem="workItem"/>
        <AllActivities class="mt-4" :activities="activities" :loading="loading"/>
      </v-col>
      <v-col>
        <TaskInformation :customer="customer" :workItem="workItem"/>
        <SoActivityWelcomeCall
          v-if="computedSoActivity !== null && (worklistType === 'welcomecall' || worklistType === 'churnpreventioncall')"
          class="mt-4"
          :customer="customer"
          :workItem="workItem"
          :soActivity="computedSoActivity"
          :soOwner="computedSoOwner"
          @fetchActivities="fetchActivities"
          @refresh="fetchSoTicket"
        />
        <SoActivityRenewal
          v-if="computedSoActivity !== null && worklistType === 'renewalcall'"
          class="mt-4"
          :customer="customer"
          :workItem="workItem"
          :soActivity="computedSoActivity"
          :soOwner="computedSoOwner"
          @fetchActivities="fetchActivities"
          @refresh="fetchSoTicket"
        />
        <SoActivityYellowFlag
          v-if="computedSoActivity !== null && worklistType === 'yellowflaggedcall'"
          class="mt-4"
          :customer="customer"
          :workItem="workItem"
          :soActivity="computedSoActivity"
          :soOwner="computedSoOwner"
          @fetchActivities="fetchActivities"
          @refresh="fetchSoTicket"

        />
        <SoActivityNotReady class="mt-4" v-if="computedSoActivity == null" :workItem="workItem" :aktorId="customer.id"></SoActivityNotReady>
      </v-col>
      <v-col>
        <CustomerScore :customer="customer"/>
        <DataSourcesWithoutLastContact
          v-if="worklistType === 'welcomecall'"
          class="mt-4"
          :customer="customer"
        ></DataSourcesWithoutLastContact>
        <DataSourcesWithoutContactAndPrices
          v-else-if="worklistType === 'churnpreventioncall'"
          class="mt-4"
          :customer="customer"
        >
        </DataSourcesWithoutContactAndPrices>
        <PricesAndSubsTable
          v-else
          class="mt-4"
          :customer="customer"
          :workItem="workItem"
        ></PricesAndSubsTable>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import CustomerInfo from "@/components/widgets/TaskSpecificUi/CustomerInfo";
import TaskInformation from "@/components/widgets/TaskSpecificUi/TaskInformation";
import CustomerScore from "@/components/widgets/TaskSpecificUi/CustomerScore";
import SoActivityWelcomeCall from "@/components/widgets/TaskSpecificUi/SoActivityWelcomeCall";
import AllActivities from "@/components/widgets/TaskSpecificUi/AllActivities";
import DataSourcesWithoutLastContact from "@/components/widgets/TaskSpecificUi/DataSourcesWithoutContact";

import { mapActions, mapGetters } from "vuex";
import axios from "@/axios-client";
import SoActivityRenewal from "@/components/widgets/TaskSpecificUi/SoActivityRenewal";
import PricesAndSubsTable from "@/components/widgets/TaskSpecificUi/PricesAndSubsTable";
import SoActivityYellowFlag from "@/components/widgets/TaskSpecificUi/SoActivityYellowFlag";
import SoActivityNotReady from "@/components/widgets/TaskSpecificUi/SoActivityNotReady";
import DataSourcesWithoutContactAndPrices from "@/components/widgets/TaskSpecificUi/DataSourcesWithoutContactAndPrices";

export default {
  name: "TaskSpecificUiHub",
  components: {
    DataSourcesWithoutContactAndPrices,
    SoActivityNotReady,
    SoActivityYellowFlag,
    PricesAndSubsTable,
    SoActivityRenewal,
    DataSourcesWithoutLastContact,
    SoActivityWelcomeCall,
    AllActivities,
    CustomerScore,
    TaskInformation,
    CustomerInfo
  },
  data: function () {
    return {
      activities: [],
      loading: false,
      soActivity: null,
      soOwner: null,
      workItem: null

    };
  },
  async mounted() {
    if (!this.workItemId) {
      await this.$store.dispatch("setUrlParameter", { name: null, value: null });
      await this.$router.push("/dashboard");
      return;
    }

    await this.$store.dispatch("setUrlParameter", { name: "workItem", value: this.workItemId });

    // Can't include these calls in `Promise.all()` since `fetchCustomer` relies on `fetchWorkItem` to finish.
    await this.fetchWorkItem();
    await this.fetchCustomer(this.workItem.aktorId).catch(() => {
      this.$store.dispatch("setUrlParameter", { name: null, value: null });
      this.$router.push("/dashboard");
    });

    await Promise.all([this.fetchSoTicket(), this.fetchActivities()])
  },
  methods: {
    ...mapActions('customerStore', ['fetchCustomer']),
    async fetchActivities() {
      if (this.customer.superOfficeId === 0 || this.customer.superOfficeId == null) {
        this.$eventBus.$emit("alert", { text: "Customer does not have an SuperOffice Id", type: "warning" });
        return;
      }

      try {
        this.loading = true;
        const { data } = await axios.get(`/api/so/customer/activities/${this.customer.superOfficeId}`);
        this.activities = data;
      } finally {
        this.loading = false;
      }
    },
    async fetchWorkItem() {
      if (!this.workItemId) return;

      try {
        this.loading = true;
        const { data } = await axios.get(`/api/worklist/${this.workItemId}`);
        this.workItem = data;
      } catch {
        await this.$store.dispatch("setUrlParameter", { name: null, value: null });
        await this.$router.push("/dashboard");
        this.$eventBus.$emit('alert', { text: 'WorkItem does not exist', type: 'error' });
      } finally {
        this.loading = false;
      }
    },
    async fetchSoTicket() {
      if (!this.workItem) {
        this.soActivity = null;
        return;
      }

      try {
        this.loading = true;
        this.soActivity = (await axios.get(`/api/so/activity/${this.workItem.soActivityId}`)).data;
        this.soOwner = (await axios.get(`/api/UserSettings/getByAssociateId?id=${this.soActivity.associateId}`)).data;
      } catch {
        this.soActivity = null;
      } finally {
        this.loading = false;
      }
    }
  },
  computed: {
    ...mapGetters('customerStore', ['customer']),
    workItemId() {
      return this.$route.params?.workItem?._id ?? this.$route.query.workItem;
    },
    worklistType() {
      return this.workItem?.worklistType?.toLowerCase() ?? "";
    },
    computedSoActivity() {
      return this.soActivity;
    },
    computedSoOwner() {
      return this.soOwner;
    }

  }
};
</script>

<style scoped>
</style>
