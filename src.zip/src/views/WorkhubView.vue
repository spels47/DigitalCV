<template>
  <v-container fluid>
  <v-card>
    <v-tabs background-color="black" :value="getIndexedTabValue(activeTab.id)" dark v-if="activeTab">
      <v-tab v-for="tab in availableTabs" :data-cy="tab.data-cy" :key="tab.id" @click="setTabQuery(tab.id)">
        {{ tab.text }}
      </v-tab>
      <v-spacer></v-spacer>
      <v-menu right background-color="black" offset-y :close-on-content-click="true">
        <template v-slot:activator="{ on }">
          <v-btn
            v-if="isPortfolioTeamMember"
            @click="showStats = true"
            icon
            class="mt-1 mr-2"
            v-on="on">
            <v-icon size="25">mdi-chart-areaspline</v-icon>
          </v-btn>
        </template>
      </v-menu>
      <CountrySelector v-if="shouldShowCountrySelector"></CountrySelector>
    </v-tabs>
    <v-tabs-items :value="activeTab.id">
      <v-tab-item v-for="tab in availableTabs" :key="tab.id" :value="tab.id">
          <SearchForCustomerDialog v-if="addCustomerDialogOpen" :title="'Search to add Customer'" @confirm="addCustomer" @cancel="addCustomerDialogOpen = false"></SearchForCustomerDialog>
          <v-card-title v-if="!showStats">
            <v-btn :class="!checkShowCompleted ? 'secondary' : 'primary'" @click="checkShowCompleted = false; showStats = false">Active</v-btn>
            <v-btn :class="checkShowCompleted ? 'secondary' : 'primary'" class="ml-2" @click="checkShowCompleted = true; showStats = false">Completed</v-btn>
            <v-spacer></v-spacer>
            <v-menu
              v-if="selectedTab.id !== 6"
              right
              offset-y
              :close-on-content-click="false"
            >
              <template v-slot:activator="{ on }">
                <v-icon class="filter-icon" :color="anyFilterChecked ? 'marked' : ''" v-on="on">
                  mdi-filter
                </v-icon>
              </template>
              <v-list>
                <v-list-item>
                  <v-list-item-title>
                    <v-checkbox class="ml-2" v-model="checkMyTasks" label="Only my assigned tasks" @change="persist"></v-checkbox>
                    <v-checkbox class="ml-2" v-model="checkShowHidden" v-if="!checkShowCompleted" label="Show hidden" @change="persist"></v-checkbox>
                  </v-list-item-title>
                </v-list-item>
              </v-list>
            </v-menu>
            <v-text-field class="mt-0 pt-0" v-model="search" append-icon="mdi-magnify" label="Search" single-line hide-details @input="persist"></v-text-field>
          </v-card-title>
          <CompletedWorklistTable :visible="checkShowCompleted && !showStats && (worklistType != 'Swap'|| worklistType == 'Swap' && !roles.DEVELOPER_ASAP)" :checkMyTasks="checkMyTasks" :search="search" :filter="filter"></CompletedWorklistTable>
          <BaseWorklistLayout v-if="!showStats && !checkShowCompleted && (worklistType != 'Swap' || worklistType == 'Swap' && !roles.DEVELOPER_ASAP)" :search="search" :filter="filter"/>
          <SwapTable v-if="!showStats && !checkShowCompleted && worklistType == 'Swap' && roles.DEVELOPER_ASAP" :search="search" :filter="filter"></SwapTable>
          <CompletedSwapTable :visible="checkShowCompleted && !showStats && worklistType == 'Swap' && roles.DEVELOPER_ASAP" :search="search" :filter="filter">></CompletedSwapTable>
      </v-tab-item>
    </v-tabs-items>
    <v-card>
      <BaseWorklistStatistics v-if="showStats" :worklistType="worklistType"></BaseWorklistStatistics>
    </v-card>
  </v-card>
  </v-container>
</template>

<script>
import CompletedWorklistTable from "@/components/Workhub/CompletedWorklistTable";
import SearchForCustomerDialog from "@/components/widgets/dialogs/SearchForCustomerDialog";
import BaseWorklistLayout from "@/components/Workhub/BaseWorklistLayout";
import SwapTable from "@/components/Workhub/Tables/SwapTable";
import CompletedSwapTable from "@/components/Workhub/Tables/CompletedSwapTable";
import BaseWorklistStatistics from "@/components/KPI Hub/BaseWorklistStatistics";
import CountrySelector from "@/components/widgets/CountrySelector";

export default {
  name: "WorkhubView",
  components: { CountrySelector, BaseWorklistStatistics, BaseWorklistLayout, SearchForCustomerDialog, CompletedWorklistTable, SwapTable, CompletedSwapTable },
  data() {
    return {
      checkShowCompleted: false,
      checkMyTasks: false,
      checkShowHidden: false,
      addCustomerDialogOpen: false,
      search: "",
      selectedTab: {},
      countrySelector: [
        { text: "All", value: "ALL" },
        { text: "Norway", value: "NO" },
        { text: "Sweden", value: "SE" },
        { text: "Finland", value: "FI" },
        { text: "Denmark", value: "DK" },
        { text: "UK", value: "GB" },
        { text: "France", value: "FR" },
        { text: "Belgium", value: "BE" },
        { text: "Netherlands", value: "NL" },
        { text: "Poland", value: "PL" }
      ],
      showStats: false,
    };
  },
  async mounted() {
    await this.$store.dispatch("waitForRolesLoaded");
    const query = parseInt(this.$route.query?.tab);
    if (!this.availableTabs.some(tab => tab.id === query)) {
      let firstAvailableId = Math.min(...this.availableTabs.map(x => x.id));
      this.setTabQuery(firstAvailableId);
      this.selectedTab = this.availableTabs.find(tab => tab.id === firstAvailableId);
    }
    else{
      this.selectedTab = this.availableTabs.find(tab => tab.id === query);
    }
    if(localStorage.getItem("worklistSearchFilter") !== null) {
      let searchProperties = JSON.parse(localStorage.getItem("worklistSearchFilter"));
      this.checkMyTasks = searchProperties.checkMyTasks ?? false;
      this.checkShowHidden = searchProperties.checkShowHidden ?? false;
      this.search = searchProperties.search ?? "";
    }
  },
  methods: {
    addCustomer(customer) {
      this.$store.dispatch("RenewalCallModule/addPortfolioCustomer", { id: customer.id, username: this.username });
    },
    persist() {
      const filters = {
        checkMyTasks: this.checkMyTasks,
        checkShowHidden: this.checkShowHidden,
        search: this.search
      };
      localStorage.setItem('worklistSearchFilter', JSON.stringify(filters))
    },
    async fetchWorkItems() {
      await this.$store.dispatch("WorklistModule/retrieveWorkItems", {worklistType: this.activeTab.worklistType, isDev: this.roles.DEVELOPER_ASAP});
    },
    async fetchCompletedWorkItems() {
      await this.$store.dispatch("WorklistModule/retrieveCompletedWorkItems", {worklistType: this.activeTab.worklistType});
    },
    setTabQuery(id) {
      this.selectedTab = this.availableTabs.find(x => x.id === id);
      this.checkShowCompleted = false;
      this.$store.dispatch("setUrlParameter", { name: "tab", value: id });
    },
    getIndexedTabValue(id) {
      // v-tabs always starts from 0 on the first tab. so we need to find the index of the element by id :/
      return this.availableTabs.findIndex(x => x.id === id);
    },
    filter(value, search, item) {
      if(item.workItems) return this.filter_country(item)
      if(this.checkShowCompleted){
        return this.filter_myTasks(item) && this.filter_country(item) && item.workItem.dateCompleted !== null
      }
      else{
        return this.filter_myTasks(item) && this.filter_showHidden(item) && this.filter_hideIgnored(item) && this.filter_country(item) && item.workItem.dateCompleted === null;
      }
    },
    filter_country(item) {
      if(!this.shouldShowCountrySelector) return true;
      if(this.defaultCountry === "ALL") return true;
      return this.defaultCountry === item.country;

    },
    filter_myTasks(item) {
      if (!this.checkMyTasks) {
        return true;
      }
      return this.checkMyTasks && item.workItem.assignedUser === this.username;
    },
    filter_showHidden(item) {
      if(!this.checkShowHidden && (item?.workItem?.hiddenUntil === null || Date.parse(item.workItem.hiddenUntil) < Date.now())){
        return true;
      }
      return this.checkShowHidden && item.workItem.assignedUser === this.username && (item?.workItem?.hiddenUntil !== null && Date.parse(item.workItem.hiddenUntil) > Date.now());
    },
    filter_hideIgnored(item) {
      if(item.ignored) return false
      return true;
    }
  },
  watch: {
    checkShowCompleted: {
      deep: true,
      async handler() {
        if(this.checkShowCompleted) {
          await this.fetchCompletedWorkItems(this.activeTab.id);
        }
        else if(this.worklistType == 'Swap' && this.roles.DEVELOPER_ASAP){
          await this.fetchWorkItems(this.activeTab.id);
        }
      }
    },
    selectedTab: {
      deep:true,
      async handler() {
        this.showStats = false;
        await this.fetchWorkItems(this.activeTab.id);
      }
    }
  },
  computed: {
    activeTab() {
      return this.selectedTab;
    },
    availableTabs() {
      let tabs = [
        { id: 0, text: "Welcome Calls", "data-cy": "workhub-welcome-call-tab", worklistType: "WelcomeCall", userRight: "WORKHUB_WELCOME_CALL", portfolioWorklist: false},
        { id: 1, text: "Renewal Calls", "data-cy": "workhub-renewal-call-tab", worklistType: "RenewalCall", userRight: "WORKHUB_RENEWAL_CALL", portfolioWorklist: true},
        { id: 2, text: "Terminations", "data-cy": "workhub-terminations-tab", worklistType: "YellowFlaggedCall", userRight: "WORKHUB_TERMINATION_CALL", portfolioWorklist: true },
        { id: 3, text: "Products Ordered", "data-cy": "workhub-products-ordered-tab", worklistType: "ProductOrdered", userRight: "WORKHUB_PRODUCTORDERED_CALL", portfolioWorklist: true },
        { id: 4, text: "New subscriptions", "data-cy": "workhub-new-subscriptions-tab", worklistType: "NewSubscription", userRight: "WORKHUB_NEW_SUBSCRIPTIONS", portfolioWorklist: true },
        { id: 5, text: "Churn prevention", "data-cy": "workhub-churn-prediction-tab", worklistType: "ChurnPreventionCall", userRight: "WORKHUB_CHURN_PREDICTION", portfolioWorklist: true },
        { id: 6, text: "Swap Request", "data-cy": "workhub-swap-request-tab", worklistType: "Swap", userRight: "WORKHUB_SWAP_REQUEST" },
        { id: 7, text: "Return handling", "data-cy": "workhub-return-handling", worklistType: "ReturnHandling", userRight: "WORKHUB_RETURN_HANDLING" },
      ];
      tabs = tabs.filter(tab => tab.userRight === "" || this.roles[tab.userRight]);
      if(!this.hasPortfolioTeam && !this.roles.WORKHUB_ADMIN) tabs = tabs.filter(tab => !tab.portfolioWorklist)
      return tabs;
    },
    shouldShowCountrySelector() {
      let tabsWithoutCountrySelector = [1,2,4,5];
      return !tabsWithoutCountrySelector.includes(this.activeTab.id)
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    anyFilterChecked() {
      return this.checkMyTasks || this.checkShowHidden;
    },
    username() {
    return this.$store.getters.currentUser?.username;
    },
    isPortfolioTeamMember() {
      return !!this.$store.state.userSettings.portfolioTeam;
    },
    worklistType() {
      return this.$store.state.WorklistModule.worklistType;
    },
    defaultCountry() {
      return this.$store.state.userSettings.defaultCountry;
    },
    hasPortfolioTeam() {
      return !!this.$store.state.userSettings.portfolioTeam
    }
  }
};
</script>

<style></style>
