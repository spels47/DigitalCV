﻿<template>
  <v-container fluid>
    <v-layout>
      <v-spacer></v-spacer>
        <v-flex xs12>
          <StockListComponent>
          </StockListComponent>
        </v-flex>
      <v-spacer></v-spacer>
    </v-layout>
  </v-container>
</template>

<script>
import StockListComponent from "@/components/widgets/StockListComponent";

export default {
  name: "Logistics",
  components: {StockListComponent},
  data() {
    return {}
  },
  async mounted() {

  },
  methods: {

  },
}
</script>

<style scoped>

</style>
