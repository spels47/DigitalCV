﻿<template>
  <v-container fluid>
    <v-row>
      <v-col :xl="2" :lg="2" :md="2" :sm="2">
        <v-card class="pa-3">
        <v-text-field
          ref="searchText"
          label="Search text"
          v-model="search"
          hide-details="auto"
          @keyup.enter="searchAuditLog">
        </v-text-field>
          <div class="mt-4">
            <v-btn color="primary" class="elevation-1 mb-5 text-capitalize" width="100%" @click="searchAuditLog">Search</v-btn>
          </div>
        </v-card>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <v-data-table
          :headers="headers"
          :items="auditLog">
          <template v-slot:item.timestamp="{ item }">{{ convertDateString(item.timestamp)}}</template>
          <template v-slot:item.oldValue="{ item }">
            <v-tooltip left>
              <template v-slot:activator="{ on }">
                <div v-on="on">
                {{ item.oldValue && item.oldValue.length > 50 ? item.oldValue.substr(0,50) + "..." : item.oldValue}}
                </div>
              </template>
              <span>{{ item.oldValue }}</span>
            </v-tooltip>
          </template>
        </v-data-table>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import util from "@/helpers/util";
export default {
  name: "AuditView",
  data() {
    return {
      auditLog: [],
      search: '',
    }
  },
  mounted() {
  },
  methods: {
    convertDateString(date){
      return util.getDateTimeByCountry(date, "NO")
    },
    async searchAuditLog() {
      let res = await axios.get(`/api/audit/search/${this.search}`)
      this.auditLog = res.data;
    },
  },
  targetFilter(target) {
    let output = ""
    if(target[0] != null)
    {
      output = target[0]
      return output;
    }
    else if(target[1] != null)
    {
      output = target[1]
      return output;
    }
    else if(target[2] != null)
    {
      output = target[2]
      return output;
    }
    return "";
  },
  computed: {
    headers() {
      return [
        {text: 'Date', value: 'timestamp'},
        {text: 'Responsible', value: 'username'},
        {text: 'Source', value: 'source'},
        {text: 'Message', value: 'message'},
        {text: 'Entity Id', value: 'entityId'},
        {text: 'Old value', value: 'oldValue'},
        {text: 'New value', value: 'newValue'}
      ]
    }
  },
  watch: {
    }
}
</script>

<style scoped>

</style>
