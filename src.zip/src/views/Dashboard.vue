<template>
  <div class="dashboard">

    <v-container class="px-12" fluid>
      <v-row :justify="widgetAmmount === 1 ? 'center' : 'start'">
        <v-col :sm="12" :md="6" :lg="4">
          <LastVisited type="customers"></LastVisited>
        </v-col>

        <v-col :sm="12" :md="6" :lg="4">
          <LastVisited type="units"></LastVisited>
        </v-col>

        <v-col :sm="12" :md="6" :lg="4">
          <LastVisited type="accounts"></LastVisited>
        </v-col>

        <v-col :sm="12" :md="12" :lg="4">
          <Favorites></Favorites>
        </v-col>
        <v-col :sm="12" :md="12" :lg="8">
          <CustomerStatisticsFavorites></CustomerStatisticsFavorites>
        </v-col>
      </v-row>

      <!-- <grid-layout
        id="dashboard-grid"
        class="pb-12"
        :layout.sync="layout"
        :responsive="true"
        :col-num="12"
        :row-height="rowHeight"
        :is-draggable="false"
        :is-resizable="false"
        :is-mirrored="false"
        :vertical-compact="true"
        :autoSize="false"
        :margin="[35, 35]"
        :use-css-transforms="true"
      >
        <grid-item
          v-for="widget in layout"
          :x="widget.x"
          :y="widget.y"
          :w="widget.w"
          :h="widget.h"
          :i="widget.i"
          :key="widget.i"
        >
          <CustomerStatisticsFavorites v-if="widget.i == 'CustomerStatistics'"></CustomerStatisticsFavorites>
          <LastVisitedCustomersList v-if="widget.i == 'LastVisitedCustomers'"></LastVisitedCustomersList>
          <ReleaseManagement v-if="widget.i == 'ReleaseManagement'"></ReleaseManagement>
        </grid-item>
      </grid-layout>-->
    </v-container>
  </div>
</template>

<script>
// import VueGridLayout from "vue-grid-layout";
import CustomerStatisticsFavorites from "~/components/widgets/CustomerStatisticsFavorites";
import LastVisited from "~/components/widgets/LastVisited";
import Favorites from "../components/widgets/Favorites";
export default {
  data() {
    return {
      // layout: [
      //   {
      //     x: 0,
      //     y: 0,
      //     w: 4,
      //     h: 6,
      //     i: "ReleaseManagement",
      //     requiredRole: "Engineering"
      //   },
      //   {
      //     x: 4,
      //     y: 0,
      //     w: 8,
      //     h: 5.8,
      //     i: "CustomerStatistics"
      //   },
      //   {
      //     x: 0,
      //     y: 5.1,
      //     w: 4,
      //     h: 5.2,
      //     i: "LastVisitedCustomers",
      //     requiredRole: "DEVELOPER_ASAP"
      //   }
      // ]
    };
  },
  computed: {
    widgetAmmount() {
      var widgetAmmount = 1;
      if (this.roles.LAST_VISITED_CUSTOMER) widgetAmmount++;
      return widgetAmmount;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    rowHeight() {
      return 86;
    }
  },
  components: {
    Favorites,
    LastVisited,
    CustomerStatisticsFavorites
    // GridLayout: VueGridLayout.GridLayout,
    // GridItem: VueGridLayout.GridItem,
  }
};
</script>

<style lang="scss" scoped>
//.dashboard{
//  padding: 10px 100px 10px 100px;
//}
</style>
