<template>
  <v-card class="ma-8">
    <v-card-title>
        <span>Usage-log cleaner</span>
    </v-card-title>
    <v-divider></v-divider>
    <v-row cols="12">
      <v-col cols="4">
          <v-text-field class="ml-4 mr-4 d-inline-flex" v-model="ctrl.usageLogParams.serialNumber" label="Serial Number" clearable clear-icon="mdi-close-circle-outline"></v-text-field>
      </v-col>
      <v-col cols="4">
          <v-select item-text="text" item-value="value" :items="ctrl.deletionModes" v-model="ctrl.usageLogParams.deletionMode" label="Deletion mode"></v-select>
      </v-col>
      <v-col cols="4">
        <v-btn class="secondary" :disabled="!paramsAreValid" @click="getData(ctrl.usageLogParams)">FIND LOGS</v-btn>
        <v-btn class="ml-4 error" :disabled="!paramsAreValid" @click="deleteData(ctrl.usageLogParams)">DELETE LOGS</v-btn>
      </v-col>
    </v-row>
    <v-row v-if="ctrl.usageLogParams.deletionMode === 'selectedPeriod'">
      <v-col>
        <v-list-item>
          <label class="params-label">From</label>
          <v-date-picker v-model="ctrl.usageLogParams.from" :first-day-of-week="1" />
        </v-list-item>
      </v-col>
      <v-col>
        <v-list-item>
          <label class="params-label">To</label>
          <v-date-picker v-model="ctrl.usageLogParams.to" :first-day-of-week="1" />
        </v-list-item>
      </v-col>
    </v-row>
    <v-row class="row" v-if="ctrl.usageLogParams.deletionMode === 'hoursAmount'">
      <v-col cols="12">
        <v-list-item>
          <label class="params-label">From</label>
          <v-date-picker v-model="ctrl.usageLogParams.from" label="From" :first-day-of-week="1" />
        </v-list-item>
      </v-col>
      <v-col>
        <v-list-item>
          <v-text-field type="number" class="float-left" v-model.number="ctrl.usageLogParams.hoursAmount" label="Hours amount" clearable clear-icon="mdi-close-circle-outline"></v-text-field>
        </v-list-item>
      </v-col>
    </v-row>
    <v-divider></v-divider>
    <v-sheet elevation="0">
      <v-subheader>Usage log list</v-subheader>
      <v-text-field
        class="mr-4 ml-4"
        v-model="search"
        append-icon="mdi-magnify"
        label="Search"
        single-line
        hide-details
      ></v-text-field>
      <v-data-table
        :headers="headers"
        :items="data"
        :items-per-page="15"
        class="elevation-1"
        :loading="loading"
        loading-text="Loading usage log list"
        :search="search"
        :custom-filter="customFilter"
      >
        <template v-slot:item.movementStart="{ item }">
          <span>{{ item.movementStart | datetime }}</span>
        </template>
        <template v-slot:item.movementStop="{ item }">
          <span>{{ item.movementStop | datetime }}</span>
        </template>
      </v-data-table>
    </v-sheet>
    <ConfirmDialog ref="confirm"></ConfirmDialog>
  </v-card>
</template>

<script>
import axios from "@/axios-client"
import ConfirmDialog from "@/components/widgets/dialogs/ConfirmDialog"

export default {
  name: "UsageLogCleaner",
  components: {
    ConfirmDialog
  },
  data(){
    return {
      ctrl: {
        usageLogParams: {
          deletionMode: 'allEntries',
          serialNumber: "",
          hoursAmount: 0,
          from: null,
          to: null
        },
        deletionModes: [
          { text: "All Entries", value: 'allEntries' },
          { text: "Selected Period", value: 'selectedPeriod' },
          { text: "Hours Amount", value: 'hoursAmount' },
        ]
      },
      data: [],
      search: '',
      loading: false,
      headers: [
        { text: 'Movement start', value: 'movementStart' },
        { text: 'Movement stop', value: 'movementStop' },
        { text: 'Movement sec', value: 'movementSec' },
        { text: 'Address info', value: 'addressInfo' },

      ],
    }
  },
  mounted() {
    this.ctrl.usageLogParams.serialNumber = window.localStorage.getItem("ted-usagelog-cleaner-last-serial") ?? ''
  },
  methods: {
    async getData(usageLogParams){
      window.localStorage.setItem("ted-usagelog-cleaner-last-serial", this.ctrl.usageLogParams.serialNumber)
      this.loading = true;
      try {
        let res = await axios.post(`/api/ted/usage-log/get`, usageLogParams)
        if(res.data.errorMessage){
          this.$eventBus.$emit('alert', {text: `Error: ${res.data.errorMessage}`, icon: 'mdi-alert-circle', type: 'error'});
          this.data = []
        } else {
          this.data = res.data.entries
        }
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: 'Call to get usage-logs failed', icon: 'mdi-alert-circle', type: 'error'});
      } finally {
        this.loading = false
      }
    },
    async deleteData(usageLogParams) {
      if(this.ctrl.usageLogParams.hoursAmount.toString() !== parseInt(this.ctrl.usageLogParams.hoursAmount).toString()) {
        alert("Possible user error 🤔 \nThat hours amount will be mangled when sending it as a INT \nTry something else...")
        return;
      }
      let result = await this.$refs.confirm.open('Are you sure?', '(this dialog is just trying to be helpful 😃 )', { width: 500, confirmLabel: `Just do it!`});
      if(result) {
        this.loading = true;
        try {
          await axios.post(`/api/ted/usage-log/delete`, usageLogParams)
          await this.$store.dispatch("audit", { source: "UsageLogCleaner", entityId: usageLogParams.serialNumber, message: "UsageLogsCleaned" });
        } catch (ex) {
          this.$eventBus.$emit('alert', {text: 'Call to wash usage-logs failed', icon: 'mdi-alert-circle', type: 'error'});
        } finally {
          this.loading = false
        }
      }
    },
    customFilter(value, search, item) {
      search = search.toString().toLowerCase();
      return Object.keys(item).some(propName => {
        return item[propName]
          ?.toString()
          .toLowerCase()
          .includes(search);
      });
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
    paramsAreValid(){
      if(this.ctrl.usageLogParams.mode === 'selectedPeriod') {
        if(!this.ctrl.usageLogParams.from || !this.ctrl.usageLogParams.to) return false;
      }
      if(this.ctrl.usageLogParams.mode === 'hoursAmount') {
        if(!this.ctrl.usageLogParams.from || !this.ctrl.usageLogParams.hoursAmount) return false;
      }
      return !this.loading && this.ctrl.usageLogParams.serialNumber?.length > 3;
    }
  },
}
</script>

<style scoped>

</style>
