<template>
  <v-container fluid>
    <UsageLogCleaner v-if="roles.USAGE_LOG_CLEANER" />
  </v-container>
</template>

<script>
import UsageLogCleaner from "@/views/Ted/UsageLogCleaner"
export default {
  name: "Ted",
  components: { UsageLogCleaner },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
  }
}
</script>
