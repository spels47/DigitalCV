import axios from "~/axios-client";

export default {
  log: async function(logLevel, origin, message) {
    await axios.post("/api/log/custom", { Level: logLevel, Origin: origin, Message: message });
  }
};
