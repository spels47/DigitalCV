import Vue from "vue";
import VueRouter from "vue-router";
import OidcCallback from "~/views/OidcCallback.vue";
import OidcCallbackError from "~/views/OidcCallbackError.vue";
import { vuexOidcCreateRouterMiddleware } from "vuex-oidc";
import store from "~/store";
import gtm from "~/gtm";

const originalPush = VueRouter.prototype.push;
VueRouter.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => {
    if (err.name !== "NavigationDuplicated") throw err;
  });
};

Vue.use(VueRouter);

const routes = [
  {
    path: "*",
    redirect: "/"
  },
  {
    path: "/",
    redirect: "/dashboard"
  },
  {
    path: "/oidc-callback",
    name: "oidcCallback",
    component: OidcCallback,
    meta: {
      isPublic: true
    }
  },
  {
    path: "/oidc-callback-error",
    name: "oidcCallbackError",
    component: OidcCallbackError,
    meta: {
      isPublic: true
    }
  },
  {
    path: "/dashboard",
    name: "dashboard",
    component: () => import("~/views/Dashboard.vue"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/auditview",
    name: "auditview",
    component: () => import("~/views/AuditView.vue"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/start-impersonation-triplog",
    name: "start-impersonation-triplog",
    component: () => import("~/views/ImpersonateProxy.vue"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/start-impersonation-central",
    name: "start-impersonation-central",
    component: () => import("~/views/ImpersonateProxyCentral.vue"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/customer/:id",
    name: "customer",
    component: () => import("~/views/customer/Customer.vue"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/customer-placeholder",
    name: "customer-placeholder",
    component: () => import("~/views/customer/CustomerPlaceholder.vue"),
    meta: {
      requiresAuth: true
    }
  },
  // {
  //   path: '/customer/:id/user-import',
  //   name: 'user-import',
  //   component: () => import('~/views/customer/UserImport.vue'),
  //   meta: {
  //     requiresAuth: true
  //   }
  // },
  {
    path: "/role-management",
    name: "roleManagement",
    component: () => import("~/views/RoleManagement/RoleManagement"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/release-management",
    name: "releaseManagement",
    component: () => import("~/views/ReleaseManagement"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/tools",
    name: "PersonalView",
    component: () => import("~/views/PersonalView/PersonalView"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/workhub",
    name: "Workhub",
    component: () => import("~/views/WorkhubView"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/kpi-hub",
    name: "kpi-hub",
    component: () => import("~/views/KPIHubView"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/swagger",
    name: "swagger",
    component: () => import("~/components/Swagger"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/siteSettings",
    name: "siteSettings",
    component: () => import("~/components/SiteSettings"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/mySwaps",
    name: "mySwaps",
    component: () => import("~/components/MySwaps/MySwaps"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/erp-cleanup-helpers",
    name: "erp-cleanup-helpers",
    component: () => import("~/views/PersonalView/ErpCleanupHelpers"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/jasper",
    name: "jasper",
    component: () => import("~/views/JasperStateNotOkView"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/jira-explorer",
    name: "jira-explorer",
    component: () => import("~/views/JiraIssuesExplorer"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/jira-statistics",
    name: "jira-statistics",
    component: () => import("../components/entityLists/JiraStatistics"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/webtext-view",
    name: "webtexts-view",
    component: () => import("~/views/Webtext/WebtextView"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/poeditor-view",
    name: "PoeditorView",
    component: () => import("~/views/Poeditor/PoeditorView"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/ted",
    name: "ted",
    component: () => import("~/views/Ted/Ted"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/ted/UsageLogCleaner",
    name: "UsageLogCleaner",
    component: () => import("~/views/Ted/UsageLogCleaner"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/swagger",
    name: "Swagger",
    component: () => import("~/components/Swagger"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/task-specific-ui",
    name: "taskSpecificUi",
    component: () => import("~/views/TaskSpecificUi/TaskSpecificUiHub"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/portfolio",
    name: "Portfolio",
    component: () => import("~/views/PortfolioTeamOverview"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/unit-wash",
    name: "UnitWash",
    component: () => import("~/views/PersonalView/UnitWash"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/pending-hot-swaps",
    name: "PendingHotSwaps",
    component: () => import("~/views/PersonalView/PendingHotSwaps"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/logistics",
    name: "Logistics",
    component: () => import("~/views/Logistics"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/tco",
    name: "TCO",
    component: () => import("~/views/TCOTable"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/return-handling",
    name: "ReturnHandlingView",
    component: () => import("~/views/Logistics/ReturnHandlingView"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/swap-prioritization",
    name: "SwapPrioritization",
    component: () => import("~/views/Logistics/SwapPrioritization"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/return-handling/pending-returns",
    name: "PendingReturns",
    component: () => import("~/views/Logistics/ReturnHandling/PendingReturns"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/return-handling/return-to-tech",
    name: "ReturnToTech",
    component: () => import("~/views/Logistics/ReturnHandling/ReturnToTech"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/return-handling/return-units",
    name: "ReturnUnits",
    component: () => import("~/views/Logistics/ReturnHandling/ReturnUnits"),
    meta: {
      requiresAuth: true
    }
  },
  {
    path: "/return-handling/send-receive-batch",
    name: "SendReceiveBatch",
    component: () => import("~/views/Logistics/ReturnHandling/SendReceiveBatch"),
    meta: {
      requiresAuth: true
    }
  },

];

const router = new VueRouter({
  mode: "history",
  base: process.env.BASE_URL,
  routes
});

router.beforeEach(vuexOidcCreateRouterMiddleware(store, "oidcStore"));

router.beforeEach((to, from, next) => {
  gtm.trackPageView(to.name);
  next();
});

export default router;
