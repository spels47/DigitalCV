import Oidc from 'oidc-client';

const manager = new Oidc.UserManager();
manager.signinSilentCallback();
