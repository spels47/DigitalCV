import Vue from "vue";
import vuetify from "./plugins/vuetify";
import errorHandler from "~/error-handler";
import gtmDirective from "~/directives/gtm-directive";
import "roboto-fontface/css/roboto/roboto-fontface.css";
import "@mdi/font/css/materialdesignicons.css";
import "~/helpers/filters";
import DatetimePicker from "vuetify-datetime-picker";
import VueFriendlyIframe from "vue-friendly-iframe";
import util from "~/helpers/util";
util.setupGlobalDateHelper();
import tooltippy from "~/helpers/tooltippy-directive";
tooltippy.register(Vue);
import VueApexCharts from "vue-apexcharts";
import VueConfetti from "vue-confetti";
import "@/assets/css/global.css";

Vue.config.productionTip = false;

errorHandler.register(Vue);
gtmDirective(Vue);

Vue.prototype.$eventBus = new Vue(); // Global event bus
Vue.prototype.$utils = util; // Global utility

Vue.use(DatetimePicker);
Vue.use(VueApexCharts);
Vue.use(VueFriendlyIframe);
Vue.use(VueConfetti);

// We must wait to load store, router and App.vue before backstage client config is loaded from backend API
// Since we are using or having references to store in router, App.vue and axios-client
// we need to make sure we load these modules after loadIdentityServerConfig and loadTriplogConfig promise is resolved or
// those modules will try to use properties and getters before they are set
(async function() {
  const { loadConfig } = await import("~/config/config-service");
  await loadConfig();

  const store = (await import("./store")).default;
  const router = (await import("./router")).default;
  const App = (await import("./App.vue")).default;

  new Vue({
    vuetify,
    store,
    router,
    render: h => h(App)
  }).$mount("#app");
})();
