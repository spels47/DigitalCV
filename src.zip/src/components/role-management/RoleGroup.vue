﻿<template>
  <div>
    <v-list>
      <v-list-item-title class="ml-4">{{ title }}</v-list-item-title>
      <v-list-item
        v-for="(role, index) in roles"
        :key="index"
        :class="index === 0 ? '' : 'mt-n8'"
      >
        <v-tooltip right>
          <template v-slot:activator="{ on, attrs }">
            <div
              v-bind="attrs"
              v-on="on"
              style="height: min-content"
            >
              <v-switch
                :label="role.text"
                :color="!isDepartment ? getUserRightOriginColor(role.role) : '#C800A1'"
                :value="role.role"
                v-model="computedRights"
                dense
              ></v-switch>
            </div>
          </template>
          <span>{{ role.role }}</span>
        </v-tooltip>
      </v-list-item>
    </v-list>
  </div>
</template>

<script>
export default {
  name: "RoleGroup",
  props: {
    title: {
      type: String,
      required: true
    },
    isDepartment: {
      type: Boolean,
      required: true
    },
    selectedRights: {
      type: Array,
      required: true
    },
    roles: {
      type: Array,
      required: true
    },
    departmentRights: {
      required: false
    }
  },
  methods: {
    updateUserRights(userRights) {
      this.$emit("updateUserRight", userRights);
    },
    getUserRightOriginColor(userRight) {
      const trigger = this.user?.roles?.find(x => x.roleName === userRight)?.trigger;
      return trigger?.toLowerCase() === "department" || this.departmentRights.roles?.includes(userRight)
        ? "#C800A1"
        : "#25BACA";
    },
  },
  computed: {
    computedRights: {
      get() {
        return this.selectedRights;
      },
      set(value) {
        this.updateUserRights(value);
      }
    }
  }
}
</script>

<style scoped>

</style>
