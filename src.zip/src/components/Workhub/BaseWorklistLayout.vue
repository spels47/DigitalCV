﻿<template>
  <div>

    <v-data-table
      :headers="addCustomFiltersToHeaders()"
      :items="workItems"
      :search="search"
      :loading="isLoading"
      :footer-props="{ 'items-per-page-options': (items_per_page = [10, 20, 50]) }"
      :sort-by="sortOptions.sortBy"
      :sort-desc="sortOptions.sortDesc"
      item-key="_id"
    >
      <template v-slot:item.customerName="{ item }">
        <WrappedTextWithTooltip
          :text="item.customerName"
          :clickable="true"
          @clicked="gotoCustomer(item)"
          :max-length="27"
        ></WrappedTextWithTooltip>
      </template>
      <template v-slot:item.workItem.assignedUser="{ item }">
        <span>{{ trimUsername(item.workItem.assignedUser) }}</span>
      </template>
      <template v-slot:item.requestedByUser="{ item }">
        <span>{{ trimUsername(item.requestedByUser) }}</span>
      </template>
      <template v-slot:item.actions="{item}">
        <WorklistActionButtons :item="item" v-if="worklistType !== 'NewSubscription' && worklistType !== 'JasperStateNotOk' && worklistType !== 'Swap' && worklistType"></WorklistActionButtons>
        <QuickCompleteActionButtons :item="item" v-if="worklistType === 'NewSubscription' || worklistType === 'JasperStateNotOk' || worklistType === 'Swap'"></QuickCompleteActionButtons>
      </template>
      <template v-slot:item.performTask="{ item }">
        <v-btn v-if="item.workItem.assignedUser === username && worklistType !== 'ProductOrdered'" icon color="success" @click.stop="performTaskAction(item)">
          <v-icon>mdi-arrow-right-circle</v-icon>
        </v-btn>

        <QuickCompleteActionButtons :item="item" v-else-if="worklistType === 'ProductOrdered'"></QuickCompleteActionButtons>

      </template>
      <template v-slot:item.workItem.dateAdded="{item}">
        <div>
          {{ item.workItem.dateAdded | ntzDate }}
        </div>
      </template>
      <template v-slot:item.numberOfUnits="{ item }">
        <v-chip outlined>
          <v-icon left size="18">mdi-cable-data</v-icon>
          {{ item.numberOfUnits }}
        </v-chip>
      </template>
      <template v-slot:item.installationDegree="{ item }">
        <v-chip outlined :class="getPercentClass(item.installationDegree)">{{ item.installationDegree }} %</v-chip>
      </template>
      <template v-slot:item.addedRegnoDegree="{ item }">
        <v-chip outlined :class="getPercentClass(item.addedRegnoDegree)">{{ item.addedRegnoDegree }} %</v-chip>
      </template>
      <template v-slot:item.miniEditedDegree="{ item }">
        <v-chip v-if="item.miniEditedDegree !== null" outlined :class="getPercentClass(item.miniEditedDegree)">{{ item.miniEditedDegree }} %</v-chip>
        <v-chip v-else outlined class="font-weight-bold">N/A</v-chip>
      </template>
      <template v-slot:item.scheduledReportsConfigured="{ item }">
        <div>
          <v-icon color="success" v-if="item.scheduledReportsConfigured">mdi-check-circle-outline</v-icon>
          <v-icon color="primary" v-if="!item.scheduledReportsConfigured">mdi-checkbox-blank-circle-outline</v-icon>
        </div>
      </template>
      <template v-slot:item.notificationsUsed="{ item }">
        <div>
          <v-icon color="success" v-if="item.notificationsUsed">mdi-check-circle-outline</v-icon>
          <v-icon color="primary" v-if="!item.notificationsUsed">mdi-checkbox-blank-circle-outline</v-icon>
        </div>
      </template>
      <template v-slot:item.driversCreated="{ item }">
        <div>
          <v-icon color="success" v-if="item.driversCreated">mdi-check-circle-outline</v-icon>
          <v-icon color="primary" v-if="!item.driversCreated">mdi-checkbox-blank-circle-outline</v-icon>
        </div>
      </template>

      <template v-slot:item.subscriptionCount="{item}">
        <v-chip outlined>{{ item.subscriptionCount }}</v-chip>
      </template>
      <template v-slot:item.triplogCount="{item}">
        <v-chip outlined>{{ item.triplogCount }}</v-chip>
      </template>
      <template v-slot:item.eqCount="{item}">
        <v-chip outlined>{{ item.eqCount }}</v-chip>
      </template>
      <template v-slot:item.mrr="{item}">
        <span>{{ formatMrr(item) }}</span>
      </template>
      <template v-slot:item.averagePriceTriplogEq="{item}">
        <span>{{ formatAveragePriceTriplogEq(item) }}</span>
      </template>
      <template v-slot:item.firstRenewalDate="{item}">
        <span>{{ item.firstRenewalDate | ntzDate }}</span>
      </template>
      <template v-slot:item.lastRenewalDate="{item}">
        <span>{{ item.lastRenewalDate | ntzDate }}</span>
      </template>
      <template v-slot:item.yellowFlaggedSubsCount="{item}">
        <v-chip outlined>{{ item.yellowFlaggedSubsCount }}</v-chip>
      </template>
      <template v-slot:item.firstYellowFlaggedDate="{item}">
        <span>{{ item.firstYellowFlaggedDate | ntzDate }}</span>
      </template>
      <template v-slot:item.portfolioTeam="{ item }">
        <span>{{ item.portfolioTeam.teamName }}</span>
      </template>
      <template v-slot:item.customerSatisfaction="{ item }">
        <v-chip
          outlined
          :class="getChurnSatisfactionValue(item.customerSatisfaction)">
          {{ item.customerSatisfaction }} %
        </v-chip>
      </template>
      <template v-slot:item.eqSubscriptions="{ item }">
        <v-chip outlined>
          <span>{{ item.eqSubscriptions }}</span>
        </v-chip>
      </template>
      <template v-slot:item.triplogSubscriptions="{ item }">
        <v-chip outlined>
          <span>{{ item.triplogSubscriptions }}</span>
        </v-chip>
      </template>
      <template v-slot:item.unitType="{ item }">
        <v-chip
          small
          outlined
        >
          <WrappedTextWithTooltip :text="item.unitType !== 0 ? item.unitType.replaceAll('_', ' ').trim() : 'Unknown unit type'" :max-length="15"></WrappedTextWithTooltip>
        </v-chip>
      </template>
      <template v-slot:item.serialNumber="{ item }">
        <v-chip
          small
          outlined
          class="cursor-pointer"
          @click.passive="gotoDatasource(item)"
        >
          {{ item.serialNumber }}
        </v-chip>
      </template>
      <template v-slot:item.confirmedAddress="{ item }">
        <WrappedTextWithTooltip :text="item.confirmedAddress" :max-length="15"></WrappedTextWithTooltip>
      </template>
      <template v-slot:item.includeReturnLabel="{ item }">
        <IconWithTooltip
          :tooltip="item.includeReturnLabel ? 'Yes, include a return label.' : 'No, do not include a return label.'"
          :icon="item.includeReturnLabel ? 'mdi-check-circle' : 'mdi-close-circle'"
          :color="item.includeReturnLabel ? 'success' : 'error'"
        ></IconWithTooltip>
      </template>
      <template v-slot:item.otherInformation="{ item }">
        <WrappedTextWithTooltip :text="item.otherInformation"></WrappedTextWithTooltip>
      </template>
      <template v-slot:item.troubleshootingInfo="{ item }">
        <WrappedTextWithTooltip :text="item.troubleshootingInfo"></WrappedTextWithTooltip>
      </template>
      <template v-slot:item.unitFound="{item}">
        <v-icon color="success" v-if="item.unitFound !== false">mdi-check-circle-outline</v-icon>
        <v-icon color="primary" v-else>mdi-checkbox-blank-circle-outline</v-icon>
      </template>
      <template v-slot:item.department="{ item }">
        <div
          style="cursor: pointer"
          @click="openMoveDialog(item)">
          <v-icon>mdi-pencil</v-icon>
          <span class="primary--text font-weight-medium">
          {{ item.department.name }}
        </span>
        </div>
      </template>
      <template v-slot:item.additionalInformation="{ item }">
        <TooltipIconButton
          :should-warn="item.otherInformation !== ''"
          icon="mdi-open-in-app"
          color="primary lighten-1"
          tooltip="Click to view additional relevant information."
          @clicked="showAdditionalSwapInfo(item)"
        ></TooltipIconButton>
      </template>
    </v-data-table>

    <AdditionalSwapInfoDialog
      :swap-work-item="selectedItem"
      :show="showSwapAdditionalInformation"
      @close="showSwapAdditionalInformation = false"
    ></AdditionalSwapInfoDialog>

    <NewSubscriptionMoveAssetDialog
      @closeMoveAssetDialog="moveAssetDialog = false"
      :item="selectedItem"
      :visible="moveAssetDialog"
    ></NewSubscriptionMoveAssetDialog>
  </div>
</template>
<script>
import WorklistActionButtons from "@/components/Workhub/Widgets/WorklistActionButtons";
import NewSubscriptionMoveAssetDialog from "@/components/Workhub/Widgets/NewSubscriptionMoveAssetDialog";
import AdditionalSwapInfoDialog from "@/components/dialogs/AdditionalSwapInfoDialog";
import QuickCompleteActionButtons from "@/components/Workhub/Widgets/QuickCompleteActionButtons";
import WrappedTextWithTooltip from "@/components/text/WrappedTextWithTooltip";
import TooltipIconButton from "@/components/buttons/TooltipIconButton";
import IconWithTooltip from "@/components/icons/IconWithTooltip.vue";

export default {
  components: { IconWithTooltip, TooltipIconButton, WrappedTextWithTooltip, NewSubscriptionMoveAssetDialog, AdditionalSwapInfoDialog, WorklistActionButtons, QuickCompleteActionButtons },
  name: "BaseWorklistLayout",
  props: ["filter", "search"],
  data() {
    return {
      selectedItem: {},
      showSwapAdditionalInformation: false,
      moveAssetDialog: false,
    };
  },
  methods: {
    showAdditionalSwapInfo(item) {
      this.selectedItem = item;
      this.showSwapAdditionalInformation = true;
    },
    openMoveDialog(item) {
      if (item?.department?.children?.length === 0) {
        this.$eventBus.$emit("alert", { text: `${item.department.name} does not have any children. Moving is unavailable.`, type: "warning" });
        return;
      } else if (item?.department?.children?.length === 0) {
        this.$eventBus.$emit("alert", { text: `${item.department.name} does not have any sub-departments.`, type: "warning" });
        return;
      }

      this.selectedItem = item;
      this.moveAssetDialog = true;
    },
    addCustomFiltersToHeaders() {
      let headers = this.getHeaders;
      headers[headers.length - 1].filter = this.filter
      return headers;
    },
    trimUsername(name) {
      return this.$utils.trimUsername(name);
    },
    async performTaskAction(item) {
      if (this.worklistType === "ProductOrdered") {
        await this.$store.dispatch("WorklistModule/completeWorklistItem", { id: item.workItem._id, });
      } else {
        await this.$router.push({ name: "taskSpecificUi", params: { aktorId: item.workItem.aktorId, workItem: item.workItem } });
      }
    },
    gotoDatasource(item) {
      this.$router.push({ path: `/customer/${item.workItem.aktorId}?activeTab=5&type=simcard&id=${item.serialNumber}` });
    },
    gotoCustomer(item) {
      this.$router.push({ path: `/customer/${item.workItem.aktorId}?activeTab=${this.$utils.getDefaultTab(this.defaultTable)}` });
    },
    getChurnSatisfactionValue(value) {
      if (value < 60 && value > 20)
        return "font-weight-medium warning--text";
      else if (value <= 20)
        return "font-weight-medium error--text";
      else
        return "font-weight-medium success--text";
    },
    getPercentClass(value) {
      let returnString = "font-weight-bold ";
      if (value < 33) {
        returnString += "warning--text ";
      } else if (value > 77) {
        returnString += "success--text"
      }
      return returnString;
    },
    formatMrr({ country, mrr }) {
      return this.$utils.getFormattedPriceForCountry(country, mrr);
    },
    formatAveragePriceTriplogEq({ country, averagePriceTriplogEq }) {
      return this.$utils.getFormattedPriceForCountry(country, averagePriceTriplogEq)
    },

  },
  computed: {
    worklistType() {
      return this.$store.state.WorklistModule.worklistType
    },
    username() {
      return this.$store.getters.currentUser?.username;
    },
    isLoading() {
      return this.$store.state.WorklistModule.loading;
    },
    workItems() {
      return this.$store.state.WorklistModule.workItems;
    },
    defaultTable() {
      return this.$store.state.userSettings.defaultTable;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    sortOptions() {
      let options = {
        sortBy: "workItem.dateAdded",
        sortDesc: true
      };

      // Add specific sorting behavior depending on type.
      switch (this.worklistType) {
        default:

      }

      return options;
    },
    getHeaders() {
      let headers = []
      switch (this.worklistType) {
        case 'WelcomeCall':
        default:
          headers = [
            { text: "Customer", value: "customerName", filterable: true },
            { text: "Country", value: "country", align: "center" },
            { text: "Task created", value: "workItem.dateAdded", align: "center", filterable: true },
            { text: "Units", value: "numberOfUnits", align: "center", filterable: true },
            { text: "Installation Degree", value: "installationDegree", align: "center" },
            { text: "Added Regno's", value: "addedRegnoDegree", align: "center", filterable: true },
            { text: "Mini's Edited", value: "miniEditedDegree", align: "center", filterable: true },
            { text: "Scheduled Reports", value: "scheduledReportsConfigured", align: "center" },
            { text: "Notifications", value: "notificationsUsed", align: "center" },
            { text: "Drivers Created", value: "driversCreated", align: "center" },
            { text: "Assignee", value: "workItem.assignedUser", align: "center", filterable: true },
            { text: "Actions", value: "actions", align: "center" },
            { text: "Perform task", value: "performTask", align: "center", sortable: false }
          ];
          break;
        case 'RenewalCall':
          headers = [
            { text: "Customer", value: "customerName" },
            { text: "ERP Customer ID", value: "erpCustomerId", align: "center" },
            { text: "Main subs", value: "subscriptionCount", align: "center" },
            { text: "Triplogs", value: "triplogCount", align: "center" },
            { text: "EQ's", value: "eqCount", align: "center" },
            { text: "First renewal date", value: "firstRenewalDate", align: "center" },
            { text: "Last renewal date", value: "lastRenewalDate", align: "center" },
            { text: "MRR", value: "mrr", align: "center" },
            { text: "Avg. Main", value: "averagePriceTriplogEq", align: "center" },
            { text: "Assignee", value: "workItem.assignedUser", align: "center" },
            { text: "Actions", value: "actions", align: "center", sortable: false },
            { text: "Perform task", value: "performTask" }
          ];
          break;
        case 'YellowFlaggedCall':
          headers = [
            { text: "Customer", value: "customerName" },
            { text: "ERP Customer ID", value: "erpCustomerId", align: "center" },
            { text: "Main subs", value: "subscriptionCount", align: "center" },
            { text: "Triplogs", value: "triplogCount", align: "center" },
            { text: "EQ's", value: "eqCount", align: "center" },
            { text: "MRR", value: "mrr", align: "center" },
            { text: "Yellow flag subs", value: "yellowFlaggedSubsCount", align: "center" },
            { text: "First yellow flag date", value: "firstYellowFlaggedDate", align: "center" },
            { text: "Assignee", value: "workItem.assignedUser", align: "center" },
            { text: "Actions", value: "actions", align: "center", sortable: false },
            { text: "Perform task", value: "performTask" }
          ];
          break;
        case 'ChurnPreventionCall':
          headers = [
            { text: "Customer", value: "customerName" },
            { text: "Country", value: "customerCountry", align: "center" },
            { text: "Task created", value: "workItem.dateAdded", align: "center" },
            { text: "Installation degree", value: "installationDegree", align: "center" },
            { text: "Customer satisfaction", value: "customerSatisfaction", align: "center" },
            { text: "Requests (open/total)", value: "totalRequests", align: "center", sortable: false },
            { text: "Triplog subscriptions", value: "triplogSubscriptions", align: "center" },
            { text: "EQ subscriptions", value: "eqSubscriptions", align: "center" },
            { text: "Assignee", value: "workItem.assignedUser", align: "center" },
            { text: "Actions", value: "actions", align: "center", sortable: false },
            { text: "Perform task", value: "performTask", align: "center", sortable: false }
          ];
          break;
        case 'ProductOrdered':
          headers = [
            { text: "Customer", value: "customerName", filterable: true },
            { text: "Country", value: "country", align: "center" },
            { text: "Created", value: "workItem.dateAdded", align: "center", filterable: true },
            { text: "Ordered Minis", value: "orderedAmount", align: "center" },
            { text: "Minis", value: "countMinis", align: "center" },
            { text: "Ordered by", value: "orderedBy", align: "center" },
            { text: "Assignee", value: "workItem.assignedUser", align: "center" },
            { text: "Actions", value: "actions", align: "center", sortable: false },
            { text: "Perform task", value: "performTask", align: "center", sortable: false }
          ];
          break;
        case 'NewSubscription':
          headers = [
            { text: "Customer name", value: "customerName" },
            { text: "Created date", value: "workItem.dateAdded" },
            { text: "Customer ID", value: "erpCustomerId" },
            { text: "Subscription no.", value: "contractNumber" },
            { text: "Serial number", value: "serialNumber" },
            { text: "Unit-type", value: "objectType", align: "center" },
            { text: "Department", value: "department", align: "center" },
            { text: "Reg-no", value: "licensePlateNumber", align: "center" },
            { text: "Actions", value: "actions", align: "center " }
          ];
          break;
        case 'JasperStateNotOk':
          headers = [
            { text: "SIMICC", value: "simicc", filterable: true },
            { text: "Date added", value: "dateAdded", filterable: true },
            { text: "Unit Found", value: "unitFound", align: "center" },
            { text: "Status", value: "status", align: "center" },
            { text: "Status Message", value: "statusMessage", align: "center" },
            { text: "Actions", value: "actions", align: "center" }
          ];
          break;
        case 'Swap':
          headers = [
            { text: "Customer", value: "customerName", filterable: true },
            { text: "Country", value: "country", align: "center" },
            { text: "Task created", value: "workItem.dateAdded", align: "center", filterable: true },
            { text: "BillingOrder NO", value: "billingOrderNo" },
            { text: "Sub. number", value: "contractNumber", align: "center", filterable: true },
            { text: "Current SN", value: "serialNumber", align: "center", filterable: true },
            { text: "Requested HW", value: "unitType", align: "center" },
            { text: "Ticket ID", value: "ticketId", align: "center" },
            { text: "Include return label", value: "includeReturnLabel", align: "center" },
            { text: "Delivery type", value: "consignmentType", align: "center" },
            { text: "Additional information", value: "additionalInformation", align: "center" },
            { text: "Requested By", value: "requestedByUser", align: "center" },
            { text: "Actions", value: "actions", align: "center", sortable: false },
          ];
          break;
        case 'ReturnHandling':
          headers = [
            { text: "Customer", value: "customerName", filterable: true },
            { text: "Customer ID", value: "workItem.erpCustomerId" },
            { text: "Country", value: "country", align: "center" },
            { text: "Task created", value: "workItem.dateAdded", align: "center", filterable: true },
            { text: "Serial number", value: "serialNumber", align: "center", filterable: true },
            { text: "Type description", value: "typeDescription", align: "center" },
            { text: "Actions", value: "actions", align: "center", sortable: false },
          ];
          break;
      }
      if (this.roles.WORKHUB_ADMIN) {
        if (this.worklistType === "RenewalCall" ||
          this.worklistType === "YellowFlaggedCall" ||
          this.worklistType === "ChurnPreventionCall" ||
          this.worklistType === "NewSubscription") {
          headers.splice(headers.length - 1, 0, { text: "Team", value: "portfolioTeam.teamName", align: "center", sortable: true })
        }
      }
      return headers;
    },
  }
};
</script>

<style scoped>
.v-data-table-header th {
  white-space: nowrap;
}

.cursor-pointer {
  cursor: pointer;
}
</style>
