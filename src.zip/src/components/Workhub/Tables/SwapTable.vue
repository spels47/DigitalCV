<template>
  <div>
    <v-data-table
      :headers="addCustomFiltersToHeaders()"
      :items="workItemsWithFilter"
      :loading="isLoading"
      :footer-props="{ 'items-per-page-options': (items_per_page = [10, 20, 50]) }"
      :sort-by="sortOptions.sortBy"
      :sort-desc="sortOptions.sortDesc"
      item-key="id"
      single-expand
      @click:row="expandRow"
      :expanded.sync="expandedRow"
    >
      <template v-slot:item.customerName="{ item }">
        <WrappedTextWithTooltip
          :text="item.customerName"
          :clickable="true"
          @clicked="gotoCustomer(item)"
          :max-length="18"
        ></WrappedTextWithTooltip>
      </template>
      <template v-slot:item.requestedByUser="{ item }">
        <span>{{ trimUsername(item.requestedByUser) }}</span>
      </template>
      <template v-slot:item.dateAdded="{item}">
        <div>
          {{ item.dateAdded | ntzDate }}
        </div>
      </template>
      <template v-slot:item.amountOfSwaps="{item}">
        <v-avatar :style="item.amountOfSwaps == 1 ? 'display: none;' : ''" color="secondary" size="26">
          <span style="color: black;">{{item.amountOfSwaps}}</span>
        </v-avatar>
      </template>

      <template v-slot:item.billingOrderNo="{item}">
        <span :style="item.amountOfSwaps > 1 ? 'display: none;' : ''">{{item.workItems[0].billingOrderNo}}</span>
      </template>
      <template v-slot:item.contractNumber="{item}">
        <span :style="item.amountOfSwaps > 1 ? 'display: none;' : ''">{{item.workItems[0].contractNumber}}</span>
      </template>
      <template v-slot:item.ticketId="{item}">
        <span :style="item.amountOfSwaps > 1 ? 'display: none;' : ''">{{item.workItems[0].ticketId}}</span>
      </template>
      <template v-slot:item.consignmentType="{item}">
        <span :style="item.amountOfSwaps > 1 ? 'display: none;' : ''">{{item.workItems[0].consignmentType}}</span>
      </template>
      <template v-slot:item.unitType="{ item }">
        <v-chip small outlined :style="item.amountOfSwaps > 1 ? 'display: none;' : ''">
          <WrappedTextWithTooltip :text="item.workItems[0].unitType !== 0 ? item.workItems[0].unitType.replaceAll('_', ' ').trim() : 'Unknown unit type'" :max-length="15"></WrappedTextWithTooltip>
        </v-chip>
    </template>
    <template v-slot:item.serialNumber="{ item }">
      <v-chip small outlined class="cursor-pointer" @click="gotoDatasource(item)" :style="item.amountOfSwaps > 1 ? 'display: none;' : ''">
        {{ item.workItems[0].serialNumber }}
      </v-chip>
    </template>
    <template v-slot:item.confirmedAddress="{ item }">
      <WrappedTextWithTooltip :style="item.amountOfSwaps > 1 ? 'display: none;' : ''" :text="item.workItems[0].confirmedAddress" :max-length="15"></WrappedTextWithTooltip>
    </template>
    <template v-slot:item.includeReturnLabel="{ item }">
      <div :style="item.amountOfSwaps > 1 ? 'display: none;' : ''">
        <IconWithTooltip
          :tooltip="item.workItems[0].includeReturnLabel ? 'Yes, include a return label.' : 'No, do not include a return label.'"
          :icon="item.workItems[0].includeReturnLabel ? 'mdi-check-circle' : 'mdi-close-circle'"
          :color="item.workItems[0].includeReturnLabel ? 'success' : 'error'"
        ></IconWithTooltip>
      </div>
    </template>
    <template v-slot:item.additionalInformation="{ item }">
      <div :style="item.amountOfSwaps > 1 ? 'display: none;' : ''">
        <TooltipIconButton
          :should-warn="item.workItems[0].otherInformation !== ''"
          icon="mdi-open-in-app"
          color="primary lighten-1"
          tooltip="Click to view additional relevant information."
          @clicked="showAdditionalSwapInfo(item.workItems[0])"
        ></TooltipIconButton>
      </div>
    </template>
    <template v-slot:item.actions="{item}">
      <SwapActionButtons :style="item.amountOfSwaps > 1 ? 'display: none;' : ''" :item="item.workItems[0]"></SwapActionButtons>
    </template>
    <!-- <template v-slot:item.data-table-expand="{item}">
      <v-icon>{{item.data-table-expand}}</v-icon>
    </template> -->
      
      <template v-slot:expanded-item="{ headers, item }">
        <td :colspan="headers.length" class="subTableContainer">
          <v-data-table
            :headers="subHeaders"
            :items="item.workItems"
            :loading="isLoading"
            :headers-length="headers.length"
            hide-default-footer
            :sort-by="sortOptions.sortBy"
            :sort-desc="sortOptions.sortDesc"
            item-key="_id"
          >
            <template v-slot:item.unitType="{ item }">
              <v-chip
                small
                outlined
              >
                <WrappedTextWithTooltip :text="item.unitType !== 0 ? item.unitType.replaceAll('_', ' ').trim() : 'Unknown unit type'" :max-length="15"></WrappedTextWithTooltip>
              </v-chip>
            </template>
            <template v-slot:item.serialNumber="{ item }">
              <v-chip
                small
                outlined
                class="cursor-pointer"
                @click="gotoDatasource(item)"
              >
                {{ item.serialNumber }}
              </v-chip>
            </template>
            <template v-slot:item.confirmedAddress="{ item }">
              <WrappedTextWithTooltip :text="item.confirmedAddress" :max-length="15"></WrappedTextWithTooltip>
            </template>
            <template v-slot:item.includeReturnLabel="{ item }">
              <IconWithTooltip
                :tooltip="item.includeReturnLabel ? 'Yes, include a return label.' : 'No, do not include a return label.'"
                :icon="item.includeReturnLabel ? 'mdi-check-circle' : 'mdi-close-circle'"
                :color="item.includeReturnLabel ? 'success' : 'error'"
              ></IconWithTooltip>
            </template>
            <template v-slot:item.additionalInformation="{ item }">
              <TooltipIconButton
                :should-warn="item.otherInformation !== ''"
                icon="mdi-open-in-app"
                color="primary lighten-1"
                tooltip="Click to view additional relevant information."
                @clicked="showAdditionalSwapInfo(item)"
              ></TooltipIconButton>
            </template>
            <template v-slot:item.actions="{item}">
              <SwapActionButtons :item="item"></SwapActionButtons>
            </template>
          </v-data-table>
        </td>
    </template>
    </v-data-table>

    <AdditionalSwapInfoDialog
      :swap-work-item="selectedItem"
      :show="showSwapAdditionalInformation"
      @close="showSwapAdditionalInformation = false"
    ></AdditionalSwapInfoDialog>
  </div>
</template>
<script>
/* eslint-disable */
import AdditionalSwapInfoDialog from "@/components/dialogs/AdditionalSwapInfoDialog";
import SwapActionButtons from "@/components/Workhub/Widgets/SwapActionButtons";
import WrappedTextWithTooltip from "@/components/text/WrappedTextWithTooltip";
import TooltipIconButton from "@/components/buttons/TooltipIconButton";
import IconWithTooltip from "@/components/icons/IconWithTooltip.vue";

export default {
  components: { IconWithTooltip, TooltipIconButton, WrappedTextWithTooltip, AdditionalSwapInfoDialog, SwapActionButtons },
  name: "SwapTable",
  props: ["filter", "search"],
  data() {
    return {
      expandedRow: [],
      mandatoryExpandedRows: [],
      selectedItem: {},
      showSwapAdditionalInformation: false,
      moveAssetDialog: false,
      headers: [
            { text: "Customer", value: "customerName", filterable: true, width: "0" },
            { text: "Country", value: "country", align: "center" },
            { text: "Task created", value: "dateAdded", align: "center", filterable: true, width: "20px" },
            { text: "BillingOrder NO", value: "billingOrderNo" },
            { text: "Sub. number", value: "contractNumber", align: "center", filterable: true,  width: "20px" },
            { text: "Current SN", value: "serialNumber", align: "center", filterable: true },
            { text: "Requested HW", value: "unitType", align: "center" },
            { text: "Ticket ID", value: "ticketId", align: "center" },
            { text: "Include return label", value: "includeReturnLabel", align: "center" },
            { text: "Delivery type", value: "consignmentType", align: "center" },
            { text: "Additional information", value: "additionalInformation", align: "center" },
            { text: "Requested By", value: "requestedByUser", align: "center" },
            { text: "Number of swaps", value: "amountOfSwaps", align: "center" },
            { text: "Actions", value: "actions", align: "center", sortable: false },
            { text: '', value: 'data-table-expand' },
          ],
        subHeaders: [
            { text: "BillingOrder NO", value: "billingOrderNo" },
            { text: "Sub. number", value: "contractNumber", align: "center", filterable: true },
            { text: "Current SN", value: "serialNumber", align: "center", filterable: true },
            { text: "Requested HW", value: "unitType", align: "center" },
            { text: "Ticket ID", value: "ticketId", align: "center" },
            { text: "Include return label", value: "includeReturnLabel", align: "center" },
            { text: "Delivery type", value: "consignmentType", align: "center" },
            { text: "Additional information", value: "additionalInformation", align: "center" },
            { text: "Actions", value: "actions", align: "center", sortable: false },
        ],
      searchValues: {
        customerName: [],
        country: [],
        dateAdded: [],
        requestedByUser: [],
        billingOrderNo: [],
        contractNumber: [],
        serialNumber: [],
        unitType: [],
        ticketId: [],
        confirmedAddress: [],
        swapReason: [],
        otherInformation: [],
        troubleshootingInfo: [],
        contactPerson: [],
        searchResult: [],
      }
    };
  },
  methods: {
    showAdditionalSwapInfo(item) {
      this.selectedItem = item;
      this.showSwapAdditionalInformation = true;
    },
    addCustomFiltersToHeaders() {
      this.headers[this.headers.length - 1].filter = this.filter
      return this.headers;
    },
    trimUsername(name) {
      return this.$utils.trimUsername(name);
    },
    gotoDatasource(item) {
      this.$router.push({ path: `/customer/${item.workItem.aktorId}?activeTab=5&type=simcard&id=${item.serialNumber}` });
    },
    gotoCustomer(item) {
      this.$router.push({ path: `/customer/${item.workItem.aktorId}?activeTab=${this.$utils.getDefaultTab(this.defaultTable)}` });
    },
    getItemsByCustomerId(erpCustomerId){
      return this.workItems.filter(item => item.erpCustomerId == erpCustomerId);
    },
    Search(){
      if(!this.search) {
        this.searchValues.searchResult = [];
        return;
      }
      this.customerNameSearch();
      this.countrySearch();
      this.dateAddedSearch();
      this.requestedByUserSearch();
      this.billingOrderNoSearch();
      this.contractNumberSearch();
      this.serialNumberSearch();
      this.unitTypeSearch();
      this.ticketIdSearch();
      this.confirmedAddressSearch();
      this.swapReasonSearch();
      this.otherInformationSearch();
      this.troubleshootingInfoSearch();
      this.contactPersonSearch();
      this.collectSearchResults();
    },
    customerNameSearch(){
      this.searchValues.customerName = [];
      let searchArray = [].concat(this.workItems);
      for (let i = 0; i < searchArray.length; i++) {
        const item = searchArray[i];
        if(item.customerName?.toLowerCase()?.includes(this.search?.toLowerCase())) this.searchValues.customerName.push(item);
      }
    },
    countrySearch(){
      this.searchValues.country = [];
      let searchArray = [].concat(this.workItems);
      for (let i = 0; i < searchArray.length; i++) {
        const item = searchArray[i];
        if(item.country?.toLowerCase()?.includes(this.search?.toLowerCase())) this.searchValues.country.push(item);
      }
    },
    dateAddedSearch(){
      this.searchValues.dateAdded = [];
      let searchArray = [].concat(this.workItems);
      for (let i = 0; i < searchArray.length; i++) {
        const item = searchArray[i];
        if(item.dateAdded?.toLowerCase()?.includes(this.search?.toLowerCase())) this.searchValues.dateAdded.push(item);
      }
    },
    requestedByUserSearch(){
      this.searchValues.requestedByUser = [];
      let searchArray = [].concat(this.workItems);
      for (let i = 0; i < searchArray.length; i++) {
        const item = searchArray[i];
        if(this.trimUsername(item.requestedByUser)?.toLowerCase()?.includes(this.search?.toLowerCase())) this.searchValues.requestedByUser.push(item);
      }
    },
    billingOrderNoSearch(){
      this.searchValues.billingOrderNo = [];
      let searchArray = [].concat(this.workItems);
      for (let i = 0; i < searchArray.length; i++) {
        const item = searchArray[i];
        if(this.checkIfExistsInTopSearch(item)) continue;
        for (let j = 0; j < item.workItems.length; j++) {
          const workItem = item.workItems[j];
          if(workItem.billingOrderNo?.toLowerCase()?.includes(this.search?.toLowerCase())){
            if(this.existsInList(this.searchValues.billingOrderNo, item) && !this.taskInList(item.workItems, workItem)) item.workItems.push(workItem);
            else {
              const itemToAdd = this.addWithoutWorkList(item);
              this.searchValues.billingOrderNo.push(itemToAdd);
              var index = this.searchValues.billingOrderNo.indexOf(itemToAdd);
              this.searchValues.billingOrderNo[index].workItems.push(workItem);
            }
          }
        }
      }
    },
    contractNumberSearch(){
      this.searchValues.contractNumber = [];
      let searchArray = [].concat(this.workItems);
      for (let i = 0; i < searchArray.length; i++) {
        const item = searchArray[i];
        if(this.checkIfExistsInTopSearch(item)) continue;
        for (let j = 0; j < item.workItems.length; j++) {
          const workItem = item.workItems[j];
          if(workItem.contractNumber?.toLowerCase()?.includes(this.search?.toLowerCase())){
            if(this.existsInList(this.searchValues.contractNumber, item) && !this.taskInList(item.workItems, workItem)) item.workItems.push(workItem);
            else {
              const itemToAdd = this.addWithoutWorkList(item);
              this.searchValues.contractNumber.push(itemToAdd);
              var index = this.searchValues.contractNumber.indexOf(itemToAdd);
              this.searchValues.contractNumber[index].workItems.push(workItem);
            }
          }
        }
      }
    },
    serialNumberSearch(){
      this.searchValues.serialNumber = [];
      let searchArray = [].concat(this.workItems);
      for (let i = 0; i < searchArray.length; i++) {
        const item = searchArray[i];
        if(this.checkIfExistsInTopSearch(item)) continue;
        for (let j = 0; j < item.workItems.length; j++) {
          const workItem = item.workItems[j];
          if(workItem.serialNumber?.toLowerCase()?.includes(this.search?.toLowerCase())){
            if(this.existsInList(this.searchValues.serialNumber, item) && !this.taskInList(item.workItems, workItem)) item.workItems.push(workItem);
            else {
              const itemToAdd = this.addWithoutWorkList(item);
              this.searchValues.serialNumber.push(itemToAdd);
              var index = this.searchValues.serialNumber.indexOf(itemToAdd);
              this.searchValues.serialNumber[index].workItems.push(workItem);
            }
          }
        }
      }
    },
    unitTypeSearch(){
      this.searchValues.unitType = [];
      let searchArray = [].concat(this.workItems);
      for (let i = 0; i < searchArray.length; i++) {
        const item = searchArray[i];
        if(this.checkIfExistsInTopSearch(item)) continue;
        for (let j = 0; j < item.workItems.length; j++) {
          const workItem = item.workItems[j];
          if(workItem.unitType?.toLowerCase()?.includes(this.search?.toLowerCase())){
            if(this.existsInList(this.searchValues.unitType, item) && !this.taskInList(item.workItems, workItem)) item.workItems.push(workItem);
            else {
              const itemToAdd = this.addWithoutWorkList(item);
              this.searchValues.unitType.push(itemToAdd);
              var index = this.searchValues.unitType.indexOf(itemToAdd);
              this.searchValues.unitType[index].workItems.push(workItem);
            }
          }
        }
      }
    },
    ticketIdSearch(){
      this.searchValues.ticketId = [];
      let searchArray = [].concat(this.workItems);
      for (let i = 0; i < searchArray.length; i++) {
        const item = searchArray[i];
        if(this.checkIfExistsInTopSearch(item)) continue;
        for (let j = 0; j < item.workItems.length; j++) {
          const workItem = item.workItems[j];
          if(workItem.ticketId?.toString()?.toLowerCase()?.includes(this.search?.toLowerCase())){
            if(this.existsInList(this.searchValues.ticketId, item) && !this.taskInList(item.workItems, workItem)) item.workItems.push(workItem);
            else {
              const itemToAdd = this.addWithoutWorkList(item);
              this.searchValues.ticketId.push(itemToAdd);
              var index = this.searchValues.ticketId.indexOf(itemToAdd);
              this.searchValues.ticketId[index].workItems.push(workItem);
            }
          }
        }
      }
    },
    confirmedAddressSearch(){
      this.searchValues.confirmedAddress = [];
      let searchArray = [].concat(this.workItems);
      for (let i = 0; i < searchArray.length; i++) {
        const item = searchArray[i];
        if(this.checkIfExistsInTopSearch(item)) continue;
        for (let j = 0; j < item.workItems.length; j++) {
          const workItem = item.workItems[j];
          if(workItem.confirmedAddress?.toLowerCase()?.includes(this.search?.toLowerCase())){
            if(this.existsInList(this.searchValues.confirmedAddress, item) && !this.taskInList(item.workItems, workItem)) item.workItems.push(workItem);
            else {
              const itemToAdd = this.addWithoutWorkList(item);
              this.searchValues.confirmedAddress.push(itemToAdd);
              var index = this.searchValues.confirmedAddress.indexOf(itemToAdd);
              this.searchValues.confirmedAddress[index].workItems.push(workItem);
            }
          }
        }
      }
    },
    swapReasonSearch(){
      this.searchValues.swapReason = [];
      let searchArray = [].concat(this.workItems);
      for (let i = 0; i < searchArray.length; i++) {
        const item = searchArray[i];
        if(this.checkIfExistsInTopSearch(item)) continue;
        for (let j = 0; j < item.workItems.length; j++) {
          const workItem = item.workItems[j];
          if(workItem.swapReason?.toLowerCase()?.includes(this.search?.toLowerCase())){
            if(this.existsInList(this.searchValues.swapReason, item) && !this.taskInList(item.workItems, workItem)) item.workItems.push(workItem);
            else {
              const itemToAdd = this.addWithoutWorkList(item);
              this.searchValues.swapReason.push(itemToAdd);
              var index = this.searchValues.swapReason.indexOf(itemToAdd);
              this.searchValues.swapReason[index].workItems.push(workItem);
            }
          }
        }
      }
    },
    otherInformationSearch(){
      this.searchValues.otherInformation = [];
      let searchArray = [].concat(this.workItems);
      for (let i = 0; i < searchArray.length; i++) {
        const item = searchArray[i];
        if(this.checkIfExistsInTopSearch(item)) continue;
        for (let j = 0; j < item.workItems.length; j++) {
          const workItem = item.workItems[j];
          if(workItem.otherInformation?.toLowerCase()?.includes(this.search?.toLowerCase())){
            if(this.existsInList(this.searchValues.otherInformation, item) && !this.taskInList(item.workItems, workItem)) item.workItems.push(workItem);
            else {
              const itemToAdd = this.addWithoutWorkList(item);
              this.searchValues.otherInformation.push(itemToAdd);
              var index = this.searchValues.otherInformation.indexOf(itemToAdd);
              this.searchValues.otherInformation[index].workItems.push(workItem);
            }
          }
        }
      }
    },
    troubleshootingInfoSearch(){
      this.searchValues.troubleshootingInfo = [];
      let searchArray = [].concat(this.workItems);
      for (let i = 0; i < searchArray.length; i++) {
        const item = searchArray[i];
        if(this.checkIfExistsInTopSearch(item)) continue;
        for (let j = 0; j < item.workItems.length; j++) {
          const workItem = item.workItems[j];
          if(workItem.troubleshootingInfo?.toLowerCase()?.includes(this.search?.toLowerCase())){
            if(this.existsInList(this.searchValues.troubleshootingInfo, item) && !this.taskInList(item.workItems, workItem)) item.workItems.push(workItem);
            else {
              const itemToAdd = this.addWithoutWorkList(item);
              this.searchValues.troubleshootingInfo.push(itemToAdd);
              var index = this.searchValues.troubleshootingInfo.indexOf(itemToAdd);
              this.searchValues.troubleshootingInfo[index].workItems.push(workItem);
            }
          }
        }
      }
    },
    contactPersonSearch(){
      this.searchValues.contactPerson = [];
      let searchArray = [].concat(this.workItems);
      for (let i = 0; i < searchArray.length; i++) {
        const item = searchArray[i];
        if(this.checkIfExistsInTopSearch(item)) continue;
        for (let j = 0; j < item.workItems.length; j++) {
          const workItem = item.workItems[j];
          var email = workItem.contactPerson?.email?.toLowerCase() ?? "";
          var name = workItem.contactPerson?.name.toLowerCase() ?? "";
          var phone = workItem.contactPerson?.phone.toLowerCase() ?? "";
          if(email.length > 0 && email?.includes(this.search?.toLowerCase()) || name?.includes(this.search?.toLowerCase()) || phone?.includes(this.search?.toLowerCase())){
            if(this.existsInList(this.searchValues.contactPerson, item) && !this.taskInList(item.workItems, workItem)) item.workItems.push(workItem);
            else {
              const itemToAdd = this.addWithoutWorkList(item);
              this.searchValues.contactPerson.push(itemToAdd);
              var index = this.searchValues.contactPerson.indexOf(itemToAdd);
              this.searchValues.contactPerson[index].workItems.push(workItem);
            }
          }
        }
      }
    },
    collectSearchResults(){
      const arrs = this.searchValues;
      this.searchValues.searchResult = this.uniq(arrs.customerName.concat(arrs.country, arrs.dateAdded, arrs.requestedByUser, this.uniqueSubLists()));
    },
    uniq(a) {
      var prims = {"boolean":{}, "number":{}, "string":{}}, objs = [];

      return a.filter(function(item) {
          var type = typeof item;
          if(type in prims) return prims[type].hasOwnProperty(item) ? false : (prims[type][item] = true);
          else return objs.indexOf(item) >= 0 ? false : objs.push(item);
      });
    },
    uniqueSubLists(){
      var billingOrderNo = this.searchValues.billingOrderNo;
      var contractNumber = this.searchValues.contractNumber;
      var serialNumber = this.searchValues.serialNumber;
      var unitType = this.searchValues.unitType;
      var ticketId = this.searchValues.ticketId;
      var confirmedAddress = this.searchValues.confirmedAddress;
      var swapReason = this.searchValues.swapReason;
      var otherInformation = this.searchValues.otherInformation;
      var troubleshootingInfo = this.searchValues.troubleshootingInfo;
      var contactPerson = this.searchValues.contactPerson;
      var completeList = billingOrderNo.concat(contractNumber, serialNumber, unitType, ticketId, confirmedAddress, swapReason, otherInformation, troubleshootingInfo, contactPerson);

      for (let i = 0; i < completeList.length; i++) {
        var duplicates = completeList.filter(x => x.id == completeList[i].id);
        var holder = null;
        if(duplicates.length > 1){
          for (let j = 0; j < duplicates.length; j++) {
            if(holder == null) {
              holder = ([].concat(completeList[i]))[0];
              var duplicateWorkItems = duplicates.map(x => x.workItems);
              var uniqueWorkItems = [];
              for (let k = 0; k < duplicateWorkItems.length; k++) {
                for (let y = 0; y < duplicateWorkItems[k].length; y++) {
                  if(!this.taskInList(uniqueWorkItems, duplicateWorkItems[k][y])) uniqueWorkItems.push(duplicateWorkItems[k][y]);
                }
              }
              holder.workItems = uniqueWorkItems;
            }
            var index = completeList.indexOf(duplicates[j]);
            completeList.splice(index, 1);
          }
          completeList.push(holder);
        }
      }
      return this.uniq(completeList);
    },
    checkIfExistsInTopSearch(item){
      for (let i = 0; i < this.searchValues.customerName.length; i++) {
        const searchVal = this.searchValues.customerName[i];
        if(item.id == searchVal.id) return true;
      }
      for (let i = 0; i < this.searchValues.country.length; i++) {
        const searchVal = this.searchValues.country[i];
        if(item.id == searchVal.id) return true;
      }
      for (let i = 0; i < this.searchValues.dateAdded.length; i++) {
        const searchVal = this.searchValues.dateAdded[i];
        if(item.id == searchVal.id) return true;
      }
      for (let i = 0; i < this.searchValues.requestedByUser.length; i++) {
        const searchVal = this.searchValues.requestedByUser[i];
        if(item.id == searchVal.id) return true;
      }
      return false;
    },
    addWithoutWorkList(item){
      var result = {
        aktorId: item.aktorId,
        amountOfSwaps: item.amountOfSwaps,
        country: item.country,
        customerName: item.customerName,
        dateAdded: item.dateAdded,
        erpClientId: item.erpClientId,
        erpCustomerId: item.erpCustomerId,
        id: item.id,
        requestedByUser: item.requestedByUser,
        workItems: []
      };
      return result;
    },
    existsInList(items, item){
      for (let i = 0; i < items.length; i++) {
        const topItem = items[i];
        if(topItem.id == item.id) return true;
      }
      return false;
    },
    taskInList(items, item){
      for (let i = 0; i < items.length; i++) {
        const subItem = items[i];
        if(subItem._id == item._id) return true;
      }
      return false;
    },
    expandRow(event, row){
      if(event.amountOfSwaps == 1 && !row.isExpanded) return;
      row.expand(!row.isExpanded);
    },
    populateMandatoryOpenArray(){
      this.mandatoryExpandedRows = [];
      let data = [].concat(this.workItemsWithFilter);
      this.mandatoryExpandedRows = [].concat(data.filter(x => x.amountOfSwaps == 1));
      var resultArray = [].concat(this.mandatoryExpandedRows);
      for (let i = 0; i < resultArray.length; i++) {
        const newResultItem = resultArray[i];
        var foundItemInNewValue = this.expandedRow.find(x => x.id == newResultItem.id);
        if(!foundItemInNewValue) this.expandedRow.push(newResultItem);
      }
    }
  },
  computed: {
    username() {
      return this.$store.getters.currentUser?.username;
    },
    isLoading() {
      return this.$store.state.WorklistModule.loading;
    },
    workItems() {
      return this.$store.state.WorklistModule.workItems;
    },
    defaultTable() {
      return this.$store.state.userSettings.defaultTable;
    },
    workItemsWithFilter() {
      if(this.search) return this.searchValues.searchResult;
      return this.workItems;
    },
    sortOptions() {
      let options = {
        sortBy: "dateAdded",
        sortDesc: true
      };

      return options;
    }
  },
  watch: {
      search: function (newValue, oldValue) {
        if(newValue != oldValue) {
          this.Search();
          // this.populateMandatoryOpenArray();
        }
      },
      workItems: {
          handler: function (newValue, oldValue) {
          if(newValue != oldValue) {
            this.Search();
            // this.populateMandatoryOpenArray();
          }
        },
        deep: true
      },
      // expandedRow: {
      //     handler: function (newValue, oldValue) {
      //     var resultArray = [].concat(this.mandatoryExpandedRows);
      //     for (let i = 0; i < resultArray.length; i++) {
      //       const newResultItem = resultArray[i];
      //       var foundItemInNewValue = newValue.find(x => x.id == newResultItem.id);
      //       if(!foundItemInNewValue) this.expandedRow.push(newResultItem);
      //     }
      //     // this.$forceUpdate();
      //     console.log("expanded rows array:", this.expandedRow);
      //   },
      //   deep: true
      // },
      isLoading: function() {
        // this.populateMandatoryOpenArray();
      }
    },
  mounted() {
    // this.populateMandatoryOpenArray();
  }
};
</script>

<style scoped>
.v-data-table-header th {
  white-space: nowrap;
}

.cursor-pointer {
  cursor: pointer;
}

.subTableContainer{
  padding: 0px !important;
  border-bottom: thin solid rgba(0,0,0,.01) !important;
}

.v-data-table{
  max-width: 100vw;
  width: 100%;
  overflow-x: hidden;
}
</style>
