<template>
  <v-data-table
    v-if="visible"
    :headers="addCustomFiltersToHeaders()"
    :items="workItems"
    :loading="isLoading"
    :search="search"
  >
    <template v-slot:item.erpCustomerId="{item}">
      <v-chip outlined>{{ item.erpCustomerId }}</v-chip>
    </template>
    <template v-slot:item.workItem.assignedUser="{ item }">
      <span>{{ trimUsername(item.workItem.assignedUser) }}</span>
    </template>
    <template v-slot:item.requestedByUser="{ item }">
      <span>{{ trimUsername(item.requestedByUser) }}</span>
    </template>
    <template v-slot:item.workItem.dateAdded="{item}">
      <span>{{ item.workItem.dateAdded | ntzDate }}</span>
    </template>
    <template v-slot:item.workItem.dateCompleted="{item}">
      <span>{{ item.workItem.dateCompleted | ntzDate }}</span>
    </template>
  </v-data-table>
</template>
<script>
export default {
  name: "CompletedSwapTable",
  props: ["visible", "search", "filter"],
  components: { },
  data() {
    return {
      loading: false,
      headers: [
            { text: "Customer", value: "customerName", filterable: true },
            { text: "Customer ID", value: "erpCustomerId" },
            { text: "Country", value: "country", align: "center" },
            { text: "Current SN", value: "serialNumber", align: "center", filterable: true },
            { text: "Swap Reason", value: "swapReason", align: "center" },
            { text: "Requested By", value: "requestedByUser", align: "center" },
            { text: "Assignee", value: "workItem.assignedUser", align: "center", filterable: true },
            { text: "Task created", value: "workItem.dateAdded", align: "center", filterable: true },
            { text: "Completed Date", value: "workItem.dateCompleted", align: "center", sortable: true }
          ]
    }
  },
  methods: {
    trimUsername(name) {
      return this.$utils.trimUsername(name);
    },
    addCustomFiltersToHeaders() {
      this.headers[this.headers.length - 1].filter = this.filter
      return this.headers;
    },
  },
  computed: {
    username() {
      return this.$store.getters.currentUser?.username;
    },
    isLoading() {
      return this.$store.state.WorklistModule.loading;
    },
    workItems() {
      return this.$store.state.WorklistModule.workItems;
    }
  },
}
</script>

<style scoped>

</style>
