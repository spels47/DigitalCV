﻿<template>
  <div class="d-flex justify-center">
    <TooltipIconButton
      v-if="item.workItem.worklistType === 'Swap'"
      @clicked="showDeclineDialog = true"
      tooltip="Decline"
      icon="mdi-cancel"
      color="error"
    ></TooltipIconButton>

    <TooltipIconButton
      v-if="item.workItem.dateCompleted === null"
      tooltip="Complete"
      icon="mdi-check-circle"
      color="success"
      @clicked="completeTask(item)"
    ></TooltipIconButton>

    <TooltipIconButton
      v-else
      tooltip="Uncomplete"
      icon="mdi-close-circle"
      color="error"
      @clicked="cancelComplete(item)"
    ></TooltipIconButton>

    <DeclineSwapWorkItemDialog
      :show="showDeclineDialog"
      :item="item"
      :key="showDeclineDialog"
      @close="showDeclineDialog = false"
    ></DeclineSwapWorkItemDialog>
  </div>
</template>

<script>
import TooltipIconButton from "@/components/buttons/TooltipIconButton";
import DeclineSwapWorkItemDialog from "@/components/Workhub/Widgets/DeclineSwapWorkItemDialog";
import axios from "~/axios-client";

export default {
  name: "QuickCompleteActionButtons",
  props: ["item"],
  components: { DeclineSwapWorkItemDialog, TooltipIconButton },
  data() {
    return {
      showDeclineDialog: false
    }
  },
  methods: {
    async completeTask(item) {
      await this.$store.dispatch("WorklistModule/completeWorklistItem", { id: item.workItem._id, });

      if(item.workItem.worklistType === 'Swap'){
        await axios.post("/api/ticket/message", {
          ticketId: item.ticketId,
          body: "The swap work list item has been set as completed by the service agent"
        });

        await axios.patch(`/api/ticket/${this.item.ticketId}/set-active`);

        // enable if we want to delete this item even when the task is completed.
        // await axios.delete(`/api/swap/${this.item.serialNumber}/swapEvent`);
      }
    },
    async cancelComplete(item) {
      await this.$store.dispatch("WorklistModule/cancelWorklistItem", { id: item.workItem._id });
    },
  }
}
</script>

<style scoped>

</style>
