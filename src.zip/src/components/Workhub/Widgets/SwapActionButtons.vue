<template>
  <div class="d-flex justify-center">
    <TooltipIconButton
      @clicked="showDeclineDialog = true"
      tooltip="Decline"
      icon="mdi-cancel"
      color="error"
    ></TooltipIconButton>

    <TooltipIconButton
      tooltip="Complete"
      icon="mdi-check-circle"
      color="success"
      @clicked="completeTask(item)"
    ></TooltipIconButton>

    <DeclineSwapWorkItemDialog
      :show="showDeclineDialog"
      :item="item"
      :key="showDeclineDialog"
      @close="showDeclineDialog = false"
    ></DeclineSwapWorkItemDialog>
  </div>
</template>

<script>
import TooltipIconButton from "@/components/buttons/TooltipIconButton";
import DeclineSwapWorkItemDialog from "@/components/Workhub/Widgets/DeclineSwapWorkItemDialog";
import axios from "~/axios-client";

export default {
  name: "SwapActionButtons",
  props: ["item"],
  components: { DeclineSwapWorkItemDialog, TooltipIconButton },
  data() {
    return {
      showDeclineDialog: false
    }
  },
  methods: {
    async completeTask(item) {
      console.log("item:", item);
      await this.$store.dispatch("WorklistModule/completeWorklistItem", { id: item._id, });
      await this.$store.dispatch("WorklistModule/removeSwapItem", item._id);

      await axios.post("/api/ticket/message", {
        ticketId: item.ticketId,
        body: "The swap work list item has been set as completed by the service agent"
      });

      await axios.patch(`/api/ticket/${this.item.ticketId}/set-active`);

        // enable if we want to delete this item even when the task is completed.
        // await axios.delete(`/api/swap/${this.item.serialNumber}/swapEvent`);
    },
    async cancelComplete(item) {
      await this.$store.dispatch("WorklistModule/cancelWorklistItem", { id: item._id });
      await this.$store.dispatch("WorklistModule/removeSwapItem", item._id);
    },
  }
}
</script>

<style scoped>

</style>
