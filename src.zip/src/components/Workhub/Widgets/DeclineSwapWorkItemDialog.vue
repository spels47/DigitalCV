﻿<template>
  <v-dialog
    :value="showDialog"
    @click:outside="showDialog = false"
    width="500"
  >
    <v-card>
      <v-card-title>Decline swap</v-card-title>
      <v-card-subtitle>Decline and remove this work-item from the list.</v-card-subtitle>

      <v-divider></v-divider>

      <v-card-text>
        <v-textarea
          label="Message to write to SuperOffice ticket"
          class="mt-2"
          rows="1"
          v-model="soMessage"
          autofocus
          auto-grow
          no-resize
          outlined
        ></v-textarea>
      </v-card-text>

      <v-card-actions>
        <v-spacer></v-spacer>

        <v-btn
          :disabled="validMessage"
          :loading="declining"
          color="error"
          @click="declineSwapWorkItem"
        >
          <v-icon left>mdi-cancel</v-icon>
          <span>Decline</span>
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import axios from "~/axios-client";

export default {
  name: "DeclineSwapWorkItemDialog",
  props: {
    show: {
      type: Boolean,
      required: true
    },
    item: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      soMessage: "",
      declining: false
    }
  },
  methods: {
    async declineSwapWorkItem() {
      this.declining = true;
      let errorMessage = "Failed to post the ticket message.";
      try {
        await axios.post("/api/ticket/message", {
          ticketId: this.item.ticketId,
          body: this.soMessage
        });
        errorMessage = "Failed to decline work item.";
        await this.$store.dispatch("WorklistModule/ignoreWorkItem", this.item?.workItem?._id ?? this.item._id);
        errorMessage = "Failed to clean up record in SwapEventRecords database";
        await axios.delete(`/api/swap/${this.item.serialNumber}/swapEvent`);
        errorMessage = "Failed to set ticket status to active";
        await axios.patch(`/api/ticket/${this.item.ticketId}/set-active`);

        this.$eventBus.$emit('alert', { text: "Swap request declined successfully.", type: "success" });
        this.$emit("declined");
        this.showDialog = false;
      } catch {
        this.$eventBus.$emit('alert', { text: errorMessage, type: "warning" });
      } finally {
        this.declining = false;
      }
    }
  },
  computed: {
    validMessage() {
      return this.soMessage.trim().length <= 0;
    },
    showDialog: {
      get() {
        return this.show;
      },
      set(value) {
        if (!value)
          this.$emit("close");
      }
    }
  }
}
</script>

<style scoped>

</style>
