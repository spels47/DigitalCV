﻿<template>
  <v-dialog
    :value="showDialog"
    width="600"
    @click:outside="showDialog = false"
  >
    <v-card>
      <v-card-title>Schedule work-item</v-card-title>
      <v-card-subtitle>Hide this work-item from the list and make it appear again when applicable.</v-card-subtitle>

      <v-divider></v-divider>

      <v-card-text class="pt-4">
        <v-date-picker
          :allowed-dates="disablePastDates"
          v-model="date"
          elevation="1"
          color="secondary"
          full-width
        >

        </v-date-picker>
      </v-card-text>

      <v-card-actions>
        <v-spacer></v-spacer>

        <v-btn
          :disabled="selectedDateIsToday"
          :loading="loading"
          class="secondary ma-2"
          @click="schedule"
        >
          <v-icon left>mdi-calendar-arrow-right</v-icon>
          Schedule
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
export default {
  name: "ScheduleWorkItemDialog",
  props: {
    show: {
      type: Boolean,
      required: true
    },
    workItem: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      date: null,
      loading: false,
    }
  },
  mounted() {
    this.date = (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substring(0, 10)
  },
  methods: {
    async schedule() {
      try {
        this.loading = true;

        await this.$store.dispatch("WorklistModule/hideWorkItemUntil", {
          taskId: this.workItem._id,
          hideUntil: this.date
        });

        this.showDialog = false;
      } finally {
        this.loading = false;
      }
    },
    disablePastDates(value) {
      return value > new Date().toISOString().substring(0, 10)
    },
  },
  computed: {
    showDialog: {
      get() {
        return this.show;
      },
      set(value) {
        if (!value)
          this.$emit("closeDialog");
      }
    },
    selectedDateIsToday() {
      return this.date === new Date().toISOString().substring(0, 10);
    }
  }
}
</script>

<style scoped>

</style>
