﻿<template>
  <v-dialog v-model="visible" max-width="30%" persistent>
    <v-card>
      <v-card-title>Move asset from {{ currentWorkItemName }}</v-card-title>
      <v-card-text>
        <HierarchyWithSearch
          @cancel="closeDialog"
          @itemClicked="setSelectedMoveAssetDestination"
          :items="departmentChildren"
        ></HierarchyWithSearch>
      </v-card-text>
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn color="primary" text @click="closeDialog" :disabled="moveAssetPending">
          Cancel
        </v-btn>
        <v-btn
          :loading="moveAssetPending"
          :disabled="moveAssetPending || !currentSelectedDestinationId"
          :color="invalidAssetMove ? 'error' : 'secondary'"
          @click="assetMove"
        >
          <v-icon left>{{ invalidAssetMove ? 'mdi-alert-circle' : 'mdi-arrow-right' }}</v-icon>
          {{ invalidAssetMove ? "Can't move to same department" : "Move" }}
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>
<script>
import HierarchyWithSearch from "@/components/HierarchyWithSearch";
import axios from "@/axios-client";
export default {
  name: "NewSubscriptionMoveAssetDialog",
  components: {HierarchyWithSearch},
  props: ["visible", "item"],
  data() {
    return {
      moveAssetPending: false,
      invalidAssetMove: false,
      currentSelectedDestinationId: null
    }
  },
  methods: {
    async assetMove() {
      this.moveAssetPending = true;

      try {
        await axios.post("/api/worklist/new-subscription/move", {
          serialNumber: this.item.serialNumber,
          DepartmentId: this.currentSelectedDestinationId
        });

        await this.$store.dispatch("audit", {
          source: "datasource",
          entityId: this.item.serialNumber,
          message: "Move simcard to department",
          oldValue: this.item.workItem.aktorId,
          newValue: this.currentSelectedDestinationId
        });

        await this.completeTask(this.item.workItem);
        await this.$store.dispatch("WorklistModule/retrieveWorkItems", {worklistType: "NewSubscription"});
      } catch {
        // It is safe to assume that this will always be the error if any
        this.$eventBus.$emit("alert",
          {
            text: `Asset was either not found or can't be moved to department ${this.currentSelectedDestinationId}, as it's under a different main office.`,
            type: "error"
          });
      } finally {
        this.moveAssetPending = false;
        this.moveAssetDialog = false;
      }
    },
    setSelectedMoveAssetDestination(id) {
      this.invalidMove = id[0] === this.item.workItem.aktorId;
      this.currentSelectedDestinationId = parseInt(id);
    },
    closeDialog() {
      this.$emit("closeMoveAssetDialog");
    }
  },
  computed: {
    departmentChildren() {
      return this.item?.department?.children ?? [];
    },
    currentWorkItemName() {
      return this.item.customerName;
    }
  }
}
</script>

<style scoped>

</style>
