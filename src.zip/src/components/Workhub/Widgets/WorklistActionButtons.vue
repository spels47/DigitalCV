﻿<template>
  <v-row no-gutters>
  <v-col cols="4">
    <TooltipIconButton
      v-if="!item.workItem.assignedUser"
      tooltip="Assign"
      icon="mdi-plus-circle"
      :loading="!!loading"
      @clicked="assign(item)"
    ></TooltipIconButton>
    <TooltipIconButton
      v-if="item.workItem.assignedUser && item.workItem.dateCompleted === null"
      tooltip="Unassign"
      icon="mdi-minus-circle"
      color="warning"
      :loading="!!loading"
      @clicked="unassign(item)"
    ></TooltipIconButton>
  </v-col>
    <v-col cols="4">
    <TooltipIconButton
      v-if="item.workItem.assignedUser === username"
      icon="mdi-calendar-arrow-right"
      color="primary"
      tooltip="Remind me later"
      :loading="!!loading"
      @clicked="scheduleWorkItem(item)"
    ></TooltipIconButton>
    </v-col>
    <v-col cols="4">
    <TooltipIconButton
      v-if="item.workItem.assignedUser === null || item.workItem.assignedUser === '' || item.workItem.assignedUser === username"
      icon="mdi-debug-step-over"
      color="error"
      tooltip="Ignore"
      :loading="!!loading"
      @clicked="ignoreWorkItem(item)"
    ></TooltipIconButton>
    </v-col>
    <ConfirmDialog ref="confirmIgnore"></ConfirmDialog>
    <ScheduleWorkItemDialog
      :show="showScheduleDialog"
      :work-item="scheduledWorkItem"
      @closeDialog="showScheduleDialog = false"
    ></ScheduleWorkItemDialog>
  </v-row>
</template>
<script>
import TooltipIconButton from "@/components/buttons/TooltipIconButton";
import ConfirmDialog from "@/components/widgets/dialogs/ConfirmDialog";
import ScheduleWorkItemDialog from "@/components/Workhub/Widgets/ScheduleWorkItemDialog";
export default {
  name: "WorklistActionButtons",
  props: ["item"],
  components: {TooltipIconButton, ScheduleWorkItemDialog, ConfirmDialog},
  data() {
    return {
    showScheduleDialog: false,
      scheduledWorkItem: {}
    }
  },
  methods: {
    scheduleWorkItem({ workItem }) {
      this.scheduledWorkItem = workItem;
      this.showScheduleDialog = true;
    },
    async ignoreWorkItem(item) {
      const confirmed = await this.$refs.confirmIgnore.open('Ignore work-item?', 'Are you sure you want to ignore this work-item?',
        {
          width: 500,
          confirmLabel: `Confirm`,
        }
      );
      if (confirmed)
        await this.$store.dispatch("WorklistModule/ignoreWorkItem", item.workItem._id);
    },
    async unassign(item) {
      if (item.workItem.assignedUser === this.username || this.roles.WORKHUB_ADMIN) {
        await this.$store.dispatch("WorklistModule/unassignWorklistItem", {
          id: item.workItem._id,
          username: item.workItem.assignedUser
        });
      }
    },
    async assign(item) {
      await this.$store.dispatch("WorklistModule/assignWorklistItem", { id: item.workItem._id});
    },
  },
  computed: {
    username() {
      return this.$store.getters.currentUser?.username;
    },
    loading() {
      return this.$store.state.WorklistModule.loading;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
  }
}
</script>

<style scoped>

</style>
