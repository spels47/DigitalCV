﻿<template>
  <v-data-table
    v-if="visible"
    :headers="addCustomFiltersToHeaders()"
    :items="workItems"
    :loading="isLoading"
    :search="search"
  >
    <template v-slot:item.name="{ item }">
      <WrappedTextWithTooltip
        :text="item.name"
        :clickable="true"
        @clicked="gotoCustomer(item)"
      ></WrappedTextWithTooltip>
    </template>
    <template v-slot:item.aktorId="{item}">
      <v-chip outlined>{{ item.workItem.aktorId }}</v-chip>
    </template>
    <template v-slot:item.erpCustomerId="{item}">
      <v-chip outlined>{{ item.erpCustomerId }}</v-chip>
    </template>
    <template v-slot:item.workItem.assignedUser="{ item }">
      <span>{{ trimUsername(item.workItem.assignedUser) }}</span>
    </template>
    <template v-slot:item.requestedByUser="{ item }">
      <span>{{ trimUsername(item.requestedByUser) }}</span>
    </template>
    <template v-slot:item.workItem.dateAdded="{item}">
      <span>{{ item.workItem.dateAdded | ntzDate }}</span>
    </template>
    <template v-slot:item.workItem.dateCompleted="{item}">
      <span>{{ item.workItem.dateCompleted | ntzDate }}</span>
    </template>
    <template v-slot:item.performTask="{ item }">
      <TooltipIconButton
        v-if="item.workItem.assignedUser === username && applicableForTsUi(item)"
        icon="mdi-arrow-right-circle"
        tooltip="Task specific UI"
        color="success"
        @clicked="performTaskAction(item)"
      ></TooltipIconButton>

      <TooltipIconButton
        v-else-if="item.workItem.assignedUser === username"
        tooltip="Uncomplete"
        icon="mdi-close-circle"
        color="error"
        @clicked="cancelComplete(item)"
      ></TooltipIconButton>
    </template>
    <template v-slot:item.SIMICC="{item}">
      <v-chip outlined>{{ item.sIMICC }}</v-chip>
    </template>
    <template v-slot:item.department="{ item }">
      <span>{{ item.department.name }}</span>
    </template>
  </v-data-table>
</template>
<script>
import WrappedTextWithTooltip from "@/components/text/WrappedTextWithTooltip";
import TooltipIconButton from "@/components/buttons/TooltipIconButton";

export default {
  name: "CompletedWorklistTable",
  props: ["visible", "checkMyTasks", "search", "filter"],
  components: { TooltipIconButton, WrappedTextWithTooltip },
  data() {
    return {
      loading: false
    }
  },
  methods: {
    async cancelComplete(item) {
      await this.$store.dispatch("WorklistModule/cancelWorklistItem", { id: item.workItem._id, });
    },
    applicableForTsUi({ workItem }) {
      return (workItem.worklistType !== "Swap" && workItem.worklistType !== "ProductOrdered" && workItem.worklistType !== "NewSubscription") && workItem.dateCompleted !== null;
    },
    gotoCustomer(item) {
      this.$router.push({ path: `/customer/${item.workItem.aktorId}?activeTab=${this.$utils.getDefaultTab(this.defaultTable)}` });
    },
    trimUsername(name) {
      return this.$utils.trimUsername(name);
    },
    async performTaskAction(item) {
      await this.$router.push({ name: "taskSpecificUi", params: { aktorId: item.workItem.aktorId, workItem: item.workItem } });
    },
    addCustomFiltersToHeaders() {
      let headers = this.getHeaders;
      headers[headers.length - 1].filter = this.filter
      return headers;
    },
  },
  computed: {
    worklistType() {
      return this.$store.state.WorklistModule.worklistType;
    },
    username() {
      return this.$store.getters.currentUser?.username;
    },
    isLoading() {
      return this.$store.state.WorklistModule.loading;
    },
    defaultTable() {
      return this.$store.state.userSettings.defaultTable;
    },
    workItems() {
      return this.$store.state.WorklistModule.workItems;
    },
    getHeaders() {
      let headers = [];
      switch (this.worklistType) {
        case 'WelcomeCall':
        default:
          headers = [
            { text: "Customer", value: "customerName", filterable: true },
            { text: "Country", value: "country", align: "center" },
          ];
          break;
        case 'RenewalCall':
          headers = [
            { text: "Customer", value: "customerName" },
            { text: "ERP Customer ID", value: "erpCustomerId", align: "center" },
          ];
          break;
        case 'YellowFlaggedCall':
          headers = [
            { text: "Customer", value: "customerName" },
            { text: "ERP Customer ID", value: "erpCustomerId", align: "center" },
          ];
          break;
        case 'ChurnPreventionCall':
          headers = [
            { text: "Customer", value: "customerName" },
            { text: "Country", value: "customerCountry", align: "center" },
          ];
          break;
        case 'ProductOrdered':
          headers = [
            { text: "Customer", value: "customerName", filterable: true },
            { text: "Country", value: "country", align: "center" },
          ];
          break;
        case 'NewSubscription':
          headers = [
            { text: "Customer name", value: "customerName" },
            { text: "Customer ID", value: "erpCustomerId" },
            { text: "Subscription no.", value: "contractNumber" },
            { text: "Serial number", value: "serialNumber" },
            { text: "Unit-type", value: "objectType", align: "center" },
            { text: "Department", value: "department", align: "center" },
            { text: "Reg-no", value: "licensePlateNumber", align: "center" },
          ];
          break;
        case 'JasperStateNotOk':
          headers = [
            { text: "SIMICC", value: "simicc", filterable: true },
            { text: "Unit Found", value: "unitFound", align: "center" },
            { text: "Status", value: "status", align: "center" },
            { text: "Status Message", value: "statusMessage", align: "center" },
          ];
          break;
        case 'Swap':
          headers = [
            { text: "Customer", value: "customerName", filterable: true },
            { text: "Customer ID", value: "erpCustomerId" },
            { text: "Country", value: "country", align: "center" },
            { text: "Current SN", value: "serialNumber", align: "center", filterable: true },
            { text: "Swap Reason", value: "swapReason", align: "center" },
            { text: "Requested By", value: "requestedByUser", align: "center" },
          ];
        break;
        case 'ReturnHandling':
          headers = [
            { text: "Customer", value: "customerName", filterable: true },
            { text: "Customer ID", value: "erpCustomerId" },
            { text: "Country", value: "country", align: "center" },
            { text: "Task created", value: "workItem.dateAdded", align: "center", filterable: true },
            { text: "Serial number", value: "serialNumber", align: "center", filterable: true },
            { text: "Type description", value: "typeDescription", align: "center" },
          ];
          break;
      }
      headers.push({ text: "Assignee", value: "workItem.assignedUser", align: "center", filterable: true });
      headers.push({ text: "Task created", value: "workItem.dateAdded", align: "center", filterable: true });
      headers.push({ text: "Completed Date", value: "workItem.dateCompleted", align: "center", sortable: true });
      if(this.worklistType != 'Swap') headers.push({ text: "Edit task", value: "performTask" });
      return headers;
    },
  },
}
</script>

<style scoped>

</style>
