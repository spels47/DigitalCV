<template>
  <div>
    <template v-for="feature in compiledFeatures">
      <v-tooltip bottom :key="feature.id">
        <template v-slot:activator="{ on }">
          <v-icon v-if="simplified" v-on="on" medium color="primary">{{feature.icon}}</v-icon>
          <v-chip pill small v-if="!simplified" v-on="on" class="ma-2"> {{feature.text}} </v-chip>
        </template>
        <span v-if="simplified">{{feature.text}}</span>
        <span v-if="!simplified">{{feature.id}}</span>
      </v-tooltip>
    </template>
  </div>
</template>

<script>
  export default {
    name: "FeatureConfiguration",
    props: {
      features: Array,
      simplified: Boolean
    },
    computed:{
      compiledFeatures(){
        if(!this.features) return []
        let data = []

        let insertIfUnique = (item) => {
          if(data.some(x => x.id === item.id)){
            return
          }
          data.push(item)
        }
        this.features.forEach(feature => {
          if (this.simplified) {
            let item = this.mapping.find(x => x.simplifies.includes(feature))
            if(!item) return // Unmapped feature, drop in simplified view
            insertIfUnique(item)
          } else {
            let item = this.mapping.find(x => x.id === feature)
            if(!item) return // Unmapped feature TODO: Should probably show these in expanded view
            insertIfUnique(item)
          }
        })

        if(this.simplified) return this.simplifyToMax4Items(data)
        return data;
      }
    },
    methods: {
      simplifyToMax4Items(data){
        let result = [];
        let triplogFeature = data.find(x => x.id === "triplog");
        let eqFeature = data.find(x => x.id === "equipment");

        if(triplogFeature){
          result.push(triplogFeature);
          let drivingBehaviour = data.find(x => x.id === "dribeh");
          let fleetManagement = data.find(x => x.id === "fleetmanagement");
          let tollCharge = data.find(x => x.id === "tollcharge");
          if(drivingBehaviour) result.push(drivingBehaviour);
          if(fleetManagement) result.push(fleetManagement);
          if(tollCharge) result.push(tollCharge);
          for (let i = 0; i < data.length; i++) {
            if(result.length === 4) break;
            const compiledFeature = data[i];
            if(result.some(x => x.id === compiledFeature.id)) continue;
            result.push(compiledFeature);
          }
          return result;
        }
        else if(eqFeature){
          result.push(eqFeature);
          let usageLog = data.find(x => x.id === "usage");
          let updatePosFrequency = data.find(x => x.id === "equipmentreportfrequency");
          if(usageLog) result.push(usageLog);
          if(updatePosFrequency) result.push(updatePosFrequency);
          for (let i = 0; i < data.length; i++) {
            if(result.length === 4) break;
            const compiledFeature = data[i];
            if(result.some(x => x.id === compiledFeature.id)) continue;
            result.push(compiledFeature);
          }
          return result;
        }
        else return data.slice(0, 4);
      }
    },
    data: function () {
      return {
        mapping: [
          // Simplified view:
          { id: 'usage', simplifies: ['301', '312', '313', '314', '321', '322', '363'], text: 'Usage log', icon: 'mdi-math-log' },
          { id: 'triplog', simplifies: ['1000'], text: 'Triplog', icon: 'mdi-car' },
          { id: 'dribeh', simplifies: ['1400', '1401', '1402'], text: 'Driving behaviour', icon: 'mdi-podium-gold' },
          { id: 'fleetmanagement', simplifies: ['2000'], text: 'Fleet management', icon: 'mdi-map' },
          { id: 'equipment', simplifies: ['3000'], text: 'Equipment', icon: 'mdi-crane' },
          { id: 'dlg', simplifies: ['10000'], text: 'Data storage (DLG)', icon: 'mdi-car-info' },
          { id: 'mini', simplifies: ['mini'], text: 'Mini', icon: 'mdi-hockey-puck' },
          { id: 'nxbuddy', simplifies: ['5000'], text: 'NX Buddy', icon: 'mdi-ufo-outline' },
          { id: 'rfid', simplifies: ['130', '134', '143', '148', '149', '150', '151', '152', '153', '154'], text: 'Id tag/RFID', icon: 'mdi-identifier' },
          { id: 'tollcharge', simplifies: ['4100'], text: 'TollCharge', icon: 'mdi-boom-gate' },
          { id: 'equipmentreportfrequency', simplifies: ['316', '319', '318', '317'], text: 'Equipment Control - Report either every 4, 6, 8 or 12 hours', icon: 'mdi-alarm' },

          // Triplog feature list (not in simplified view):
          { id:"100", simplifies: [], text:"Triplog - Basic configuration", icon: "mdi-car"},
          { id:"102", simplifies: [], text:"Triplog - F&P Approved Geofence", icon: "mdi-car"},
          { id:"103", simplifies: [], text:"Triplog - Use ADC input to end trip", icon: "mdi-car"},
          { id:"110", simplifies: [], text:"Triplog - Report position every one minute", icon: "mdi-car"},
          { id:"111", simplifies: [], text:"Triplog - Report position every 30 seconds", icon: "mdi-car"},
          { id:"112", simplifies: [], text:"Triplog - Report position every 5 seconds", icon: "mdi-car"},
          { id:"113", simplifies: [], text:"Triplog - Report position every 1 seconds", icon: "mdi-car"},
          { id:"120", simplifies: [], text:"Triplog - RC - Use RC to end trip", icon: "mdi-car"},
          { id:"121", simplifies: [], text:"Triplog - RC - Activate Stealth mode (ID req.)", icon: "mdi-car"},
          { id:"130", simplifies: [], text:"Triplog - ID-TAG - Active map driver recog.", icon: "mdi-car"},
          { id:"134", simplifies: [], text:"Triplog - ID-TAG - Driver recog. on trips", icon: "mdi-car"},
          { id:"140", simplifies: [], text:"Triplog - Low speed (10km/h - 100m)  ", icon: "mdi-car"},
          { id:"141", simplifies: [], text:"Triplog - Low power mode (sleep mode 60 mins) ", icon: "mdi-car"},
          { id:"142", simplifies: [], text:"Triplog - Powersave on power disconnect", icon: "mdi-car"},
          { id:"143", simplifies: [], text:"Triplog - RFiD Driver Req", icon: "mdi-car"},
          { id:"144", simplifies: [], text:"Triplog - Charging voltage dependent triplog", icon: "mdi-car"},
          { id:"145", simplifies: [], text:"Triplog - Quick Drop", icon: "mdi-car"},
          { id:"146", simplifies: [], text:"Triplog - Triplog w/ignition", icon: "mdi-car"},
          { id:"147", simplifies: [], text:"Triplog - Very Low Speed 5km/100m", icon: "mdi-car"},
          { id:"148", simplifies: [], text:"Triplog - RFiD Reader 2 - Beep no driver", icon: "mdi-car"},
          { id:"149", simplifies: [], text:"Triplog - RFiD Reader 2 - Beep - EM4100", icon: "mdi-car"},
          { id:"150", simplifies: [], text:"Triplog - RFiD Reader 2 - Beep - MIFARE", icon: "mdi-car"},
          { id:"151", simplifies: [], text:"Triplog - RFiD 2.0", icon: "mdi-car"},
          { id:"152", simplifies: [], text:"Triplog - RFiD 2.0 auto logout", icon: "mdi-car"},
          { id:"153", simplifies: [], text:"Triplog - RFiD 2.0 manual logout", icon: "mdi-car"},
          { id:"154", simplifies: [], text:"Triplog - RFID 2.0 MIFARE only", icon: "mdi-car"},
          { id:"155", simplifies: [], text:"Triplog - RFID 2.0 EM only", icon:"mdi-car"},
          { id:"180", simplifies: [], text:"Triplog - TollRoad suggestion", icon: "mdi-car"},
          { id:"200", simplifies: [], text:"Fleet - Basic Fleet Management configuration", icon: "mdi-car"},
          { id:"210", simplifies: [], text:"Fleet - Active fleet monitoring basic config", icon: "mdi-car"},
          { id:"211", simplifies: [], text:"Fleet - Turn off GPS Logging, set unit in alarm", icon: "mdi-car"},
          { id:"212", simplifies: [], text:"Fleet - Power save mode, alarm off, awake every hour  ", icon: "mdi-car"},
          { id:"213", simplifies: [], text:"Fleet - Back to active logging mode", icon: "mdi-car"},
          { id:"300", simplifies: [], text:"Equipment Control - Basic configuration", icon: "mdi-car"},
          { id:"301", simplifies: [], text:"Equipment Control Usagelog configuration", icon: "mdi-car"},
          { id:"302", simplifies: [], text:"Equipment Control Temp/Tilt configuration", icon: "mdi-car"},
          { id:"303", simplifies: [], text:"Equipment Control Tank monitoring", icon: "mdi-car"},
          { id:"312", simplifies: [], text:"Equipment Control - Usage report with ignition", icon: "mdi-car"},
          { id:"313", simplifies: [], text:"Equipment Control - Usage report with movement", icon: "mdi-car"},
          { id:"314", simplifies: [], text:"Equipment Control - Door and Geofence alarm (Usagelog)  ", icon: "mdi-car"},
          { id:"315", simplifies: [], text:"Equipment Control - Update position every 15 min during movement", icon: "mdi-car"},
          { id:"316", simplifies: [], text:"Equipment Control - Report every 12 hours", icon: "mdi-alarm"},
          { id:"317", simplifies: [], text:"Equipment Control - 8 hour sleep time while moving", icon: "mdi-alarm"},
          { id:"318", simplifies: [], text:"Equipment Control - Report pos 4 hours", icon: "mdi-alarm"},
          { id:"319", simplifies: [], text:"Equipment Control - Report pos 6 hours", icon: "mdi-alarm"},
          { id:"320", simplifies: [], text:"Equipment Control - Report realtime positions", icon: "mdi-car"},
          { id:"321", simplifies: [], text:"Equipment Control - Abax4 - Usagelog - 12V", icon: "mdi-car"},
          { id:"322", simplifies: [], text:"Equipment Control - Abax4 - Usagelog - 24V", icon: "mdi-car"},
          { id:"330", simplifies: [], text:"Equipment Control - Temperature Monitoring", icon: "mdi-car"},
          { id:"350", simplifies: [], text:"Equipment Control - Low Power Mode", icon: "mdi-car"},
          { id:"363", simplifies: [], text:"Equipment Control - Multiple usage logs", icon: "mdi-car"},
          { id:"380", simplifies: [], text:"Equipment Control - Service Notification", icon: "mdi-car"},
          { id:"390", simplifies: [], text:"Equipment Control - OEM (Mixed fleet)", icon: "mdi-car"},
          { id:"500", simplifies: [], text:"NX-buddy - Basic configuration", icon: "mdi-car"},
          { id:"600", simplifies: [], text:"Assistant button - Basic configuration", icon: "mdi-car"},
          { id:"800", simplifies: [], text:"Cloud Ingress - Kafka", icon: "mdi-car"},
          { id:"1000", simplifies: [], text:"Triplog interface", icon: "mdi-car"},
          { id:"1100", simplifies: [], text:"Triplog - CarAdmin module", icon: "mdi-car"},
          { id:"1200", simplifies: [], text:"Triplog - App with tracking", icon: "mdi-car"},
          { id:"1300", simplifies: [], text:"Triplog - Tags", icon: "mdi-car"},
          { id:"1301", simplifies: [], text:"Addon - Securitas CarAlarm forward to Communicator", icon: "mdi-car"},
          { id:"1400", simplifies: [], text:"Triplog - Driving behaviour", icon: "mdi-car"},
          { id:"1401", simplifies: [], text:"Triplog - Driving behaviour Legacy", icon: "mdi-car"},
          { id:"1402", simplifies: [], text:"Triplog - Driving behaviour no UI", icon: "mdi-car"},
          { id:"2000", simplifies: [], text:"Fleet Management", icon: "mdi-car"},
          { id:"3000", simplifies: [], text:"Equipment Control interface", icon: "mdi-car"},
          { id:"4000", simplifies: [], text:"TollRoad Admin", icon: "mdi-car"},
          { id:"4100", simplifies: [], text:"TollCharge", icon: "boom-gate"},
          { id:"5000", simplifies: [], text:"NX-Buddy", icon: "mdi-car"},
          { id:"6000", simplifies: [], text:"Assistant button", icon: "mdi-car"},
          { id:"7000", simplifies: [], text:"Route4 access", icon: "mdi-car"},
          { id:"8000", simplifies: [], text:"TrackAndTrace", icon: "mdi-car"},
          { id:"8002", simplifies: [], text:"ABAX EQ-ATM", icon: "mdi-car"},
          { id:"9000", simplifies: [], text:"ABAX Total", icon: "mdi-car"},
          { id:"10000", simplifies: [], text:"Datastorage Warranty", icon: "mdi-car-info"},
          { id:"10100", simplifies: [], text:"Privacy Assistant", icon: "mdi-car"},
          { id:"11000", simplifies: [], text:"24/7 Support", icon: "mdi-car"},
          { id:"12000", simplifies: [], text:"Reports - Report Package", icon: "mdi-car"},
          { id:"12001", simplifies: [], text:"Reports - Fiscal report", icon: "mdi-car"},
          { id:"12100", simplifies: [], text:"Reports - Scheduled Reports", icon: "mdi-car"},
          { id:"13000", simplifies: [], text:"ABAX Customer API", icon: "mdi-car"},
          { id:"14000", simplifies: [], text:"ABAX Lifetime Warranty", icon: "mdi-car"},
          { id:"15000", simplifies: [], text:"Insurance Integration", icon: "mdi-shield-car"},
        ]
      }
    }
  }
</script>

<style scoped>

</style>
