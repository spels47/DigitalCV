<template>
  <v-container fluid>
  <v-card>
    <v-tabs background-color="black" :value="getIndexedTabValue(activeTab.id)" dark v-if="activeTab">
      <v-tab v-for="tab in availableTabs" :data-cy="tab.data-cy" :key="tab.id" @click="setTabQuery(tab.id)">
        {{ tab.text }}
      </v-tab>
      <v-spacer></v-spacer>
      <v-menu right background-color="black" offset-y :close-on-content-click="true">
        
      </v-menu>
      <CountrySelector></CountrySelector>
    </v-tabs>
    <v-tabs-items :value="activeTab.id">
      <v-tab-item v-for="tab in availableTabs" :key="tab.id" :value="tab.id">
          <SearchForCustomerDialog v-if="addCustomerDialogOpen" :title="'Search to add Customer'" @confirm="addCustomer" @cancel="addCustomerDialogOpen = false"></SearchForCustomerDialog>
          <v-card-title>
            <v-btn :class="!checkShowCompleted ? 'secondary' : 'primary'" @click="checkShowCompleted = false;">Active</v-btn>
            <v-btn :class="checkShowCompleted ? 'secondary' : 'primary'" class="ml-2" @click="checkShowCompleted = true;">Completed</v-btn>
            <v-spacer></v-spacer>
            <v-text-field class="mt-0 pt-0" v-model="search" append-icon="mdi-magnify" label="Search" single-line hide-details @input="persist"></v-text-field>
          </v-card-title>
          <MyCompletedSwapsList :visible="checkShowCompleted" :search="search" :filter="filter"/>
          <MySwapsList v-if="!checkShowCompleted" :search="search" :filter="filter"/>
      </v-tab-item>
    </v-tabs-items>
  </v-card>
  </v-container>
</template>

<script>
import MyCompletedSwapsList from "@/components/MySwaps/MyCompletedSwapsList";
import SearchForCustomerDialog from "@/components/widgets/dialogs/SearchForCustomerDialog";
import MySwapsList from "@/components/MySwaps/MySwapsList";
import CountrySelector from "@/components/widgets/CountrySelector";

export default {
  name: "MySwaps",
  components: { CountrySelector, MySwapsList, SearchForCustomerDialog, MyCompletedSwapsList },
  data() {
    return {
      checkShowCompleted: false,
      addCustomerDialogOpen: false,
      search: "",
      selectedTab: {},
      countrySelector: [
        { text: "All", value: "ALL" },
        { text: "Norway", value: "NO" },
        { text: "Sweden", value: "SE" },
        { text: "Finland", value: "FI" },
        { text: "Denmark", value: "DK" },
        { text: "UK", value: "GB" },
        { text: "France", value: "FR" },
        { text: "Belgium", value: "BE" },
        { text: "Netherlands", value: "NL" },
        { text: "Poland", value: "PL" }
      ]
    };
  },
  async mounted() {
    await this.$store.dispatch("waitForRolesLoaded");
    const query = parseInt(this.$route.query?.tab);
    if (!this.availableTabs.some(tab => tab.id === query)) {
      let firstAvailableId = Math.min(...this.availableTabs.map(x => x.id));
      this.setTabQuery(firstAvailableId);
      this.selectedTab = this.availableTabs.find(tab => tab.id === firstAvailableId);
    }
    else{
      this.selectedTab = this.availableTabs.find(tab => tab.id === query);
    }
    if(localStorage.getItem("mySwapsSearchFilter") !== null) {
      let searchProperties = JSON.parse(localStorage.getItem("mySwapsSearchFilter"));
      this.search = searchProperties.search ?? "";
    }
  },
  methods: {
    persist() {
      const filters = {
        search: this.search
      };
      localStorage.setItem('mySwapsSearchFilter', JSON.stringify(filters))
    },
    async fetchMySwaps() {
      await this.$store.dispatch("MySwapsModule/retrieveMySwaps", {state: "active"});
    },
    async fetchMyCompletedSwaps() {
      await this.$store.dispatch("MySwapsModule/retrieveMySwaps", {state: "completed"});
    },
    setTabQuery(id) {
      this.selectedTab = this.availableTabs.find(x => x.id === id);
      this.checkShowCompleted = false;
      this.$store.dispatch("setUrlParameter", { name: "tab", value: id });
    },
    getIndexedTabValue(id) {
      // v-tabs always starts from 0 on the first tab. so we need to find the index of the element by id :/
      return this.availableTabs.findIndex(x => x.id === id);
    },
    filter(value, search, item) {
      if(this.checkShowCompleted){
        return this.filter_country(item) && item.dateCompleted !== null
      }
      else{
        return this.filter_showHidden(item) && this.filter_hideIgnored(item) && this.filter_country(item) && item.dateCompleted === null;
      }
    },
    filter_country(item) {
      if(this.defaultCountry === "ALL") return true;
      return this.defaultCountry === item.country;

    },
    filter_showHidden(item) {
      if((item.hiddenUntil === null || Date.parse(item.hiddenUntil) < Date.now())){
        return true;
      }
      return item.assignedUser === this.username && (item.hiddenUntil !== null && Date.parse(item.hiddenUntil) > Date.now());
    },
    filter_hideIgnored(item) {
      if(item.ignored) return false
      return true;
    }
  },
  watch: {
    checkShowCompleted: {
      deep: true,
      async handler() {
        if(this.checkShowCompleted) {
          await this.fetchMyCompletedSwaps();
        }
      }
    },
    selectedTab: {
      deep:true,
      async handler() {
        await this.fetchMySwaps();
      }
    }
  },
  computed: {
    activeTab() {
      return this.selectedTab;
    },
    availableTabs() {
      let tabs = [
        { id: 0, text: "My Swaps", "data-cy": "workhub-my-swaps-tab", worklistType: "Swap", userRight: "DATASOURCE_SWAP" }
      ];
      tabs = tabs.filter(tab => tab.userRight === "" || this.roles[tab.userRight]);
      return tabs;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    username() {
    return this.$store.getters.currentUser?.username;
    },
    defaultCountry() {
      return this.$store.state.userSettings.defaultCountry;
    }
  }
};
</script>

<style></style>