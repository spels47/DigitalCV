<template>
  <div>
    <v-data-table
      v-if="visible"
      :headers="addCustomFiltersToHeaders()"
      :items="myCompletedSwaps"
      :loading="isLoading"
      item-key="_id"
      :search="search"
      :footer-props="{ 'items-per-page-options': (items_per_page = [10, 20, 50]) }"
    >
      <template v-slot:item.aktorId="{item}">
        <v-chip outlined>{{ item.aktorId }}</v-chip>
      </template>
      <template v-slot:item.erpCustomerId="{item}">
        <v-chip outlined>{{ item.erpCustomerId }}</v-chip>
      </template>
      <template v-slot:item.requestedByUser="{ item }">
        <span>{{ trimUsername(item.requestedByUser) }}</span>
      </template>
      <template v-slot:item.assignedUser="{ item }">
        <span>{{ trimUsername(item.assignedUser) }}</span>
      </template>
      <template v-slot:item.additionalInformation="{ item }">
          <TooltipIconButton
            :should-warn="item.otherInformation !== ''"
            icon="mdi-open-in-app"
            color="primary lighten-1"
            tooltip="Click to view additional relevant information."
            @clicked="showAdditionalSwapInfo(item)"
          ></TooltipIconButton>
        </template>
      <template v-slot:item.dateAdded="{item}">
        <span>{{ item.dateAdded | ntzDate }}</span>
      </template>
      <template v-slot:item.dateCompleted="{item}">
        <span>{{ item.dateCompleted | ntzDate }}</span>
      </template>
      <template v-slot:item.ignored="{item}">
        <TooltipIconButton
             v-if="!item.ignored"
            icon="mdi-check-circle"
            color="success"
            tooltip="Swap was executed by logistics"
          ></TooltipIconButton>
          <TooltipIconButton
            v-if="item.ignored"
            icon="mdi-close-circle"
            color="error"
            tooltip="Swap was declined by logistics"
          ></TooltipIconButton>
      </template>
    </v-data-table>

    <AdditionalSwapInfoDialog
        :swap-work-item="selectedItem"
        :show="showSwapAdditionalInformation"
        @close="showSwapAdditionalInformation = false"
    ></AdditionalSwapInfoDialog>
  </div>
</template>
<script>
import TooltipIconButton from "@/components/buttons/TooltipIconButton";
import AdditionalSwapInfoDialog from "@/components/dialogs/AdditionalSwapInfoDialog";

export default {
  name: "MyCompletedSwapsList",
  props: ["search", "filter", "visible"],
  components: { TooltipIconButton, AdditionalSwapInfoDialog },
  data() {
    return {
      selectedItem: {},
      showSwapAdditionalInformation: false,
      headers: [
            { text: "Customer", value: "customerName", filterable: true },
            { text: "Customer ID", value: "erpCustomerId" },
            { text: "Country", value: "country", align: "center" },
            { text: "Current SN", value: "serialNumber", align: "center", filterable: true },
            { text: "Swap Reason", value: "swapReason", align: "center" },
            { text: "Requested By", value: "requestedByUser", align: "center" },
            { text: "Completed By", value: "assignedUser", align: "center", filterable: true },
            { text: "Ticket ID", value: "ticketId", align: "center" },
            { text: "Additional information", value: "additionalInformation", align: "center" },
            { text: "Task created", value: "dateAdded", align: "center", filterable: true },
            { text: "Completed Date", value: "dateCompleted", align: "center", sortable: true },
            { text: "Swap executed", value: "ignored", align: "center", sortable: true }
          ]
    }
  },
  methods: {
    trimUsername(name) {
      return this.$utils.trimUsername(name);
    },
    addCustomFiltersToHeaders() {
      let headers = this.headers;
      headers[headers.length - 1].filter = this.filter
      return headers;
    },
    showAdditionalSwapInfo(item) {
      this.selectedItem = item;
      this.showSwapAdditionalInformation = true;
    },
  },
  computed: {
    username() {
      return this.$store.getters.currentUser?.username;
    },
    isLoading() {
      return this.$store.state.MySwapsModule.loading;
    },
    myCompletedSwaps() {
      return this.$store.state.MySwapsModule.myCompletedSwaps;
    }
  }
}
</script>

<style scoped>

</style>
