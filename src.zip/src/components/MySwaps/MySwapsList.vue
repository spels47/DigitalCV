<template>
  <div>

    <v-data-table
      :headers="addCustomFiltersToHeaders()"
      :items="mySwaps"
      :search="search"
      item-key="_id"
      :loading="isLoading"
      :footer-props="{ 'items-per-page-options': (items_per_page = [10, 20, 50]) }"
    >
      <template v-slot:item.customerName="{ item }">
        <WrappedTextWithTooltip
          :text="item.customerName"
          :clickable="true"
          @clicked="gotoCustomer(item)"
        ></WrappedTextWithTooltip>
      </template>
      <template v-slot:item.requestedByUser="{ item }">
        <span>{{ trimUsername(item.requestedByUser) }}</span>
      </template>
      <template v-slot:item.actions="{item}">
        <MySwapActions :item="item"></MySwapActions>
      </template>
      <template v-slot:item.dateAdded="{item}">
        <div>
          {{ item.dateAdded | ntzDate }}
        </div>
      </template>
      <template v-slot:item.unitType="{ item }">
        <v-chip
          small
          outlined
        >
          <WrappedTextWithTooltip :text="item.unitType !== 0 ? item.unitType.replaceAll('_', ' ').trim() : 'Unknown unit type'" :max-length="15"></WrappedTextWithTooltip>
        </v-chip>
      </template>
      <template v-slot:item.serialNumber="{ item }">
        <v-chip
          small
          outlined
          class="cursor-pointer"
          @click="gotoDatasource(item)"
        >
          {{ item.serialNumber }}
        </v-chip>
      </template>
      <template v-slot:item.confirmedAddress="{ item }">
        <WrappedTextWithTooltip :text="item.confirmedAddress" :max-length="15"></WrappedTextWithTooltip>
      </template>
      <template v-slot:item.additionalInformation="{ item }">
        <TooltipIconButton
          :should-warn="item.otherInformation !== ''"
          icon="mdi-open-in-app"
          color="primary lighten-1"
          tooltip="Click to view additional relevant information."
          @clicked="showAdditionalSwapInfo(item)"
        ></TooltipIconButton>
      </template>
    </v-data-table>

    <AdditionalSwapInfoDialog
      :swap-work-item="selectedItem"
      :show="showSwapAdditionalInformation"
      @close="showSwapAdditionalInformation = false"
    ></AdditionalSwapInfoDialog>
  </div>
</template>
<script>
import AdditionalSwapInfoDialog from "@/components/dialogs/AdditionalSwapInfoDialog";
import MySwapActions from "@/components/MySwaps/MySwapActions";
import WrappedTextWithTooltip from "@/components/text/WrappedTextWithTooltip";
import TooltipIconButton from "@/components/buttons/TooltipIconButton";

export default {
  components: { TooltipIconButton, WrappedTextWithTooltip, AdditionalSwapInfoDialog, MySwapActions },
  name: "MySwapsList",
  props: ["filter", "search"],
  data() {
    return {
      selectedItem: {},
      showSwapAdditionalInformation: false,
      moveAssetDialog: false,
      headers: [
            { text: "Customer", value: "customerName", filterable: true },
            { text: "Customer ID", value: "erpCustomerId" },
            { text: "Country", value: "country", align: "center" },
            { text: "Task created", value: "dateAdded", align: "center", filterable: true },
            { text: "Sub. number", value: "contractNumber", align: "center", filterable: true },
            { text: "Current SN", value: "serialNumber", align: "center", filterable: true },
            { text: "Requested HW", value: "unitType", align: "center" },
            { text: "Ticket ID", value: "ticketId", align: "center" },
            { text: "Swap Reason", value: "swapReason", align: "center" },
            { text: "Delivery Address", value: "confirmedAddress", align: "center" },
            { text: "Delivery type", value: "consignmentType", align: "center" },
            { text: "Additional information", value: "additionalInformation", align: "center" },
            { text: "Requested By", value: "requestedByUser", align: "center" },
            { text: "Actions", value: "actions", align: "center", sortable: false },
          ]
    };
  },
  methods: {
    showAdditionalSwapInfo(item) {
      this.selectedItem = item;
      this.showSwapAdditionalInformation = true;
    },
    addCustomFiltersToHeaders() {
      let headers = this.headers;
      headers[headers.length - 1].filter = this.filter
      return headers;
    },
    trimUsername(name) {
      return this.$utils.trimUsername(name);
    },
    gotoCustomer(item) {
      this.$router.push({ path: `/customer/${item.aktorId}?activeTab=${this.$utils.getDefaultTab(this.defaultTable)}` });
    },
    gotoDatasource(item) {
      this.$router.push({ path: `/customer/${item.aktorId}?activeTab=5&type=simcard&id=${item.serialNumber}` });
    },
  },
  computed: {
    isLoading() {
      return this.$store.state.MySwapsModule.loading;
    },
    mySwaps() {
      return this.$store.state.MySwapsModule.mySwaps;
    },
    defaultTable() {
      return this.$store.state.userSettings.defaultTable;
    }
  }
};
</script>

<style scoped>
.v-data-table-header th {
  white-space: nowrap;
}
</style>
