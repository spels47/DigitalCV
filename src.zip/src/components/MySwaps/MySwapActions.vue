<template>
  <div class="d-flex justify-center">
    <TooltipIconButton
      v-if="item.worklistType === 'Swap'"
      @clicked="showDeclineDialog = true"
      tooltip="Decline"
      icon="mdi-cancel"
      color="error"
    ></TooltipIconButton>

    <DeclineSwapWorkItemDialog
      :show="showDeclineDialog"
      :item="item"
      :key="showDeclineDialog"
      @close="showDeclineDialog = false"
      @declined="cancelComplete()"
    ></DeclineSwapWorkItemDialog>
  </div>
</template>

<script>
import TooltipIconButton from "@/components/buttons/TooltipIconButton";
import DeclineSwapWorkItemDialog from "@/components/Workhub/Widgets/DeclineSwapWorkItemDialog";

export default {
  name: "MySwapActions",
  props: ["item"],
  components: { DeclineSwapWorkItemDialog, TooltipIconButton },
  data() {
    return {
      showDeclineDialog: false
    }
  },
  methods: {
    async cancelComplete() {
      await this.$store.dispatch("MySwapsModule/removeMySwapItem", this.item);
    },
  }
}
</script>

<style scoped>

</style>
