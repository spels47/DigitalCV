<template>
  <div class="map-container">
    <v-icon class="toggle-source" @click="toggleSource" color="black">mdi-layers-triple-outline</v-icon>
    <div class="map-type-label" :class="{ darkMode: darkMode }">{{ currentLayerText }}</div>
    <div class="map-scroll-info" :class="{ darkMode: darkMode }">Use CTRL + scroll to zoom</div>
    <div class="the-map" :id="mapId"></div>
    <slot></slot>
  </div>
</template>

<script>
import mapboxgl from "mapbox-gl/dist/mapbox-gl.js";
import util from '~/helpers/util';

export default {
  name: "Map",
  props: {
    center: Object
  },
  data: function() {
    return {
      map: null,
      mapId: "",
      styleHasLoaded: false,
      currentLayer: 0,
      tileLayers: [
        {
          name: "Mapbox map",
          getStyleString: () => this.darkMode ? "mapbox://styles/frenabax/ckk2ccxvi3bh117qwl594tca4" : "mapbox://styles/frenabax/ckk2c8v3a3bmb17tlz1p82iya"
        },
        {
          name: "Here maps",
          getStyleString: () => "https://assets.vector.hereapi.com/styles/berlin/base/mapbox/tilezen?apikey=3KlSM74nF46x29JC8M22k9QtL5uTmYpkvL8FmJKZ5BU"
        },
        {
          name: "Mapbox satellite",
          getStyleString: () => "mapbox://styles/frenabax/ckiykph236td919s39b66e6c8"
        }
      ]
    };
  },
  provide: function () {
    return {
      getMap: this.getMap
    }
  },
  async mounted() {
    this.mapId = util.getGuid();

    const waitOne = new Promise(resolve => {
      this.$nextTick(function() {
        resolve();
      });
    });
    await waitOne;

    mapboxgl.accessToken = "pk.eyJ1IjoiZnJlbmFiYXgiLCJhIjoiY2p1ZTZwMHR1MDBkNTN5cWo2c3Y2cGF2OCJ9.tJtarkhtz9Mt9lUPIWQUYQ";
    this.addMapboxglLayersPersistence();
    this.map = new mapboxgl.Map({
      container: this.mapId,
      style: this.getStyleString(),
      center: this.centerToUse,
      zoom: 1,
      attributionControl: false
    });
    this.map.addControl(new mapboxgl.NavigationControl({ showCompass: false }), "bottom-right");
    this.map.addControl(new mapboxgl.FullscreenControl(), "top-left");

    this.setupCtrlToScrollMap();
    this.map.on("style.load", () => {
      this.styleHasLoaded = true;
      this.map.restoreCustomSourcesAndLayers();
    });
  },
  computed: {
    centerToUse() {
      return this.center ? [this.center.longitude, this.center.latitude] : [10.7522, 59.9139];
    },
    currentLayerText() {
      return this.tileLayers[this.currentLayer].name;
    },
    darkMode() {
      return this.$store.getters.darkMode;
    }
  },
  methods: {
    async getMap() {
      while (!this.styleHasLoaded) { await new Promise(r => setTimeout(r, 10)); }
      return this.map;
    },
    addMapboxglLayersPersistence() {
      if (!mapboxgl.Map.prototype.restoreCustomSourcesAndLayers) {
        mapboxgl.Map.prototype.ensureCustomSourcesAndLayers = function() {
          this.customLayers = this.customLayers || {};
          this.customSources = this.customSources || {};
        };

        mapboxgl.Map.prototype.originalAddLayer = mapboxgl.Map.prototype.addLayer;
        mapboxgl.Map.prototype.originalRemoveLayer = mapboxgl.Map.prototype.removeLayer;
        mapboxgl.Map.prototype.originalAddSource = mapboxgl.Map.prototype.addSource;
        mapboxgl.Map.prototype.originalRemoveSource = mapboxgl.Map.prototype.removeSource;
        mapboxgl.Map.prototype.addLayer = function(layer) {
          this.ensureCustomSourcesAndLayers();
          this.customLayers[layer.id] = layer;
          this.originalAddLayer(layer);
        };
        mapboxgl.Map.prototype.removeLayer = function(layerId) {
          this.ensureCustomSourcesAndLayers();
          delete this.customLayers[layerId];
          this.originalRemoveLayer(layerId);
        };
        mapboxgl.Map.prototype.addSource = function(sourceId, source) {
          this.ensureCustomSourcesAndLayers();
          this.customSources[sourceId] = source;
          this.originalAddSource(sourceId, source);
        };
        mapboxgl.Map.prototype.removeSource = function(sourceId) {
          this.ensureCustomSourcesAndLayers();
          delete this.customSources[sourceId];
          this.originalRemoveSource(sourceId);
        };

        mapboxgl.Map.prototype.restoreCustomSourcesAndLayers = function() {
          this.ensureCustomSourcesAndLayers();
          Object.keys(this.customSources).forEach(sourceId => this.addSource(sourceId, this.customSources[sourceId]));
          Object.keys(this.customLayers).forEach(layerId => this.addLayer(this.customLayers[layerId]));
        };
      }
    },
    setupCtrlToScrollMap() {
      this.map.touchZoomRotate.disable();
      this.map.dragRotate.disable();
      this.map.scrollZoom.setWheelZoomRate(0.01); // Default 1/450

      this.map.on("wheel", event => {
        if (event.originalEvent.ctrlKey) {
          // Check if CTRL key is pressed
          event.originalEvent.preventDefault(); // Prevent chrome/firefox default behavior
          if (!this.map.scrollZoom._enabled) this.map.scrollZoom.enable(); // Enable zoom only if it's disabled
        } else {
          if (this.map.scrollZoom._enabled) this.map.scrollZoom.disable(); // Disable zoom only if it's enabled
        }
      });
    },
    toggleSource() {
      this.currentLayer = (this.currentLayer + 1) % this.tileLayers.length;
      this.map.setStyle(this.getStyleString());
    },
    getStyleString() {
      return this.tileLayers[this.currentLayer].getStyleString();
    }
  }
};
</script>

<style lang="scss">

// view hack
.mapboxgl-popup.mapboxgl-popup-anchor-bottom {
  z-index: 12;
}
</style>

<style scoped lang="scss">
.map-container {
  height: 100%;
}

.the-map {
  padding: 0;
  margin: 0;
  width: 100%;
  height: 100%;
  outline: none;
}
.the-map.expanded {
  width: 800px;
}

.toggle-source {
  position: absolute;
  right: 6px;
  top: 6px;
  z-index: 4000;
  background-color: #f1f1f1;
  border-radius: 4px;
  padding: 4px;
}

.map-type-label {
  color: #000000;
  font-size: 10px;
  position: absolute;
  bottom: 5px;
  left: 5px;
  z-index: 4000;
}

.map-type-label.darkMode {
  color: #f1f1f1;
}

.map-scroll-info {
  color: #000000;
  font-size: 10px;
  position: absolute;
  bottom: 15px;
  left: 5px;
  z-index: 4000;
}

.map-scroll-info.darkMode {
  color: #f1f1f1;
}
</style>

<style>
/*We might want to have this for legality*/
a.mapboxgl-ctrl-logo {
  display: none !important;
}
</style>
