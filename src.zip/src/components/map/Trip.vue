<template>
    <div></div>
</template>

<script>
import mapboxgl from "mapbox-gl/dist/mapbox-gl.js";
import { getPositionPopupHtml } from '~/helpers/map-util';
import util from '~/helpers/util';

export default {
  name: "Trip",
  props: {
    positions: Array
  },
  data: function() {
    return {
      map: null,
      markers: [],
      idOnMap: null
    };
  },
  inject: ["getMap"],
  watch: {
    positions: {
      deep: true,
      async handler() {
        this.draw();
      }
    }
  },
  async mounted() {
    this.idOnMap = `trip-${util.getGuid()}`;
    this.draw();
  },
  beforeDestroy() {
    this.removeFromMap();
  },
  methods: {
    async draw() {
      if (!this.map) this.map = await this.getMap();
      this.removeFromMap();
      if (this.positions) {
        this.drawRoute();
      }
    },
    removeFromMap() {
      if (!this.map) return;
      this.markers.forEach(marker => marker.remove());
      if (this.map.getLayer(this.idOnMap)) this.map.removeLayer(this.idOnMap);
      if (this.map.getSource(this.idOnMap)) this.map.removeSource(this.idOnMap);
    },
    drawRoute() {
      if (this.positions.length === 0) return;
      
      this.map.addSource(this.idOnMap, {
        type: "geojson",
        data: {
          type: "Feature",
          properties: {},
          geometry: {
            type: "LineString",
            coordinates: this.positions.map(pos => [pos.longitude, pos.latitude])
          }
        }
      });

      this.map.addLayer({
        id: this.idOnMap,
        type: "line",
        source: this.idOnMap,
        layout: {
          "line-join": "round",
          "line-cap": "round"
        },
        paint: {
          "line-color": "#888888",
          "line-width": 8
        }
      });

      this.positions.forEach((pos, index) => {
        this.markers.push(
          new mapboxgl.Marker(this.getMarkerElement(index))
            .setLngLat([pos.longitude, pos.latitude])
            .setPopup(new mapboxgl.Popup({ closeButton: false }).setHTML(getPositionPopupHtml(pos)))
            .setRotation(pos.course)
            .addTo(this.map)
        );
      });

      this.$emit('displayedOnMap', this.map);
    },
    getMarkerElement(index) {
      const el = document.createElement("div");
      switch (this.positions[index].positionType) {
        case 'START': el.className = "map-component-positions-route-marker-start"; break;
        case 'STOP': el.className = "map-component-positions-route-marker-stop"; break;
        default: el.className = "map-component-positions-route-marker";
      }
      return el;
    }
  }
};
</script>

<style lang="scss">
.map-component-positions-route-marker {
  background-color: #b637c6;
  border-radius: 10px;
  width: 10px;
  height: 10px;
}
.map-component-positions-route-marker-start {
  background-color: #4caa71;
  border-radius: 10px;
  width: 12px;
  height: 12px;
  z-index: 10;
}
.map-component-positions-route-marker-stop {
  background-color: #e5043a;
  border-radius: 10px;
  width: 12px;
  height: 12px;
}
.map-component-positions-route-marker-start:hover {
  background-color: #0073ff;
  border-radius: 15px;
  width: 15px;
  height: 15px;
  cursor: none;
}
.map-component-positions-route-marker-stop:hover {
  background-color: #0073ff;
  border-radius: 15px;
  width: 15px;
  height: 15px;
  cursor: none;
}
.map-component-positions-route-marker:hover {
  background-color: #0073ff;
  border-radius: 15px;
  width: 15px;
  height: 15px;
  cursor: none;
}
</style>
