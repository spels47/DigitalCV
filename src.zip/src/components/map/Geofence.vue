<template>
    <div></div>
</template>

<script>
import util from '~/helpers/util';

export default {
  name: "Geofence",
  props: {
    geofence: Object
  },
  data: function() {
    return {
      map: null,
      idOnMap: null
    };
  },
  inject: ["getMap"],
  watch: {
    geofence: async function() {
      this.draw();
    }
  },
  async mounted() {
    this.idOnMap = `geofence-${util.getGuid()}`;
    this.draw();
  },
  beforeDestroy() {
    this.removeFromMap();
  },
  methods: {
    async draw() {
      if (!this.map) this.map = await this.getMap();
      this.removeFromMap();
      if (this.geofence) {
        const polygon = this.geofence.Polygon.map(x => [x.lng, x.lat])
        this.map.addSource(this.idOnMap, {
          type: 'geojson',
          data: {
            type: 'Feature',
            geometry: {
              type: 'Polygon',
              coordinates: [polygon]
            }
          }
        });
        this.map.addLayer({
          id: this.idOnMap,
          type: 'line',
          source: this.idOnMap,
          layout: {},
          paint: {
            'line-color': '#000',
            'line-width': 3
          }
        });
      }
      this.$emit('displayedOnMap', this.map);
    },
    removeFromMap() {
      if (!this.map) return;
      if (this.map.getLayer(this.idOnMap)) this.map.removeLayer(this.idOnMap);
      if (this.map.getSource(this.idOnMap)) this.map.removeSource(this.idOnMap);
    }
  }
};
</script>
