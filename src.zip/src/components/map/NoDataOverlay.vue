<template>
  <div class="overlay"><div class="overlay-inner"><slot></slot></div></div>
</template>

<script>
export default {
  name: "NoDataOverlay"
};
</script>
    
<style scoped lang="scss">
.overlay {
  z-index: 3000;
  position: absolute;
  left: 0;
  top: 0;
  background: rgba(243, 240, 240, 0.5);
  width: 100%;
  height: 100%;
  pointer-events: none;
}

.overlay-inner {
  position: absolute;
  top: 50%;
  width: 100%;
  text-align: center;
  color: black;
  z-index: 3001;
}
</style>