<template>
  <div>
    <NoDataOverlay v-if="!positions || positions.length === 0">No positions to show</NoDataOverlay>
    <Map>
      <Trip :positions="positions" @displayedOnMap="onDisplayedOnMap"></Trip>
    </Map>
  </div>
</template>

<script>
import mapboxgl from "mapbox-gl/dist/mapbox-gl.js";
import Map from "@/components/map/Map";
import NoDataOverlay from "@/components/map/NoDataOverlay";
import Trip from "@/components/map/Trip";

export default {
  name: "MapWithTrip",
  components: { Map, NoDataOverlay, Trip },
  props: {
    positions: Array
  },
  methods: {
    onDisplayedOnMap(map) {
      const coords = this.positions.map(pos => [pos.longitude, pos.latitude]);
      const bounds = coords.reduce(
        function(bounds, coord) { return bounds.extend(coord); },
        new mapboxgl.LngLatBounds(coords[0], coords[0]));
      map.fitBounds(bounds, { padding: { top: 70, bottom: 70, left: 70, right: 70 }, duration: 0, maxZoom: 12 });
    }
  }
};
</script>
