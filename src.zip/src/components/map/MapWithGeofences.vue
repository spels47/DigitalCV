<template>
  <div>
    <NoDataOverlay v-if="!geofences || geofences.length === 0">No geofences to show</NoDataOverlay>
    <Map>
      <Geofence v-for="(geofence, index) in geofences" v-bind:key="index" :geofence="geofence" @displayedOnMap="onDisplayedOnMap"></Geofence>
    </Map>
  </div>
</template>

<script>
import mapboxgl from "mapbox-gl/dist/mapbox-gl.js";
import Map from "@/components/map/Map";
import NoDataOverlay from "@/components/map/NoDataOverlay";
import Geofence from "@/components/map/Geofence";

export default {
  name: "MapWithGeofences",
  components: { Map, NoDataOverlay, Geofence },
  props: {
    geofences: Array
  },
  methods: {
    onDisplayedOnMap(map) {
      const allPoints = this.geofences.flatMap(geofence => geofence.Polygon);
      const bounds = allPoints.reduce(
        function(aggregateBounds, point) { return aggregateBounds.extend([point.lng, point.lat]); },
        new mapboxgl.LngLatBounds([allPoints[0].lng, allPoints[0].lat], [allPoints[0].lng, allPoints[0].lat]));
      map.fitBounds(bounds, { padding: { top: 70, bottom: 70, left: 70, right: 70 }, duration: 0, maxZoom: 12 });
    }
  }
};
</script>
