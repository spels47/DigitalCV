<template>
    <div></div>
</template>

<script>
import mapboxgl from "mapbox-gl/dist/mapbox-gl.js";
import { getPositionPopupHtml } from '~/helpers/map-util';
import util from '~/helpers/util';

export default {
  name: "Position",
  props: {
    position: Object
  },
  data: function() {
    return {
      map: null,
      marker: null,
      idOnMap: null
    };
  },
  inject: ["getMap"],
  watch: {
    position: async function() {
      this.draw();
    }
  },
  async mounted() {
    this.idOnMap = `position-${util.getGuid()}`;
    this.draw();
  },
  beforeDestroy() {
    this.removeFromMap();
  },
  methods: {
    async draw() {
      if (!this.map) this.map = await this.getMap();
      this.removeFromMap();
      if (this.position) {
        this.drawMarker();
        if (this.position.radius > 0) this.drawCircle();
        this.$emit('displayedOnMap', this.map);
      }
    },
    removeFromMap() {
      if (!this.map) return;
      if (this.marker) this.marker.remove();
      if (this.map.getLayer(this.idOnMap)) this.map.removeLayer(this.idOnMap);
      if (this.map.getSource(this.idOnMap)) this.map.removeSource(this.idOnMap);
    },
    drawMarker() {
      this.marker = new mapboxgl.Marker({ clickTolerance: 10 })
        .setLngLat([this.position.longitude, this.position.latitude])
        .setPopup(new mapboxgl.Popup({ closeButton: false }).setHTML(getPositionPopupHtml(this.position)))
        .addTo(this.map);
    },
    drawCircle() {
      this.map.addSource(this.idOnMap, {
        type: "geojson",
        data: {
          type: "Feature",
          geometry: {
            type: "Point",
            coordinates: [this.position.longitude, this.position.latitude]
          }
        }
      });

      this.map.addLayer({
        id: this.idOnMap,
        type: "circle",
        source: this.idOnMap,
        paint: {
          "circle-radius": {
            stops: [
              [0, 0],
              [20, this.metersToPixelsAtMaxZoom(this.position.radius, this.position.latitude)]
            ],
            base: 2
          },
          "circle-color": "#5b94c6",
          "circle-opacity": 0.6
        }
      });
    },
    metersToPixelsAtMaxZoom(meters, latitude) {
      return meters / 0.075 / Math.cos((latitude * Math.PI) / 180);
    }
  }
};
</script>
