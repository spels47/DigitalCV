<template>
  <div>
    <NoDataOverlay v-if="!position">No position to show</NoDataOverlay>
    <Map :center="position">
      <Position :position="position" @displayedOnMap="onDisplayedOnMap"></Position>
    </Map>
  </div>
</template>

<script>
import Map from "@/components/map/Map";
import NoDataOverlay from "@/components/map/NoDataOverlay";
import Position from "@/components/map/Position";

export default {
  name: "MapWithPosition",
  components: { Map, NoDataOverlay, Position },
  props: {
    position: Object
  },
  methods: {
    onDisplayedOnMap(map) {
      var coord = [this.position.longitude, this.position.latitude];
      // only fly if point is not visible or is zoomed out too much
      if (!map.getBounds().contains(coord) || map.getZoom() < 9) {
        map.flyTo({ center: coord, zoom: 12, bearing: 0, speed: 10 });
      }
    }
  }
};
</script>
