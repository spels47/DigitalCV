<template>
  <div class="fixed-bottom-max-z">
    <TransitionGroup
      name="list"
      tag="ul"
    >
      <v-alert
        v-for="alert in timedAlertsList"
        :key="alert.id"
        :type="alert.type"
        :icon="alert.icon"
        close-icon="mdi-delete"
        border="left"
        dismissible
      >
        <div class="filler multiline" @click.stop="closeAlert(alert, $event)">
          {{ alert.text }}
        </div>
      </v-alert>
    </TransitionGroup>
  </div>
</template>

<script>

// --- To use this directive ---
// Emit your alert on the global EventBus like this:
// this.$eventBus.$emit('alert', {text: 'This is a good test yo!', icon: 'mdi-car', type: 'success'});
// or use a template:
// this.$eventBus.$emit('alert', {template: 'api-error'});
// Types supported are: success, info, warning, error

export default {
  name: "AlertMessage",
  data: function () {
    return {
      alertsList: [],
      now: Date.now(),
      _intervalHolder: null,
      templates: [
        {
          name: 'api-error',
          alert: {
            text: 'An error occurred contacting the API. The error has been logged, and we will look into it 😓',
            icon: 'mdi-api',
            type: 'error'
          }
        },
        {
          name: 'forbidden',
          alert: { text: 'You do not have the required access rights for this operation', icon: 'mdi-key', type: 'error' }
        },
        {
          name: 'invalid-username',
          alert: { text: 'The username entered is not valid or already in use', icon: 'mdi-api', type: 'warning' }
        },
        {
          name: 'invalid-rcid',
          alert: { text: 'The RCID entered is not valid or already in use', icon: 'mdi-api', type: 'warning' }
        }
      ]
    };
  },
  mounted() {
    this._intervalHolder = setInterval(() => {
      this.now = Date.now();
    }, 1000);
    this.$eventBus.$on('alert', this.incomingAlert);
  },
  destroyed() {
    clearInterval(this._intervalHolder);
    this.$eventBus.$off('alert', this.incomingAlert);
  },
  methods: {
    incomingAlert(alert) {
      if (alert.template) {
        let template = this.templates.find(x => x.name === alert.template);
        if (template) alert = template.alert;
        else {
          let errorMessage = alert.template.toString();
          if (errorMessage.includes("status code 403")) {
            alert = this.templates.find(x => x.name === "forbidden").alert;
          } else if (errorMessage.includes("status code 401")) {
            alert = this.templates.find(x => x.name === "forbidden").alert;
          } else if (errorMessage.includes("status code 500")) {
            alert = this.templates.find(x => x.name === "api-error").alert;
          } else {
            alert = { text: 'Unhandled error template', icon: 'mdi-microsoft-internet-explorer', type: 'error' };
          }
        }
      }

      if (!alert.icon) alert.icon = 'mdi-alert-circle';
      if (!alert.duration) alert.duration = 3;

      alert.id = Date.now();
      this.alertsList.push(JSON.parse(JSON.stringify(alert)));
      this.alertsList = this.alertsList.slice(-10); // Max 10 alerts at once
    },
    closeAlert(alert, event) {
      event.preventDefault();
      this.alertsList = this.alertsList.filter(x => x.id !== alert.id);
    }
  },
  computed: {
    timedAlertsList() {
      return this.alertsList.filter(x => x.id + (1000 * x.duration) > this.now);
    }
  }
};
</script>

<style scoped>
.list-move, /* apply transition to moving elements */
.list-enter-active,
.list-leave-active {
  transition: all 0.5s ease;
}

.list-enter-from,
.list-leave-to {
  opacity: 0;
  transform: translateX(30px);
}

/* ensure leaving items are taken out of layout flow so that moving
   animations can be calculated correctly. */
.list-leave-active {
  position: absolute;
}

.fixed-bottom-max-z {
  position: fixed;
  bottom: 0;
  right: 0;
  z-index: 10000;
}

.filler {
  height: 100%;
  width: 100%;
  margin: 0;
}

.multiline {
  white-space: pre;
}
</style>
