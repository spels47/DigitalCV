﻿<template>
  <v-card class="text-center pt-1" :color="infoBannerColor" height="35px">
    <v-icon class="mr-2">mdi-bullhorn</v-icon>
    <span>{{infoBannerText}}</span>
    <v-icon class="ml-2">mdi-bullhorn</v-icon>
  </v-card>
</template>

<script>
export default {
name: "InfoBanner",
  computed: {
    infoBannerText() {
      return this.$store.getters.infoBannerSettings.text
    },
    infoBannerColor() {
      if(this.$store.getters.infoBannerSettings.colorCode !== "") return this.$store.getters.infoBannerSettings.colorCode;
      return "warning";
    }
  }
}
</script>

<style scoped>

</style>
