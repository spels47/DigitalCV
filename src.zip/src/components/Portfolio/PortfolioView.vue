<template>
  <v-container fluid>
    <v-row>
      <v-col cols="3">
        <TeamDetails
          :currentTeam="portfolioTeam"
          :height="'100%'"
        ></TeamDetails>
      </v-col>
      <v-col cols="4.5">
        <ApexTimeChart
          :name="'New customers added to portfolio'"
          :statistic="customersAdded"
          :xAxis="{ label: 'Week', format: 'w' }"
          :loading="loadingCustomers"
          :height="'100%'"
        />
      </v-col>
      <v-col cols="4.5">
        <ApexTimeChart
          :name="'Terminated customers'"
          :statistic="customersTerminated"
          :xAxis="{ label: 'Week', format: 'w' }"
          :loading="loadingCustomers"
          :height="'100%'"
        />
      </v-col>
    </v-row>
    <v-row>
      <v-container fluid>
        <PortfolioCustomers
          :portfolioCustomers="customers"
          :loading="loadingCustomers"
          :team="portfolioTeam"
          @fetchCustomers="getPortfolioCustomers"
        ></PortfolioCustomers>
      </v-container>
    </v-row>
  </v-container>
</template>

<script>
import TeamDetails from "@/components/Portfolio/widgets/TeamDetails";
import PortfolioCustomers from "@/components/Portfolio/PortfolioCustomers";
import ApexTimeChart from "@/components/widgets/Charts/ApexTimeChart";
import axios from "@/axios-client";

export default {
  name: "PortfolioView",
  props: ["portfolioTeam"],
  components: {
    PortfolioCustomers,
    TeamDetails,
    ApexTimeChart
  },
  data() {
    return {
      loadingCustomers: false,
      portfolioStats: null,
      portfolioCustomers: []
    }
  },
  async mounted() {
    await this.getPortfolioCustomers();
  },
  methods: {
    async getPortfolioCustomers() {
      this.loadingCustomers = true;
      this.portfolioStats = null;
      this.portfolioCustomers = [];
      try {
        if(!this.portfolioTeam) return null;
        const { data } = await axios.get(`api/portfolio/team/customers?teamId=${this.portfolioTeam._id}`);
        this.portfolioStats = data.statistics;
        this.portfolioCustomers = data.portfolioCustomerStatistics
      } catch {
        if(!this.roles.PORTFOLIO_ADMIN) this.$eventBus.$emit('alert', { text: 'User has no team assigned. Information not be available.', type: 'error'});
      } finally {
        this.loadingCustomers = false;
      }
    }
  },
  watch: {
    portfolioTeam: {
      handler: function() {
        this.getPortfolioCustomers();
      },
      deep: true
    }
  },
  computed: {
    customersAdded() {
      return this.portfolioStats == null ? [] : this.portfolioStats[0].valueSet;
    },
    customersTerminated() {
      return this.portfolioStats == null ? [] : this.portfolioStats[1].valueSet;
    },
    customers() {
      return this.portfolioCustomers ?? [];
    },
    username() {
      return this.$store.getters.currentUser?.username;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
  }
};
</script>

<style scoped></style>
