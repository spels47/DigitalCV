﻿<template>
  <v-card class="rounded-lg">
    <v-tabs background-color="black" dark>
      <v-tab
        v-for="tab in tabs"
        :key="tab.id"
        :data-cy="tab.data-cy"
        @click="currentTab = tab.id"
      >
        {{ tab.text }}
      </v-tab>
      <v-spacer></v-spacer>
      <v-icon v-tooltippy="'Download report'" class="pr-2 pl-2" data-cy="kpi-hub-download-report" @click="downloadReport">
        mdi-download-circle
      </v-icon>
      <PortfolioTeamSelector v-if="roles.PORTFOLIO_ADMIN"></PortfolioTeamSelector>
    </v-tabs>

    <v-tabs-items v-model="currentTab">
      <v-tab-item>
        <PortfolioCustomersTable
          :loading="loading"
          :customers="portfolioCustomers"
          :team="team"
          @fetchPortfolioCustomers="fetchCustomers"
        ></PortfolioCustomersTable>
      </v-tab-item>
      <v-tab-item :eager="true">
        <BasePortfolioStatistics
          :showTeamDetails="false"
        ></BasePortfolioStatistics>
      </v-tab-item>
    </v-tabs-items>
  </v-card>
</template>

<script>
import PortfolioCustomersTable from "@/components/Portfolio/PortfolioCustomersTable";
import BasePortfolioStatistics from "@/components/KPI Hub/BasePortfolioStatistics";
import PortfolioTeamSelector from "@/components/widgets/PortfolioTeamSelector";
import axios from "@/axios-client";
export default {
  name: "PortfolioCustomers",
  components: {BasePortfolioStatistics, PortfolioCustomersTable, PortfolioTeamSelector},
  props: ["portfolioCustomers", "loading", "team"],
  data() {
    return {
      currentTab: 0,
      tabs: [
        { id: 0, text: "Customers", userRight: "PORTFOLIO_ACCESS", "data-cy": "portfolio-customers-tab" },
        { id: 1, text: "Statistics", userRight: "PORTFOLIO_ACCESS", "data-cy": "portfolio-statistics-tab" },
      ],
    }
  },
  methods: {
    fetchCustomers() {
      this.$emit("fetchCustomers");
    },
    async downloadReport() {
      let file = await axios.get(`api/customerStatistics/downloadReport?teamId=${this.team._id}`)
      const anchor = document.createElement('a');
      anchor.href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(file.data);
      anchor.target = '_blank';
      anchor.download = 'Report ' + this.team.teamName + '.csv';
      anchor.click();
    },
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
  }
};
</script>

<style scoped>
</style>
