﻿<template>
  <v-card
    :loading="loading"
    :height="cardHeight"
    class="rounded-lg"
  >
    <v-list class="card-header">
      <v-list-item :three-line="hasTeamLeader">
        <v-list-item-content>
          <v-list-item-title class="text-h4 font-weight-bold white--text">
            {{ teamName }}
          </v-list-item-title>
          <v-list-item-subtitle class="text-h5">
            <span class="faded-country-text">{{ getCountryFromCode(teamCountry) }}</span>
          </v-list-item-subtitle>
          <v-list-item-subtitle
            v-if="hasTeamLeader"
            class="font-weight-bold"
          >
            <span class="team-leader-text">Team leader: {{ teamLeaderName }}</span>
          </v-list-item-subtitle>
        </v-list-item-content>

        <v-list-item-action>
          <v-icon
            size="80"
            color="white"
          >
            mdi-account-group
          </v-icon>
        </v-list-item-action>
      </v-list-item>

    </v-list>
    <v-card-text
      class="pa-0"
    >
      <v-row>
        <v-col>
          <v-flex v-for="(member, index) in teamMembers" :key="index" class="mt-1">
            <v-list-item-subtitle class="team-member-text ml-2 font-weight-medium">
              <v-icon :color="member.memberType === 'TeamLeader' ? 'secondary' : 'primary'">mdi-account</v-icon>{{ prettyFormatUsername(member.username) }}
            </v-list-item-subtitle>
          </v-flex>
        </v-col>
      </v-row>
    </v-card-text>
  </v-card>
</template>

<script>
export default {
  name: "TeamDetails",
  props: ["height", "currentTeam"],
  data() {
    return {
      loading: false,
    }
  },
  methods: {
    prettyFormatUsername(username) {
      if (!username.includes("@") && !username.includes(".")) return username;
      return username.substring(0, username.indexOf("@")).replace(".", " ").toUpperCase();
    },
    getCountryFromCode(country) {
      if (country === "") return "COUNTRY";
      return country === "NO" ? "NORWAY" : "SWEDEN";
    }
  },
  computed: {
    cardHeight() {
      return this.height ?? "";
    },
    teamName() {
      return this.currentTeam?.teamName?.toUpperCase() ?? "TEAM";
    },
    teamLeaderName() {
      if (this.teamMembers.length === 0) return "LEADER";
      let username = this.teamMembers.find(member => member.memberType.toLowerCase() === "teamleader")?.username;
      return username === undefined ? "LEADER" : this.prettyFormatUsername(username);
    },
    hasTeamLeader() {
      return this.teamMembers.some(member => member.memberType.toLowerCase() === "teamleader");
    },
    teamCountry() {
      return this.currentTeam?.country ?? "";
    },
    teamMembers() {
      return this.currentTeam?.teamMembers ?? [];
    },
    username() {
      return this.$store.getters.currentUser?.username;
    }
  }
};
</script>

<style scoped>
.card-header {
  background-color: #25BACA;
}

.faded-country-text {
  color: #FFFFFF;
  opacity: 0.8;
}

.team-member-text {
  color: #707070;
}

.team-leader-text {
  color: #707070;
}
</style>
