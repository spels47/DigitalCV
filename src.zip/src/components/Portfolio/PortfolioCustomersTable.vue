﻿<template>
  <v-card>
    <v-card-title>
      <v-dialog
        v-model="addCustomerDialog"
        persistent
        max-width="525px"
      >
        <template v-slot:activator="{ on }">
          <v-btn
            dark
            v-on="on"
            color="secondary"
            elevation="2"
            class="rounded-xl"
            v-if="roles.PORTFOLIO_ADMIN || roles.PORTFOLIO_KEY_ADD_CUSTOMER"
          >
            Add Customer
          </v-btn>
        </template>
        <v-card
          height="175"
          :loading="addingCustomer"
        >
          <v-card-title>
            Search for a customer
            <v-spacer></v-spacer>
            <v-btn
              icon
              @click="addCustomerDialog = false"
            >
              <v-icon large>mdi-close</v-icon>
            </v-btn>
          </v-card-title>
          <v-card-subtitle>The customer will be added to your portfolio.</v-card-subtitle>
          <v-card-text>
            <CustomerSearchbar
              @CUSTOMER_SELECTED="addCustomer"
              :include-sub-departments="true"
            ></CustomerSearchbar>
          </v-card-text>
        </v-card>
      </v-dialog>

      <v-dialog
        v-if="isKeyAccountTeam"
        v-model="removeCustomerDialog"
        persistent
        max-width="1000px"
      >
        <template v-slot:activator="{ on }">
          <v-btn
            v-if="roles.PORTFOLIO_KEY_REMOVE_CUSTOMER"
            dark
            v-on="on"
            color="error"
            class="ml-3 rounded-xl"
          >
            Remove customer
          </v-btn>
        </template>
        <v-card
          :loading="removingCustomer"
          height="750"
        >
          <v-card-title>
            Choose an existing customer in your Portfolio
            <v-spacer></v-spacer>
            <v-btn
              icon
              @click="removeCustomerDialog = false"
            >
              <v-icon large>mdi-close</v-icon>
            </v-btn>
          </v-card-title>
          <v-card-subtitle>
            Remove the customer using the trash-can on the right side.
            <v-text-field
              append-icon="mdi-magnify"
              label="Search for customer"
              v-model="customerDeleteSearch"
              single-line
              hide-details
            ></v-text-field>
          </v-card-subtitle>
          <v-card-text>
            <v-data-table
              :headers="removeCustomerTableHeaders"
              :items="customers"
              :search="customerDeleteSearch"
              :footer-props="{ 'items-per-page-options': [10] }"
            >
              <template v-slot:item.action="{ item }">
                <v-btn
                  icon
                  @click="removeCustomer(item)"
                >
                  <v-icon color="error">mdi-delete</v-icon>
                </v-btn>
              </template>
            </v-data-table>
          </v-card-text>
        </v-card>
      </v-dialog>

      <v-spacer></v-spacer>

      <v-menu
        offset-y
        :close-on-content-click="false"
      >
        <template v-slot:activator="{ on }">
          <v-icon
            class="mr-2"
            :color="anyFilterChecked ? 'marked' : ''"
            v-on="on"
          >
            mdi-filter-menu
          </v-icon>
        </template>
        <v-list>
          <v-list-item>
            <v-list-item-title>
              <v-checkbox
                v-model="filterActiveCustomers"
                dense
                class="ml-2"
                label="Active customers"
              ></v-checkbox>
              <v-checkbox
                v-model="filterTerminatedCustomers"
                class="ml-2"
                dense
                label="Terminated customers"
              ></v-checkbox>
            </v-list-item-title>
          </v-list-item>
        </v-list>
      </v-menu>
      <v-text-field
        v-model="search"
        single-line
        hide-details
        class="mt-0 pt-0"
        append-icon="mdi-magnify"
        label="Search"
      ></v-text-field>
    </v-card-title>

    <v-card-text>
      <v-data-table
        :headers="tableHeaders"
        :items="customersInTable"
        :loading="loading"
        :loading-text="'Loading customers for this team'"
        :search="search"
        :footer-props="{ 'items-per-page-options': [10, 20, 100] }"
        :item-class="getCustomItemClass"
      >
        <template v-slot:item.customerName="{ item }">
          <div @click="clickCustomer(item)" >
            <span v-if="item.customerName.length < 30" style="color: #25BACA; cursor: pointer">{{ item.customerName }}</span>
            <v-tooltip v-else bottom>
              <template v-slot:activator="{ on }">
                <span class="text-no-wrap text-truncate" style="color: #25BACA; cursor: pointer" v-on="on">{{ item.customerName.substring(0, 30) }}...</span>
              </template>
              <span>{{ item.customerName }}</span>
            </v-tooltip>
          </div>
        </template>

        <template v-slot:item.mainSubscriptions="{ item }">
          <v-chip outlined>
            {{ item.mainSubscriptions }}
          </v-chip>
        </template>

        <template v-slot:item.mrr="{ item }">
          <span class="font-weight-medium text--primary">{{ formatMrr(item.mrr) }}</span>
        </template>

        <template v-slot:item.yellowFlaggedSubs="{ item }">
          <v-chip outlined>
            {{ item.yellowFlaggedSubs }}
          </v-chip>
        </template>

        <template v-slot:item.createdDate="{ item }">
          {{ item.createdDate | ntzDate }}
        </template>

        <template v-slot:item.firstRenewalDate="{ item }">
          {{ item.firstRenewalDate | ntzDate }}
        </template>

        <template v-slot:item.lastRenewalDate="{ item }">
          {{ item.lastRenewalDate | ntzDate }}
        </template>

        <template v-slot:item.firstYellowFlagDate="{ item }">
          {{ item.firstYellowFlagDate | ntzDate }}
        </template>
      </v-data-table>
    </v-card-text>
    <ConfirmDialog ref="confirm"></ConfirmDialog>
  </v-card>
</template>

<script>
import CustomerSearchbar from "@/components/CustomerSearchbar";
import axios from "@/axios-client";
import ConfirmDialog from "@/components/widgets/dialogs/ConfirmDialog";

export default {
  name: "PortfolioCustomersTable",
  components: { ConfirmDialog, CustomerSearchbar },
  props: ["loading", "customers", "team"],
  data() {
    return {
      customersInTable: [],
      removingCustomer: false,
      addingCustomer: false,
      addCustomerDialog: false,
      removeCustomerDialog: false,
      filterActiveCustomers: true,
      filterTerminatedCustomers: false,
      search: "",
      customerDeleteSearch: "",
      customerTableHeaders: [
        { text: "Customer", value: "customerName", filterable: true },
        { text: "ERP Customer ID", value: "erpCustomerId", align: "center", filterable: true },
        { text: "Created", value: "createdDate", align: "center", filterable: true },
        { text: "Main subscriptions", value: "mainSubscriptions", align: "center", filterable: true },
        { text: "MRR", value: "mrr", align: "center", filterable: true },
        { text: "First renewal date", value: "firstRenewalDate", align: "center", filterable: true },
        { text: "Last renewal date", value: "lastRenewalDate", align: "center", filterable: true },
        { text: "Yellow flagged subs", value: "yellowFlaggedSubs", align: "center", filterable: true },
        { text: "First yellow flag date", value: "firstYellowFlagDate", align: "center", filterable: true },
      ],
      removeCustomerTableHeaders: [
        { text: "Customer", value: "customerName", align: "start" },
        { text: "ERP Customer ID", value: "erpCustomerId", align: "center" },
        { text: "Remove", value: "action", align: "center", sortable: false }
      ]
    }
  },
  watch: {
    customers: {
      handler: function(value) {
        this.customersInTable = value;
      },
      deep: true
    }
  },
  methods: {
    getCustomItemClass(item) {
      if (item.isTerminated) return "tablered"
    },
    async removeCustomer(customer) {
      try {
        this.removingCustomer = true;
        const { data } = await axios.post(`/api/portfolio/removeCustomerFromKeyAccountTeam/${customer.aktorId}`);
        if (data._id > 0) {
          this.$eventBus.$emit('alert', { text: `Customer removed from portfolio`, icon: 'mdi-alert-circle', type: 'success'});
          const index = this.customersInTable.indexOf(customer);
          if (index !== -1) {
            this.customersInTable.splice(index, 1);
          }
          this.removeCustomerDialog = false;
        }
      } catch {
        this.$eventBus.$emit('alert', { text: "An error occured when trying to remove the customer", icon: 'mdi-alert-circle', type: 'error' });
      } finally {
        this.customerDeleteSearch = "";
        this.removingCustomer = false;
      }
    },
    async addCustomer(customer) {
      if (this.customersInTable.findIndex(c => c.aktorId.toString() === customer.id) !== -1) {
        this.$eventBus.$emit('alert', { text: "This customer is already a part of this team.", type: 'warning' });
        return;
      }

      const { data: team } = await axios.get(`/api/portfolio/teamForCustomer/${customer.id}`);
      if (team !== "") {
        if (team?.portfolioTeamType?.toLowerCase() === "keyaccount") {
          this.$eventBus.$emit('alert', { text: "You can't move a customer that belongs to Key-Account Portfolio.", type: 'warning' });
          return;
        }

        this.$refs.confirm.open('Already a part of another team', `<b>${customer.name} is already a part of ${team.teamName}</b>. <br/>Are you sure you want to add this customer to <b>${this.team.teamName}</b>?`
          , { width: 500, preformatted: true }).then(async confirmed => {
            if (confirmed) {
              await this.addCustomerActually(customer);
            }
        });
      } else {
        let confirmMessage = `Are you sure you want to add <b>${customer.name}</b> to team <b>${this.team.teamName}</b>?`;

        try {
          // Get country for this customer
          const { data } = await axios.get(`api/customerStatistics/backstage?customerId=${customer.id}`);
          if (data.data.country === this.team.country)
            confirmMessage = `Customer <b>${customer.name}</b> is based in <b>${data.data.country}</b>, but this Portfolio team is located in <b>${this.team.country}</b>.`;
        } catch {
          // ignored
        }

        this.$refs.confirm.open("Are you sure you want to add this customer?", confirmMessage, { width: 650, preformatted: true, confirmLabel: "Add customer" }).then(async confirmed => {
          if (confirmed) {
            await this.addCustomerActually(customer);
          }
        });
      }
    },
    async addCustomerActually(customer) {
      try {
        this.addingCustomer = true;

        var safetyDance = await axios.get(`api/customerStatistics/backstage?customerId=${customer.id}`);
        if(!safetyDance.data) {
          this.$eventBus.$emit('alert', { text: "No statistics for this customer, probably has no subscriptions 🤷‍♀️", icon: 'mdi-alert-circle', type: 'error'});
          this.addingCustomer = false;
          return;
        }

        let response = null;
        if (this.isKeyAccountTeam) {
          response = (await axios.post(`/api/portfolio/addCustomerToKeyAccountTeam/${customer.id}/${this.team._id}`)).data;
        } else {
          response = (await axios.post(`/api/portfolio/add-customer-to-portfolio-team/${customer.id}/${this.team._id}`)).data;
        }

        if (response._id > 0) {
          this.$eventBus.$emit('alert', { text: `Customer added to portfolio`, icon: 'mdi-alert-circle', type: 'success'});
          this.$emit("fetchPortfolioCustomers");
          this.addCustomerDialog = false;
        }
      } catch {
        this.$eventBus.$emit('alert', { text: "An error occured when trying to add the customer", icon: 'mdi-alert-circle', type: 'error'});
      } finally {
        this.addingCustomer = false;
      }
    },
    clickCustomer(item) {
      this.$router.push({path: `/customer/${item.aktorId}?activeTab=${this.$utils.getDefaultTab(this.defaultTable)}`});
    },
    formatMrr(mrr) {
      return this.$utils.getFormattedPriceForCountry(this.team.country, mrr);
    },
    applyFilter(value, search, item) {
      if ((this.filterTerminatedCustomers && item.isTerminated)) return true;
      return this.filterActiveCustomers && !item.isTerminated;
    }
  },
  computed: {
    isDarkMode() {
      return this.$store.getters.darkMode;
    },
    defaultTable() {
      return this.$store.state.userSettings.defaultTable;
    },
    isKeyAccountTeam() {
      return this.team?.portfolioTeamType?.toLowerCase() === "keyaccount";
    },
    tableHeaders() {
      const headers = this.customerTableHeaders;
      headers[2].filter = this.applyFilter;
      return headers;
    },
    anyFilterChecked() {
      return !this.filterActiveCustomers || this.filterTerminatedCustomers;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
  }
}
</script>

<style scoped>
</style>
