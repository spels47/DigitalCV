<template>
  <div>
    <v-menu
      offset-y
      content-class="user-profile-menu-content"
    >
      <template v-slot:activator="{ on }">
        <v-badge
          bottom
          color="red"
          overlap
          offset-x="12"
          offset-y="12"
          dot
          data-cy="profile-avatar-navbar"
        >
          <v-avatar
            v-if="roles.DEVELOPER_ASAP && apiErrorCount > 0 || errorCount > 0"
            :color="avatarColor"
            size="40"
            v-on="on"
          >
            <span class="white--text">{{ initials }}</span>
          </v-avatar>
        </v-badge>
        <v-avatar
          v-if="apiErrorCount === 0 && errorCount === 0"
          :color="avatarColor"
          data-cy="profile-avatar-navbar"
          size="40"
          v-on="on"
        >
          <span class="white--text">{{ initials }}</span>
        </v-avatar>
      </template>

      <v-list>
        <div class="pb-3 pt-2 pa-2">
          <v-avatar
            :color="avatarColor"
            size="40"
          >
            <span class="white--text">{{ initials }}</span>
          </v-avatar>
          <div
            class="d-inline-flex flex-column justify-center ms-3"
            style="vertical-align: middle"
          >
            <span class="text--primary font-weight-medium mb-n1">
              {{ name }}
            </span>

            <span>{{ username }}</span>
            <small class="text--disabled text-capitalize">{{ department }}</small>
          </div>
        </div>

        <v-divider></v-divider>

        <v-list-item data-cy="profile-dropdown-toggle-dark-mode" @click="toggleDarkMode()">
          <v-list-item-icon class="me-2">
            <v-icon size="22">
              {{ isDarkMode ? 'mdi-weather-sunny' : 'mdi-weather-night' }}
            </v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>Toggle dark mode</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-divider v-if="roles.DEVELOPER_ASAP"></v-divider>

        <v-list-item v-if="roles.DEVELOPER_ASAP" data-cy="profile-dropdown-site-settings" @click="gotoSiteSettings()">
          <v-list-item-icon class="me-2">
            <v-icon size="22">
              mdi-cog
            </v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>Site settings</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-list-item v-if="roles.DEVELOPER_ASAP" data-cy="profile-dropdown-datadog" @click="openDatadogDashboard()">
          <v-list-item-icon class="me-2">
            <v-icon size="22">
              mdi-dog-side
            </v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>Datadog</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-list-item v-if="roles.DEVELOPER_ASAP" data-cy="profile-dropdown-swagger" @click="goToSwagger()">
          <v-list-item-icon class="me-2">
            <v-icon size="22">
              mdi-api
            </v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>Swagger</v-list-item-title>
          </v-list-item-content>
        </v-list-item>

        <v-divider v-if="roles.DEVELOPER_ASAP && apiErrorCount > 0 || errorCount > 0"></v-divider>

        <v-list-item v-if="roles.DEVELOPER_ASAP && apiErrorCount > 0">
          <v-list-item-icon class="me-2">
            <v-icon size="22">
              mdi-alert-circle
            </v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>API errors</v-list-item-title>
          </v-list-item-content>

          <v-list-item-action>
            <v-badge
              inline
              color="error"
              :content="apiErrorCount"
            >
            </v-badge>
          </v-list-item-action>
        </v-list-item>

        <v-list-item v-if="roles.DEVELOPER_ASAP && errorCount > 0">
          <v-list-item-icon class="me-2">
            <v-icon size="22">
              mdi-alert-circle
            </v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>Errors</v-list-item-title>
          </v-list-item-content>

          <v-list-item-action>
            <v-badge
              inline
              color="error"
              :content="errorCount"
            >
            </v-badge>
          </v-list-item-action>
        </v-list-item>

        <v-divider v-if="roles.DEVELOPER_ASAP"></v-divider>

        <v-list-item data-cy="profile-dropdown-logout" @click="signOut()">
          <v-list-item-icon class="me-2">
            <v-icon size="22">
              mdi-logout
            </v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>Log out</v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-menu>
  </div>
</template>

<script>
import { mapActions } from "vuex"
import axios from "@/axios-client";

export default {
  name: "UserAvatar",
  data: function () {
    return {
      timeoutHolder: null,
      errorHandlerMessagesSent: 0,
      axiosClientFailedRequests: 0
    }
  },
  mounted() {
    this.timeoutHolder = setInterval(() => {
      this.errorHandlerMessagesSent = window.errorHandlerMessagesSent
      this.axiosClientFailedRequests = window.axiosClientFailedRequests
    }, 1000);
  },
  destroy() {
    clearInterval(this.timeoutHolder);
    this.$destroy();
  },
  methods: {
    ...mapActions("oidcStore", ["signOutOidc"]),
    stringToHslColor(str, s, l) {
      let hash = 0;
      for (let i = 0; i < str.length; i++) {
        hash = str.charCodeAt(i) + ((hash << 5) - hash);
      }

      let h = hash % 360;
      return "hsl(" + h + ", " + s + "%, " + l + "%)";
    },
    gotoSiteSettings(){
      this.$router.push("/sitesettings");
    },
    goToSwagger(){
      if(this.$route.name === 'swagger') return;
      this.$router.push({ name: 'swagger'});
    },
    async openDatadogDashboard() {
      const { data } = await axios.get('/api/developer/datadogdashboard')
      window.open(data.url, '_blank')
    },
    toggleDarkMode(){
      this.$vuetify.theme.dark = !this.$vuetify.theme.dark;
      this.$vuetify.theme.dark ? window.localStorage.setItem('darkmode', 'true') : window.localStorage.setItem('darkmode', null);
      this.$store.commit("updateVuetifyDarkMode", this.$vuetify.theme.dark);
    },
    signOut: function() {
      this.signOutOidc().then(() => {
        this.$router.push("/");
      })
    },
  },
  computed: {
    initials() {
      return this.username?.substring(0, 2)?.toUpperCase() || "--";
    },
    avatarColor() {
      return this.stringToHslColor(this.username?.substring(0, 2)?.toUpperCase(), 50, 50);
    },
    name() {
      return this.$store.getters.currentUser?.name || "--";
    },
    username() {
      return this.$store.getters.currentUser?.username || "--";
    },
    department() {
      return this.$store.getters.currentUser?.departmentName || "--";
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    isDarkMode() {
      return this.$store.getters.darkMode;
    },
    errorCount(){
      return this.errorHandlerMessagesSent;
    },
    apiErrorCount(){
      return this.axiosClientFailedRequests;
    }
  },
}
</script>

<style lang="scss" scoped>
.user-profile-menu-content {
  .v-list-item {
    min-height: 2.5rem !important;
  }
}
</style>
