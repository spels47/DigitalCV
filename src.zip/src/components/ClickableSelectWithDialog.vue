<template>
  <v-combobox
    :prepend-icon="icon"
    :label="fieldLabel"
    v-model="items"
    readonly
  >
    <template #selection="{ attrs, item, select, selected }">
      <v-chip
        :close="showCloseIcon"
        :disabled="disabled"
        :color="disabled ? 'primary' : 'secondary'"
        @click="itemClicked"
        @click:close="closeIconClicked"
      >
        <WrappedTextWithTooltip
          :text="item"
          :max-length="35"
          class="font-weight-bold"
        ></WrappedTextWithTooltip>
      </v-chip>
    </template>

    <template #append>
      <!-- Filler to hide the default chevron icon -->
      <span></span>

      <v-icon
        v-if="showAppendIcon !== false && hasEditRights"
        class="ml-2"
        @click="appendIconClicked"
      >
        mdi-pencil
      </v-icon>
    </template>
  </v-combobox>
</template>

<script>
import WrappedTextWithTooltip from "@/components/text/WrappedTextWithTooltip.vue";

export default {
  components: { WrappedTextWithTooltip },
  props: ["fieldLabel", "itemText", "icon", "showAppendIcon", "showCloseIcon", "disabled", "hasEditRights"],
  data() {
    return {};
  },
  methods: {
    itemClicked() {
      if (this.disabled) return;
      this.$emit("itemClicked");
    },
    appendIconClicked() {
      this.$emit("appendIconClicked");
    },
    closeIconClicked() {
      if (this.hasEditRights)
        this.$emit("closeIconClicked");
    }
  },
  computed: {
    items() {
      return this.itemText ?? "";
    }
  }
};
</script>

<style></style>
