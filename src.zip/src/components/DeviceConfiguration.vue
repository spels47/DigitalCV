<template>
  <div>
    <v-progress-linear indeterminate color="primary" active v-if="loading"></v-progress-linear>
    <template v-for="feature in compiledFeatures">
      <v-tooltip bottom :key="feature.id">
        <template v-slot:activator="{ on }">
          <v-chip pill small v-on="on" class="ma-2" :color="feature.color">
            <v-icon v-if="feature.icon">{{feature.icon}}</v-icon>
            {{feature.id}}
          </v-chip>
        </template>
        <span>{{feature.text}}</span>
      </v-tooltip>
    </template>
  </div>
</template>

<script>
  import axios from "@/axios-client"

  export default {
    name: "DeviceConfiguration",
    props: {
      serialNumber: String,
    },
    computed:{
      compiledFeatures(){
        return this.deviceFeatures
      }
    },
    data: function () {
      return {
        currentlyLoadedSerialNumber: null,
        deviceFeatures: [],
        loading: false
      }
    },
    async mounted() {
      if (!this.serialNumber) return;
      await this.getDeviceStatus()
    },
    watch: {
      serialNumber: async function () {
        if (!this.serialNumber) return;
        await this.getDeviceStatus()
      }
    },
    methods : {
      async getDeviceStatus() {
        if (!this.serialNumber) return;
        if(this.currentlyLoadedSerialNumber === this.serialNumber) return
        this.currentlyLoadedSerialNumber = this.serialNumber
        this.deviceFeatures = []
        if(this.serialNumber.startsWith('FAKE')) return

        this.loading = true
        try {
          let res = await axios.get(`/api/device-registry/serial-number/${this.serialNumber}/status`);
          if(res.data.is4GOnlyUnit) this.deviceFeatures.push({ id: '4G Only', text: 'This unit only supports 4G', icon: null, color: 'info' })
        } catch (ex) {
          this.$eventBus.$emit('alert', { text: "Failed fetching device status from device registry", type: "error" });
        }
        this.loading = false
      },
    }
  }
</script>

<style scoped>

</style>
