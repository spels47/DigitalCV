<template>
  <v-dialog v-model="dialog" persistent max-width="80%">
    <v-main>
      <v-card>
        <v-row no-gutters>
          <v-col cols="lg-3">
            <v-sheet color="black" class="pa-4 fill-height">
              <v-form ref="importForm" v-model="valid">
                <v-text-field v-model="name" placeholder="Name" prepend-icon="mdi-account" :rules="nameRules" dark></v-text-field>
                <v-text-field v-model="username" placeholder="Username" :error-messages="usernameErrorMessage" prepend-icon="mdi-account" dark></v-text-field>
                <p v-show="usernameInUse" style="color:red;">Username already in use</p>
                <v-text-field v-model="email" placeholder="Email" prepend-icon="mdi-email" :rules="email !== undefined && email.length > 1 ? emailRules: []" dark></v-text-field>
                <v-text-field v-model="phone" placeholder="Mobile" prepend-icon="mdi-phone" :rules="phone !== undefined && phone.length > 1 ? phoneRules: []" dark></v-text-field>
                <v-text-field v-model="rcid" placeholder="RCID" ref="rcidInput" prepend-icon="mdi-numeric" :error-messages="rcidErrorMessage" :rules="rcidRules" dark></v-text-field>
                <p v-show="rcidInUse" style="color:red;">RCID already in use</p>
                <v-select v-model="department" prepend-icon="mdi-flag" :items="departmentList" dense dark></v-select>
                <v-text-field v-model="employeeNumber" placeholder="Employee Number" prepend-icon="mdi-numeric-1-box" dark></v-text-field>
                <v-text-field v-model="title" placeholder="Title" prepend-icon="mdi-account-box" dark></v-text-field>
                <v-checkbox v-model="sendPasswordToUser" dense label="Send password to user" color="secondary" dark></v-checkbox>
              </v-form>
              <v-row class="justify-center">
                <v-btn color="secondary" class="elevation-1 mb-5 text-capitalize" width="200" @click="addUser()">
                  <v-icon color="white">mdi-plus-circle</v-icon>
                  <span v-if="!bEditUser">Add User</span>
                  <span v-if="bEditUser">Edit User</span>
                </v-btn>
              </v-row>
              <v-row v-if="!bEditUser" class="justify-center">
                <v-btn class="elevation-1 mb-3 text-capitalize" color="secondary" width="200" @click="$refs.excelUpload.click()" outlined>
                  <v-icon color="secondary"> mdi-file-excel</v-icon>
                  <span class="secondary--text">Import Excel</span>
                </v-btn>
                <input v-show="false" ref="excelUpload" type="file" accept="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" @change="onFilePicked" />
              </v-row>
              <v-row v-if="bEditUser" class="justify-center">
                <v-btn ref="btnCancelUserEdit" class="elevation-1 text-capitalize" color="secondary" width="200" @click="cancelEditUser()" outlined>
                  <v-icon color="secondary">mdi-close-circle-outline</v-icon>
                  <span class="secondary--text">Cancel edit</span>
                </v-btn>
              </v-row>
              <v-row v-if="!bEditUser" class="justify-center">
                <v-btn color="white" text x-small @click="downloadTemplate">
                  <span>Download template</span>
                </v-btn>
              </v-row>
            </v-sheet>
          </v-col>

          <v-col cols="lg-9" class="d-flex flex-column justify-space-between">
            <v-data-table :sort-by.sync="sortBy" :sort-desc.sync="sortDesc" :headers="importHeaders" :items="importItems" :footer-props="{ 'items-per-page-options': (items_per_page = [12]) }">
              <template v-slot:item="{ item }">
                <tr @click="userRowClick(item)">
                  <td>
                    <v-btn v-if="item.invalidFields.length > 0" fab x-small class="elevation-1" color="white">
                      <v-icon style="font-size:40px" color="red">mdi-alert-circle</v-icon>
                    </v-btn>
                    <v-btn v-if="item.invalidFields.length === 0" color="secondary" fab x-small class="elevation-1">
                      <v-icon>mdi-check</v-icon>
                    </v-btn>
                  </td>
                  <td v-bind:title="item.name">
                    <span v-bind:style="{ color: item.invalidFields && item.invalidFields.includes('name') ? 'red' : '' }">{{ item.name ? item.name : "*" }}</span>
                  </td>
                  <td v-bind:title="item.username" class="text-no-wrap  text-truncate" style="max-width: 150px;">
                    <span v-bind:style="{ color: item.invalidFields && item.invalidFields.includes('username') ? 'red' : '' }">{{ item.username }}</span>
                  </td>
                  <td v-bind:title="item.email" class="text-no-wrap  text-truncate" style="max-width: 150px;">
                    <span v-bind:style="{ color: item.invalidFields && item.invalidFields.includes('email') ? 'red' : '' }">{{ item.email ? item.email : "*" }}</span>
                  </td>
                  <td v-bind:title="item.phone">
                    <span v-bind:style="{ color: item.invalidFields && item.invalidFields.includes('phone') ? 'red' : '' }">{{ item.phone ? item.phone : "*" }}</span>
                  </td>
                  <td v-bind:title="item.rcid" class="text-no-wrap  text-truncate" style="max-width: 150px;">
                    <span v-bind:style="{ color: item.invalidFields && item.invalidFields.includes('rcid') ? 'red' : '' }">{{ item.rcid ? item.rcid : "" }}</span>
                  </td>
                  <td v-bind:title="item.department">
                    {{ item.department }}
                  </td>
                  <td>
                    <v-simple-checkbox v-model="item.sendUserNameAndPassword" color="secondary" disabled></v-simple-checkbox>
                  </td>
                  <td>
                    <v-btn @click.stop="removeUser(item)" icon color="red" text>
                      <v-icon>mdi-delete</v-icon>
                    </v-btn>
                  </td>
                </tr>
              </template>
            </v-data-table>

            <span v-show="showImportError" class="ml-3">
              <v-icon color="red" style="font-size:40px;">mdi-alert-circle</v-icon>
              <span class="ml-3">Some users are missing valid import data {{ importErrorCount }}</span>
            </span>
            <span v-show="showImportProgress" class="ml-3">
              <span class="ml-3">{{importProgressCount}} users remaining</span>
            </span>

            <v-container class="d-flex flex-row align-end">
              <v-row class="d-flex flex-column align-end">
                <div class="ma-4">
                  <v-btn @click="closeDialog()" text>
                    <span>Cancel</span>
                  </v-btn>
                  <v-btn class="elevation-1" color="secondary" @click="saveUsers()" v-show="!importLoading">
                    <v-icon>mdi-content-save</v-icon>
                    <span>Save Users</span>
                  </v-btn>
                  <v-progress-circular v-show="importLoading" indeterminate color="secondary"> </v-progress-circular>
                </div>
              </v-row>
            </v-container>
          </v-col>
        </v-row>
      </v-card>
    </v-main>
  </v-dialog>
</template>
<script>
import axios from "~/axios-client";
import XLSX from "xlsx";

export default {
  props: {
    customer: Object,
    trigger: Number,
    departmentList: Array
  },
  data() {
    return {
      sortBy: "validData",
      sortDesc: false,
      rcidErrorMessage: [],
      usernameErrorMessage: [],
      usernameInUse: false,
      rcidInUse: false,
      importErrorCount: "",
      dialog: true,
      validPhone: false,
      bEditUser: false,
      importLoading: false,
      showImportError: false,
      showImportProgress: false,
      importProgressCount: 0,
      importItems: [],
      importHeaders: [
        { text: "", value: "validData", width: "30px", align: "center" },
        { text: "Name", value: "name", width: "100px" },
        { text: "Username", value: "username", width: "150px" },
        { text: "E-mail", value: "email", width: "150px" },
        { text: "Phone", value: "phone", width: "80px" },
        { text: "RCID", value: "rcid", width: "80px" },
        { text: "Dep", value: "department", width: "100px" },
        { text: "Send pw", value: "sendUserNameAndPassword", width: "110px" },
        { text: "", value: "delete", width: "30px", align: "center" }
      ],
      editUserId: 0,
      valid: false,
      validData: false,
      department: this.customer.id,
      employeeNumber: "",
      username: "",
      sendPasswordToUser: true,
      sendUserNameAndPassword: true,
      departmentLanguage: "",
      name: "",
      usernameRules: [v => !!v || "Username is required"],
      nameRules: [v => !!v || "Name is required", v => (v && v.length < 251) || "Name is too long"],
      email: "",
      emailRules: [v => !!v || "E-mail is required", v => /\S+@\S+\.\S+/.test(v) || "E-mail must be valid", v => (v && v.length) < 256 || "E-mail is too long"],
      phone: "",
      phoneRules: [v => !!v || "Number is required", v => /^\+[0-9]+$/.test(v) || "Number must be valid", v => (v && v.length > 6) || "Number is too short", v => (v && v.length < 16) || "Number is too long"],
      rcid: "",
      rcidRules: [v => (v !== undefined && /^[0-9]+$|^$/.test(v)) || "RCID should only be numbers"],
      title: "",
      titleRules: [v => !!v || "Title is required", v => (v && v.length < 151) || "Title is too long"]
    };
  },
  async created() {
    this.department = parseInt(this.customer.id);
  },
  methods: {
    async verifyUser(user) {
      let response = await axios({
        method: "post",
        url: "/api/user/verifyuser",
        headers: {},
        data: {
          Username: user.username,
          RcidString: user.rcid
        }
      });
      if (response.data.success === false) {
        let errorMessage = response.data.errorMessage;
        errorMessage.forEach(x => {
          user.invalidFields.push(x);
        });
      }
    },
    async verifyUsers(users) {
      let base = this;
      let result = [];
      let response = await axios({
        method: "post",
        url: "/api/user/verifyuserlist",
        headers: {},
        data: users
      });
      result = response.data;
      result.forEach(x => {
        let item = base.importItems.find(z => z.importId === x.importId);
        if (!x.rcidValid) {
          item.invalidFields.push("rcid");
        }
        if (!x.usernameValid) {
          item.invalidFields.push("username");
        }
      });
    },
    async postUser(user) {

      let department = this.getDepartmentIdByName(user.department);
      let response = await axios({
        method: "post",
        url: "/api/user",
        headers: {},
        data: {
          Name: user.name,
          Username: user.username,
          Email: user.email,
          Mobile: user.phone,
          EmployeeNumber: user.employeeNumber?.toString(),
          Title: user.title,
          Country: user.country,
          DepartmentId: parseInt(department),
          RcidString: user.rcid,
          SendUserNameAndPassword: user.sendUserNameAndPassword
        }
      });
      if(response.status === 200){
        this.$store.dispatch("audit", { source: "account", entityId: response.data, message: "User created", newValue: response.data });
      }
      return response.status === 200;
    },
    getDepartmentIdByName(departmentName) {
      let returnValue = 0;
      this.departmentList.forEach(dep => {
        if (dep.text?.toString().toLowerCase() === departmentName?.toString().toLowerCase()) returnValue = dep.value;
      });
      return returnValue;
    },
    getDepartmentNameById(departmentId) {
      let returnValue = "";
      this.departmentList.forEach(dep => {
        if (dep.value === parseInt(departmentId)) {
          returnValue = dep.text;
        }
      });
      return returnValue;
    },
    resetImportForm() {
      this.name = "";
      this.username = "";
      this.email = "";
      this.phone = "";
      this.rcid = "";
      this.employeeNumber = "";
      this.title = "";
      this.department = "";
      this.$refs.importForm.resetValidation();
      this.department = parseInt(this.customer.id);
      this.sendUserNameAndPassword = true;
      this.rcidErrorMessage = [];
      this.usernameErrorMessage = [];
    },
    userRowClick(value) {
      this.name = value.name;
      this.username = value.username;
      this.email = value.email;
      this.phone = value.phone;
      this.rcid = value.rcid;
      this.employeeNumber = value.employeeNumber;
      this.title = value.title;
      this.sendUserNameAndPassword = value.sendUserNameAndPassword;
      this.editUserId = this.importItems.indexOf(value);
      this.bEditUser = true;
      this.$refs.importForm.validate();
      if (value.invalidFields.includes("rcid")) {
        this.rcidErrorMessage.push("RCID already exists");
      } else {
        this.rcidErrorMessage = [];
      }
      if (value.invalidFields.includes("username")) {
        this.usernameErrorMessage.push("Username already exists");
      } else {
        this.usernameErrorMessage = [];
      }
    },
    async addUser() {
      if (this.name.toLowerCase() === "candy rykkelid") this.candyEasterEgg();

      if (this.$refs.importForm.validate()) {
        let user = {
          username: this.username,
          rcid: this.rcid,
          invalidFields: []
        };
        user.invalidFields = [];
        await this.verifyUser(user);
        if (user.invalidFields.length > 0) {
          if (user.invalidFields.includes("username")) {
            this.usernameErrorMessage.push("Username already exists");
          }
          if (user.invalidFields.includes("rcid")) {
            this.rcidErrorMessage.push("RCID already exists");
          }
          return false;
        } else {
          this.usernameErrorMessage = [];
          this.rcidErrorMessage = [];
          this.usernameInUse = false;
          this.rcidInUse = false;
        }
        if (this.bEditUser) {
          this.importItems.splice(this.editUserId, 1);
          this.editUserId = -1;
          this.bEditUser = false;
        }
        this.importItems.unshift({
          name: this.name,
          username: this.username,
          email: this.email,
          phone: this.phone,
          rcid: this.rcid,
          title: this.title,
          department: this.getDepartmentNameById(this.department),
          employeeNumber: this.employeeNumber,
          sendUserNameAndPassword: this.sendPasswordToUser,
          validData: true,
          invalidFields: []
        });
        this.resetImportForm();
        this.updateImportTable();
      }
    },
    removeUser: function(row) {
      if(row.invalidFields.length > 0 ){
        this.importErrorCount = (parseInt(this.importErrorCount) - 1) + " / " + (this.importItems.length - 1);
      }
      this.importItems.splice(this.importItems.indexOf(row), 1);
    },
    async saveUsers() {
      this.importLoading = true;
      let allValid = true;
      let country = this.customer.country;
      this.importItems.forEach(item => {
        if (item.invalidFields.length > 0) {
          allValid = false;
        }
      });
      if (allValid) {
        this.importProgressCount = this.importItems.length
        this.showImportProgress = true;
        let importClone = this.importItems.map(x => x);
        for (const item of importClone) {
          item.country = country;
          if (await this.postUser(item)) {
            this.importProgressCount = this.importProgressCount - 1;
            this.removeUser(item);
          }
        }
        this.$store.dispatch("retrieveAccounts", this.customer.id);
        this.importLoading = false;
        this.showImportProgress = false;
        this.importProgressCount = 0;
        this.closeDialog();
      } else {
        this.updateImportTable();
      }
    },
    async onFilePicked(e) {
      let excelFile = e.target.files[0];
      let errorCounter = 0;
      let userCounter = 0;
      const table = this.importItems;
      let func = this;
      if (excelFile !== undefined && excelFile.name.endsWith(".xlsx")) {
        const reader = new FileReader();
        reader.onload = function(e) {
          func.importLoading = true;
          const data = new Uint8Array(e.target.result);
          const workbook = XLSX.read(data, { type: "array" });
          const first_sheet_name = workbook.SheetNames[0];
          const worksheet = workbook.Sheets[first_sheet_name];
          const worksheetJson = XLSX.utils.sheet_to_json(worksheet, { header: ["userId", "department", "name", "username", "email", "phone", "title", "employeeNumber", "rcid", "Sender user/pass"] });

          worksheetJson.forEach(function(user) {
            user.department = func.getDepartmentIdByName(user.department) !== 0 ? func.getDepartmentNameById(func.getDepartmentIdByName(user.department)) : func.getDepartmentNameById(func.department);
            user = func.verifyValidImportUser(user);
            if (user.username !== "Username *" && !!user.username) {
              let idCounter = 1;
              userCounter++;
              if (user.invalidFields.length > 0) {
                errorCounter++;
                func.showImportError = true;
              }
              table.unshift({
                id: idCounter,
                name: user.name,
                username: !user.username ? user.email : user.username.toString(),
                email: user.email,
                phone: user.phone,
                rcid: user.rcid ? user.rcid.toString() : "",
                title: user.title,
                department: user.department,
                employeeNumber: user.employeeNumber,
                sendUserNameAndPassword: user["Sender user/pass"] !== 0,
                validData: user.invalidFields.length < 1,
                invalidFields: user.invalidFields
              });
              idCounter++;
            }
            func.importErrorCount = errorCounter + " / " + userCounter;
          });
        };
        reader.readAsArrayBuffer(excelFile);
        reader.onloadend = function() {
          func.checkImportUsernameAndRcid();
        };
      }
      this.$refs.excelUpload.value = "";
    },
    async checkImportUsernameAndRcid() {
      let users = [];
      let counter = 1;
      this.importItems.forEach(x => {
        let user = {
          ImportId: counter,
          Username: x.username,
          RcidString: x.rcid ? x.rcid : ""
        };
        x.importId = counter;
        counter++;
        users.push(user);
      });
      await this.verifyUsers(users);

      this.importItems.forEach(x => {
        x.importId = 0;
      });
      this.updateImportTable();
    },
    cancelEditUser() {
      this.bEditUser = false;
      this.editUserId = -1;
      this.resetImportForm();
    },
    downloadTemplate() {
      window.open("/files/ABAX_User_Import_Template.xlsx", "download");
    },
    verifyValidImportUser: function(user) {
      let invalidFields = [];
      // if(!user.username || !user.name || !user.email || !user.phone || !user.department || user.department === '')
      // {
      //   valid = false;
      // }
       if (user.phone !== undefined && (!/^\+[0-9]+$/.test(user.phone) || user.phone.length < 6 || user.phone.length > 16)) {
        invalidFields.push("phone");
      }
      if (user.email !== undefined && (!/.+@.+\..+/.test(user.email) || user.email.length > 256)) {
        invalidFields.push("email");
      }
      if (user.name?.length > 251) {
        invalidFields.push("name");
      }

      if (user.rcid !== "" && user.rcid !== undefined) {
        if (!/^[0-9]+$|^$/.test(user.rcid) || this.importItems.find(x => x.rcid === user.rcid)) {
          invalidFields.push("rcid");
        }
      }
      if (this.importItems.find(x => x.username === user.username)) {
        invalidFields.push("username");
      }
      // if(user.title.length > 150)
      // {
      //   return false;
      // }
      user.invalidFields = invalidFields;
      return user;
    },
    updateImportTable() {
      let showError = false;
      let valid;
      let userCount = 0;
      let errorCount = 0;
      this.importItems.forEach(item => {
        userCount++;
        valid = item.invalidFields?.length < 1;
        if (!valid) {
          showError = true;
          item.validData = false;
          errorCount++;
        }
      });
      this.importErrorCount = errorCount + " / " + userCount;
      this.showImportError = showError;
      this.importLoading = false;
    },
    async closeDialog() {
      this.resetImportForm();
      this.importItems = [];
      this.showImportError = false;
      this.bEditUser = false;
      this.$emit("closeDialog");
      await this.$store.dispatch("setUrlParameter", { name: "type", value: null });
    },
    candyEasterEgg() {
      this.resetImportForm();
    }
  },
  watch: {
    trigger: function() {
      this.dialog = true;
    },
    importErrorCount: function() {
      if(parseInt(this.importErrorCount) < 1){
        this.showImportError = false;
      }
    }
  }
};
</script>
