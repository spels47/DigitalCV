<template>
  <v-autocomplete
    :items="searchResults"
    :filter="customFilter"
    :loading="isLoading"
    :search-input.sync="search"
    @change="emitSearchValue"
    @click:clear="clear"
    v-model="selectedCustomer"
    item-text="name"
    prepend-inner-icon="mdi-magnify"
    placeholder="Search..."
    autofocus
    auto-select-first
    open-on-clear
    clearable
    hide-details
    hide-no-data
    return-object
    autocomplete="off"
    ref="focus"
    data-cy="customer-searchbar"
  >
    <template v-slot:item="data">
        <v-tooltip bottom>
          <template v-slot:activator="{ on }">
            <v-icon v-if="data.item.type === 'MainOfficeCustomer'" v-on="on" class="mr-2 mb-2" color="secondary">mdi-office-building</v-icon>
            <v-icon v-else v-on="on" class="mr-2 mb-2">mdi-office-building</v-icon>
          </template>
          <span>{{ data.item.type === "MainOfficeCustomer" ? "MainOffice" : "Customer" }}</span>
        </v-tooltip>
        <v-list-item-content>
          <v-list-item-title
            class="font-weight-medium"
            v-html="data.item.name"
          ></v-list-item-title>
          <v-list-item-subtitle v-html="data.item.id"></v-list-item-subtitle>
        </v-list-item-content>
    </template>
  </v-autocomplete>
</template>

<script>
import axios from "../axios-client";
export default {
  name: 'CustomerSearchbar',
  props: {
    includeSubDepartments: {
      type: Boolean,
      default: false
    },
    terminatedFilter: {
      type: String,
      default: 'active'
    }
  },
  data() {
    return {
      search: '',
      searchResults: [],
      selectedCustomer: null,
      isLoading: false
    };
  },
  watch: {
    search(val) {
      if (!val || val.length < 3) return;
      this.fetchSearchResultsDebounced();
    }
  },
  methods: {
    customFilter(item, queryText, itemText){
      const hasName = item.name.toLowerCase().includes(itemText.toLowerCase());
      const hasId = item.id.includes(itemText);
      return hasName || hasId;
    },
    emitSearchValue(val) {
      if (val == null) return;
      this.$emit("CUSTOMER_SELECTED", val);
      this.selectedCustomer = "";
    },
    clear() {
      this.searchResults = [];
    },
    async fetchSearchResultsDebounced() {
      clearTimeout(this._timerId);

      if(!this.search) {
        this.clear()
        return
      }

      this._timerId = setTimeout(async () => {
        await this.fetchSearchResults();
      }, 500);
    },
    async fetchSearchResults() {
      this.isLoading = true;
      let searchQuery = { SearchString: this.search }

      const { data } = await axios.post(`/api/search/customer`, searchQuery)
      if (!this.includeSubDepartments)
        this.searchResults = data.filter(x => x.type === 'MainOfficeCustomer'); // Only mainoffice level
      else
        this.searchResults = data;

      if (this.terminatedFilter == 'active') this.searchResults = this.searchResults.filter(x => x.terminated == false); // Only customers that has not been terminated
      else if (this.terminatedFilter == 'terminated') this.searchResults = this.searchResults.filter(x => x.terminated == true); // Only terminated customers

      this.isLoading = false;
    }
  },
};
</script>

<style lang="scss" scoped>
</style>
