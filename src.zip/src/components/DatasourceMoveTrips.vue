<template>
  <v-dialog v-model="showDialog" persistent max-width="80%">
    <v-main>
      <v-card :loading="isLoading" class="dialog-height-fixed">
        <v-row no-gutters>
          <v-col cols="3">
            <v-sheet dark class="pa-4 dialog-height-fixed">
              <v-menu
                v-model="menu1"
                :close-on-content-click="false"
                :nudge-right="40"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="dateFrom"
                    label="Date From"

                    readonly
                    v-bind="attrs"
                    v-on="on"
                    color="secondary"
                    dark
                  ></v-text-field>
                </template>
                <v-date-picker
                  :first-day-of-week="1"
                  v-model="dateFrom"
                  @input="menu1 = false"
                ></v-date-picker>
              </v-menu>
              <v-menu
                v-model="menuTimeFrom"
                :close-on-content-click="false"
                :nudge-right="40"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="timeFrom"
                    label="Time From"
                    prepend-icon="mdi-clock"
                    readonly
                    v-bind="attrs"
                    v-on="on"
                    color="secondary"
                    dark
                  ></v-text-field>
                </template>
                <v-time-picker
                  v-model="timeFrom"
                  format="24hr"
                  use-seconds
                ></v-time-picker>
              </v-menu>
              <v-menu
                v-model="menu2"
                :close-on-content-click="false"
                :nudge-right="40"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="dateTo"
                    label="Date To"
                    prepend-icon="mdi-calendar"
                    readonly
                    v-bind="attrs"
                    v-on="on"
                    color="secondary"
                    dark
                  ></v-text-field>
                </template>
                <v-date-picker
                  :first-day-of-week="1"
                  v-model="dateTo"
                  @input="menu2 = false"
                ></v-date-picker>
              </v-menu>
              <v-menu
                v-model="menuTimeTo"
                :close-on-content-click="false"
                :nudge-right="40"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="timeTo"
                    label="Time to"
                    prepend-icon="mdi-clock"
                    readonly
                    v-bind="attrs"
                    v-on="on"
                    color="secondary"
                    dark
                  ></v-text-field>
                </template>
                <v-time-picker
                  v-model="timeTo"
                  format="24hr"
                  use-seconds
                ></v-time-picker>
              </v-menu>

              <v-divider></v-divider>

              <v-sheet dark class="pa-0">
                  <v-card-actions>
                    <v-btn text @click="selectTargetPrevious">
                      <v-icon>mdi-chevron-left</v-icon>
                    </v-btn>
                    <v-item-group>
                      <v-item>
                        <h3>Destination asset</h3>
                      </v-item>
                    </v-item-group>
                    <v-btn text @click="selectTargetNext">
                      <v-icon>mdi-chevron-right</v-icon>
                    </v-btn>
                  </v-card-actions>
                <div v-if="!destinationAsset">
                  <v-icon medium color="warning">mdi-alert-circle-outline</v-icon>
                  <span class="ml-2">No assets found to be connected to this data source</span>
                </div>
                <div v-if="destinationAsset">
                  <v-text-field hint="AssetId" :value="destinationAsset.assetId" persistent-hint disabled></v-text-field>
                  <v-text-field hint="Vehicle ID" :value="destinationAsset.vehicleId" persistent-hint disabled></v-text-field>
                  <v-text-field hint="License Plate" :value="destinationAsset.licensePlate" persistent-hint disabled></v-text-field>
                  <v-text-field hint="Alias"  :value="destinationAsset.alias" persistent-hint disabled></v-text-field>
                  <v-text-field hint="DepartmentId" :value="destinationAsset.departmentId" persistent-hint disabled></v-text-field>
                </div>

              </v-sheet>
            </v-sheet>
          </v-col>

          <v-col cols="9" class="d-flex flex-column justify-space-between">
            <v-data-table
              :items="assets"
              :headers="headers"
              :sort-by.sync="sortBy"
              :sort-desc.sync="sortDesc"
              :footer-props="{ 'items-per-page-options': (items_per_page = [12]) }"
              @click:row="rowClick"
            >
              <template v-slot:item.selected="{ item }">
                <v-tooltip bottom v-if="item.assetId === destinationAsset.assetId">
                  <template v-slot:activator="{ on }">
                    <v-icon color="success" v-on="on">mdi-alpha-d-circle</v-icon>
                  </template>
                  <span>This is the destination asset</span>
                </v-tooltip>
                <v-tooltip bottom v-if="item.assetId === sourceAsset.assetId">
                  <template v-slot:activator="{ on }">
                    <v-icon color="warning" v-on="on">mdi-alpha-s-circle</v-icon>
                  </template>
                  <span>This is the source asset</span>
                </v-tooltip>
              </template>
              <template v-slot:item.currentActiveAsset="{ item }">
                <v-tooltip bottom>
                  <template v-slot:activator="{ on }">
                    <v-icon :color="!item.currentActiveAsset ? 'primary' : 'accent'" v-on="on">{{!item.currentActiveAsset ? 'mdi-alpha-h-circle' : 'mdi-alpha-a-circle'}}</v-icon>
                  </template>
                  <span v-if="item.currentActiveAsset">This vehicle is active</span>
                  <span v-if="!item.currentActiveAsset">This vehicle is historic</span>
                </v-tooltip>
              </template>

              <template v-slot:item.vehicleId="{ item }">
                <span>{{ item.vehicleId }}</span>
              </template>

              <template v-slot:item.licensePlate="{ item }">
                <span>{{ item.licensePlate }}</span>
              </template>

              <template v-slot:item.alias="{ item }">
                <span>{{ item.alias }}</span>
              </template>

              <template v-slot:item.firstTrip="{ item }">
                <span>{{ item.firstTrip | ntzDatetime }}</span>
              </template>

              <template v-slot:item.lastTrip="{ item }">
                <span>{{ item.lastTrip | ntzDatetime }}</span>
              </template>

              <template v-slot:item.tripCount="{ item }">
                <span>{{ item.tripCount }}</span>
              </template>

              <template v-slot:item.departmentPath="{ item }">
                <DepartmentPath :department-path="item.departmentPath"></DepartmentPath>
              </template>

            </v-data-table>
            <v-container class="d-flex flex-row align-end">
              <v-row class="d-flex flex-column align-end">
                <div class="ma-4">
                  <v-btn @click="closeDialog()" text>
                    <span>Cancel</span>
                  </v-btn>
                  <span v-tooltippy="executeButtonTooltipText">
                  <v-btn class="elevation-1"
                         color="secondary"
                         @click="revisionClick()"
                         :loading="isLoading"
                         :disabled="!inputsAreValid || !applicableForRevision || isLoading">
                    <v-icon>mdi-content-save</v-icon>
                    <span>Move trips</span>
                  </v-btn>
                  </span>
                </div>
              </v-row>
            </v-container>
          </v-col>
        </v-row>
        <ConfirmDialog ref="confirm"></ConfirmDialog>
      </v-card>
    </v-main>
  </v-dialog>
</template>
<script>
import axios from '~/axios-client'
import util from "@/helpers/util"
import DepartmentPath from "~/components/DepartmentPath";
import ConfirmDialog from "@/components/widgets/dialogs/ConfirmDialog"

export default {
  components: {
    DepartmentPath,
    ConfirmDialog
  },
  props: {
    serialNumber: String,
    simcardId: Number,
    showDialog: Boolean,
  },
  data() {
    return {
      headers: [
        { text: 'Selected', value: 'selected'},
        { text: 'Status', value: 'currentActiveAsset'},
        { text: 'Vehicle ID', value: 'vehicleId'},
        { text: "Alias", value: "alias" },
        { text: "License Plate", value: "licensePlate" },
        { text: 'First trip', value: 'firstTrip' },
        { text: 'Last trip', value: 'lastTrip' },
        { text: 'TripCount', value: 'tripCount' },
        { text: 'Customer Path', value: 'departmentPath' },
      ],
      assets: [],
      destinationAsset: {},
      sortBy: 'vehicleId',
      sortDesc: true,
      isLoading: false,
      menu1: false,
      menuTimeFrom: false,
      menuTimeTo: false,
      menu2: false,
      timeFrom: '00:00:00',
      timeTo: '23:59:59',
      dateFrom: "",
      dateTo: "",
      sourceAsset: {}
    }
  },
  watch: {
    async showDialog(value) {
      if(!value) return
      await this.getAssetRevisionStatus(this.serialNumber)
      let versionDates = this.assets.filter(x => x.firstTrip).map(x =>new Date(x.firstTrip))
      if(!versionDates.some(x => x)) {
        this.dateFrom = util.getIsoDateString(util.getStartOfYearDate())
        this.dateTo = util.getIsoDateString(new Date())
        return
      }

      let minDate = new Date(Math.min.apply(null, versionDates))
      minDate.setHours(12) // Timezone support
      this.dateFrom = util.getIsoDateString(minDate)
      this.dateTo = util.getIsoDateString(new Date())
    }
  },
  methods: {
    selectTargetPrevious(){
      let currentIndex = this.assets.indexOf(this.destinationAsset)
      currentIndex--;
      if(currentIndex < 0) currentIndex = this.assets.length-1
      this.destinationAsset = this.assets[currentIndex]
    },
    selectTargetNext(){
      let currentIndex = this.assets.indexOf(this.destinationAsset)
      currentIndex++;
      if(currentIndex > this.assets.length-1) currentIndex = 0
      this.destinationAsset = this.assets[currentIndex]
    },
    rowClick(row){
      this.sourceAsset = row
      if(row.firstTrip){
        this.dateFrom = row.firstTrip.substring(0, 10);
        this.timeFrom = row.firstTrip.substring(11, 19);
      } else {
        this.dateFrom = '2000-01-01';
        this.timeFrom = '12:00:00'
      }
    },
    async revisionClick() {
      let revisionText = `
This operation will move all trips and positions between the selected assets
in the time frame: <b>${this.dateFrom} ${this.timeFrom}</b> ➡ <b>${this.dateTo} ${this.timeTo}</b>
From source asset: <b>${this.sourceAsset.vehicleId} ${this.sourceAsset.alias??''} ${this.sourceAsset.licensePlate??''}</b>
To destination asset: <b>${this.destinationAsset.vehicleId} ${this.destinationAsset.alias??''} ${this.destinationAsset.licensePlate??''}</b>
`
      let confirmed = await this.$refs.confirm.open('Move trips', revisionText, { width: 700, preformatted: true, html: true })
      if(!confirmed) return

      if(this.sourceAsset.assetId === this.destinationAsset.assetId) return;
      let fromDate = new Date(`${this.dateFrom}T${this.timeFrom}`);
      let toDate =  new Date(`${this.dateTo}T${this.timeTo}`);

      await this.postMoveTripsInDateRangeBetweenAssets(this.sourceAsset, fromDate, toDate, this.destinationAsset)
    },
    async getAssetRevisionStatus(serialNumber) {
      try {
        this.isLoading = true;
        let res = await axios.get(`/api/asset/asset-revision/status/device/${serialNumber}`);
        this.assets = res.data.assets
        this.destinationAsset = this.assets.find(x => x.currentActiveAsset)
      } catch(ex) {
        if(ex.response.status === 404) this.$eventBus.$emit("alert", {text: "No assets found for this data source", type: "warning"});
        else this.$eventBus.$emit("alert", {text: "Failed to get list of assets for this data source", type: "error"});
      } finally {
        this.isLoading = false;
      }
    },
    async postMoveTripsInDateRangeBetweenAssets(sourceAsset, fromDate, toDate, destinationAsset) {
      if(!sourceAsset?.vehicleId || !sourceAsset?.assetId
        || !destinationAsset?.vehicleId || !destinationAsset?.assetId
        || !this.simcardId
        || (this.sourceAsset.assetId === this.destinationAsset.assetId)
      ){
        this.$eventBus.$emit("alert", {text: "Unable to perform action, missing data on source/destination asset", type: "warning"});
        return;
      }

      try {
        this.isLoading = true;
        await axios.post(`/api/asset/asset-revision/move-trips-in-date-range-between-assets`, {
          sourceAssetId: sourceAsset.assetId,
          fromDate: fromDate,
          toDate: toDate,
          destinationAssetId: destinationAsset.assetId
        });
        await this.$store.dispatch("audit", { source: "datasource", entityId: this.simcardId, message: "Moved trips in date range to vehicle based on simcardId", oldValue: `Trips in range: ${fromDate}-${toDate}`, newValue: `Moved to vehicleId: ${destinationAsset.vehicleId}` });
        await this.$store.dispatch("audit", { source: "vehicle", entityId: destinationAsset.vehicleId, message: "Moved trips in date range to vehicle based on simcardId", oldValue: `Moved from simcardId: ${this.simcardId}`, newValue: `Trips in range: ${fromDate}-${toDate}` });
        this.$eventBus.$emit("alert", {text: "Move trips operation completed", type: "success"});
      } catch {
        this.$eventBus.$emit("alert", {text: "Move trips operation failed", type: "error"});
      } finally {
        this.isLoading = false;
      }
      await this.getAssetRevisionStatus(this.serialNumber)
    },
    closeDialog() {
      this.destinationAsset = {}
      this.assets = [];
      this.isLoading = false;
      this.dateFrom = "";
      this.dateTo = "";
      this.$emit("closeDialog");
    },
  },
  computed: {
    inputsAreValid(){
      if(!this.sourceAsset?.assetId) return false;
      if(!this.destinationAsset?.assetId) return false;
      if(this.sourceAsset?.assetId === this.destinationAsset?.assetId) return false;
      if(this.sourceAsset?.tripCount === 0) return false;
      return this.dateFrom && this.dateTo && this.timeFrom && this.timeTo
    },
    executeButtonTooltipText(){
      if(!this.sourceAsset?.assetId) return 'Source asset not set';
      if(!this.destinationAsset?.assetId) return 'Destination asset not set';
      if(this.sourceAsset?.assetId === this.destinationAsset?.assetId) return 'Source and destination is set to the same asset';
      if(this.sourceAsset?.tripCount === 0) return 'No trips on source asset'
      if(!this.dateFrom || !this.dateTo || !this.timeFrom || !this.timeTo) return 'Date not properly set'
      return null
    },
    applicableForRevision(){
      return this.destinationAsset && this.assets?.length > 1
    }
  }
}
</script>

<style lang="scss">
.dialog-height-fixed{
  height: 800px;
}

</style>
