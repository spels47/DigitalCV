﻿<template>
  <v-container>
    <v-row cols="12">
      <v-col cols="lg-12">
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath clickable :department-path="vehicle.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                Trips
              </v-list-item-title>

              <v-list-item-subtitle>
                <v-menu ref="menu" v-model="menu" :close-on-content-click="false" :return-value.sync="dates" transition="scale-transition" offset-y min-width="290px">
                  <template v-slot:activator="{ on, attrs }">
                    <v-text-field style="width: 18%" v-model="datesAsText" range prepend-inner-icon="mdi-calendar" readonly v-bind="attrs" v-on="on"></v-text-field>
                  </template>
                  <v-date-picker v-model="dates" range color="secondary darken-1" no-title scrollable :first-day-of-week="1">
                    <v-spacer></v-spacer>
                    <v-btn text color="primary" @click="menu = false">
                      Cancel
                    </v-btn>
                    <v-btn text color="primary" @click="dateRangeChanged">
                      OK
                    </v-btn>
                  </v-date-picker>
                </v-menu>
              </v-list-item-subtitle>

              <v-fade-transition>
                <v-list-item-subtitle v-if="tripSearchResults.length > 0">
                  <v-chip
                    small
                    outlined
                    v-tooltippy="'Total minutes'"
                  >
                    <v-icon
                      left
                      small
                    >
                      mdi-map-clock
                    </v-icon>
                    {{ trips.totalMinutes }} minutes
                  </v-chip>
                  <v-chip
                    class="ml-2"
                    small
                    outlined
                    v-tooltippy="'Total distance'"
                  >
                    <v-icon
                      left
                      small
                    >
                      mdi-map-marker-distance
                    </v-icon>
                    {{ totalDistance }}
                  </v-chip>
                </v-list-item-subtitle>
              </v-fade-transition>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>

    <v-row v-if="selectedTripPositions">
      <v-progress-linear indeterminate color="primary" :active="positionsLoading"></v-progress-linear>
      <v-card class="map-card">
        <MapWithTrip :positions="selectedTripPositions"></MapWithTrip>
      </v-card>
    </v-row>

    <v-row>
      <v-col cols="12">
        <v-data-table
          class="fill-width"
          :headers="headers"
          :items="tripSearchResults"
          :loading="tripsLoading"
          loading-text="Loading trips..."
          :footer-props="{ 'items-per-page-options': (items_per_page = [10, 20, 50, -1]) }"
          @click:row="tripRowClicked($event)"
        >
          <template v-slot:item.startTime="{ item }">
            <span :class="shouldApplyClass(item)">{{ convertDateToCustomerCountry(item.startDate) }}</span>
            <br/>
            <span :class="shouldApplyClass(item)">{{ convertDateToCustomerCountry(item.endDate) }}</span>
          </template>

          <template v-slot:item.startStopAddress="{ item }">
            <WrappedTextWithTooltip
              :text="item.startAddress"
              :max-length="45"
              :class="shouldApplyClass(item)"
            ></WrappedTextWithTooltip>

            <WrappedTextWithTooltip
              :text="item.stopAddress"
              :max-length="45"
              :class="shouldApplyClass(item)"
            ></WrappedTextWithTooltip>
          </template>

          <template v-slot:item.tripType="{ item }">
            <IconWithTooltip
              :icon="item.tripType === 'UNIT' ? 'mdi-cable-data' : 'mdi-merge'"
              :tooltip="item.tripType === 'UNIT' ? 'Unit' : 'Merged'"
              :color="shouldApplyClass(item) === 'secondary--text' ? 'secondary' : 'primary'"
            ></IconWithTooltip>
          </template>

          <template v-slot:item.distance="{ item }">
            <span :class="shouldApplyClass(item)">{{ getDistanceText(item.distance) }}</span>
          </template>

          <template v-slot:item.private="{ item }">
            <span :class="shouldApplyClass(item)">{{ item.private ? "P" : "C" }}</span>
          </template>

          <template v-slot:item.objectRegNo="{ item }">
            <span :class="shouldApplyClass(item)">{{ item.objectRegNo }}</span>
          </template>

          <template v-slot:item.objectRegNo="{ item }">
            <span :class="shouldApplyClass(item)">{{ item.objectRegNo }}</span>
          </template>

          <template v-slot:item.driverName="{ item }">
            <WrappedTextWithTooltip
              :text="item.driverName"
              :max-length="15"
              :class="shouldApplyClass(item)"
            ></WrappedTextWithTooltip>
          </template>

          <template v-slot:item.tollRoadCost="{ item }">
            <span
              v-if="item.tollRoadCost !== 0"
              :class="shouldApplyClass(item)"
            >
              {{ item.tollRoadCost }},-
            </span>
          </template>

          <template v-slot:item.comment="{ item }">
            <WrappedTextWithTooltip
              :text="item.comment"
              :max-length="15"
              :class="shouldApplyClass(item)"
            ></WrappedTextWithTooltip>
          </template>
        </v-data-table>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import MapWithTrip from "@/components/map/MapWithTrip";
import WrappedTextWithTooltip from "@/components/text/WrappedTextWithTooltip.vue";
import IconWithTooltip from "@/components/icons/IconWithTooltip.vue";
import DepartmentPath from "@/components/DepartmentPath.vue";

export default {
  name: "VehicleTrips",
  props: {
    id: String,
    type: String,
    expanded: Boolean,
    customer: Object,
  },
  data: function () {
    return {
      trips: {},
      dates: [],
      menu: false,
      tripsLoading: false,
      positionsLoading: false,
      tripHeaders: [
        { text: "Start/Stop Date", value: "startTime" },
        { text: "Driver", value: "driverName" },
        { text: "Distance", value: "distance" }
      ],
      tripHeadersLong: [
        { text: "Start/Stop Date", value: "startTime" },
        { text: "Start/Stop Address", value: "startStopAddress" },
        { text: "Driver", value: "driverName" },
        { text: "Distance", value: "distance" },
        { text: "Trip Type", value: "private" },
        { text: "Source", value: "tripType" },
        { text: "Reg No", value: "objectRegNo" },
        { text: "Purpose", value: "comment" },
        { text: "Toll", value: "tollRoadCost" }
      ],
      selectedTrip: null,
      selectedTripPositions: null
    };
  },
  async mounted() {
    await this.init();
  },
  watch: {
    async id() {
      await this.init();
    }
  },
  methods: {
    async init() {
      await this.$store.dispatch("retrieveVehicle", { id: this.id });
      this.dates = this.getDefaultDates();
      await this.getTripsInfo(this.vehicle.vehicleId);
    },
    async getTripsInfo(vehicleId) {
      this.tripsLoading = true;
      this.selectedTrip = null;
      this.selectedTripPositions = null;
      this.trips = [];
      let fullFromDate = this.dates[0] + ' 00:00:00'
      let fullEndDate = this.dates[1] + ' 23:59:59'
      try {
        let res = await axios.get(`/api/trip/searchByVehicle/${vehicleId}/${fullFromDate}/${fullEndDate}?dontShowDeletedTrips=true`)
        this.trips = res.data;
      } catch (ex) {
        this.$eventBus.$emit("alert", { text: "Failed to get list of trips for this vehicle", type: "error" });
      }
      this.tripsLoading = false
    },
    shouldApplyClass(item) {
      const index = this.trips?.tripSearchResults?.findIndex(trip => trip.tripId === item.tripId);
      return index === this.selectedTrip?.index ? "secondary--text" : "";
    },
    getDefaultDates() {
      // Choosing vehicle's last trip or today, one week span
      let maxDate = new Date();
      if (this.vehicle.lastTrip) {
        maxDate = new Date(this.vehicle.lastTrip);
      }
      let minDate = this.$utils.addDays(maxDate, -7);
      return [this.$utils.getIsoDateString(minDate), this.$utils.getIsoDateString(maxDate)];
    },
    convertDateToCustomerCountry(date) {
      return this.$utils.getDateTimeByCountry(date, this.customer.country).substr(0, 16);
    },
    async dateRangeChanged() {
      if (this.dates.length > 1) {
        // Sort dates
        let startDate = new Date(this.dates[0]);
        let endDate = new Date(this.dates[1]);
        if (startDate > endDate) {
          this.dates = [this.dates[1], this.dates[0]];
        }
      } else {
        this.dates = [this.dates[0], this.dates[0]];
      }
      this.$refs.menu.save(this.dates);
      await this.getTripsInfo(this.vehicle.vehicleId);
    },
    getDistanceText(distance) {
      let roundedDistance = (distance / 1000).toFixed(1);
      return `${roundedDistance} km`;
    },
    async tripRowClicked(row) {
      this.selectedTrip = row;
      this.selectedTrip.index = this.trips.tripSearchResults.findIndex(trip => trip.tripId === row.tripId);
      await this.getPositions();
    },
    async getPositions() {
      if (!this.selectedTrip) return;

      this.selectedTripPositions = [];
      this.positionsLoading = true;
      try {
        let res = await axios.get(`/api/trip/positions/${this.vehicle.simcardId}/${this.selectedTrip.startDate}/${this.selectedTrip.endDate}`);
        this.selectedTripPositions = res.data;
        // Adding objects for the start/stop position that are part of the trip object
        let startPosition = {
          trackedObjectId: this.vehicle.simcardId,
          latitude: this.selectedTrip.startLat,
          longitude: this.selectedTrip.startLon,
          course: 0,
          isFix: false,
          isManual: false,
          positionType: 'START',
          radius: 0,
          speed: 0,
          timestamp: this.selectedTrip.startDate
        }
        let stopPosition = {
          trackedObjectId: this.vehicle.simcardId,
          latitude: this.selectedTrip.stopLat,
          longitude: this.selectedTrip.stopLon,
          course: 0,
          isFix: false,
          isManual: false,
          positionType: 'STOP',
          radius: 0,
          speed: 0,
          timestamp: this.selectedTrip.endDate
        }
        this.selectedTripPositions.unshift(startPosition)
        this.selectedTripPositions.push(stopPosition)
      } catch (ex) {
        this.$eventBus.$emit("alert", { template: "api-error" });
      }
      this.positionsLoading = false;
    }
  },
  computed: {
    totalDistance() {
      if (this.customer.country === "GB") {
        return `${(this.trips.totalDistance * 0.62137).toFixed(1)} miles`;
      }
      return `${this.trips.totalDistance} km`;
    },
    headers() {
      return this.expanded ? this.tripHeadersLong : this.tripHeaders;
    },
    tripSearchResults() {
      return this.trips?.tripSearchResults ?? [];
    },
    datesAsText() {
      return this.dates.join(" - ");
    },
    vehicle() {
      return this.$store.state.SidebarModule.selectedVehicle;
    }
  },
  components: {
    DepartmentPath,
    IconWithTooltip,
    WrappedTextWithTooltip,
    MapWithTrip
  }
};
</script>

<style scoped>
.fill-width {
  width: 100%;
}
</style>
