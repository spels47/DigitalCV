<template>
  <v-container>
    <v-progress-linear absolute :active="this.isLoading" indeterminate dark></v-progress-linear>
    <v-row>
      <v-col cols="lg-12">
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath class="ml-5" clickable :department-path="vehicle.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline ml-5">
                <span>Vehicle info</span>
              </v-list-item-title>
              <v-list-item-title class="headline ml-5" v-if="vehicle.id && !vehicle.isMounted">
                <span class="error--text">INACTIVE</span>
              </v-list-item-title>
              <v-list-item-title class="headline ml-5" v-if="vehicle.id && !vehicle.assetId">
                <span class="error--text">Error: missing assetId</span>
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row no-gutters>
      <v-row>
        <v-col cols="lg-12">
          <v-list min-width="100">
            <v-list-item>
              <v-text-field @change="updateVehicleMetadataField('alias', vehicle.alias, 'Name')" :readonly="!roles.ASSET_EDIT" prepend-icon="mdi-identifier" label="Alias" v-model="vehicle.alias"/>
            </v-list-item>
            <v-list-item>
              <v-text-field
                :value="vehicle.licensePlate"
                :readonly="true"
                append-icon="mdi-pencil"
                prepend-icon="mdi-numeric"
                label="License plate"
                @click:append="roles.ASSET_EDIT ? (updateLicensePlateDialog = true) : (updateLicensePlateDialog = false)"
              />
            </v-list-item>
            <v-list-item>
              <v-text-field readonly prepend-icon="mdi-calendar" label="Vehicle Id" :value="vehicle.vehicleId"/>
            </v-list-item>
            <v-list-item>
              <v-text-field readonly prepend-icon="mdi-identifier" label="Primary data source id" :value="vehicle.primaryDataSourceId"/>
            </v-list-item>
            <v-list-item>
              <v-select :readonly="!roles.ASSET_EDIT" prepend-icon="mdi-power" label="Unit active" :items="[true, false]" v-model="isMounted"></v-select>
            </v-list-item>
            <v-list-item>
              <ClickableSelectWithDialog
                @itemClicked="navigateToAssignedDriver"
                @appendIconClicked="assignDriverDialog = true"
                :fieldLabel="'Connected Driver'"
                :itemText="vehicle.currentDriverName ? vehicle.currentDriverName + ' - ' + vehicle.currentDriverUserName : null"
                :icon="'mdi-account'"
                :showCloseIcon="true"
                @closeIconClicked="unassignDriverDialog = true"
                :hasEditRights="roles.ASSET_EDIT"
              ></ClickableSelectWithDialog>
            </v-list-item>
            <v-list-item>
              <ClickableSelectWithDialog
                @itemClicked="navigateToConnectedDataSource"
                :fieldLabel="'Connected DataSource'"
                :itemText="vehicle.primaryDataSourceId"
                :icon="'mdi-cable-data'"
                :showAppendIcon="false"
              ></ClickableSelectWithDialog>
            </v-list-item>
          </v-list>
        </v-col>

        <v-dialog v-model="updateLicensePlateDialog" max-width="38%" persistent>
          <v-card :loading="updateLicensePlateIsLoading">
            <v-card-title>Change license plate</v-card-title>
            <v-divider></v-divider>

            <v-card-text class="mt-6">
              <template v-if="!updateLicensePlateIsLoading">
                <v-text-field prepend-icon="mdi-numeric" label="License plate" v-model="vehicle.licensePlate"></v-text-field>
                <v-checkbox label="Unit has been moved to a new vehicle. Create a new asset with this license plate number." v-if="assetConnectedToDevice" v-model="resetOdometerAndService"></v-checkbox>
              </template>
            </v-card-text>

            <v-card-actions v-if="!updateLicensePlateIsLoading">
              <v-spacer></v-spacer>
              <v-btn color="primary" rounded text @click="updateLicensePlateDialog = false">
                Cancel
              </v-btn>
              <v-btn color="secondary" rounded  @click="UpdateLicensePlate">
                <v-icon>mdi-account-arrow-right</v-icon>
                Save
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>

        <v-dialog width="700" v-model="assignDriverDialog" persistent>
          <AssignDriverWidget :customerId="customer.id" @closeMergeDialog="assignDriverDialog = false" @userSelected="assignDriver"></AssignDriverWidget>
        </v-dialog>

        <v-dialog v-model="unassignDriverDialog" max-width="30%" persistent>
          <v-card>
            <v-card-title class="headline">
              <span>Unassign Driver</span>
            </v-card-title>
            <v-card-text>
              Are you sure you want to unassign the driver of this vehicle?
            </v-card-text>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="primary" text @click="unassignDriverDialog = false">
                Cancel
              </v-btn>
              <v-btn color="primary" text @click="unassignDriver">
                <v-icon>mdi-account-arrow-right</v-icon>
                Unassign
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>
        <MoveEntityDialog
          v-if="moveAssetDialog"
          :mainOfficeId="customer.mainOfficeId"
          :initialCustomerId="this.vehicle.departmentId"
          :title="'Select Department to move asset to'"
          :loading="movePending"
          @closeDialog="moveAssetDialog = false"
          @confirm="assetMove"
          :checkbox-label="'Also move user connected to vehicle'"
        ></MoveEntityDialog>

        <v-col cols="12">
          <v-bottom-navigation grow :background-color="'cardbg'" class="elevation-0">
            <v-btn v-if="roles.ASSET_MOVE" @click="moveAssetDialog = true">
              <span>Move asset</span>
              <v-icon>mdi-domain</v-icon>
            </v-btn>
            <v-btn @click="toggleFavorite">
              <span v-if="isFavorite">Favorite</span>
              <span v-if="!isFavorite">Add to favorites</span>
              <v-icon :color="isFavorite ? 'marked' : ''">mdi-heart</v-icon>
            </v-btn>
          </v-bottom-navigation>
          <v-bottom-navigation grow :background-color="'cardbg'" class="elevation-0" v-if="roles.ASSET_REVISION">
            <v-btn @click="showVehicleRevision = showVehicleRevision + 1">
              <span>Revise Vehicle</span>
              <v-icon>mdi-map-marker-path</v-icon>
            </v-btn>
            <v-btn @click="showUpdateTrips = showUpdateTrips + 1">
              <span>Update Trips</span>
              <v-icon>mdi-update</v-icon>
            </v-btn>
          </v-bottom-navigation>
        </v-col>
      </v-row>
      <v-row>
        <v-col>
          <v-list>
            <v-list-item>
              <v-select @change="updateVehicleMetadataField('objectType', vehicle.objectType, 'VehicleLegalType')" :readonly="!roles.ASSET_EDIT" prepend-icon="mdi-car-cog" :items="getVehicleTypesByCountry()" label="Vehicle type"
                        v-model="vehicle.objectType"></v-select>
            </v-list-item>
            <v-list-item>
              <v-text-field readonly prepend-icon="mdi-car" label="Make" :value="vehicle.make"/>
            </v-list-item>
            <v-list-item>
              <v-text-field readonly prepend-icon="mdi-car" label="Model" :value="vehicle.model"/>
            </v-list-item>
            <v-list-item>
              <v-text-field readonly prepend-icon="mdi-calendar" label="Registration date" :value="vehicle.vehicleCreatedDate | date"/>
            </v-list-item>
            <v-list-item>
              <v-text-field readonly prepend-icon="mdi-beaker-outline" label="Emissions CO2" :value="vehicle.emissionCo2" suffix="g/km"/>
            </v-list-item>
            <v-list-item>
              <v-text-field readonly prepend-icon="mdi-format-color-fill" label="Color" :value="vehicle.color"/>
            </v-list-item>
            <v-list-item>
              <v-text-field readonly prepend-icon="mdi-calendar" label="Road toll profile" :value="vehicle.tollRoadProfile"/>
            </v-list-item>
            <v-list-item>
              <v-text-field readonly prepend-icon="mdi-airplane" label="Current mileage" :value="vehicle.currentMileage" suffix="km"/>
            </v-list-item>
          </v-list>
        </v-col>
      </v-row>
    </v-row>
    <UpdateTrips :trigger="showUpdateTrips" :vehicle="vehicle"></UpdateTrips>
    <VehicleRevision :trigger="showVehicleRevision" :vehicle="vehicle"></VehicleRevision>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import DepartmentPath from "~/components/DepartmentPath";
import UpdateTrips from "@/components/UpdateTrips";
import VehicleRevision from "@/components/VehicleRevision";
import ClickableSelectWithDialog from "@/components/ClickableSelectWithDialog";
import AssignDriverWidget from "@/components/widgets/AssignDriverWidget";
import util from "@/helpers/util";
import logger from "@/logger";
import MoveEntityDialog from "@/components/widgets/dialogs/MoveEntityDialog";

export default {
  name: "VehicleDetails",
  components: { VehicleRevision, DepartmentPath, UpdateTrips, ClickableSelectWithDialog, AssignDriverWidget, MoveEntityDialog },
  props: {
    customer: Object,
    id: String,
    expanded: Boolean,
    mainOfficeHierarchy: Object
  },
  data: function () {
    return {
      initialLoadOfVehicle: null,
      showUpdateTrips: 0,
      showVehicleRevision: 0,
      isLoading: false,
      assignDriverDialog: false,
      unassignDriverDialog: false,
      assignVehicle: {},
      updateLicensePlateDialog: false,
      updateLicensePlateIsLoading: false,
      resetConfirm: false,
      moveAssetDialog: false,
      assetMoveConnected: true,
      originalLicensePlate: "",
      resetOdometerAndService: false,
      movePending: false,
      invalidMove: false
    };
  },
  mounted() {
    this.$store.dispatch("retrieveVehicle", { id: this.id });
  },
  watch: {
    id: function () {
      this.$store.dispatch("retrieveVehicle", { id: this.id });
    },
    vehicle: function () {
      if (!this.vehicle) return
      this.$emit("userIdChange", this.vehicle.currentDriverId);
      this.$emit("dataSourceIdChange", this.vehicle.primaryDataSourceId);
      this.originalLicensePlate = this.vehicle.licensePlate;
      if (this.initialLoadOfVehicle == null) this.initialLoadOfVehicle = JSON.parse(JSON.stringify(this.vehicle));
    }
  },
  methods: {
    async navigateToAssignedDriver() {
      let self = this;
      this.$router.push({ path: `/customer/${this.$route.params.id}?type=account&activeTab=1&id=${this.vehicle.currentDriverId}` }).catch(async function (err) {
        await logger.log('error', 'navigateToAssignedDriver', `navigating to assigned driver failed. Path: /customer/${self.$route.params.id}?type=account&activeTab=1&id=${self.vehicle.currentDriverId} driverId: ${self.vehicle.currentDriverId} Error: ${err}`);
      });
    },
    async navigateToConnectedDataSource() {
      let self = this;
      this.$router.push({ path: `/customer/${this.$route.params.id}?type=simcard&activeTab=5&id=${this.vehicle.primaryDataSourceId}` }).catch(async function (err) {
        await logger.log('error', 'navigateToConnectedDataSource', `navigating to connected data source failed. Path: /customer/${self.$route.params.id}?type=simcard&activeTab=5&id=${self.vehicle.primaryDataSourceId} dataSourceId: ${self.vehicle.primaryDataSourceId} Error: ${err}`);
      });
    },
    async assetMove(moveConnected, destinationId) {
      this.movePending = true
      try {
        let moveToDepartmentHierarchyRes = await axios.get(`/api/customer/hierarchy/${destinationId}/main-office-and-down`)
        await axios.post(`/api/asset/${this.vehicle.assetId}/move/${destinationId}`)
        await this.$store.dispatch("audit", { source: "vehicle", entityId: this.vehicle.id, message: "Move vehicle to department", oldValue: this.vehicle.departmentId, newValue: destinationId })

        this.vehicle.departmentId = destinationId
        this.vehicle.departmentPath = moveToDepartmentHierarchyRes.data.departmentPath
        this.vehicle.departmentName = moveToDepartmentHierarchyRes.data.name

        if (moveConnected && this.vehicle.currentDriverId) {
          await axios.put("/api/user/moveUser", { SelectedId: [this.vehicle.currentDriverId], DestinationId: destinationId })
          await this.$store.dispatch("audit", { source: "vehicle", entityId: this.vehicle.id, message: "Move connected user to department", oldValue: this.vehicle.departmentId, newValue: destinationId });
        }
      } catch (ex) {
        this.$eventBus.$emit("alert", { text: `Failed to move vehicle or connected user`, type: "error" });
      }
      this.movePending = false
      this.moveAssetDialog = false;
    },
    assignDriver(driver) {
      this.isLoading = true;
      let assignedDriver = {};
      assignedDriver.vehicleId = parseInt(this.vehicle.id);
      assignedDriver.userId = driver.id;
      if (driver.id && driver.id !== 0) {
        axios
          .put("/api/vehicle/assignDriver", assignedDriver)
          .then(() => {
            this.$store.dispatch("audit", { source: "vehicle", entityId: assignedDriver.vehicleId, message: "Vehicle Assigned To Driver", oldValue: this.vehicle.currentDriverId, newValue: assignedDriver.userId });
            this.$store.dispatch("audit", {
              source: "account",
              entityId: assignedDriver.userId,
              message: "Vehicle Assigned To Driver",
              oldValue: driver.vehicleAssignedVehicleId !== 0 ? driver.vehicleAssignedVehicleId : "",
              newValue: assignedDriver.vehicleId
            });
          })
          .catch(e => {
            console.log(e);
            this.$eventBus.$emit("alert", { template: "api-error" });
          })
          .finally(() => {
            this.isLoading = false;
            this.$store.dispatch("getVehiclesForDepartment", this.customer.id);
            this.$store.dispatch("retrieveVehicle", { id: this.id });
            this.assignDriverDialog = false;
          });
      } else this.$eventBus.$emit("alert", { template: "api-error" });
    },
    unassignDriver() {
      if (this.vehicle.currentDriverId) {
        this.isLoading = true;
        //unassign driver
        axios
          .put("/api/vehicle/unassignDriver/" + this.vehicle.id)
          .then(() => {
            this.$store.dispatch("audit", { source: "vehicle", entityId: this.id, message: "Vehicle Unassigned from Driver", oldValue: this.vehicle.currentDriverId, newValue: "" });
            this.$store.dispatch("audit", { source: "account", entityId: this.vehicle.currentDriverId, message: "Vehicle Unassigned from Driver", oldValue: this.id, newValue: "" });
          })
          .catch(() => {
            this.$eventBus.$emit("alert", { template: "api-error" });
          })
          .finally(() => {
            this.isLoading = false;
            this.unassignDriverDialog = false;
            this.$store.dispatch("retrieveVehicle", { id: this.id });
            this.$store.dispatch("getVehiclesForDepartment", this.customer.id);
          });
      }
    },
    getVehicleTypesByCountry() {
      switch (this.customer.country) {
        case "DK":
          return [{ text: "PRIVATE" }, { text: "CORPORATE" }];
        case "NO":
          return [{ text: "PRIVATE" }, { text: "CORPORATE" }, { text: "CORPORATE2" }];
        case "FI":
          return [{ text: "PRIVATE" }, { text: "CORPORATE" }, { text: "COMPANY" }];
        case "GB":
          return [{ text: "PRIVATE" }, { text: "CORPORATE" }, { text: "COMPANY" }];
        case "NL":
          return [{ text: "PRIVATE" }, { text: "CORPORATE" }, { text: "COMPANY" }];
        case "SE":
          return [{ text: "PRIVATE" }, { text: "CORPORATE" }, { text: "COMPANY" }];
        case "PL":
          return [{ text: "PRIVATE" }, { text: "CORPORATE" }, { text: "COMPANY" }]
        default:
          return [];
      }
    },
    async UpdateLicensePlate() {
      if (!this.resetOdometerAndService || !this.assetConnectedToDevice) {
        await this.updateVehicleMetadataField("licensePlate", this.vehicle.licensePlate, "RegistrationNumber");
        this.updateLicensePlateDialog = false
        return
      }

      this.updateLicensePlateIsLoading = true
      try {
        let request = {
          AssetId: this.vehicle.assetId,
          DepartmentId: this.vehicle.departmentId,
          NewLicensePlateNumber: this.vehicle.licensePlate,
          SerialNumber: this.vehicle.primaryDataSourceId,
          VehicleLegalType: this.vehicle.objectType
        };
        this.updateLicensePlateIsLoading = true
        let assetIdRes = await axios.put(`/api/vehicle/createVehicleFromPreviousVehicle`, request)
        let newVehicleId = await this.getVehicleIdForNewAssetOnceAvailable(assetIdRes.data)
        if (!newVehicleId) this.$eventBus.$emit("alert", { text: "License plate update requires asset-object re-creation. Operation initialized, but still pending", type: "warning" });
        else await this.$router.push({ path: `/customer/${this.customer.id}?type=vehicle&activeTab=2&id=${newVehicleId}` });
      } catch (ex) {
        this.$eventBus.$emit("alert", { text: "Failed to update license plate and asset re-creation", type: "error" });
        this.vehicle.licensePlate = this.originalLicensePlate;
      } finally {
        this.updateLicensePlateDialog = false
        this.updateLicensePlateIsLoading = false
      }
    },
    async getVehicleIdForNewAssetOnceAvailable(assetId) {
      for (let i = 0; i < 60; i++) {
        await util.sleep(1000)
        let vehicleIdRes = await axios.get(`/api/vehicle/vehicle-id-by-asset-id/${assetId}`)
        if (vehicleIdRes.data) {
          return vehicleIdRes.data
        }
      }
      return null
    },
    async updateVehicleMetadataField(propertyName, value, metadataKey) {
      this.isLoading = true;
      let assetUpdateModel = {
        AssetId: this.vehicle.assetId,
        AktorId: this.vehicle.departmentId,
        Key: metadataKey,
        Value: value,
      }
      try {
        await axios.put(`/api/vehicle`, assetUpdateModel)
        await this.$store.dispatch("audit", {
          source: "vehicle",
          entityId: this.id,
          message: `Update vehicle field: ${metadataKey} (${propertyName})`,
          oldValue: this.initialLoadOfVehicle[propertyName],
          newValue: this.vehicle[propertyName]
        });
      } catch (ex) {
        this.$eventBus.$emit("alert", { text: "Failed updating field on vehicle", type: "error" });
      } finally {
        this.isLoading = false;
        this.initialLoadOfVehicle = JSON.parse(JSON.stringify(this.vehicle));
      }
    },
    async toggleFavorite() {
      let favorite = {
        departmentPath: this.vehicle.departmentPath,
        id: this.vehicle.vehicleId.toString(),
        name: this.vehicle.vehicleId.toString(),
        subName: this.vehicle.alias ?? "",
        type: "Vehicle"
      };
      await this.$store.dispatch("toggleFavorite", favorite);
    }
  },
  computed: {
    isFavorite() {
      return this.$store.state.userSettings?.favorites?.some(x => x.type === "Vehicle" && x.id === this.vehicle.vehicleId?.toString());
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    vehicle() {
      return this.$store.state.SidebarModule.selectedVehicle;
    },
    assetConnectedToDevice() {
      if (!this.vehicle?.primaryDataSourceId) return false
      if (this.vehicle.primaryDataSourceId.startsWith('FAKE')) return false
      return true
    },
    isMounted: {
      get: function () {
        return this.vehicle.isMounted;
      },
      set: async function (value) {
        try {
          await this.$store.dispatch("updateAssetIsMountedState", { id: this.vehicle.assetId, isMounted: value, vehicleId: this.id });
          this.vehicle.isMounted = value
        } catch (ex) {
          this.$eventBus.$emit("alert", { text: "Failed updating vehicle isMounted state", type: "error" });
        }
      }
    },
    mainOfficeHierarchyArray() {
      return [this.mainOfficeHierarchy]
    },
  }
};
</script>

<style scoped>
</style>
