<template>
  <BaseSidebar :menuItems="menuItems" @sidebarSizeChanged="sidebarSizeChanged" @pageChanged="pageChanged">
    <span>
      <VehicleDetails :id="id" :customer="customer" :main-office-hierarchy="mainOfficeHierarchy" :expanded="expanded" v-if="currentPage === 'vehicle-details'"></VehicleDetails>
      <VehicleTrips :id="id" :expanded="expanded" :customer="customer" v-if="currentPage === 'vehicle-trips'"> </VehicleTrips>
      <VehicleAuditDetails :customer="customer" :expanded="expanded" v-if="currentPage === 'audit-details'"></VehicleAuditDetails>
    </span>
  </BaseSidebar>
</template>

<script>
import BaseSidebar from "../BaseSidebar";
import VehicleDetails from "./VehicleDetails";
import VehicleTrips from "./VehicleTrips";
import VehicleAuditDetails from "./VehicleAuditDetails";
export default {
  props: ["id", "customer", "mainOfficeHierarchy"],
  components: { BaseSidebar, VehicleDetails, VehicleTrips, VehicleAuditDetails },
  data() {
    return {
      expanded: false,
      currentPage: "vehicle-details",
      menuItems: [
        { page: "vehicle-details", icon: "mdi-information", expandedAsDefault: false, id: 0 },
        { page: "vehicle-trips", icon: "mdi-vector-polyline", expandedAsDefault: true, id: 1 },
        { page: "audit-details", icon: "mdi-math-log", expandedAsDefault: false, id: 2 }
      ]
    };
  },
  methods: {
    sidebarSizeChanged(state) {
      this.expanded = state;
    },
    pageChanged(page) {
      this.currentPage = page;
    }
  }
};
</script>

<style></style>
