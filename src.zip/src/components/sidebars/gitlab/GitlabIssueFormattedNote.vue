﻿<template>
  <div style="white-space: pre-line" class="text-caption ml-8" v-html="formatNoteBody(this.note.body)"></div>
</template>

<script>
import util from "@/helpers/util";

export default {
  props: ["note"],
  data: () => {
    return {
      attachmentRegex: new RegExp("\\[.*\\]\\(.*\\)", "g"), //eslint-disable-line
      imageFileTypes: [".png", ".jpg", ".jpeg"],
      videoFileTypes: [".mp4"],
    };
  },
  methods: {
    formatNoteBody(body) {
      let bodyWithLinks = util.linkify(body);
      const parsedAttachments = bodyWithLinks.match(this.attachmentRegex);
      let attachmentObject = [];

      if (parsedAttachments !== null) {
        for (let i = 0; i < parsedAttachments.length; i++) {
          const fileName = parsedAttachments[i].substr(0, parsedAttachments[i].lastIndexOf("]")).replace("[", "");
          const url = parsedAttachments[i].substr(parsedAttachments[i].indexOf("(")).replace("(", "").replace(")", "");
          attachmentObject.push({ fileName: fileName, path: this.getAttachmentLink(url) })

          if (this.imageFileTypes.some(x => fileName.includes(x) || this.imageFileTypes.some(x => url.includes(x)))) {
            bodyWithLinks = bodyWithLinks.replace("!" + parsedAttachments[i], `<img
                  style="max-width: 600px; max-height: 600px;"
                  src="${this.getAttachmentLink(url)}"/>`)
          } else if (this.videoFileTypes.some(x => fileName.includes(x)) || this.videoFileTypes.some(x => url.includes(x))) {
            bodyWithLinks = bodyWithLinks.replace(parsedAttachments[i], `<video style="margin: 1rem" width="300" height="300" src="${this.getAttachmentLink(url)}" controls></video>`);
          } else {
            bodyWithLinks = bodyWithLinks.replace(parsedAttachments[i], `<a style="text-decoration-line: none;" href="${this.getAttachmentLink(url)}" target="_blank">${fileName}</a>`)
          }
        }
      }
      return bodyWithLinks;
    },
    getAttachmentLink(url) {
      return `https://gitlab.planetabax.com/${this.getGitlabIssue.references.full.substring(0,
        this.getGitlabIssue.references.full.indexOf("#")).replace("#", "")}/${url.substr(1)}`;
    },
  },
  computed: {
    getGitlabIssue() {
      return this.$store.state.GitlabModule.linkedGitlabIssue;
    },
  }
};
</script>

<style></style>
