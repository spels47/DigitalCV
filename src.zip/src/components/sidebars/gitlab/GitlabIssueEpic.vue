﻿<template>
  <div class="mt-3">
    <span style="display: block; font-weight: bold">Epic</span>
    <a :href="getEpicLink" target="_blank">{{getEpicTitle}}</a>
  </div>
</template>

<script>
export default {
  props: ["issue"],
  computed: {
    getEpicTitle() {
      return this.issue.epic.title;
    },
    getEpicLink() {
      // /groups/ram/-/epics/5
      return `https://gitlab.planetabax.com/${this.issue.epic.url}`;
    }
  }
};
</script>

<style scoped>
a {
  text-decoration: none;
  color: #303030;
}

a:hover {
  color: #064787;
  text-decoration: underline;
}
</style>
