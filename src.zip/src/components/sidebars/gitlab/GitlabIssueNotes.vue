﻿<template>
  <v-dialog persistent v-model="show" width="1250">
    <v-card
      class="mx-auto"
      max-width="1250"
    >
      <v-card
        dark
        flat
      >
        <v-card-title class="pa-2 blue darken-2">
          <h3 class="text-h6 font-weight-light text-center grow">
            Issue history/notes
          </h3>
          <v-icon style="cursor: pointer" @click="show = false" large>mdi-close</v-icon>
        </v-card-title>
      </v-card>
      <v-card-text class="py-0">
        <v-timeline
          align-top
          dense
        >
          <v-timeline-item color="blue darken-1" v-for="note in notes" :key="note.id" small>
            <v-row class="pt-1">
              <v-col cols="3">
                <strong>{{parseIsoDatetime(note.updatedAt)}}</strong>
              </v-col>
              <v-col>
                <v-avatar size="25">
                  <img :src="note.gitlabAuthor.avatarUrl"/></v-avatar>
                <strong class="ml-2">{{note.gitlabAuthor.name}} - {{getTimeSince(note.createdAt)}} ago</strong>
                <FormattedNote :note="note"/>
              </v-col>
            </v-row>
          </v-timeline-item>
        </v-timeline>
      </v-card-text>
    </v-card>
  </v-dialog>
</template>

<script>
import util from "@/helpers/util";
import FormattedNote from "../gitlab/GitlabIssueFormattedNote";

export default {
  props: ["issue", "showDialog"],
  components: {
    FormattedNote
  },
  data: function() {
    return {
      dateOptions: { weekday: 'short', year: 'numeric', month: 'long', day: 'numeric' },
      notes: [],
    }
  },
  watch: {
    issue: function (newVal) {
      if (!newVal.notes) return [];
      this.notes = newVal.notes.sort(function (a,b) { return new Date(b.updatedAt) - new Date(a.updatedAt)});
    },
  },
  methods: {
    getTimeSince(time) {
      return util.getTimeSince(new Date(time))
    },
    parseIsoDatetime(dtstr) {
      const dt = dtstr.split(/[: T-]/).map(parseFloat);
      return new Date(dt[0], dt[1] - 1, dt[2], dt[3] || 0, dt[4] || 0, dt[5] || 0, 0).toLocaleString("en-US", this.dateOptions);
    },
  },
  computed: {
    getGitlabIssue() {
      return this.$store.state.GitlabModule.linkedGitlabIssue;
    },
    show: {
      get() {
        return this.showDialog;
      },
      set(value) {
        if (!value) {
          this.$emit("closeDialog");
        }
      }
    }
  }
};
</script>

<style></style>
