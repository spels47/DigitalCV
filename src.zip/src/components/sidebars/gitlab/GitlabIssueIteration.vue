﻿<template>
  <div class="mt-3">
    <span style="display: block; font-weight: bold">Iteration</span>
    <a :href="getIterationLink" target="_blank">{{getIterationTitle}}</a>
  </div>
</template>

<script>
export default {
  props: ["issue"],
  computed: {
    getIterationTitle() {
      return this.issue.iterations.title;
    },
    getIterationLink() {
      return `https://gitlab.planetabax.com/${this.issue.references.full.substring(0, this.issue.references.full.indexOf("#")).replace("#", "")}/-/${this.issue.iterations.iid}`;
    }
  }
};
</script>

<style scoped>
a {
  text-decoration: none;
  color: #303030;
}

a:hover {
  color: #064787;
  text-decoration: underline;
}
</style>
