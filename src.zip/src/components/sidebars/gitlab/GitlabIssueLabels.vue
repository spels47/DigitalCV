﻿<template>
  <div class="mt-3">
    <span class="font-weight-bold d-block">Labels</span>
    <div class="mt-2">
      <v-chip
        v-for="(label, index) in getLabels" :key="index"
        :outlined="!beOutlined(label)"
        class="mr-2" :text-color="!beOutlined(label) ? 'black' : 'white'"
        v-html="getLabel(label)"
        :color="getLabelColor(label)"
      ></v-chip>
    </div>
  </div>
</template>

<script>
export default {
  props: ["issue"],
  data: () => {
    return {
      labelColors: [ "green", "red", "blue", "yellow", "#B676B1", "#E6E6FA" ],
      outlinedLabels: ["bug", "customer", "incident"]
    };
  },
  methods: {
    getLabelColor(label) {
      switch (label.toLowerCase()) {
        case "bug":
          return "#FF0000";
        case "customer":
          return "#F0AD4E";
        case "incident":
          return "#CC0033";
      }

      let color = this.labelColors[Math.floor(Math.random() * this.labelColors.length)];
      return color.startsWith("#") ? color : `${color} darken-3`;
    },
    getLabel(label) {
      if (label.includes(":")) {
        label = label.substring(0, label.indexOf("::")).replace("::", "")
          + " : "
          + label.substring(label.indexOf("::")).replace("::", "");
      }
      return label.charAt(0).toUpperCase() + label.slice(1);
    },
    beOutlined(label) {
      return this.outlinedLabels.some(x => x === label.toLowerCase());
    }
  },
  computed: {
    getLabels() {
      return this.issue.labels;
    },
  }
};
</script>

<style></style>
