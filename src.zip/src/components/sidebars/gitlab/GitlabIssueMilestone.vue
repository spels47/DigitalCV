﻿<template>
  <div class="mt-3">
    <span style="display: block; font-weight: bold">Milestone</span>
    <a :href="getMilestoneLink" target="_blank">{{getMilestoneTitle}}</a>
  </div>
</template>

<script>
export default {
  props: ["issue"],
  computed: {
    getMilestoneTitle() {
      return this.issue.milestone.title;
    },
    getMilestoneLink() {
      return `https://gitlab.planetabax.com/${this.issue.references.full.substring(0, this.issue.references.full.indexOf("#")).replace("#", "")}/-/milestones/${this.issue.milestone.iid}`;
    }
  }
};
</script>

<style scoped>
a {
  text-decoration: none;
  color: #303030;
}

a:hover {
  color: #064787;
  text-decoration: underline;
}
</style>
