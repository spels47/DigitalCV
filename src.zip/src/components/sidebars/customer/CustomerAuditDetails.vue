<template>
  <v-container>
    <v-row>
      <v-col>
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-title class="headline">
                <span>Customer Audit Log</span>
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <v-list>
          <v-data-table :headers="getHeaders()" :items="auditLog">
            <template v-slot:item.timestamp="{ item }"> {{ convertToCustomerDatetime(item.timestamp) }}</template>
          </v-data-table>
        </v-list>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "@/axios-client";
import util from "@/helpers/util";

export default {
  name: "AccountAuditDetails",
  props: {
    id: String,
    expanded: Boolean,
    customer: Object,
  },
  components: {},
  data: function() {
    return {
      isLoading: true,
      auditLog: [],
      auditHeaders: [
        { text: "Date", value: "timestamp" },
        { text: "Change", value: "message" },
        { text: "New Value", value: "newValue" }
      ],
      auditHeadersLong: [
        { text: "Date", value: "timestamp" },
        { text: "Change", value: "message" },
        { text: "Old Value", value: "oldValue" },
        { text: "New Value", value: "newValue" },
        { text: "Responsible", value: "name" }
      ]
    };
  },
  mounted() {
    this.getAuditLog();
  },
  methods: {
    getHeaders() {
      if (this.expanded) {
        return this.auditHeadersLong;
      }
      return this.auditHeaders;
    },
    getAuditLog() {
      axios.get(`/api/audit?sourceType=customer&id=` + this.id).then(res => {
        this.auditLog = res.data;
      });
    },
    formatDate(date) {
      return util.setupGlobalDateHelper(new Date(date));
    },
    convertToCustomerDatetime(date){
      return util.getDateTimeByCountry(date, this.customer.country )
    },
  },
  computed: {
    account() {
      return this.$store.state.SidebarModule.selectedAccount;
    }
  }
};
</script>

<style scoped></style>
