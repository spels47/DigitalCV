<template>
  <v-container fluid>
    <v-row>
      <v-progress-linear v-show="loading" indeterminate></v-progress-linear>
      <v-col>
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath clickable :department-path="customer.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                <span>Customer Settings</span>
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
        <v-list>
          <v-list-item
            v-for="setting in editableCustomerSettings"
            :key="setting.label"
          >
            <v-switch
              v-if="setting.editable"
              :readonly="!roles.CUSTOMER_SETTINGS_EDIT"
              :disabled="loading"
              :label="setting.label"
              v-model="setting.value"
              color="secondary"
              dense
              @change="updateCustomerSetting(setting)"
            ></v-switch>
          </v-list-item>

          <v-divider></v-divider>
          <v-list dense>
            <v-list-item>
              <v-text-field prepend-icon="mdi-check-decagram" readonly label="TCO agreement" :value="tcoConsent"></v-text-field>
            </v-list-item>
            <v-list-item>
              <v-text-field prepend-icon="mdi-check-decagram" readonly label="DB consent" :value="drivingBehaviourConsentStatus"></v-text-field>
            </v-list-item>
            <v-list-item>
              <v-text-field prepend-icon="mdi-check-decagram" readonly label="MAP consent" :value="mapConsentStatus"></v-text-field>
            </v-list-item>
          </v-list>

          <div v-if="roles.CUSTOMER_SETTINGS_EDIT">
            <v-btn block class="mt-4 primary" :disabled="tcoConsent !== 'Denied'" @click="resetTcoConsent" :loading="resettingTcoConsent">Reset TCO agreement</v-btn>
            <v-btn block class="mt-4 primary" :disabled="!showConsentResetDrivingBehaviour" @click="resetConsentDrivingBehaviour">Reset DrivingBehaviour consent</v-btn>
            <v-btn block class="mt-4 primary" :disabled="!showConsentResetFleetMap" @click="resetConsentFleetMap">Reset FleetMap consent</v-btn>
          </div>
        </v-list>
        <v-divider></v-divider>
        <v-list>
          <v-list-item v-for="setting in unEditableCustomerSettings" v-bind:key="setting.label">
            <v-switch
              v-if="!setting.editable"
              :label="setting.label"
              v-model="setting.value"
              disabled
              color="primary"
              dense
            ></v-switch>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <ConfirmDialog ref="confirm"></ConfirmDialog>
  </v-container>
</template>

<script>
import axios from "@/axios-client";
import DepartmentPath from "~/components/DepartmentPath";
import ConfirmDialog from "~/components/widgets/dialogs/ConfirmDialog";

export default {
  components: { DepartmentPath, ConfirmDialog },
  props: ["customer"],
  data() {
    return {
      loading: true,
      resettingTcoConsent: false,
      customerSettings: [
        {
          label: "Access to set work trip ",
          AktorSettings: ["WorkTrip"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Access to set work trip for company car",
          AktorSettings: ["triplog_WTCompany"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Access to set work trip for corporate car",
          AktorSettings: ["triplog_WTCorporate"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Access to export to Visma.net Expense",
          AktorSettings: ["triplog_VismaExpense"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Access to optional registration numbers",
          AktorSettings: ["triplog_RegnoInt"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "DriversID: Admin sees all vehicle trips driver independent",
          AktorSettings: ["triplog_AdminSeeDept"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Enable approval step for submitted triplogs",
          AktorSettings: ["triplog_ApprTriplog"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Free / Busy functionality",
          AktorSettings: ["triplog_StatusButton"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Live labels",
          AktorSettings: ["Map_Label", "LiveJumpyLabels"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Require union representative logon - Show trips",
          AktorSettings: ["triplog_ReqUnionRep"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Minimized driving behaviour",
          AktorSettings: ["dribeh_MinimizedUI"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Access to sales channel",
          AktorSettings: ["triplog_SaleInApp"],
          value: false,
          editable: true,
          DevLock: true
        },
        // All below are controlled by ERP
        {
          label: "Access to ABAX Mini",
          AktorSettings: ["AbaxMini"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Access to Parking",
          AktorSettings: ["triplog_ParkNGo"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Access to multi-sending of SMS to drivers",
          AktorSettings: ["triplog_SendMultiSMS"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Access to RFID Transmitter log",
          AktorSettings: ["triplog_RFIDTrans"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Access to Toll Road Admin",
          AktorSettings: ["triplog_TollRdAdm", "triplog_TollRoad"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Access to traffic layer in the map (beta)",
          AktorSettings: ["triplog_Traffic"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Send SMS reminder about missing mileage reading",
          AktorSettings: ["triplog_KmRemindSMS"],
          value: false,
          editable: true,
          DevLock: false
        },
        {
          label: "Show speed in map",
          AktorSettings: ["triplog_ShowSpeedInMap"],
          value: false,
          editable: true,
          DevLock: false
        }
      ],
      tcoConsent: null,
      dbConsent: null,
      rawAktorSettings: []
    };
  },
  async mounted() {
    await this.getCustomerSettings();
    await this.checkTcoStatus();
  },
  methods: {
    async checkTcoStatus() {
      const { data: tco } = await axios.get(`/api/customer/tco/${this.customer.id}`);

      if (!tco)
        this.tcoConsent = "N/A";
      else if (tco.consentDialogStatus === "1")
        this.tcoConsent = "Pending";
      else if (tco.consentDialogStatus === "consented" || tco.consentDialogStatus === "denied")
        this.tcoConsent = this.$utils.capitalizeFirstLetter(tco.consentDialogStatus);
      else
        this.tcoConsent = "N/A";
    },
    async getCustomerSettings() {
      let res = await axios.get(`/api/customer/GetCustomerSettings/${this.customer.id}`);
      this.rawAktorSettings = res.data.aktorSettings;
      this.customerSettings.forEach(customerSetting => {
        let val = true;
        customerSetting.AktorSettings.forEach(setting => {
          let settingVal = res.data.aktorSettings.find(s => s.parameterName === setting);
          if (!settingVal || !settingVal?.parameterValue || settingVal?.parameterValue === '0')
            val = false;
        });
        customerSetting.value = val;
      });
      this.loading = false;
    },
    async updateCustomerSetting(setting) {
      this.loading = true;
      if (!setting.DevLock || (setting.DevLock && this.roles.DEVELOPER_ASAP)) {
        setting.AktorSettings.forEach(aktorSetting => {
          axios
            .put(`/api/customer/UpdateCustomerSettings`, {
              AktorId: this.customer.id,
              SettingName: aktorSetting,
              Value: setting.value
            })
            .then(res => {
              this.$store.dispatch("audit", {
                source: "customer",
                entityId: this.customer.id,
                message: "Update Customer Setting: " + aktorSetting,
                oldValue: !setting.value,
                newValue: setting.value
              });
            })
            .finally(async () => {
              await this.getCustomerSettings();
            });
        });
      } else {
        await this.getCustomerSettings();
      }
    },
    async resetConsentDrivingBehaviour() {
      let confirmed = await this.$refs.confirm.open('Reset', 'Are you sure? This will remove feature 1400 on all units for this customer and reset the consent dialog so the customer can choose to consent or not again', {
        width: 700,
        preformatted: true
      });
      if (!confirmed) return;
      this.loading = true;
      try {
        await axios.post(`/api/customer/ResetAccessUpgradeConsent/${this.customer.id}/DrivingBehaviour`);
        await this.getCustomerSettings();
        await this.$store.dispatch("audit", { source: "customer", entityId: this.customer.id, message: "Reset consent for DrivingBehaviour" });
      } catch (ex) {
        this.$eventBus.$emit("alert", { text: "Failed saving the customer setting", type: "error" });
      }
      this.loading = false;
    },
    async resetConsentFleetMap() {
      let confirmed = await this.$refs.confirm.open('Reset', 'Are you sure? This will remove feature 2000 on all units for this customer and reset the consent dialog so the customer can choose to consent or not again', {
        width: 700,
        preformatted: true
      });
      if (!confirmed) return;
      this.loading = true;
      try {
        await axios.post(`/api/customer/ResetAccessUpgradeConsent/${this.customer.id}/FleetMap`);
        await this.getCustomerSettings();
        await this.$store.dispatch("audit", { source: "customer", entityId: this.customer.id, message: "Reset consent for FleetMap" });
      } catch (ex) {
        this.$eventBus.$emit("alert", { text: "Failed saving the customer setting", type: "error" });
      }
      this.loading = false;
    },
    async resetTcoConsent() {
      if (this.resettingTcoConsent)
        return;

      this.resettingTcoConsent = true;

      try {
        await axios.put(`/api/customer/tco/${this.customer.id}/reset`);
        await this.checkTcoStatus();
      } catch {
        this.$eventBus.$emit("alert", { text: "Failed resetting TCO consent", type: "error" });
      } finally {
        this.resettingTcoConsent = false;
      }
    }
  },
  computed: {
    editableCustomerSettings() {
      let conditionalSettings = [];
      return this.customerSettings.filter(i => i.editable === true).concat(conditionalSettings);
    },
    unEditableCustomerSettings() {
      let conditionalSettings = [];
      if (this.customer && this.customer.country === "FIN") {
        conditionalSettings.push({
          label: "Access to Per diem",
          AktorSettings: ["triplog_PerDiem"],
          value: true,
          editable: false
        });
      }
      return this.customerSettings.filter(i => !i.editable).concat(conditionalSettings);
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    drivingBehaviourConsentStatus() {
      if (this.rawAktorSettings.length === 0)
        return "N/A";

      const value = this.rawAktorSettings.find(x => x.parameterName === "dribeh_CapabilityToggleDialog");
      if (!value)
        return "N/A";

      let { parameterValue } = value;

      if (!parameterValue)
        return "N/A";
      else if (parameterValue === "1")
        return "Pending";
      else if (parameterValue === "consented" || parameterValue === "denied")
        return this.$utils.capitalizeFirstLetter(parameterValue);
      else
        return "N/A";
    },
    mapConsentStatus() {
      if (this.rawAktorSettings.length === 0)
        return "N/A";

      const value = this.rawAktorSettings.find(x => x.parameterName === "Map_CapabilityToggleDialog");
      if (!value)
        return "N/A";

      let { parameterValue } = value;

      if (!parameterValue)
        return "N/A";
      else if (parameterValue === "1")
        return "Pending";
      else if (parameterValue === "consented" || parameterValue === "denied")
        return this.$utils.capitalizeFirstLetter(parameterValue);
      else
        return "N/A";
    },
    showConsentResetDrivingBehaviour() {
      return this.rawAktorSettings.some(x => x.parameterName === 'dribeh_CapabilityToggleDialog' && (x.parameterValue === 'consented' || x.parameterValue === 'denied'));
    },
    showConsentResetFleetMap() {
      return this.rawAktorSettings.some(x => x.parameterName === 'Map_CapabilityToggleDialog' && (x.parameterValue === 'consented' || x.parameterValue === 'denied'));
    }
  }
};
</script>

<style></style>
