<template>
  <BaseSidebar :menuItems="menuItems" @sidebarSizeChanged="sidebarSizeChanged" @pageChanged="pageChanged">
    <span>
      <!-- <CustomerAuditDetails :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'customer-audit'"></CustomerAuditDetails> -->
      <CustomerSettings :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'customer-settings'"></CustomerSettings>
    </span>
  </BaseSidebar>
</template>

<script>
import BaseSidebar from "../BaseSidebar";
// import CustomerAuditDetails from "./CustomerAuditDetails";
import CustomerSettings from "./CustomerSettings";
export default {
  props: ["id", "customer"],
  components: {
    // CustomerAuditDetails,
    CustomerSettings,
    BaseSidebar
  },
  data() {
    return {
      expanded: false,
      currentPage: "customer-settings"
    };
  },
  methods: {
    sidebarSizeChanged(state) {
      this.expanded = state;
    },
    pageChanged(page) {
      this.currentPage = page;
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
    menuItems() {
      return [
        { page: "customer-settings", icon: "mdi-cog", expandedAsDefault: false, id: 0 }
        // { page: "customer-audit", icon: "mdi-math-log", expandedAsDefault: false, id: 1 }
      ];
    }
  }
};
</script>

<style></style>
