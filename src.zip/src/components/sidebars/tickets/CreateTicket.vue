﻿<template>
  <v-dialog
    :value="showDialog"
    width="700"
    persistent
  >
    <v-card class="rounded-lg">
      <v-card-title>
        <span>Create a new ticket</span>
        <v-spacer></v-spacer>

        <v-btn
          :disabled="creatingTicket"
          icon
          @click="showDialog = false"
        >
          <v-icon size="30">mdi-close</v-icon>
        </v-btn>

      </v-card-title>

      <v-divider></v-divider>

      <v-card-text class="mt-4">
        <v-text-field
          label="Title"
          prepend-icon="mdi-text-short"
          v-model="ticketData.title"
          autofocus
        ></v-text-field>

        <v-select
          :items="priorities"
          label="Priority"
          prepend-icon="mdi-priority-low"
          item-text="text"
          item-value="id"
          v-model="priority"
          return-object
        ></v-select>

        <v-select
          :items="topLevelCategories"
          label="Category"
          prepend-icon="mdi-drawing"
          item-text="text"
          item-value="id"
          v-model="category"
          return-object
        ></v-select>

        <v-select
          :items="applicableSubCategories"
          :disabled="!category"
          v-model="subCategory"
          label="Sub-category"
          prepend-icon="mdi-arrow-down"
          item-text="text"
          item-value="id"
          clearable
          return-object
        ></v-select>

        <v-textarea
          label="Message"
          prepend-icon="mdi-text"
          v-model="ticketData.message"
          auto-grow
        ></v-textarea>
      </v-card-text>

      <v-card-actions>
        <v-spacer></v-spacer>

        <v-btn
          :loading="creatingTicket"
          :disabled="missingData"
          color="secondary"
          @click="createTicket"
        >
          <v-icon left>mdi-plus</v-icon>
          Create
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import axios from "~/axios-client";
import { getApplicableSubCategoriesFromTopCategory, determineCategoryId } from "@/helpers/create-ticket-helpers";

export default {
  name: "CreateTicket",
  props: {
    show: {
      type: Boolean,
      required: true
    }
  },
  data() {
    return {
      priorities: [
        { id: -2, text: "(Automatic)" },
        { id: 1, text: "Low" },
        { id: 2, text: "Normal" },
        { id: 4, text: "Development" },
        { id: 3, text: "Critical" }
      ],
      topLevelCategories: [
        { id: 1, text: "01 New Customer or existing wants to buy", categoryId: 838 },
        { id: 2, text: "02 Customer has issues with delivery", categoryId: 898 },
        { id: 3, text: "03 Customer has invoice or financial issues", categoryId: 901 },
        { id: 4, text: "04 Customer has issues with contact", categoryId: 910 },
        { id: 5, text: "05 Customer wishes to change customer details", categoryId: 913 },
        { id: 6, text: "06 Customer needs to move unit", categoryId: 917 },
        { id: 7, text: "07 Customers wants to reduce or end contract", categoryId: 921 },
        { id: 8, text: "08 Customer is experiencing a system issue", categoryId: 926 },
        { id: 9, text: "09 Customer is experiencing a hardware error", categoryId: 937 },
        { id: 10, text: "10 Customer needs help or training to use the system", categoryId: 848 },
        { id: 11, text: "11 Customer needs workaround for system restrictions or issues", categoryId: 958 },
        { id: 12, text: "12 Customer has issues with GDPR, Tax or Compliance", categoryId: 845 },
        { id: 13, text: "13 Customer is affected by an Abax technical incident", categoryId: 857 },
        { id: 14, text: "14 Customer has an Improvement suggestion or complaint", categoryId: 861 },
        { id: 15, text: "15 Internal workflows", categoryId: 865 }
      ],
      creatingTicket: false,
      category: null,
      subCategory: null,
      priority: null,
      ticketData: {
        title: null,
        message: null
      }
    }
  },
  mounted() {
    /*
    Make "Normal" the default priority.
    Initially wanted to do this in data(), but seems like the property is undefined.
     */
    this.priority = this.priorities[2];
  },
  watch: {
    category() {
      this.subCategory = null;
    }
  },
  methods: {
    async createTicket() {
      this.creatingTicket = true;

      try {
        this.ticketData.ticketCategoryId = determineCategoryId(this.category, this.subCategory)
        this.ticketData.ticketPriorityId = this.priority.id;

        const { data: ticket } = await axios.post("api/ticket", this.ticketData);
        this.$emit("createdTicket", ticket);

        this.$eventBus.$emit("alert", { text: "Successfully created the ticket.", type: "success" });
        this.showDialog = false;
      } catch {
        this.$eventBus.$emit("alert", { text: "There was a problem creating the ticket.", type: "error" });
      } finally {
        this.creatingTicket = false;
      }
    }
  },
  computed: {
    applicableSubCategories() {
      return getApplicableSubCategoriesFromTopCategory(this.category?.id) ?? [];
    },
    missingData() {
      return (this.ticketData?.title === null || this.ticketData?.title === "" || this.ticketData?.title?.trim() === "") || this.priority === null || this.category === null;
    },
    showDialog: {
      get() {
        return this.show;
      },
      set(value) {
        if (!value)
          this.$emit("close")
      }
    }
  }
}
</script>

<style scoped>

</style>
