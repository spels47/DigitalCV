﻿<template>
  <v-card
    @click.stop="expanded = !expanded"
    :ripple="false"
  >
    <v-card-title>
      <v-icon size="20">mdi-account</v-icon>
      <span class="ml-2 subtitle-1">{{ message.author }}</span>

      <v-spacer></v-spacer>

      <v-chip
        outlined
        small
      >
        {{ formatDate(message.createdAt) }}
      </v-chip>

      <v-btn
        icon
        @click.stop="expanded = !expanded"
      >
        <v-icon>{{ expanded ? 'mdi-chevron-up' : 'mdi-chevron-down' }}</v-icon>
      </v-btn>
    </v-card-title>

    <v-expand-transition>
      <v-card-text v-show="expanded">
        <v-progress-circular
          v-if="fetching"
          indeterminate
          size="30"
          width="3"
          color="primary"
        ></v-progress-circular>

        <template v-else>
          <pre
            v-html="messageMetadata.body"
            class="subtitle-2 mt-6"
          >
          </pre>
        </template>
      </v-card-text>
    </v-expand-transition>
  </v-card>
</template>

<script>
import axios from "@/axios-client";

export default {
  name: "TicketMessage",
  props: {
    customer: {
      type: Object,
      required: true
    },
    message: {
      type: Object,
      required: true
    },
    search: {
      type: String,
      required: true
    },
    messageIndex: {
      type: Number,
      required: true
    }
  },
  data() {
    return {
      expanded: false,
      fetching: true,
      messageMetadata: null
    }
  },
  async mounted() {
    this.expanded = this.messageIndex < 3;
    await this.fetchTicketMessage();
  },
  watch: {
    search(newValue) {
      if (newValue.trim() === "") {
        this.expanded = this.messageIndex < 3;
        return;
      }

      if (this.messageContainsSearch)
        this.expanded = true;
    }
  },
  methods: {
    async fetchTicketMessage() {
      try {
        const { data: metadata } = await axios.get(`/api/ticket/message/${this.message.ticketMessageId}`);
        this.messageMetadata = metadata;

        if (this.messageContainsSearch)
          this.expanded = true;
      } finally {
        this.fetching = false;
      }
    },
    formatDate(date) {
      return this.$utils.getDateTimeByCountry(date, this.customer.country, false);
    }
  },
  computed: {
    messageContainsSearch() {
      return !this.messageMetadata?.body ? false : this.$utils.stringContainsWord(this.messageMetadata.body, this.search);
    }
  }
}
</script>

<style scoped>

</style>
