﻿<template>
  <v-container>
    <v-row>
      <v-col cols="lg-12">
        <v-list two-line>
          <v-list-item>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath :department-path="customer.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                <span>Ticket messages</span>
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="lg-12">
        <v-text-field
          v-bind:value="messageSearch"
          v-on:input="setSearch($event)"
          label="Search"
          prepend-inner-icon="mdi-magnify"
        ></v-text-field>

        <v-textarea
          v-model="ticketMessage"
          label="Write message"
          rows="2"
          auto-grow
          outlined
        >
          <template #append>
            <v-fade-transition>
              <v-btn
                v-if="validTicketMessage"
                :loading="addingTicketMessage"
                @click="createTicketMessage"
                class="mb-2"
                color="secondary"
                dark
                x-small
                fab
              >
                <v-icon>mdi-plus</v-icon>
              </v-btn>
            </v-fade-transition>
          </template>
        </v-textarea>

        <TicketMessage
          v-for="(message, index) in sortedMessages"
          :key="message.ticketMessageId"
          :message="message"
          :customer="customer"
          :search="messageSearch"
          :message-index="index"
          :class="index > 0 ? 'mt-5' : ''"
        >
        </TicketMessage>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import TicketMessage from "@/components/sidebars/tickets/TicketMessage";
import DepartmentPath from "@/components/DepartmentPath";
import axios from "@/axios-client";

export default {
  name: "CustomerTicketMessages",
  components: { DepartmentPath, TicketMessage },
  props: {
    ticketId: {
      type: Number
    },
    customer: {
      type: Object
    },
    messages: {
      type: Array
    }
  },
  data() {
    return {
      messageSearch: "",
      ticketMessage: "",
      addingTicketMessage: false
    }
  },
  methods: {
    setSearch(event) {
      this.messageSearch = event;
    },
    async createTicketMessage() {
      this.addingTicketMessage = true;

      try {
        await axios.post("api/ticket/message", {
          ticketId: this.ticketId,
          body: this.ticketMessage
        });

        // This actually does a complete re-fetching of the ticket, which then causes the ticket messages to get re-fetched again.
        // Not entirely sure if this is a feasible approach, but it'll work for now.
        this.$emit("fetchTicketMessages");

        this.ticketMessage = "";

        this.$eventBus.$emit("alert", { text: "Successfully added ticket message.", type: "success" });
      } catch {
        this.$eventBus.$emit("alert", { text: "There was a problem adding the ticket message.", type: "error" });
      } finally {
        this.addingTicketMessage = false;
      }
    }
  },
  computed: {
    validTicketMessage() {
      return this.ticketMessage && this.ticketMessage.trim() !== "" && this.ticketMessage !== "";
    },
    sortedMessages() {
      // eslint-disable-next-line vue/no-side-effects-in-computed-properties
      return this.messages.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }
  }
}
</script>

<style scoped>

</style>
