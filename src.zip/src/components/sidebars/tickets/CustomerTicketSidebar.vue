﻿<template>
  <BaseSidebar
    :normal-width="700"
    :menuItems="menuItems"
    @sidebarSizeChanged="sidebarSizeChanged"
    @pageChanged="pageChanged"
  >
    <CustomerTicketDetails
      v-if="currentPage === 'ticket-details'"
      :fetching-ticket="fetchingTicket"
      :ticket="fetchedTicket"
      :customer="customer"
    ></CustomerTicketDetails>
    <CustomerTicketMessages
      v-if="currentPage === 'ticket-messages'"
      :ticket-id="fetchedTicket.ticketId"
      :messages="fetchedTicket.ticketMessages"
      :customer="customer"
      @fetchTicketMessages="fetchTicket"
    ></CustomerTicketMessages>
  </BaseSidebar>
</template>

<script>
import BaseSidebar from "../BaseSidebar";
import CustomerTicketDetails from "@/components/sidebars/tickets/CustomerTicketDetails";
import CustomerTicketMessages from "@/components/sidebars/tickets/CustomerTicketMessages";
import axios from "@/axios-client";

export default {
  name: "CustomerTicketSidebar",
  props: ["customer", "ticket"],
  components: {
    CustomerTicketMessages,
    CustomerTicketDetails,
    BaseSidebar
  },
  data() {
    return {
      currentPage: "ticket-details",
      fetchingTicket: false,
      fetchedTicket: {}
    };
  },

  async mounted() {
    await this.fetchTicket();
  },
  methods: {
    async fetchTicket() {
      if (this.ticket === undefined) {
        this.$emit("closeSidebar");
        return;
      }

      this.fetchingTicket = true;

      try {
        const { data: ticket } = await axios.get(`/api/ticket/${this.ticket.ticketId}`);
        this.fetchedTicket = ticket;
      } finally {
        this.fetchingTicket = false;
      }
    },
    sidebarSizeChanged(state) {
      this.expanded = state;
    },
    pageChanged(page) {
      this.currentPage = page;
    }
  },
  computed: {
    menuItems() {
      if (Object.keys(this.fetchedTicket).length === 0) {
        return [
          { page: "ticket-details", icon: "mdi-information", expandedAsDefault: false, id: 0 },
        ];
      } else {
        return [
          { page: "ticket-details", icon: "mdi-information", expandedAsDefault: false, id: 0 },
          { page: "ticket-messages", icon: "mdi-forum", expandedAsDefault: true, id: 1 }
        ];
      }
    }
  }
};
</script>

<style></style>
