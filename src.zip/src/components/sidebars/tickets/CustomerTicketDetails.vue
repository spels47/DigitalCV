﻿<template>
  <v-container>
    <v-row>
      <v-progress-linear
        v-if="fetchingTicket"
        indeterminate
      ></v-progress-linear>
      <v-col cols="lg-12">
        <v-list two-line>
          <v-list-item>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath :department-path="customer.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                <span>Ticket details</span>
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="lg-12">
        <v-list min-width="100">
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-identifier" label="Ticket ID" :value="ticket.ticketId"/>
          </v-list-item>
          <v-list-item>
            <v-text-field v-if="title.length < 75" readonly prepend-icon="mdi-text-short" label="Title" :value="title"/>
            <v-textarea v-else no-resize auto-grow readonly outlined prepend-icon="mdi-text-short" label="Title" :value="title"/>
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-account" label="Author" :value="ticket.author"/>
          </v-list-item>
        </v-list>
      </v-col>

      <v-col cols="lg-12">
        <v-list min-width="100">
          <v-list-item>
            <v-text-field readonly :prepend-icon="priority === 'High' ? 'mdi-priority-high' : 'mdi-priority-low'" label="Priority" :value="priority"/>
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-shape" label="Category" :value="category"/>
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-help" label="Status" :value="ticket.baseStatus"/>
          </v-list-item>
        </v-list>
      </v-col>

      <v-col cols="lg-12">
        <v-list min-width="100">
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-calendar-plus" label="Deadline" :value="formatDate(ticket.deadline)"/>
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-calendar-edit" label="Last updated" :value="formatDate(ticket.lastChanged)"/>
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-calendar-alert" label="Created" :value="formatDate(ticket.createdAt)"/>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import DepartmentPath from "@/components/DepartmentPath";

export default {
  name: "CustomerTicketDetails",
  components: { DepartmentPath },
  props: ["customer", "fetchingTicket", "ticket"],
  data() {
    return {}
  },
  methods: {
    formatDate(date) {
      if (!date)
        return "";

      return this.$utils.getDateTimeByCountry(date, this.customer.country, false);
    }
  },
  computed: {
    title() {
      return this.ticket?.title ?? "";
    },
    priority() {
      return this.ticket?.priority?.name ?? "";
    },
    category() {
      return this.ticket?.category?.name ?? "";
    }
  }
}
</script>

<style scoped>

</style>
