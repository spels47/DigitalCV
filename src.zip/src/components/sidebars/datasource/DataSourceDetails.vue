<template>
  <v-container>
    <v-row>
      <v-col cols="lg-12">
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath clickable :department-path="dataSource.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                <span>Data source info</span>
              </v-list-item-title>
              <v-list-item-subtitle v-if="roles.DEVELOPER_ASAP"> {{ dataSource.dataSourceId }} - {{ dataSource.simcardId }} - {{ dataSource.subscriptionNumber }}</v-list-item-subtitle>
              <v-list-item-subtitle v-if="dataSource.storageUnit">
                <h2 class="warning--text">STORAGE UNIT</h2>
              </v-list-item-subtitle>
              <v-list-item-subtitle v-if="dataSource.subscriptionExpired">
                <h2 class="error--text">EXPIRED</h2>
              </v-list-item-subtitle>
              <v-list-item-subtitle class="mt-4" v-if="dataSource.pendingHotSwap">
                <h2 class="error--text">
                  <v-icon class="mr-2" color="red">mdi-swap-horizontal-circle</v-icon>
                  Hot-swap in progress
                </h2>
                <span class="error--text" v-if="dataSource.dataSourceId === dataSource.pendingHotSwap.oldSerialNumber"> This unit will be replaced with: {{ dataSource.pendingHotSwap.newSerialNumber }} </span>
                <span class="error--text" v-if="dataSource.dataSourceId === dataSource.pendingHotSwap.newSerialNumber"> This unit will replace: {{ dataSource.pendingHotSwap.oldSerialNumber }} </span>
              </v-list-item-subtitle>
              <v-list-item-subtitle class="mt-4" v-if="dataSource.pendingSwap">
                <h2 class="success--text">
                  <v-icon class="mr-2" color="success">mdi-swap-horizontal-circle</v-icon>
                  Is in a swap process
                </h2>
              </v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="lg-12">
        <v-list min-width="100">
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-identifier" label="Data Source ID" :value="dataSource.dataSourceId"/>
          </v-list-item>
          <v-list-item>
            <v-text-field
              readonly
              prepend-icon="mdi-drawing"
              label="Type"
              :value="determineDataSourceType()"
            ></v-text-field>
          </v-list-item>
          <v-list-item v-if="dataSource.unitTypeId === 'MINI'">
            <ClickableSelectWithDialog @itemClicked="navigateToConnectedAsset()" :fieldLabel="'MINI Name'" :itemText="dataSource.name" :icon="'mdi-identifier'" :showAppendIcon="false"></ClickableSelectWithDialog>
          </v-list-item>
          <v-list-item>
            <ClickableSelectWithDialog
              :disabled="dataSource.subscriptionNumber && dataSource.subscriptionNumber.startsWith('FAKE')"
              @itemClicked="navigateToConnectedSubscription"
              :fieldLabel="'Subscription number'"
              :itemText="dataSource.subscriptionNumber"
              :icon="'mdi-numeric'"
              :showAppendIcon="false">
            </ClickableSelectWithDialog>
          </v-list-item>
          <v-list-item v-if="dataSource.unitTypeId !== 'MINI'">
            <v-text-field readonly prepend-icon="mdi-calendar" label="Last contact" :value="dataSource.lastContact"/>
          </v-list-item>
          <v-list-item v-if="dataSource.unitTypeId === 'MINI'">
            <v-text-field readonly prepend-icon="mdi-calendar" label="Last position" :value="dataSource.lastPositionUtc"></v-text-field>
          </v-list-item>
          <v-list-item v-if="dataSource.simcardId">
            <v-text-field readonly prepend-icon="mdi-numeric" label="Simcard ID" :value="dataSource.simcardId"/>
          </v-list-item>
          <v-list-item v-if="type !== 'mini'">
            <ClickableSelectWithDialog
              :fieldLabel="'Connected Asset'"
              :itemText="asset.licensePlate ? (asset.alias ? asset.alias : '') + ' - ' + asset.licensePlate : (asset.alias ? asset.alias : '') + ' - ' + id"
              :icon="'mdi-cable-data'"
              :disabled="dataSource.storageUnit"
              :showAppendIcon="false"
              @itemClicked="navigateToConnectedAsset"
            ></ClickableSelectWithDialog>
          </v-list-item>
          <v-list-item v-if="dataSource.hardwareSerialNumber">
            <ClickableSelectWithDialog
              @itemClicked="navigateToConnectedRfid"
              :fieldLabel="'Connected RFID'"
              :itemText="dataSource.hardwareSerialNumber + ' - ' + dataSource.hardwareType"
              :icon="'mdi-access-point'"
              :showAppendIcon="false"
            ></ClickableSelectWithDialog>
          </v-list-item>
        </v-list>
      </v-col>
      <v-col cols="12">
        <v-bottom-navigation
          grow
          class="elevation-0"
        >
          <v-btn @click="toggleFavorite">
            <span v-if="isFavorite">Favorite</span>
            <span v-if="!isFavorite">Add to favorites</span>
            <v-icon :color="isFavorite ? 'marked' : ''">mdi-heart</v-icon>
          </v-btn>
          <v-btn
            v-if="dataSourceEligibleForSwap"
            :loading="fetchingSubscriptions"
            @click="showSwapHandlingWizard"
          >
            <span>Swap unit</span>
            <v-icon>mdi-swap-horizontal-circle</v-icon>
          </v-btn>

          <template v-if="!dataSourceEligibleForSwap">
            <v-btn
              v-if="roles.ASSET_REVISION && (dataSource.type === 'Simcard' || dataSource.type === 'SimcardStorageUnit') && !isFakeUnit"
              :disabled="unitFeatureReEvalRequested"
              @click="reEvaluateUnitFeatures(dataSource.dataSourceId)"
            >
              <span>Re-evaluate <br/>unit features</span>
              <v-icon color="primary">mdi-feature-search</v-icon>
            </v-btn>

            <v-btn @click="showVehiclesRevision = true" v-if="roles.ASSET_REVISION && dataSource.type === 'Simcard'">
              <span>Move trips</span>
              <v-icon>mdi-map-marker-path</v-icon>
            </v-btn>

          </template>
        </v-bottom-navigation>

        <v-bottom-navigation
          v-if="dataSourceEligibleForSwap"
          grow
          class="elevation-0"
        >
          <v-btn
            v-if="roles.ASSET_REVISION && (dataSource.type === 'Simcard' || dataSource.type === 'SimcardStorageUnit') && !isFakeUnit"
            :disabled="unitFeatureReEvalRequested"
            @click="reEvaluateUnitFeatures(dataSource.dataSourceId)"
          >
            <span>Re-evaluate <br/>unit features</span>
            <v-icon color="primary">mdi-feature-search</v-icon>
          </v-btn>

          <v-btn @click="showVehiclesRevision = true" v-if="roles.ASSET_REVISION && dataSource.type === 'Simcard'">
            <span>Move trips</span>
            <v-icon>mdi-map-marker-path</v-icon>
          </v-btn>
        </v-bottom-navigation>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <v-list-item>
          <v-list-item-content>
            <v-list-item-title class="heading">Configuration:</v-list-item-title>
            <device-configuration :serial-number="dataSource.dataSourceId"></device-configuration>
            <feature-configuration :features="dataSource.features"></feature-configuration>
          </v-list-item-content>
        </v-list-item>
      </v-col>
    </v-row>
    <v-row v-if="dataSource.type === 'Simcard' || dataSource.type === 'SimcardStorageUnit'">
      <v-col cols="lg-12">
        <v-list min-width="100">
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-numeric" label="GSM No." :value="dataSource.msisdn"/>
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-identifier" label="SIMICC" :value="dataSource.iccid"/>
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-identifier" label="IMEI" :value="dataSource.imei"/>
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-information-outline" label="SIM Card Status" :value="simStatus"/>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <DatasourceMoveTrips :serialNumber="dataSource.dataSourceId" :simcardId="dataSource.simcardId" :showDialog="showVehiclesRevision" @closeDialog="showVehiclesRevision = false"/>
    <SwapHandlingWizard
      v-if="showSwapHandlingWizardDialog"
      :customer="customer"
      :show="showSwapHandlingWizardDialog"
      :subscriptions="subscriptions"
      :simcards="[dataSource]"
      :key="showSwapHandlingWizardDialog"
      @closeDialog="showSwapHandlingWizardDialog = false"
    ></SwapHandlingWizard>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import DepartmentPath from "~/components/DepartmentPath";
import FeatureConfiguration from "~/components/FeatureConfiguration";
import ClickableSelectWithDialog from "@/components/ClickableSelectWithDialog";
import DatasourceMoveTrips from "@/components/DatasourceMoveTrips";
import SwapHandlingWizard from "@/components/dialogs/swap-handling/SwapHandlingWizard";
import DeviceConfiguration from "@/components/DeviceConfiguration"

export default {
  name: "DataSourceDetails",
  components: { SwapHandlingWizard, DeviceConfiguration, DatasourceMoveTrips, FeatureConfiguration, DepartmentPath, ClickableSelectWithDialog },
  props: {
    id: String,
    customer: Object,
    expanded: Boolean
  },
  data: function () {
    return {
      asset: {},
      subscriptions: [],
      isLoading: true,
      unitFeatureReEvalRequested: false,
      showVehiclesRevision: false,
      showSwapHandlingWizardDialog: false,
      fetchingSubscriptions: false,
      simStatus: ""
    };
  },
  async mounted() {
    await this.$store.dispatch("retrieveDataSource", { type: this.type, id: this.id });
    this.getConnectedAssetInfo();
  },
  watch: {
    id: async function () {
      await this.$store.dispatch("retrieveDataSource", { type: this.type, id: this.id });
      this.getConnectedAssetInfo();
    },
    dataSource: function () {
      if (this.dataSource.dataSourceId) {
        this.$emit("dataSourceIdChange", this.dataSource.dataSourceId);
      }
      if (this.dataSource.iccid) {
        this.getSimcardStatus(this.dataSource.iccid);
      }
    }
  },
  methods: {
    async showSwapHandlingWizard() {
      this.fetchingSubscriptions = true;
      try {
        const { data } = await axios.get(`/api/customer/details?customerId=${this.customer.id}&type=subscription`);
        this.subscriptions = data.data;
      } finally {
        this.fetchingSubscriptions = false;
      }
      this.showSwapHandlingWizardDialog = true;
    },
    determineDataSourceType() {
      return (this.dataSource.unitTypeId ?? "") + (this.dataSource.bmnComments ? ', ' + this.dataSource.bmnComments : '')
    },
    navigateToConnectedAsset() {
      if (this.dataSource.storageUnit)
        return;

      if (this.asset.vehicleId) {
        this.$router.push({ path: `/customer/${this.$route.params.id}?type=vehicle&activeTab=2&id=${this.asset.vehicleId}` });
      } else if (this.dataSource.simcardId) {
        this.$router.push({ path: `/customer/${this.$route.params.id}?type=eq&activeTab=3&id=${this.dataSource.simcardId}` });
      } else {
        this.$router.push({ path: `/customer/${this.$route.params.id}?type=eq&activeTab=3&id=${this.id}` });
      }
    },
    navigateToConnectedSubscription() {
      if (this.dataSource.storageUnit)
        return;

      if (this.dataSource.subscriptionNumber) {
        this.$router.push({ path: `/customer/${this.$route.params.id}?type=subscription&activeTab=4&id=${this.dataSource.subscriptionNumber}` });
      } else {
        this.$router.push({ path: `/customer/${this.$route.params.id}?type=eq&activeTab=3&id=${this.id}` });
      }
    },
    navigateToConnectedRfid() {
      this.$emit("pageChanged", "datasource-connected-rfid");
    },
    getConnectedAssetInfo() {
      if (!this.dataSource.simcardId) return
      axios.get(`/api/datasource/connectedasset/${this.dataSource.simcardId}`).then(res => (this.asset = res.data));
    },
    getSimcardStatus(iccid) {
      axios.get(`/api/datasource/simcardStatus/${iccid}`).then(res => (this.simStatus = res.data));
    },
    updateDataSourceInfo() {
      clearTimeout(this._timerId);

      this._timerId = setTimeout(() => {
        this.isLoading = true;
        axios
          .put(`/api/datasource/${this.type}`, this.dataSource)
          .catch(() => {
            this.$eventBus.$emit("alert", { template: "api-error" });
          })
          .finally(() => (this.isLoading = false));
      }, 500);
    },
    async toggleFavorite() {
      let favorite = {
        departmentPath: this.dataSource.departmentPath,
        id: this.dataSource.dataSourceId.toString(),
        name: this.dataSource.dataSourceId.toString(),
        subName: this.dataSource.alias ?? "",
        type: this.dataSource.type
      };
      await this.$store.dispatch("toggleFavorite", favorite);
    },
    async reEvaluateUnitFeatures(serialNumber) {
      this.unitFeatureReEvalRequested = true;
      try {
        let featuresBefore = JSON.parse(JSON.stringify(this.dataSource.features));
        await axios.put(`/api/subscription/ReEvaluateUnitFeatures/${serialNumber}`);
        await this.$store.dispatch("audit", { source: "datasource", entityId: serialNumber, message: "ReEvaluateUnitFeatures", oldValue: featuresBefore, newValue: "" });
        this.$eventBus.$emit("alert", { text: `Unit features will be re-evaluated for ${serialNumber}`, icon: "mdi-feature-search", type: "success" });
      } catch {
        this.$eventBus.$emit("alert", { template: "api-error" });
      }
    }
  },
  computed: {
    dataSourceEligibleForSwap() {
      return this.roles.DATASOURCE_SWAP && this.dataSource.type !== 'Oem' && !this.dataSource.pendingSwap && !this.dataSource.storageUnit && Object.values(this.dataSource?.pendingHotSwap ?? []).length === 0;
    },
    isFavorite() {
      return this.$store.state.userSettings?.favorites?.some(x => x.type === this.dataSource.type && x.id === this.dataSource.dataSourceId?.toString());
    },
    type() {
      return this.id.startsWith("MUM") || this.id.startsWith("AM") ? "mini" : "simcard";
    },
    dataSource() {
      return this.$store.state.SidebarModule.selectedDataSource;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    isFakeUnit() {
      return this.dataSource?.dataSourceId?.toUpperCase().startsWith('FAKE')
    }
  }
};
</script>

<style scoped>
.fill-width {
  width: 100%;
}

.icon-button-wrap {
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
