<template>
  <v-container fluid>
    <v-row>
      <v-col cols="12">
        <v-list>
          <v-list-item>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath clickable :department-path="dataSource.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                <span>Telemetry Log</span>
              </v-list-item-title>
              <v-list-item-subtitle>
                <span>{{ dataSource.dataSourceId }} - {{ dataSource.unitTypeId }} - {{ dataSource.simcardId }}</span>
              </v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col v-if="dataSource.simcardId">
        <TelemetryLogHolder :unitId="dataSource.simcardId" :unitTypeId="dataSource.unitTypeId"></TelemetryLogHolder>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import DepartmentPath from "~/components/DepartmentPath";
const TelemetryLogHolder = () => import("@/components/sidebars/datasource/TelemetryLog/TelemetryLogHolder") // Lazy imported due to bufy and stuff
export default {
  props: {
    id: String,
    expanded: Boolean,
    type: String
  },
  data() {
    return {};
  },
  mounted() {

    this.$store.dispatch("retrieveDataSource", { type: this.type, id: this.id });
  },
  computed: {
    dataSource() {
      return this.$store.state.SidebarModule.selectedDataSource;
    }
  },
  components: {
    TelemetryLogHolder,
    DepartmentPath
  }
};
</script>

<style lang="scss">
.iframe {
  height: 80vh;
  width: 100%;
}
</style>
