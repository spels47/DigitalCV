<template>
  <v-container>
    <v-row no-gutters>
      <v-col cols="lg-12">
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-title class="headline">
                <span>Warehouse log</span>
              </v-list-item-title>
              <v-list-item-subtitle>
                <span>{{id}}</span>
              </v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row cols="lg-12">
      <v-col cols="lg-12">
        <v-list min-width="100">
          <v-data-table
            dense
            hide-default-footer
            :headers="getHeaders()"
            :items="log"
            :loading="loading"
            loading-text="Loading..."
            no-data-text="No items in log"
          >
            <template v-slot:item.timeStamp="{ item }">
              <span>{{ item.timeStamp | datetime }}</span>
            </template>
          </v-data-table>
        </v-list>
      </v-col>
    </v-row>
  </v-container>
</template>
<script>
import axios from "~/axios-client";
export default {
  name: "DataSourceWarehouseLog",
  props: {
    id: String,
    expanded: Boolean,
  },
  data() {
    return {
      loading: false,
      log: [],
      headers: [
        {text: 'Timestamp', value: 'timeStamp'},
        {text: 'State', value: 'state'},
      ],
      headersLong: [
        {text: 'Timestamp', value: 'timeStamp'},
        {text: 'State', value: 'state'},
        {text: 'Location', value: 'location'},
        {text: 'Batch number', value: 'batchNumber'}
      ],
    }
  },
  async mounted() {
    await this.getLog()
  },
  methods: {
    async getLog() {
      this.loading = true
      try{
        let res = await axios.get(`/api/return-handling/warehouse/serial-number/${this.id}`)
        this.log = res.data
      } catch(ex){
        this.$eventBus.$emit('alert', { text: "Failed fetching warehouse log for unit", type: "error" });
      }
      this.loading = false
    },
    getHeaders() {
      if (this.expanded) {
        return this.headersLong;
      }
      return this.headers;
    },
  }
}
</script>

<style scoped>

</style>
