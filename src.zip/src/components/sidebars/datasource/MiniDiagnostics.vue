<template>
  <v-container>
    <v-row>
      <v-col cols="12">
        <v-list>
          <v-list-item>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath clickable :department-path="dataSource.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                <span>Unit diagnostics</span>
              </v-list-item-title>
              <v-list-item-subtitle>
                <span>{{ dataSource.dataSourceId }} - {{ dataSource.unitTypeId }} - {{ dataSource.subscriptionNumber }}</span>
              </v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>

    <v-row>
      <v-expansion-panels class="elevation-2">
        <v-expansion-panel style="cursor: auto;">
          <v-expansion-panel-header hide-actions style="cursor: auto;" disabled>
            <span>Battery status</span>
            <div class="icon-right">
              <UnitDiagnosticMini :serial-number="dataSource.dataSourceId"></UnitDiagnosticMini>
            </div>
          </v-expansion-panel-header>
        </v-expansion-panel>
      </v-expansion-panels>
    </v-row>
    <v-row>
      <v-expansion-panels class="elevation-2">
        <v-expansion-panel style="cursor: auto;">
          <v-expansion-panel-header hide-actions style="cursor: auto;" disabled>
            <span>Message counter</span>
            <div class="icon-right">
              <span>{{dataSource.msgCounter}}</span>
            </div>
          </v-expansion-panel-header>
        </v-expansion-panel>
      </v-expansion-panels>
    </v-row>
    <v-row>
      <v-expansion-panels class="elevation-2">
        <v-expansion-panel style="cursor: auto;">
          <v-expansion-panel-header hide-actions style="cursor: auto;" @click.stop="navigateToRelayUnit(dataSource.relayUnitSerialNumber)">
            <ClickableSelectWithDialog
              @itemClicked="navigateToRelayUnit(dataSource.relayUnitSerialNumber)"
              :fieldLabel="'Relay Unit'"
              :itemText="`${dataSource.relayUnitId} - ${dataSource.relayUnitSerialNumber}`"
              :disabled="!hasRelayUnit"
              :showAppendIcon="false"></ClickableSelectWithDialog>
          </v-expansion-panel-header>
        </v-expansion-panel>
      </v-expansion-panels>
    </v-row>

    <v-row>
      <v-card class="map-card">
        <MapWithPosition :position="currentPosition"></MapWithPosition>
      </v-card>
    </v-row>

    <v-row class="px-6">
      <v-spacer></v-spacer>
      <div><span class="my-2">Showing last 500 positions</span><v-checkbox class="ma-0 pa-0" v-model="showHeartbeats" label="Show heartbeats"></v-checkbox></div>
      <div></div>
      <v-spacer></v-spacer>
    </v-row>

    <v-row>
      <v-col cols="12">
        <v-data-table
          item-key="timestamp"
          :show-expand="expanded"
          single-expand
          height="360"
          :headers="headers"
          :items="positionsWithIndex"
          :loading="positionsLoading"
          :items-per-page="10"
          class="elevation-0 datatable-scroll"
          loading-text="Loading positions..."
          no-data-text="No positions..."
          :footer-props="{ 'items-per-page-options': (items_per_page = [10, 100, -1]) }"
          dense
        >
          <template v-slot:item="{ item }">
            <tr v-if="!item.heartbeat" @click="positionRowClicked(item)">
              <td><span :class="{ 'secondary--text': item.index === currentPosition.index }">{{ item.timestamp | ntzDatetime }}</span></td>
              <td><span :class="{ 'secondary--text': item.index === currentPosition.index }">{{ item.latitude.toFixed(6) }} / {{ item.longitude.toFixed(6) }}</span></td>
              <td v-if="expanded"><span :class="{ 'secondary--text': item.index === currentPosition.index }">{{ item.radius }} m</span></td>
              <td v-if="expanded"><v-chip pill small>POSITION</v-chip></td>
            </tr>
            <tr v-if="showHeartbeats && item.heartbeat">
              <td><span :class="{ 'secondary--text': item.index === currentPosition.index }">{{ item.timestamp | ntzDatetime }}</span></td>
              <td><span class="secondary--text" style="cursor: pointer" @click="navigateToRelayUnit(item.relayUnitSerialNumber)">{{getRelayText}}</span></td>
              <td v-if="expanded"></td>
              <td v-if="expanded"><v-chip pill small>HEARTBEAT</v-chip></td>
            </tr>
          </template>
        </v-data-table>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import DepartmentPath from "~/components/DepartmentPath";
import MapWithPosition from "@/components/map/MapWithPosition";
import UnitDiagnosticMini from "@/components/UnitDiagnosticMini";
import ClickableSelectWithDialog from "@/components/ClickableSelectWithDialog";
export default {
  name: "MiniDiagnostics",
  components: { MapWithPosition, DepartmentPath, UnitDiagnosticMini, ClickableSelectWithDialog },
  props: {
    id: String,
    expanded: Boolean
  },
  data: function() {
    return {
      dataSource: {},
      isLoading: true,
      positions: [],
      heartbeats: [],
      currentPosition: null,
      positionsLoading: false,
      heartbeatsLoading: false,
      showHeartbeats: false
    };
  },
  async mounted() {
    await this.init();
  },
  watch: {
    id: async function() {
      await this.init();
    },
  },
  methods: {
    navigateToRelayUnit(relayUnitSerialNumber) {
      if(!relayUnitSerialNumber) return;
      this.$router.push({path: `/customer/${this.$route.params.id}?type=simcard&activeTab=5&id=${relayUnitSerialNumber}`});
    },
    async init() {
      this.loading = true;
      if (!this.id) return;
      await this.getDataSourceInfo();
      await this.getPositionsDebounced();
      if (this.positions.length > 0) {
        this.currentPosition = this.positions[0];
        this.currentPosition.index = 0;
      }
      this.loading = false;
    },
    async getPositions() {
      this.positions = [];
      this.positionsLoading = true;
      try {
        let res = await axios.get(`/api/datasource/position/mini/${this.dataSource.dataSourceId}`);
        this.positions = res.data;
        if (this.positions?.length > 0) {
          this.currentPosition = this.positions[0];
          this.currentPosition.index = 0;
        } else this.currentPosition = null;
      } catch (ex) {
        this.$eventBus.$emit("alert", { template: "api-error" });
      }
      this.positionsLoading = false;
    },
    async getHeartbeats() {
      this.heartbeats = [];
      this.heartbeatsLoading = true;
      try {
        let res = await axios.get(`/api/datasource/heartbeats/mini/${this.dataSource.dataSourceId}`);
        this.heartbeats = res.data;
      } catch (ex) {
        this.$eventBus.$emit("alert", { template: "api-error" });
      }
      this.heartbeatsLoading = false;
    },
    getPositionsDebounced() {
      clearTimeout(this._timerId);

      this._timerId = setTimeout(() => {
        this.getPositions();
        this.getHeartbeats();
      }, 500);
    },
    async getDataSourceInfo() {
      this.dataSource = {};
      this.isLoading = true;
      try {
        let res = await axios.get(`/api/datasource/mini/${this.id}`);
        this.dataSource = res.data;
      } catch (ex) {
        this.$eventBus.$emit("alert", { template: "api-error" });
      }
    },
    positionRowClicked(row) {
      this.currentPosition = row;
      this.currentPosition.index = row.index;
    }
  },
  computed: {
    positionsWithIndex() {
      let res = this.positions
      if(this.showHeartbeats){
        let heartBeats = this.heartbeats.map((item, index) => ({ ...item, heartbeat: true  }));
        res = res.concat(heartBeats)
      }
      res = res.map((item, index) => ({ ...item, index: index, date: new Date(item.timestamp) }));
      res.sort((a, b) => b.date - a.date);
      return res
    },
    headers() {
      let latLngText = this.showHeartbeats ? 'Lat/Lng or Relay unit' : 'Lat/Lng'
      if (this.expanded) {
        return [
          { text: "Date", value: "date" },
          { text: latLngText, value: "latLng" },
          { text: "Accuracy", value: "radius" },
          { text: "Info", value: "info" },
          { text: '', value: 'data-table-expand' },
        ];
      } else {
        return [
          { text: "Date", value: "date" },
          { text: latLngText, value: "latLng" },
        ];
      }
    },
    getRelayText() {
      if(!this.hasRelayUnit) return 'N/A'
      if(this.relaySimcard === undefined) return this.dataSource.relayUnitId;
      else return `${this.dataSource.relayUnitId}-${this.relaySimcard.dataSourceId}`
    },
    hasRelayUnit(){
      return this.dataSource?.relayUnitId;
    }
  }
};
</script>

<style scoped>
.icon-right {
  position: absolute;
  right: 80px;
}
</style>
