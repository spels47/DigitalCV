<template>
  <v-row>
    <v-col cols="12">
      <div class="d-flex align-center justify-center pa-0 mx-auto">
        <span class="warning--text body-1 mr-4">Firmware version:</span>
        <span class="primary--text body-2">{{ firmwareVersion }}</span>
      </div>
    </v-col>
    <v-col cols="12" v-if="!unitTypeId.startsWith('ABAX6') && !unitTypeId.startsWith('FM')">
      <v-bottom-navigation grow :background-color="'cardbg'" class="elevation-0" v-if="roles.DATASOURCE_FIRMWARE_UPDATE">
        <v-btn v-if="roles.DATASOURCE_FIRMWARE_UPDATE && !newestFirmwareVersion" @click="updateFirmware" :disabled="!requestFirmwareUpdateAvailable">
          <span v-if="requestFirmwareUpdateAvailable">Update firmware</span>
          <span v-if="!requestFirmwareUpdateAvailable">Update in progress</span>
          <v-icon>mdi-cellphone-arrow-down</v-icon>
        </v-btn>
        <v-btn v-if="roles.DATASOURCE_FIRMWARE_UPDATE && (unitTypeId === 'ABAX4' || unitTypeId === 'ABAX5' || unitTypeId === 'ABAXEQ' || unitTypeId === 'ABAXEQ2')" @click="resetUnit">
          <span>Reset unit</span>
          <v-icon>mdi-undo-variant</v-icon>
        </v-btn>
        <v-btn v-if="roles.DATASOURCE_FIRMWARE_UPDATE && (unitTypeId === 'ABAX4' || unitTypeId === 'ABAX5')" @click="requestPositions">
          <span>Request positions</span>
          <v-icon>mdi-map-marker-radius</v-icon>
        </v-btn>
        <v-btn v-if="roles.DATASOURCE_FIRMWARE_UPDATE && (unitTypeId === 'ABAXEQ' || unitTypeId === 'ABAXEQ2')" @click="resetBatteryCounter">
          <span>Reset battery counter</span>
          <v-icon>mdi-battery-alert-variant-outline</v-icon>
        </v-btn>

        <v-fade-transition>
          <v-btn
            v-if="shouldShowConfigLockOption"
            @click="removeSimcardCurrentConfigLocks"
          >
            <span>Remove config lock</span>
            <v-icon v-if="this.hasLockedConfig === null" :color="configLocksIconColor">mdi-lock-open</v-icon>
            <v-icon v-if="!this.hasLockedConfig && this.hasLockedConfig !== null" :color="configLocksIconColor">mdi-lock-open-variant</v-icon>
            <v-icon v-if="this.hasLockedConfig" :color="configLocksIconColor">mdi-lock</v-icon>
          </v-btn>
        </v-fade-transition>
      </v-bottom-navigation>
    </v-col>
  </v-row>
</template>

<script>
import axios from "@/axios-client"

export default {
  name: "FirmwareDetails",
  props: {
    dataSourceId: String,
    unitTypeId: String,
    simcardId: Number
  },
  data() {
    return {
      firmwareVersion: "Loading...",
      latestFirmwareVersion: null,
      firmwareUpdateLoading: false,
      resetBatteryCounterLoading: false,
      firmwareResetUnitLoading: false,
      firmwareRequestPositionsLoading: false,
      requestFirmwareUpdateAvailable: true,
      newestFirmwareVersion: false,
      hasLockedConfig: null
    }
  },
  async mounted() {
    await this.init()
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
    shouldShowConfigLockOption() {
      return this.roles.DEVELOPER_ASAP && (this.unitTypeId === 'ABAX4' || this.unitTypeId === 'ABAX5' || this.unitTypeId === 'VTS') && this.hasLockedConfig;
    },
    configLocksIconColor() {
      if (this.hasLockedConfig === null) return "grey";
      if (this.hasLockedConfig) return "error";
      return "success";
    }
  },
  methods: {
    async init() {
      await this.getLastUpdateRequest();

      if (this.unitTypeId.startsWith('ABAX6') || this.unitTypeId.startsWith('FM')) {
        // New stuff uses device registry
        await this.getDeviceStatus()
      } else {
        // Old stuff goes to abax4UpgradeService
        await this.getFirmwareVersion();
        await this.getAllFirmwareVersions();
        if (this.roles.DEVELOPER_ASAP) {
          await this.getSimcardCurrentConfigHasConfigLocks();
        }
      }
    },
    async getDeviceStatus() {
      this.firmwareVersion = "Loading...";
      try {
        let res = await axios.get(`/api/device-registry/serial-number/${this.dataSourceId}/status`);
        this.firmwareVersion = `${res.data.firmwareVersion} - Status: ${res.data.status}`;
      } catch (ex) {
        this.firmwareVersion = "Failed getting current firmware version...";
      }
    },
    async getFirmwareVersion() {
      this.firmwareVersion = "Loading...";
      try {
        let res = await axios.get(`/api/datasource/firmware/get-version/${this.dataSourceId}`);
        this.firmwareVersion = `${res.data.currentFirmware}, revision: ${res.data.currentConfigRevision}`;
      } catch (ex) {
        this.firmwareVersion = "Failed getting current firmware version...";
      }
    },
    async getSimcardCurrentConfigHasConfigLocks() {
      try {
        let res = await axios.get(`/api/datasource/simcard/${this.simcardId}/simcardCurrentConfig/hasConfigLocks`);
        this.hasLockedConfig = res.data;
      } catch (ex) {
        console.error(ex)
        this.hasLockedConfig = null;
      }
    },
    async removeSimcardCurrentConfigLocks() {
      try {
        await axios.post(`/api/datasource/simcard/${this.simcardId}/simcardCurrentConfig/removeConfigLocks`);
        await this.$store.dispatch("audit", { source: "datasource", entityId: this.dataSourceId, message: "RemoveConfigLocks", oldValue: this.hasLockedConfig, newValue: false });
        await this.getSimcardCurrentConfigHasConfigLocks();
      } catch (ex) {
        this.$eventBus.$emit("alert", { text: "Sorry, but we somehow failed to reset the config locks", icon: "mdi-alert-circle", type: "error" });
      }
    },
    async requestPositions() {
      if (this.firmwareRequestPositionsLoading) return;
      this.firmwareRequestPositionsLoading = true;
      try {
        await axios.post(`/api/datasource/firmware/request-positions/${this.dataSourceId}`);
        await this.$store.dispatch("audit", { source: "datasource", entityId: this.dataSourceId, message: "Unit Request Position", oldValue: "", newValue: "" });
        this.$eventBus.$emit('alert', { text: `Positions have been requested.`, icon: 'mdi-information', type: 'success' });
      } catch (ex) {
        this.$eventBus.$emit("alert", { template: "api-error" });
      }
      this.firmwareRequestPositionsLoading = false;
      await this.init();
    },
    async resetUnit() {
      if (this.firmwareResetUnitLoading) return;

      this.firmwareResetUnitLoading = true;
      try {
        await axios.post(`/api/datasource/firmware/reset/${this.dataSourceId}`);
        await this.$store.dispatch("audit", { source: "datasource", entityId: this.dataSourceId, message: "Unit Reset", oldValue: "", newValue: "" });
        this.$eventBus.$emit('alert', { text: `Reset unit request has been sent.`, icon: 'mdi-information', type: 'success' });
      } catch (ex) {
        this.$eventBus.$emit("alert", { template: "api-error" });
      } finally {

        this.firmwareResetUnitLoading = false;
      }
    },
    async resetBatteryCounter() {
      if (this.resetBatteryCounterLoading) return;
      this.resetBatteryCounterLoading = true;
      try {
        let res = await axios.put(`/api/datasource/resetBatteryCounter/${this.dataSourceId}`);
        this.$eventBus.$emit('alert', { text: `Battery counter has been reset.`, icon: 'mdi-information', type: 'success' });
      } catch (ex) {
        this.$eventBus.$emit("alert", { template: "api-error" });
      }
      await this.$store.dispatch("audit", { source: "datasource", entityId: this.dataSourceId, message: "Reset Battery Counter", oldValue: "", newValue: "" });
      this.resetBatteryCounterLoading = false;
    },
    async updateFirmware() {
      if (this.firmwareUpdateLoading) return;
      this.requestFirmwareUpdateAvailable = false;
      this.firmwareUpdateLoading = true;
      try {
        let res = await axios.post(`/api/datasource/firmware/update/${this.dataSourceId}`);
        this.$eventBus.$emit('alert', { text: `Firmware update request has been sent.`, icon: 'mdi-information', type: 'success' });
      } catch (ex) {
        this.$eventBus.$emit("alert", { template: "api-error" });
      } finally {
        this.firmwareUpdateLoading = false;
        this.firmwareVersion = "Firmware version update requested, this will take some time...";
        await axios.put(`/api/datasource/firmware/update-request/${this.dataSourceId}`);
        await this.$store.dispatch("audit", { source: "datasource", entityId: this.dataSourceId, message: "Firmware version update", oldValue: this.firmwareVersion, newValue: this.latestFirmwareVersion });
      }
    },
    async getLastUpdateRequest() {
      let res = await axios.get(`/api/datasource/firmware/update-request/${this.dataSourceId}`);
      if (res.data !== "") {
        this.requestFirmwareUpdateAvailable = res.data.availableForUpdate;
      }
    },
    async getAllFirmwareVersions() {
      let res = await axios.get(`/api/datasource/firmware/get-all-versions/${this.unitTypeId}`);
      if (res.data.length > 0) {
        let latest = res.data.pop();
        if (this.firmwareVersion.split(",")[0].startsWith(latest.firmwareId)) {
          this.newestFirmwareVersion = true;
          this.latestFirmwareVersion = latest.firmwareId;
        }
      }
    },
  }
}
</script>

<style scoped>

</style>
