<template>
  <v-container>
    <v-row no-gutters>
      <v-col cols="lg-12">
        <v-list>
          <v-progress-linear indeterminate color="black" v-if="loading"></v-progress-linear>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle> </v-list-item-subtitle>
              <v-list-item-title class="headline ml-5">
                <span>RFID Device</span>
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="lg-12">
        <v-list min-width="100">
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-identifier" label="Serial No." :value="dataSource.hardwareSerialNumber" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-devices" label="Hardware Type" :value="dataSource.hardwareType" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-calendar" label="First Event" :value="this.rfidLog.firstEvent | ntzDatetimeSeconds" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-calendar" label="Last Event" :value="this.rfidLog.lastEvent | ntzDatetimeSeconds" />
          </v-list-item>
          <v-list-item>
            <ClickableSelectWithDialog
              @itemClicked="navigateToConnectedUnit"
              :fieldLabel="'Connected Unit'"
              :itemText="dataSource.dataSourceId + ' - ' + dataSource.simcardId"
              :icon="'mdi-view-grid'"
              :showAppendIcon="false"
            ></ClickableSelectWithDialog>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row cols="lg-12">
      <v-col cols="lg-12">
        <v-list min-width="100">
          <v-data-table :headers="getHeaders()" :items="rfidLog.logs">
            <template v-slot:item="{ item }">
              <tr v-if="!expanded">
                <td>{{ item.date | ntzDatetimeSeconds }}</td>
                <td>{{ item.aktorRefID }}</td>
                <td>{{ item.driverName }}</td>
              </tr>
              <tr v-if="expanded">
                <td>{{ item.date | ntzDatetimeSeconds }}</td>
                <td>{{ item.transmitterID }}</td>
                <td>{{ item.rssi }}</td>
                <td>{{ item.battADC }}</td>
                <td>{{ item.uidHex == 0 && item.uidInt == 0 ? "Logged out" : item.uidHex }}</td>
                <td>{{ item.uidHex == 0 && item.uidInt == 0 ? "Logged out" : item.uidInt }}</td>
                <td>{{ item.aktorRefID }}</td>
                <td>{{ item.driverName }}</td>
              </tr>
            </template>
          </v-data-table>
        </v-list>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import ClickableSelectWithDialog from "@/components/ClickableSelectWithDialog";

export default {
  name: "DataSourceConnectedRfid",
  components: { ClickableSelectWithDialog },
  props: {
    simcardId: String,
    expanded: Boolean
  },
  data: function() {
    return {
      loading: false,
      rfidLog: {},
      headers: [
        { text: "Date", value: "date" },
        { text: "Driver ID", value: "aktorRefID" },
        { text: "Driver Name", value: "driverName" }
      ],
      headersLong: [
        { text: "Date", value: "date" },
        { text: "Transmitter ID", value: "transmitterID" },
        { text: "RSSI", value: "rssi" },
        { text: "BattADC", value: "battADC" },
        { text: "RFID_UID_Hex", value: "uidHex" },
        { text: "RFID_UID_Int", value: "uidInt" },
        { text: "Driver ID", value: "aktorRefID" },
        { text: "Driver Name", value: "driverName" }
      ]
    };
  },
  mounted() {
    this.getRfidLog();
  },
  methods: {
    navigateToConnectedUnit() {
      this.$emit("pageChanged", "datasource-details");
    },
    getHeaders() {
      if (this.expanded) {
        return this.headersLong;
      }
      return this.headers;
    },
    getRfidLog() {
      if (this.dataSource.hardwareSerialNumber) {
        this.loading = true;
        axios
          .get(`/api/datasource/simcard/${this.dataSource.simcardId}/rfidLog`)
          .then(res => (this.rfidLog = res.data))
          .finally(() => (this.loading = false));
      }
    }
  },
  computed: {
    dataSource() {
      return this.$store.state.SidebarModule.selectedDataSource;
    }
  }
};
</script>

<style lang="css" scoped>
.fill-width {
  width: 100%;
}
</style>
