<template>
  <v-card-subtitle>
    <v-data-table
      :headers="headers"
      :items="items"
      :loading="isLoading"
      loading-text="Loading... Please wait"
      dense
    >
      <template v-slot:footer>
        <MassHandleButton
          class="my-2 ml-6 mr-2 float-right"
          v-if="items.length > 0"
          :icon="'mdi-microsoft-excel'"
          :tooltip="'Export to Excel'"
          :loading="exportingToExcel"
          :buttonColor="'success'"
          @buttonClicked="$emit('export')"
          data-cy="export-excel-datasource"
        ></MassHandleButton>
      </template>

      <template v-slot:item.receivedAt="{ item }">
        {{ item.receivedAt | datetime }}
      </template>

      <template v-slot:item.BatteryVoltage="{ item }">
        {{ item.json.BatteryVoltage }}
      </template>

      <template v-slot:item.UsedmAh="{ item }">
        {{ item.json.UsedmAh }}
      </template>

      <template v-slot:item.BrownOuResets="{ item }">
        {{ item.json.BrownOuResets }}
      </template>

      <template v-slot:item.Uptime="{ item }">
        {{ item.json.Uptime }}
      </template>

      <template v-slot:item.Temperature="{ item }">
        {{ item.json.Temperature }}
      </template>

      <template v-slot:item.NumberOfAwakes="{ item }">
        {{ item.json.NumberOfAwakes }}
      </template>

      <template v-slot:item.AccelerometerX="{ item }">
        {{ item.json.AccelerometerX }}
      </template>

      <template v-slot:item.AccelerometerY="{ item }">
        {{ item.json.AccelerometerY }}
      </template>

      <template v-slot:item.AccelerometerZ="{ item }">
        {{ item.json.AccelerometerZ }}
      </template>

      <template v-slot:item.CurrentAntenna="{ item }">
        {{ item.json.CurrentAntenna }}
      </template>

      <template v-slot:item.RealTimeClock="{ item }">
        {{ item.json.RealTimeClock }}
      </template>

      <template v-slot:item.GSMModuleResets="{ item }">
        {{ item.json.GSMModuleResets }}
      </template>

      <template v-slot:item.GSMSoftwareResets="{ item }">
        {{ item.json.GSMSoftwareResets }}
      </template>

    </v-data-table>
  </v-card-subtitle>
</template>

<script lang="ts">
import MassHandleButton from "@/components/MassHandleButton";

export default {
  name: "AbaxEqTable",
  props: {
    items: { type: Array },
    unitType: { type: String },
    unitId: { type: Number },
    isLoading: { type: Boolean },
    showEmptySection: { type: Boolean }
  },
  components: {
    MassHandleButton
  },
  data(){
    return {
      headers: [
        { text: "", value: "index" },
        { text: "ReceivedAt", value: "receivedAt" },
        { text: "BatteryVoltage", value: "BatteryVoltage" },
        { text: "UsedmAh", value: "UsedmAh" },
        { text: "BrownOuResets", value: "BrownOuResets" },
        { text: "Uptime", value: "Uptime" },
        { text: "Temperature", value: "Temperature" },
        { text: "NumberOfAwakes", value: "NumberOfAwakes" },
        { text: "AccelerometerX", value: "AccelerometerX" },
        { text: "AccelerometerY", value: "AccelerometerY" },
        { text: "AccelerometerZ", value: "AccelerometerZ" },
        { text: "CurrentAntenna", value: "CurrentAntenna" },
        { text: "RealTimeClock", value: "RealTimeClock" },
        { text: "GSMModuleResets", value: "GSMModuleResets" },
        { text: "GSMSoftwareResets", value: "GSMSoftwareResets" },
      ],
      exportingToExcel: false
    }
  }
};
</script>

<style scoped lang="scss">

</style>
