<template>
  <v-card elevation="2">
    <v-data-table
      :headers="headers"
      :items="items"
      :loading="isLoading"
      loading-text="Loading... Please wait"
      dense
    >
      <template v-slot:footer>
        <MassHandleButton
          class="my-2 ml-6 mr-2 float-right"
          v-if="items.length > 0"
          :icon="'mdi-microsoft-excel'"
          :tooltip="'Export to Excel'"
          :loading="exportingToExcel"
          :buttonColor="'success'"
          @buttonClicked="$emit('export')"
          data-cy="export-excel-datasource"
        ></MassHandleButton>
      </template>

      <template v-slot:item.receivedAt="{ item }">
        {{ item.receivedAt | datetime }}
      </template>

      <template v-slot:item.UpTime="{ item }">
        {{ item.json.Uptime }}
      </template>

      <template v-slot:item.GPSHDOP="{ item }">
        {{ item.json.GPSHDOP }}
      </template>

      <template v-slot:item.VisibleSatellites="{ item }">
        {{ item.json.VisibleSatellites }}
      </template>

      <template v-slot:item.ExternalVCCVoltage="{ item }">
        {{ item.json.ExternalVCCVoltage }}
      </template>

      <template v-slot:item.GSMVoltage="{ item }">
        {{ item.json.GSMVoltage }}
      </template>

      <template v-slot:item.BatteryVoltage="{ item }">
        {{ item.json.BatteryVoltage }}
      </template>

      <template v-slot:item.Charging="{ item }">
        {{ item.json.Charging }}
      </template>

      <template v-slot:item.CurrentPowerSource="{ item }">
        {{ item.json.CurrentPowerSource }}
      </template>

      <template v-slot:item.WDTResets="{ item }">
        {{ item.json.WDTResets }}
      </template>

      <template v-slot:item.ExternalResets="{ item }">
        {{ item.json.ExternalResets }}
      </template>

      <template v-slot:item.BrownOutResets="{ item }">
        {{ item.json.BrownOutResets }}
      </template>

      <template v-slot:item.FirmwareResets="{ item }">
        {{ item.json.FirmwareResets }}
      </template>

      <template v-slot:item.FlashResets="{ item }">
        {{ item.json.FlashResets }}
      </template>

      <template v-slot:item.TripState="{ item }">
        {{ item.json.TripState }}
      </template>

      <template v-slot:item.GPSPowerState="{ item }">
        {{ item.json.GPSPowerState }}
      </template>

      <template v-slot:item.NetworkStatus="{ item }">
        {{ item.json.NetworkStatus }}
      </template>

      <template v-slot:item.PowerState="{ item }">
        {{ item.json.PowerState }}
      </template>
    </v-data-table>
  </v-card>
</template>

<script lang="ts">
import Vue from "vue";
import MassHandleButton from "@/components/MassHandleButton";

export default Vue.extend({
  name: "Abax4Table",
  props: {
    items: { type: Array },
    unitType: { type: String },
    unitId: { type: Number },
    isLoading: { type: Boolean },
    showEmptySection: { type: Boolean }
  },
  components: {
    MassHandleButton
  },
  data(){
    return {
      headers: [
        { text: "", value: "index" },
        { text: "ReceivedAt", value: "receivedAt" },
        { text: "UpTime", value: "UpTime" },
        { text: "GPSHDOP", value: "GPSHDOP" },
        { text: "VisibleSatellites", value: "VisibleSatellites" },
        { text: "ExternalVCCVoltage", value: "ExternalVCCVoltage" },
        { text: "GSMVoltage", value: "GSMVoltage" },
        { text: "BatteryVoltage", value: "BatteryVoltage" },
        { text: "CurrentPowerSource", value: "CurrentPowerSource" },
        { text: "WDTResets", value: "WDTResets" },
        { text: "ExternalResets", value: "ExternalResets" },
        { text: "BrownOutResets", value: "BrownOutResets" },
        { text: "FirmwareResets", value: "FirmwareResets" },
        { text: "FlashResets", value: "FlashResets" },
        { text: "TripState", value: "TripState" },
        { text: "GPSPowerState", value: "GPSPowerState" },
        { text: "NetworkStatus", value: "NetworkStatus" },
        { text: "PowerState", value: "PowerState" },
      ],
      exportingToExcel: false
    }
  }
});
</script>

<style scoped lang="scss">

</style>
