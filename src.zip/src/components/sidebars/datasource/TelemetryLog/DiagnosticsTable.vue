<template>
  <v-card elevation="0">
    <v-row cols="12" class="px-8">
      <v-col cols="4"></v-col>
      <v-col cols="3">
        <v-datetime-picker
          :textFieldProps="textFieldProps"
          :timePickerProps="{ format: '24hr' }"
          label="To"
          v-model="to"
        >
          <template v-slot:dateIcon>
            <v-icon>mdi-calendar</v-icon>
          </template>
          <template v-slot:timeIcon>
            <v-icon>mdi-clock</v-icon>
          </template>
        </v-datetime-picker>
      </v-col>
      <v-col cols="2">
        <v-text-field type="number" v-model="days" label="Days" />
      </v-col>
      <v-col cols="2">
        <v-text-field type="number" v-model="limit" label="Limit" />
      </v-col>
      <v-col cols="1">
        <v-btn class="primary" size="is-small" v-on:click="fetchData">Search</v-btn>
      </v-col>
    </v-row>

    <Abax4Table
      v-if="unitType === 'abax4'"
      :items="items"
      :unitId="unitId"
      :unitType="unitType"
      :is-loading="isLoading"
      :show-empty-section="showEmptySection"
      @export="exportDataSourcesToExcel"
    />

    <Abax5Table
      v-if="unitType === 'abax5'"
      :items="items"
      :unitId="unitId"
      :unitType="unitType"
      :is-loading="isLoading"
      :show-empty-section="showEmptySection"
      @export="exportDataSourcesToExcel"
    />

    <AbaxEqTable
      v-if="unitType === 'abaxeq' || unitType === 'abaxeq2'"
      :items="items"
      :unitId="unitId"
      :unitType="unitType"
      :is-loading="isLoading"
      :show-empty-section="showEmptySection"
      @export="exportDataSourcesToExcel"
    />
  </v-card>
</template>

<script lang="ts">
import Abax4Table from "./Abax4Table.vue";
import Abax5Table from "./Abax5Table.vue";
import AbaxEqTable from "./AbaxEqTable.vue";
import axios from "~/axios-client";
import moment from "moment";
import {exportToExcelFile} from "@/helpers/excel-util";
import util from "@/helpers/util"
import qs from "qs";

export default {
  name: "DiagnosticsTable",
  components: {
    Abax4Table,
    Abax5Table,
    AbaxEqTable
  },
  props: {
    unitId: { type: Number},
    unitType: { type: String},
    toDate: { type: Date}
  },
  data: () => {
    return {
      isLoading: false,
      items: [],
      showEmptySection: false,
      days: 7,
      limit: 25,
      textFieldProps: {
        prependIcon: "mdi-calendar"
      },
      to: new Date(),
    };
  },
  mounted() {
  },
  methods: {
    async fetchData() {
      this.isLoading = true;

      let params = {
        to: moment(this.toDate).format('YYYY-MM-DDThh:mm:ss.SSSZ'),
        days: this.days,
        limit: this.limit
      }
      try {
        let response = await axios.get(`/api/telemetry/unit/${this.unitId}/lastDiagnostics`, { params: params, paramsSerializer: qs.stringify })
        this.items = response.data.map(item => {
          if (item.data) {
            const itemData = JSON.parse(item.data);
            if (itemData.TelemetryId) {
              item.json = itemData.SensorData.Value;
            } else {
              item.json = itemData;
            }
          }
          return item;
        });
        this.showEmptySection = this.items.length === 0;
      } catch (ex) {
        this.$eventBus.$emit('alert', { text: "Failed to fetch diagnostic events list", type: "error" });
      }
      this.isLoading = false;
    },
    async exportDataSourcesToExcel() {
      let toDateString = this.to.toISOString().replaceAll(':', '_').replaceAll('.', '__')
      const fileName = `diagnosticTable-${this.unitType}-${this.unitId}-${toDateString}.xlsx`;
      const sheetName = 'Diagnostic'

      let data = []
      let tempArray = JSON.parse(JSON.stringify(this.items))
      tempArray.forEach(x => {
        x.data = JSON.parse(x.data)
        let temp = util.flattenDict(x)
        data.push(temp)
      })
      await exportToExcelFile(fileName, sheetName, data);
      this.exportingToExcel = false
    },
  }
}
</script>

<style scoped lang="scss">

</style>
