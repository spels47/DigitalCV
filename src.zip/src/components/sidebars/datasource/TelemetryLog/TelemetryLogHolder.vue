<template>
  <v-card>
    <v-card-actions>
      <v-btn-toggle v-model="currentList" tile group v-if="showDiagnosticTable">
        <v-btn value="events">
          Event info
        </v-btn>
        <v-btn value="diagnostic">
          Diagnostic table
        </v-btn>
      </v-btn-toggle>
      <v-spacer></v-spacer>
      <a :href="`https://bo.track2find.com/telemetry-logger/index.html#/unitId/${this.unitId}`">Back to old telemetry log</a>
    </v-card-actions>
    <TelemetryList v-show="currentList === 'events'" :unitId="unitId" :unitTypeId="unitTypeId"></TelemetryList>
    <DiagnosticsTable v-show="currentList === 'diagnostic'" :unit-id="unitId" :unit-type="unitTypeId.toLowerCase()" />
  </v-card>
</template>

<script>
import TelemetryList from "@/components/sidebars/datasource/TelemetryLog/TelemetryList"
import DiagnosticsTable from "@/components/sidebars/datasource/TelemetryLog/DiagnosticsTable"
export default {
  name: "TelemetryLogHolder",
  props: {
    unitId: { type: Number },
    unitTypeId: { type: String }
  },
  components: {
    TelemetryList,
    DiagnosticsTable
  },
  data(){
    return {
      currentList: 'events'
    }
  },
  methods: {
    openOldLog(){
      window.open(`https://bo.track2find.com/telemetry-logger/index.html#/unitId/${this.unitId}`)
    }
  },
  computed: {
    showDiagnosticTable(){
      return ['abax4', 'abax5', 'abaxeq', 'abaxeq2'].includes(this.unitTypeId.toLowerCase());
    },
  }
}
</script>

<style scoped>

</style>
