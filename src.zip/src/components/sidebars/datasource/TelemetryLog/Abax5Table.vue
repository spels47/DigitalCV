<template>
  <v-card elevation="2">

    <v-data-table
      :headers="headers"
      :items="items"
      :loading="isLoading"
      loading-text="Loading... Please wait"
      dense
    >
      <template v-slot:footer>
        <MassHandleButton
          class="my-2 ml-6 mr-2 float-right"
          v-if="items.length > 0"
          :icon="'mdi-microsoft-excel'"
          :tooltip="'Export to Excel'"
          :loading="exportingToExcel"
          :buttonColor="'success'"
          @buttonClicked="$emit('export')"
          data-cy="export-excel-datasource"
        ></MassHandleButton>
      </template>

      <template v-slot:item.receivedAt="{ item }">
        {{ item.receivedAt | datetime }}
      </template>

      <template v-slot:item.CurrentUptime="{ item }">
        {{ item.json.CurrentUptime }}
      </template>

      <template v-slot:item.CurrentPDOP="{ item }">
        {{ item.json.CurrentPDOP }}
      </template>

      <template v-slot:item.VisibleSatellites="{ item }">
        {{ item.json.VisibleSatellites }}
      </template>

      <template v-slot:item.ExternalVoltage="{ item }">
        {{ item.json.ExternalVoltage }}
      </template>

      <template v-slot:item.InternalVoltage="{ item }">
        {{ item.json.InternalVoltage }}
      </template>

      <template v-slot:item.SignalVoltage="{ item }">
        {{ item.json.SignalVoltage }}
      </template>

      <template v-slot:item.BatteryVoltage="{ item }">
        {{ item.json.BatteryVoltage }}
      </template>

      <template v-slot:item.Temperature="{ item }">
        {{ item.json.Temperature }}
      </template>

      <template v-slot:item.BatteryChargeStatus="{ item }">
        {{ item.json.BatteryChargeStatus }}
      </template>

      <template v-slot:item.BrownOutResets="{ item }">
        {{ item.json.BrownOutResets }}
      </template>

      <template v-slot:item.WDTResets="{ item }">
        {{ item.json.WDTResets }}
      </template>

      <template v-slot:item.PinResets="{ item }">
        {{ item.json.PinResets }}
      </template>

      <template v-slot:item.FlashBufferFails="{ item }">
        {{ item.json.FlashBufferFails }}
      </template>

      <template v-slot:item.XAxisAccelerometer="{ item }">
        {{ item.json.XAxisAccelerometer }}
      </template>

      <template v-slot:item.YAxisAccelerometer="{ item }">
        {{ item.json.YAxisAccelerometer }}
      </template>

      <template v-slot:item.ZAxisAccelerometer="{ item }">
        {{ item.json.ZAxisAccelerometer }}
      </template>

      <template v-slot:item.GPSFixFailed="{ item }">
        {{ item.json.GPSFixFailed }}
      </template>
    </v-data-table>

  </v-card>
</template>

<script lang="ts">
import Vue from "vue";
import MassHandleButton from "@/components/MassHandleButton";

export default Vue.extend({
  name: "Abax5Table",
  props: {
    items: { type: Array },
    unitType: { type: String },
    unitId: { type: Number },
    isLoading: { type: Boolean },
    showEmptySection: { type: Boolean }
  },
  components: {
    MassHandleButton
  },
  data(){
    return {
      headers: [
        { text: "", value: "index" },
        { text: "ReceivedAt", value: "receivedAt" },
        { text: "CurrentUptime", value: "CurrentUptime" },
        { text: "CurrentPDOP", value: "CurrentPDOP" },
        { text: "VisibleSatellites", value: "VisibleSatellites" },
        { text: "ExternalVoltage", value: "ExternalVoltage" },
        { text: "InternalVoltage", value: "InternalVoltage" },
        { text: "SignalVoltage", value: "SignalVoltage" },
        { text: "BatteryVoltage", value: "BatteryVoltage" },
        { text: "Temperature", value: "Temperature" },
        { text: "BatteryChargeStatus", value: "BatteryChargeStatus" },
        { text: "BrownOutResets", value: "BrownOutResets" },
        { text: "WDTResets", value: "WDTResets" },
        { text: "PinResets", value: "PinResets" },
        { text: "FlashBufferFails", value: "FlashBufferFails" },
        { text: "XAxisAccelerometer", value: "XAxisAccelerometer" },
        { text: "YAxisAccelerometer", value: "YAxisAccelerometer" },
        { text: "ZAxisAccelerometer", value: "ZAxisAccelerometer" },
        { text: "GPSFixFailed", value: "GPSFixFailed" },
      ],
      exportingToExcel: false
    }
  }
});
</script>

<style scoped lang="scss">

</style>
