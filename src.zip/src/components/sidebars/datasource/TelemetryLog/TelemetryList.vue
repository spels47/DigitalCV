<template>
  <v-card elevation="0">
      <v-card elevation="0">
        <v-row class="px-8">
          <v-col cols="5"></v-col>
          <v-col cols="2">
            <v-datetime-picker
              :textFieldProps="textFieldProps"
              :timePickerProps="{ format: '24hr' }"
              label="From"
              v-model="from"
              :disabled="last24hours"
            >
              <template v-slot:dateIcon>
                <v-icon>mdi-calendar</v-icon>
              </template>
              <template v-slot:timeIcon>
                <v-icon>mdi-clock</v-icon>
              </template>
            </v-datetime-picker>
          </v-col>

          <v-col cols="2">
            <v-datetime-picker
              :textFieldProps="textFieldProps"
              :timePickerProps="{ format: '24hr' }"
              label="To"
              v-model="to"
              :disabled="last24hours"
            >
              <template v-slot:dateIcon>
                <v-icon>mdi-calendar</v-icon>
              </template>
              <template v-slot:timeIcon>
                <v-icon>mdi-clock</v-icon>
              </template>
            </v-datetime-picker>
          </v-col>
          <v-col cols="2">
            <v-checkbox v-model="last24hours" label="Last 24 hours" :disabled="isLoading"></v-checkbox>
          </v-col>
          <v-col cols="1">
            <v-btn class="primary mx" size="sm" @click="refreshData" :disabled="isLoading">Search</v-btn>
          </v-col>
        </v-row>

        <v-row class="px-8">
          <v-col cols="4"></v-col>
          <v-col cols="2">
            <v-text-field
              v-model.trim="searchContent"
              placeholder="Search content"
              size="is-small"
              :disabled="isLoading"
            />
          </v-col>

          <v-col cols="2">
            <v-select
              class="pt-1"
              v-model="selectedFilters"
              :disabled=" isLoading"
              :items="filterItems"
              item-value="value"
              item-text="text"
              chips
              dense
              label="Filters"
              multiple
            >
              <template v-slot:selection="{ item, index }">
                <v-chip v-if="index === 0">
                  <span>{{ item.text }}</span>
                </v-chip>
                <span v-if="index === 1" class="grey--text text-caption">(+{{ selectedFilters.length - 1 }} others)</span>
              </template>
            </v-select>
          </v-col>

          <v-col cols="2">
            <v-text-field
              type="number"
              label="Limit"
              v-model="rowsLimit"
              size="is-small"
              :disabled="isLoading"
            />
          </v-col>
          <v-col cols="1">
            <v-checkbox dense v-model="includePositions" :disabled="isLoading" label="GPS data"></v-checkbox>
          </v-col>
          <v-col cols="1">
            <v-checkbox dense v-model="includeBuffer" :disabled="isLoading" label="Include newest"></v-checkbox>
          </v-col>

        </v-row>

      </v-card>

    <v-card v-if="currentList === 'events'">
      <v-data-table
        :items="filteredItems"
        :loading="isLoading"
        :per-page="perPage"
        @click:row="showDetailsModal"
        loading-text="Loading... Please wait"
        :headers="headers"
        :sort-by="['receivedAt']"
        :sort-desc="['true', 'false']"
        :footer-props="{ 'items-per-page-options': (items_per_page = [10, 100, -1]) }"
        dense
      >
        <template v-slot:footer>
            <MassHandleButton
            class="my-2 ml-6 mr-2 float-right"
            v-if="filteredItems.length > 0"
            :icon="'mdi-microsoft-excel'"
            :tooltip="'Export to Excel'"
            :loading="exportingToExcel"
            :buttonColor="'success'"
            @buttonClicked="exportDataSourcesToExcel"
            data-cy="export-excel-datasource"
          ></MassHandleButton>
        </template>

        <template v-slot:item.receivedAt="{ item }">
          {{ item.receivedAt | datetime }}
        </template>

        <template v-slot:item.protocol="{ item }">
          {{ item.protocol }}
        </template>

        <template v-slot:item.originator="{ item }">
          {{ item.originator }}
        </template>

        <template v-slot:item.eventType="{ item }">
          {{ item.eventType }}
        </template>

        <template v-slot:item.content="{ item }">
          {{ item.content }}
          <span v-if="item.hasPosition" title="Position">📍</span>
          <span v-if="item.hasSystemReport" title="System Report">📝</span>
          <span v-if="item.hasScan" title="Scan">📶</span>
          <span v-if="item.hasDebug" title="Debug">🐛</span>
        </template>
      </v-data-table>
    </v-card>

    <Details v-bind="detailsProps" v-model="isModalActive" :unitId="unitId"/>

  </v-card>
</template>

<script lang="ts">
import axios from "~/axios-client";
import Details from "./Details.vue";
import moment from "moment";
import MassHandleButton from "@/components/MassHandleButton";
import {exportToExcelFile} from "@/helpers/excel-util";
import util from "@/helpers/util"
import qs from "qs";

export default {
  name: "TelemetryList",
  props: {
    unitId: { type: Number },
    unitTypeId: { type: String }
  },
  components: {
    Details,
    MassHandleButton
  },
  data: () => {
    return {
      items: [],
      isLoading: false,
      includePositions: false,
      includeBuffer: false,
      from: new Date(),
      to: new Date(),
      searchContent: "",
      rowsLimit: 50,
      showEmptySection: false,
      isModalActive: false,
      detailsProps: {},
      perPage: 30,
      isPaginationEnabled: false,
      last24hours: false,
      fullScreenModal: false,
      selectedFilters: [],
      headers: [
        { text: "", value: "index" },
        { text: "ReceivedAt", value: "receivedAt" },
        { text: "Protocol", value: "protocol" },
        { text: "Originator", value: "originator" },
        { text: "EventType", value: "eventType" },
        { text: "Content", value: "content" }
      ],
      textFieldProps: {
        prependIcon: "mdi-calendar"
      },
      filterItems: [
        { text: "📍 Position", value: "position" },
        { text: "📝 System report", value: "systemreport" },
        { text: "📶 Scan", value: "scan" },
        { text: "🐛 Debug", value: "debug" }
      ],
      currentList: 'events',
      exportingToExcel: false
    };
  },
  async mounted() {
    this.from = moment().startOf('year').toDate();
    this.to = moment().endOf('day').toDate();

    await this.refreshData();
  },
  watch: {
    from() {
      this.clearItems();
    },
    to() {
      this.clearItems();
    }
  },
  computed: {
    filteredItems() {
      return this.items.filter(i => {
        if (this.selectedFilters.length === 0) return true;

        let filters = this.selectedFilters;

        if (filters.includes("position") && i.hasPosition ||
            filters.includes("systemreport") && i.hasSystemReport ||
            filters.includes("scan") && i.hasScan ||
            filters.includes("debug") && i.hasDebug)
          return true;

        return false;
      });
    }
  },
  methods: {

    closeDialog(){
      this.isModalActive = false
    },
    clearItems() {
      this.isModalActive = false
      this.detailsProps = {}
      this.items = [];
    },
    async refreshData() {
      this.isLoading = true;
      this.clearItems();
      await this.fetchData();
    },
    isDiagnosticEvent(row) {
      return row.eventType.indexOf("DiagnosticReceived") != -1;
    },
    datetimeFormatter(date) {
      return this.$options.filters.dateTime(date);
    },
    showDetailsModal(row) {
      this.fullScreenModal = this.isDiagnosticEvent(row);
      this.isModalActive = true;
      this.detailsProps = row;
    },
    hasPosition(row) {
      return row.eventType.indexOf("DiagnosticReceived") != -1;
    },
    isPositionEvent(eventType) {
      return eventType.indexOf("PositionPackage") != -1;
    },
    async fetchData() {
      this.isLoading = true
      this.showEmptySection = false;
      const params = {
        from: moment(this.from).format('YYYY-MM-DDThh:mm:ss.SSSZ'),
        to: moment(this.to).format('YYYY-MM-DDThh:mm:ss.SSSZ'),
        includePositions: this.includePositions,
        includeBuffer: this.includeBuffer,
        searchContent: [],
        excludeContent: [],
        searchEventType: [],
        excludeEventType: [],
        limit: this.rowsLimit
      };

      if (this.searchContent && this.searchContent != "") {
        let splittedContent = this.searchContent.split(" ");
        params.searchContent = splittedContent.filter(
          i => !i.startsWith("!") && !i.startsWith("e:") && !i.startsWith("!e:")
        );
        params.excludeContent = splittedContent.filter(
          i => i.startsWith("!") && !i.startsWith("!e:")
        );
        params.searchEventType = splittedContent.filter(i =>
          i.startsWith("e:")
        );
        params.excludeEventType = splittedContent.filter(i =>
          i.startsWith("!e:")
        );
        for (let i = 0; i < params.excludeContent.length; i++) {
          params.excludeContent[i] = params.excludeContent[i].substr(1);
        }
        for (let i = 0; i < params.searchEventType.length; i++) {
          params.searchEventType[i] = params.searchEventType[i].substr(2);
        }
      }

      try {
        let response = await axios.get(`/api/telemetry/unit/${this.unitId}${this.last24hours ? '/last24hours' : ''}`, { params: params, paramsSerializer: qs.stringify })
        this.items = response.data.map((item, index) => {
          item.index = index
          if (item.data) {
            const data = JSON.parse(item.data);

            if (data.TelemetryId && data.Headers && data.Headers["originator"]) {
              item.originator = data.Headers["originator"];
            } else {
              item.originator = data.Originator;
            }

            if (this.isPositionEvent(item.eventType) && data.Positions && data.Positions.length > 0) {
              const lastPositionDate = this.datetimeFormatter(new Date(data.Positions[data.Positions.length - 1].LogDate));
              if (data.Positions.length == 1) item.content = `Received ${data.Positions.length} position. ${lastPositionDate}`;
              else item.content = `Received ${data.Positions.length} positions. ${lastPositionDate}`;
              if (data.IsLast) item.content = item.content + " - Last pos";
            }
          }
          item.index = index;
          let jsonData = JSON.parse(item.data);
          item.hasPosition = jsonData.Position != null;
          item.hasSystemReport = jsonData.System && jsonData.System.Report != null;
          item.hasScan = jsonData.Scan != null;
          item.hasDebug = jsonData.System && jsonData.System.Debug != null;
          item.eventType = item.eventType ? item.eventType.split('.').pop() : ''
          return item;
        });
        this.showEmptySection = this.items.length === 0;
      } catch(ex){
        this.$eventBus.$emit('alert', { text: `Unable to fetch telemetry log for unit ${this.unitId}`, type: 'error'});
      }
      this.isLoading = false;
    },
    async exportDataSourcesToExcel() {
      let fromDateString = this.from.toISOString().replaceAll(':', '_').replaceAll('.', '__')
      let toDateString = this.to.toISOString().replaceAll(':', '_').replaceAll('.', '__')
      const fileName = `telemetryLog-${this.unitTypeId}-${this.unitId}-${fromDateString}-${toDateString}.xlsx`;
      const sheetName = 'Log'

      let data = []
      let tempArray = JSON.parse(JSON.stringify(this.filteredItems))
      tempArray.forEach(x => {
        x.data = JSON.parse(x.data)
        let temp = util.flattenDict(x)
        data.push(temp)
      })
      await exportToExcelFile(fileName, sheetName, data);
      this.exportingToExcel = false
    },
  }
};
</script>
<style lang="scss">

</style>
