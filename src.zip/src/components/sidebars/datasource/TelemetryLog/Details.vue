<template>
  <v-dialog v-model="displayDialog" max-width="80%">
    <v-card class="pa-4">
      <v-card-title class="d-flex">
        Event details
        <v-spacer></v-spacer>
        <v-btn
          icon
          @click="displayDialog = false"
        >
          <v-icon large>mdi-close</v-icon>
        </v-btn>
      </v-card-title>

      <v-divider></v-divider>

      <vue-json-pretty
        :data="jsonData"
        :deep="2"
        :showDoubleQuotes="false"
        :showLength="true"
        :highlightMouseoverNode="true"
        class="ma-6"
      />
    </v-card>
  </v-dialog>
</template>

<script lang="ts">
import VueJsonPretty from "vue-json-pretty";
import 'vue-json-pretty/lib/styles.css';

export default {
  name: "Details",
  components: {
    VueJsonPretty,
  },
  props: {
    value: { type: Boolean, default: false },
    data: { type: String },
    unitId: { type: Number },
    content: { type: String },
    receivedAt: { type: String },
    eventType: { type: String },
  },
  data: () => {
    return {
      jsonData: {},
      showDiagnosticTable: false,
      showDialogModel: false
    };
  },
  mounted() {
    this.showDialogModel = this.showDialog
  },
  destroyed() {
  },
  methods: {
    closeDialog(){
      this.$emit("close");
    },
    isDiagnosticEvent() {
      if(!this.eventType) return false
      return this.eventType.indexOf("Diagnostic") != -1;
    },
    getEventType() {
      return this.eventType.split(".").pop();
    }
  },
  computed: {
    displayDialog: {
      get() {
        // returns the value of your prop
        return this.value
      },
      set(newValue) {
        // v-model listens to the input event, so emitting `input` with a value
        // will update the model with that value
        this.$emit('input', newValue)
      }
    }
  },
  watch: {
    value(val) {
      if(!val) return
      this.jsonData = JSON.parse(this.data);
      this.jsonData.EventType = this.getEventType();
      if (this.content) this.jsonData.Content = this.content;
    }
  },
};
</script>
