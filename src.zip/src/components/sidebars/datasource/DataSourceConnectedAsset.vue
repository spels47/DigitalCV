<template>
  <v-card
    outlined
    class="fill-width"
  >
    <v-row cols="12">
      <v-list>
        <v-progress-linear indeterminate color="black" v-if="isLoading"></v-progress-linear>
        <v-list-item three-line>
          <v-list-item-content>
            <v-list-item-subtitle>
              <DepartmentPath class="ml-5" clickable :department-path="dataSource.departmentPath"></DepartmentPath>
            </v-list-item-subtitle>
            <v-list-item-title class="headline ml-5">
              <span>Data source connected asset</span>
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-row>
    <v-row cols="12" class="ml-5" no-gutters>
      <v-row>
        <v-list width="80%" v-if="connectedAsset && connectedAsset.vehicleId === undefined">
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-identifier" label="Alias" :value="connectedAsset.alias" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-numeric" label="License plate" :value="connectedAsset.simcardLicensePlateNumber" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-identifier" label="Primary data source id" :value="connectedAsset.primaryDataSourceId" />
          </v-list-item>
          <v-row class="justify-center">
            <v-col cols="4">
              <v-list-item class="icon-button-wrap">
                <v-icon>mdi-domain</v-icon>
                <v-list-item-subtitle>Move asset</v-list-item-subtitle>
              </v-list-item>
            </v-col>
            <v-col cols="4">
              <v-list-item class="icon-button-wrap" @click="toggleFavorite">
                <v-icon :color="isFavorite ? 'marked' : ''">mdi-heart</v-icon>
                <v-list-item-subtitle>
                  <span v-if="isFavorite">Favorite</span>
                  <span v-if="!isFavorite">Add to favorites</span>
                </v-list-item-subtitle>
              </v-list-item>
              <v-list-item class="icon-button-wrap">
                <v-icon color="error">mdi-delete</v-icon>
                <v-list-item-subtitle>Delete asset</v-list-item-subtitle>
              </v-list-item>
            </v-col>
            <v-col cols="4">
              <v-list-item class="icon-button-wrap">
                <v-icon>mdi-cog-counterclockwise</v-icon>
                <v-list-item-subtitle>Revise usage</v-list-item-subtitle>
              </v-list-item>
            </v-col>
          </v-row>

          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-cog" label="Asset type" :value="connectedAsset.typeOfObject" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-information-outline" label="Unit description" :value="connectedAsset.objectDescription" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-information-outline" label="Unit info" :value="connectedAsset.unitInfo" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-calendar" label="Last contact" :value="connectedAsset.lastContact | date" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-calendar" label="Last inspection" :value="connectedAsset.lastInspection | date" />
          </v-list-item>
          <!--          <v-list-item>-->
          <!--            <v-text-field readonly prepend-icon="mdi-calendar" label="Next inspection" :value="equipment.inspectionInterval" ></v-text-field>-->
          <!--          </v-list-item>-->
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-information-outline" label="Unit status" :value="connectedAsset.unitStatus" />
          </v-list-item>
        </v-list>

        <v-list width="80%" v-if="connectedAsset.vehicleId !== undefined">
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-identifier" label="Alias" :value="connectedAsset.alias" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-numeric" label="License plate" :value="connectedAsset.licensePlate" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-calendar" label="Vehicle Id" :value="connectedAsset.vehicleId" />
          </v-list-item>
          <v-row class="justify-center">
            <v-col cols="4">
              <v-list-item class="icon-button-wrap">
                <v-icon>mdi-domain</v-icon>
                <v-list-item-subtitle>Move asset</v-list-item-subtitle>
              </v-list-item>
              <v-list-item class="icon-button-wrap">
                <v-icon v-if="connectedAsset.currentDriverId">mdi-car-arrow-right</v-icon>
                <v-icon v-if="!connectedAsset.currentDriverId">mdi-car-arrow-left</v-icon>
                <v-list-item-subtitle>
                  <span v-if="connectedAsset.currentDriverId">Unassign driver</span>
                  <span v-if="!connectedAsset.currentDriverId">Assign driver</span>
                </v-list-item-subtitle>
              </v-list-item>
            </v-col>
            <v-col cols="4">
              <v-list-item class="icon-button-wrap" @click="toggleFavorite">
                <v-icon :color="isFavorite ? 'marked' : ''">mdi-heart</v-icon>
                <v-list-item-subtitle>
                  <span v-if="isFavorite">Favorite</span>
                  <span v-if="!isFavorite">Add to favorites</span>
                </v-list-item-subtitle>
              </v-list-item>
              <v-list-item class="icon-button-wrap">
                <v-icon color="error">mdi-delete</v-icon>
                <v-list-item-subtitle>Delete vehicle</v-list-item-subtitle>
              </v-list-item>
            </v-col>
            <v-col cols="4">
              <v-list-item class="icon-button-wrap">
                <v-icon>mdi-map-marker-path</v-icon>
                <v-list-item-subtitle>Revise trips</v-list-item-subtitle>
              </v-list-item>
            </v-col>
          </v-row>

          <v-list-item>
            <v-select
              readonly
              prepend-icon="mdi-car-cog"
              :items="['PRIVATE', 'CORPORATE', 'CORPORATE2', 'COMPANY']"
              label="Vehicle type"
              v-model="connectedAsset.objectType"
            ></v-select>
          </v-list-item>


          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-car" label="Make" :value="connectedAsset.make" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-car" label="Model" :value="connectedAsset.model" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-calendar" label="Registration date" :value="connectedAsset.vehicleCreatedDate | date" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-beaker-outline" label="Emissions CO2" :value="connectedAsset.emissionCo2" suffix="g/km"/>
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-format-color-fill" label="Color" :value="connectedAsset.color" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-calendar" label="Road toll profile" :value="connectedAsset.tollRoadProfile" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-airplane" label="Current mileage" :value="connectedAsset.currentMileage" suffix="km" />
          </v-list-item>
        </v-list>
        <v-list width="80%" v-if="connectedAsset.id === undefined">
        <span>The assets that this data source is connected to could not be found</span>
        </v-list>
      </v-row>
    </v-row>
  </v-card>
</template>

<script>
import axios from "~/axios-client"
import DepartmentPath from "~/components/DepartmentPath"
import FeatureConfiguration from "~/components/FeatureConfiguration"
export default {
  name: "DataSourceConnectedAsset",
  components: {DepartmentPath},
  showResult: false,
  props: {
    id: String,
    type: String,
    expanded: Boolean
  },
  data: function () {
    return {
      dataSource: {},
      connectedAsset: '',
      isLoading:true
    }
  },
  mounted() {
    this.getDataSourceInfo()
    this.getConnectedAsset()
  },
  watch: {
    id: function () {
      this.getDataSourceInfo()
      this.getConnectedAsset()
    }
  },
  methods:{
    getDataSourceInfo(){
      this.dataSource = {}
      this.isLoading = true
      if(!this.type) return
      axios.get(`/api/datasource/${this.type}/${this.id}`)
        .then((res) => this.dataSource = res.data)
        // .catch(() => alert('error'))
        .finally(() => this.isLoading = false)
    },
    getConnectedAsset() {
      this.connectedAsset = ''
      this.isLoading = true
      axios.get(`/api/datasource/connectedAsset/${this.id}`)
        .then((res) => this.connectedAsset = res.data)
        // .catch(() => alert('error'))
        .finally(() => this.isLoading = false)
    },
    updateDataSourceInfo(){
      clearTimeout(this._timerId);

      this._timerId = setTimeout(() => {
        this.isLoading = true
        axios.put(`/api/datasource/${this.type}`, this.dataSource)
          .finally(() => this.isLoading = false)
      }, 500);
    },
  }
}
</script>

<style scoped>
.fill-width{
  width: 100%;
}

.icon-button-wrap {
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
