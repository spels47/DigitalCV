<template>
  <BaseSidebar :menuItems="menuItems" @sidebarSizeChanged="sidebarSizeChanged" @pageChanged="pageChanged" :stateless="isStateless">
    <span>
      <DataSourceDetails :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'datasource-details'" v-on:dataSourceIdChange="dataSourceIdChange" @pageChanged="pageChanged"></DataSourceDetails>
      <DataSourceDiagnostics :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'datasource-diagnostics'"></DataSourceDiagnostics>
      <MiniDiagnostics :id="id" :expanded="expanded" v-if="currentPage === 'mini-diagnostics'"></MiniDiagnostics>
      <DataSourceTelemetry :id="id" :type="'simcard'" :expanded="expanded" v-if="currentPage === 'datasource-telemetry'"></DataSourceTelemetry>
      <DataSourceTelemetryLog :id="id" :type="'simcard'" :expanded="expanded" v-if="currentPage === 'datasource-telemetry2'"></DataSourceTelemetryLog>
      <DataSourceAuditDetails :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'audit-details'"></DataSourceAuditDetails>
      <DataSourceConnectedRfid :simcardId="dataSource.simcardId" :expanded="expanded" v-if="currentPage === 'datasource-connected-rfid' && dataSource.hardwareSerialNumber" @pageChanged="pageChanged"></DataSourceConnectedRfid>
      <DataSourceWarehouseLog  :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'datasource-warehouse-log'"></DataSourceWarehouseLog>
    </span>
  </BaseSidebar>
</template>

<script>
import axios from "~/axios-client";
import BaseSidebar from "../BaseSidebar";
import DataSourceDetails from "./DataSourceDetails";
import DataSourceDiagnostics from "./DataSourceDiagnostics";
import DataSourceTelemetry from "./DataSourceTelemetry";
import DataSourceTelemetryLog from "./DataSourceTelemetryLog";
import DataSourceAuditDetails from "./DataSourceAuditDetails";
import MiniDiagnostics from "@/components/sidebars/datasource/MiniDiagnostics";
import DataSourceConnectedRfid from "./DataSourceConnectedRfid";
import DataSourceWarehouseLog from "@/components/sidebars/datasource/DataSourceWarehouseLog"
export default {
  props: ["id", "customer", "stateless"],
  components: {
    DataSourceWarehouseLog,
    MiniDiagnostics,
    BaseSidebar,
    DataSourceDetails,
    DataSourceDiagnostics,
    DataSourceTelemetry,
    DataSourceTelemetryLog,
    DataSourceAuditDetails,
    DataSourceConnectedRfid
  },
  data() {
    return {
      expanded: false,
      currentPage: "datasource-details",
      menuItems: []
    };
  },
  methods: {
    sidebarSizeChanged(state) {
      this.expanded = state;
    },
    pageChanged(page) {
      this.currentPage = page;
    },
    async dataSourceIdChange(serialNumber) {
      if (!serialNumber) return;
      if (serialNumber.startsWith("FAKE")) {
        this.menuItems = [
          { page: "datasource-details", icon: "mdi-information", expandedAsDefault: false, id: 0 }
        ];
        return; // FAKE unit from asset management
      }
      if (serialNumber.startsWith("MUM") || serialNumber.startsWith("AM")) {
        this.menuItems = [
          { page: "datasource-details", icon: "mdi-information", expandedAsDefault: false, id: 0 },
          { page: "mini-diagnostics", icon: "mdi-heart-pulse", expandedAsDefault: false, id: 2 }
        ];
        return; // MINI
      }

      try {
        let res = await axios.get(`/api/datasource/connectedAsset/${this.dataSource.simcardId}`);
        this.vehicle = res.data;
      } catch (ex) {
        this.$eventBus.$emit('alert', { text: `Failed to look up info about connected asset`, type: 'error'});
      }
      this.menuItems = [
        { page: "datasource-details", icon: "mdi-information", expandedAsDefault: false, id: 0 },
        { page: "datasource-diagnostics", icon: "mdi-heart-pulse", expandedAsDefault: true, id: 4 },
        { page: "datasource-telemetry", icon: "mdi-signal", expandedAsDefault: true, id: 5 },
        { page: "audit-details", icon: "mdi-math-log", expandedAsDefault: false, id: 7 }
      ]

      if (this.dataSource.hardwareSerialNumber) {
        this.menuItems.push({ page: "datasource-connected-rfid", icon: "mdi-access-point", expandedAsDefault: true, id: 6 })
      }

      if(this.roles.DEVELOPER_ASAP) {
        this.menuItems.push({ page: "datasource-telemetry2", icon: "mdi-signal", expandedAsDefault: true, id: 99 },)

      }
      if(this.roles.RETURN_HANDLING){
        this.menuItems.push({ page: "datasource-warehouse-log", icon: "mdi-dolly", expandedAsDefault: false, id: 8 },)
      }
    }

  },
  computed: {
    isStateless() {
      return this.stateless ?? false;
    },
    dataSource() {
      return this.$store.state.SidebarModule.selectedDataSource;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
  }
};
</script>

<style></style>
