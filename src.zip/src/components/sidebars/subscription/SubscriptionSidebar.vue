﻿<template>
  <BaseSidebar :menuItems="menuItems" @sidebarSizeChanged="sidebarSizeChanged" @pageChanged="pageChanged">
    <span>
      <SubscriptionDetails :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'subscription-details'"></SubscriptionDetails>
      <SubscriptionDetailsDebug :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'subscription-details-debug'"></SubscriptionDetailsDebug>
      <SubscriptionDetailsList :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'subscription-list'"> </SubscriptionDetailsList>
    </span>
  </BaseSidebar>
</template>

<script>
import BaseSidebar from "../BaseSidebar";
import SubscriptionDetails from "@/components/sidebars/subscription/SubscriptionDetails";
import SubscriptionDetailsList from "@/components/sidebars/subscription/SubscriptionDetailsList";
import SubscriptionDetailsDebug from "@/components/sidebars/subscription/SubscriptionDetailsDebug";
export default {
  props: ["id", "customer"],
  components: {
    SubscriptionDetailsDebug,
    SubscriptionDetailsList,
    SubscriptionDetails, BaseSidebar },
  data() {
    return {
      expanded: false,
      currentPage: "subscription-details",
    };
  },
  methods: {
    sidebarSizeChanged(state) {
      this.expanded = state;
    },
    pageChanged(page) {
      this.currentPage = page;
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
    menuItems() {
      if(this.roles.DEVELOPER_ASAP)
      {
        return [
          {page: 'subscription-details', icon: 'mdi-information', id: 0},
          {page: 'subscription-details-debug', icon: 'mdi-clipboard', id: 1},
          {page: 'subscription-list', icon: 'mdi-clipboard-list', id: 2 }
        ]
      }
      else
      {
        return [
          {page: 'subscription-details', icon: 'mdi-information', id: 0},
        ]
      }
    }
  }
};
</script>

<style></style>
