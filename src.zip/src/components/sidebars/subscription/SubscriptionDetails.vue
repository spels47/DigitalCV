﻿<template>
  <v-container>
    <v-row no-gutters>
      <v-progress-linear indeterminate color="black" v-if="loading"></v-progress-linear>
      <v-col cols="lg-12">
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
              </v-list-item-subtitle>
              <v-list-item-title class="headline ml-5">
                <span>Subscription info</span>
              </v-list-item-title>
              <v-list-item-title class="headline ml-5" v-if="hasExpired">
                <span class="error--text">
                EXPIRED
                  </span>
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="lg-12">
        <v-list min-width="100">
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-numeric" label="Subscription Number" :value="subscriptionNumber" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-calendar" label="Subscription Start Date" :value="subscriptionStartDate | ntzDatetimeSeconds" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-calendar" label="Renewal Date" :value="subscriptionRenewalDate | ntzDatetimeSeconds" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-calendar" label="Termination Date" :value="subscriptionTerminationDate | ntzDatetimeSeconds" />
          </v-list-item>
          <v-list-item>
            <ClickableSelectWithDialog
              @itemClicked="navigateToAssignedItem"
              :fieldLabel="'Main Item'"
              :itemText="serialNumber"
              :icon="'mdi-rss'"
              :showAppendIcon = false
            ></ClickableSelectWithDialog>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row cols="lg-12">
      <v-col cols="lg-12">
        <v-list min-width="100">
          <v-data-table
            dense
            hide-default-footer
            :headers="getHeaders()"
            :item-class="rowClass"
            :items="subscriptions">
            <template v-slot:item.createdDate="{ item }">
              <span>{{ item.createdDate | datetime }}</span>
            </template>
            <template v-slot:item.expiredDate="{ item }">
              <span>{{ item.expiredDate | datetime }}</span>
            </template>
          </v-data-table>
        </v-list>
      </v-col>
    </v-row>
  </v-container>


</template>

<script>
import ClickableSelectWithDialog from "@/components/ClickableSelectWithDialog";

export default {
  name: "SubscriptionDetails",
  components: {ClickableSelectWithDialog},
  props: {
    id: String,
    customer: Object,
    expanded: Boolean,
  },
  data: function () {
    return {
      loading: false,
      subscriptionNumber: "",
      subscriptionStartDate: "",
      subscriptionTerminationDate: "",
      subscriptionRenewalDate: "",
      serialNumber: "",
      hasExpired: false,
      unitSettings: [],
      headers: [
        {text: 'Description', value: 'subscriptionName'},
        {text: 'Serial Number', value: 'serialNumber'},
      ],
      headersLong: [
        {text: 'Description', value: 'subscriptionName'},
        {text: 'Serial Number', value: 'serialNumber'},
        {text: 'Register date', value: 'createdDate'},
        {text: 'Expired date', value: 'expiredDate'}
      ],
      subscriptions: []
    }
  },
  methods:{
    rowClass(item) {
      if(item.expiredDate) return 'tablered'
      return ''
    },
    navigateToAssignedItem() {
      this.$router.push({ path: `/customer/${this.$route.params.id}?type=simcard&activeTab=5&id=${this.serialNumber}` }).catch(err => {});
    },
    getHeaders() {
      if (this.expanded) {
        return this.headersLong;
      }
      return this.headers;
    },
    setVariables(sub) {
      if(sub.length > 0)
      {
        this.subscriptionNumber = sub[0].contractNumber;
        this.subscriptionStartDate = sub[0].createdDate;
        this.subscriptionTerminationDate = sub[0].terminationDate;
        this.subscriptionRenewalDate = sub[0].renewalDate;
        this.serialNumber = sub[0].serialNumber;
        this.hasExpired = !sub.some(x => x.expiredDate == null)
      }
    },
    async setSubscriptions() {
      this.loading = true;
      await this.$store.dispatch("retrieveSubscriptionsAsync", {id: this.id, erpClientId: this.customer.erpClientId, erpCustomerId: this.customer.erpCustomerId})
      let sub = this.$store.state.SidebarModule.selectedSubscriptions;
      this.loading = false;
      if (!sub) return;
      this.setVariables(sub);
      this.subscriptions = sub;
    }
  },
  async mounted() {
    await this.setSubscriptions()
  },
  watch: {
    id: async function () {
      await this.setSubscriptions()
    },
  }
}
</script>

<style lang="css" scoped>
.expired-row{
  background-color: #a59800;
}
</style>
