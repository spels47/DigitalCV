﻿<!-- TODO: Not compatible with new sidebar system -->
<template>
  <v-card
    outlined
    class="fill-width"
  >
    <v-row cols="12">
      <v-progress-linear indeterminate color="black" v-if="loading"></v-progress-linear>
      <v-list>
        <v-list-item three-line>
          <v-list-item-content>
            <v-list-item-subtitle>
            </v-list-item-subtitle>
            <v-list-item-title class="headline ml-5">
              <span>Subscription debug</span>
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list>
    </v-row>
    <v-row cols="12" class="ml-5" no-gutters>
      <v-row>
        <v-list width="80%">
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-numeric" label="Serial Number" :value="id" />
          </v-list-item>

          <v-subheader>
            <v-icon left>mdi-toy-brick</v-icon>
            Features:
          </v-subheader>
          <v-list-item v-if="unitFeatures">
            <v-list-item-content v-if="unitFeatures.length === 0">
              <v-list-item-subtitle class="text-center">No items</v-list-item-subtitle>
            </v-list-item-content>
            <feature-configuration :features="unitFeatures"></feature-configuration>
          </v-list-item>

          <v-subheader>
            <v-icon left>mdi-cog</v-icon>
            Customer settings:
          </v-subheader>
          <v-list-item v-if="customerSettings">
            <v-list-item-content v-if="customerSettings.length === 0">
              <v-list-item-subtitle class="text-center">No items</v-list-item-subtitle>
            </v-list-item-content>
            <v-simple-table v-if="customerSettings.length > 0">
              <template v-slot:default>
                <thead>
                <tr>
                  <th>Type</th>
                  <th>Name</th>
                  <th>Value</th>
                </tr>
                </thead>
                <tbody>
                <tr v-for="(customerSetting, index) in customerSettings" :key="index">
                  <td>{{ customerSetting.typeOfSetting }}</td>
                  <td>{{ customerSetting.settingName }}</td>
                  <td>{{ customerSetting.settingValue }}</td>
                </tr>
                <tr v-if="customerSettings.length === 0">No items</tr>
                </tbody>
              </template>
            </v-simple-table>
          </v-list-item>

          <v-subheader>
            <v-icon left>mdi-cog</v-icon>
            Unit settings:
          </v-subheader>
          <v-list-item v-if="unitSettings">
            <v-list-item-content v-if="unitSettings.length === 0">
              <v-list-item-subtitle class="text-center">No items</v-list-item-subtitle>
            </v-list-item-content>
            <v-simple-table v-if="unitSettings.length > 0">
              <template v-slot:default>
                <thead>
                <tr>
                  <th>Name</th>
                  <th>Value</th>
                </tr>
                </thead>
                <tbody>
                <tr v-for="(unitSetting, index) in unitSettings" :key="index">
                  <td>{{ unitSetting.settingName }}</td>
                  <td>{{ unitSetting.settingValue }}</td>
                </tr>
                </tbody>
              </template>
            </v-simple-table>
          </v-list-item>
        </v-list>
      </v-row>

    </v-row>
  </v-card>


</template>

<script>
import axios from "~/axios-client"
import FeatureConfiguration from "~/components/FeatureConfiguration"
export default {
  name: "SubscriptionDetailsDebug",
  props: {
    id: String,
    customer: Object,
  },
  data: function(){
    return {
      finishedCalls: 0,
      unitSettings: [],
      customerSettings: [],
      unitFeatures: [],
    }
  },
  mounted() {
    this.getData()
  },
  watch: {
    id: function () {
      this.getData()
    }
  },
  methods:{
    async getData() {
      await this.$store.dispatch("retrieveSubscriptionsAsync", {
        id: this.id,
        erpClientId: this.customer.erpClientId,
        erpCustomerId: this.customer.erpCustomerId
      });
      let activeSub = this.$store.state.SidebarModule.selectedSubscriptions;
      if(activeSub.length <= 0) return
      let serialNumber = activeSub[0].serialNumber;

      this.unitSettings = []
      this.customerSettings = []
      this.unitFeatures = []
      this.finishedCalls = 0

      axios.get(`/api/subscription/UnitSettings?clientId=${this.customer.erpClientId}&customerId=${this.customer.erpCustomerId}&serialNumber=${serialNumber ?? ''}`)
        .then((res) => this.unitSettings = res.data)
        .catch(() => alert('error'))
        .finally(() => this.finishedCalls++)

      axios.get(`/api/subscription/CustomerSettings?clientId=${this.customer.erpClientId}&customerId=${this.customer.erpCustomerId}&serialNumber=${serialNumber ?? ''}`)
        .then((res) => this.customerSettings = res.data)
        .catch(() => alert('error'))
        .finally(() => this.finishedCalls++)

      axios.get(`/api/subscription/UnitFeatures?clientId=${this.customer.erpClientId}&customerId=${this.customer.erpCustomerId}&serialNumber=${serialNumber ?? ''}`)
        .then((res) => this.unitFeatures = res.data)
        .catch(() => alert('error'))
        .finally(() => this.finishedCalls++)
    }
  },
  computed:{
    loading(){
      return this.finishedCalls < 3
    }
  },
  components: {
    FeatureConfiguration
  }
}
</script>

<style lang="css" scoped>
.fill-width{
  width: 100%;
}
</style>
