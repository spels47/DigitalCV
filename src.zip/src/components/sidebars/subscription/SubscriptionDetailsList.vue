﻿<template>
  <v-container>
    <v-row no-gutters>
      <v-progress-linear indeterminate color="black" v-if="loading"></v-progress-linear>
      <v-col cols="lg-12">
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
              </v-list-item-subtitle>
              <v-list-item-title class="headline ml-2">
                <span>Subscription list</span>
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="lg-12">
        <v-list min-width="100%">
          <v-list-item>
            <v-simple-table dense>
              <template v-slot:default>
                <thead>
                <tr>
                  <th>ClientId/CustomerId</th>
                  <th>SubscriptionName</th>
                  <th>SerialNumber</th>
                  <th>AddonSerialNumber</th>
                  <th>CreatedDate</th>
                  <th>CreationTrigger</th>
                  <th>ExpiredDate</th>
                  <th>ExpirationTrigger</th>
                </tr>
                </thead>
                <tbody>
                <tr v-for="(subscription, index) in subscriptions" :key="index" :class="{'tablered' : subscription.expiredDate != null}">
                  <td>{{ subscription.clientId }}/{{ subscription.customerId }}</td>
                  <td>{{ subscription.subscriptionName }}</td>
                  <td>{{ subscription.serialNumber }}</td>
                  <td>{{ subscription.addonSerialNumber }}</td>
                  <td>{{ subscription.createdDate | date }}</td>
                  <td>{{ subscription.creationTrigger }}</td>
                  <td>{{ subscription.expiredDate | date }}</td>
                  <td>{{ subscription.expirationTrigger }}</td>
                </tr>
                </tbody>
              </template>
            </v-simple-table>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
  </v-container>


</template>

<script>
export default {
  name: "SubscriptionDetailsList",
  props: {
    id: String,
    customer: Object,
  },
  data: function () {
    return {
      loading: false,
    }
  },
  async mounted() {
    await this.$store.dispatch("retrieveSubscriptionsAsync", {
      id: this.id,
      erpClientId: this.customer.erpClientId,
      erpCustomerId: this.customer.erpCustomerId
    });
  },
  computed: {
    subscriptions() {
      return this.$store.state.SidebarModule.selectedSubscriptions;
    },
  },
  watch: {
    id: async function () {
      await this.$store.dispatch("retrieveSubscriptionsAsync", {
        id: this.id,
        erpClientId: this.customer.erpClientId,
        erpCustomerId: this.customer.erpCustomerId
      });
    },
  },
  methods: {},
}
</script>

<style lang="css" scoped>
.fill-width {
  width: 100%;
}
</style>
