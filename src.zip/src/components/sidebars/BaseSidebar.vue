<template>
  <v-navigation-drawer
    :width="expanded ? expandedWidth : normalWidth"
    :stateless="stateless"
    class="pr-15"
    color="cardbg"
    right
    temporary
    app
    v-model="sidebarState"
    hide-overlay
  >
    <BaseSidebarNavigation
      :expanded="expanded"
      :shown="sidebarState"
      :initial-page="currentPage"
      :menuItems="menuItems"
      @toggleExpand="expanded = !expanded"
      @pageChanged="pageChanged"
    >
    </BaseSidebarNavigation>
    <slot></slot>
  </v-navigation-drawer>
</template>

<script>
import BaseSidebarNavigation from "./BaseSidebarNavigation";
export default {
  components: { BaseSidebarNavigation },
  props: {
    normalWidth: {
      type: Number,
      default: 500
    },
    expandedWidth: {
      type: Number,
      default: 1300
    },
    menuItems: {
      type: Array,
      required: true
    },
    currentPage: {
      type: String
    },
    defaultExpanded: {
      type: Boolean
    },
    stateless: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      expanded: false,
    };
  },
  mounted() {
    if(this.defaultExpanded){
      this.expanded = true;
    }
  },
  methods: {
    pageChanged(page) {
      this.$emit("pageChanged", page);
    }
  },
  watch: {
    expanded() {
      this.$emit("sidebarSizeChanged", this.expanded);
    }
  },
  computed: {
    sidebarState: {
      get: function() {
        return this.$store.state.SidebarModule.sidebarState;
      },
      set: function(value) {
        this.$store.commit("updateSidebarState", value);
        if (!value) {
          this.$store.dispatch("setUrlParameter", { name: "type", value: null });
          this.$store.dispatch("setUrlParameter", { name: "id", value: null });
        }
      }
    }
  }
};
</script>

<style></style>
