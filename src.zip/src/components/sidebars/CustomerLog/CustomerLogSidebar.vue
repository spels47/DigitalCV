﻿<template>
  <BaseSidebar :menuItems="menuItems" @sidebarSizeChanged="sidebarSizeChanged" @pageChanged="pageChanged" :defaultExpanded=true>
    <span>
      <ContactLog :id="id" :customer="customer" v-if="currentPage === 'contact-log'"></ContactLog>
      <CustomerAuditLog :id="id" :customer="customer" v-if="currentPage === 'audit-log'"></CustomerAuditLog>
    </span>
  </BaseSidebar>
</template>

<script>
import BaseSidebar from "../BaseSidebar";
import ContactLog from "@/components/sidebars/CustomerLog/ContactLog";
import CustomerAuditLog from "@/components/sidebars/CustomerLog/CustomerAuditLog.vue";

export default {
  props: ["id", "customer"],
  components: {
    CustomerAuditLog,
    ContactLog,
    BaseSidebar
  },
  name: "CustomerLogSidebar",
  data() {
    return {
      currentPage: "contact-log"
    };
  },
  methods: {
    sidebarSizeChanged(state) {
      this.expanded = state;
    },
    pageChanged(page) {
      this.currentPage = page;
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
    menuItems() {
      return [
        { page: "contact-log", icon: "mdi-stack-exchange", expandedAsDefault: true, id: 0 },
        { page: "audit-log", icon: "mdi-math-log", expandedAsDefault: true, id: 1 }
      ];
    }
  }
};
</script>

<style></style>
