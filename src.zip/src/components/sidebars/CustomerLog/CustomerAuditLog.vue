﻿<template>
  <v-container>
    <v-row>
      <v-col cols="lg-12">
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath clickable :department-path="customer.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                Audit log
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="12">
        <v-text-field
          append-icon="mdi-magnify"
          label="Search"
          class="ml-2 mr-2"
          v-model="search"
        ></v-text-field>

        <v-data-table
          :headers="headers"
          :items="auditLog"
          :search="search"
          :loading="loading"
          :loading-text="'Retrieving audit log...'"
          :custom-filter="filterSearch"
          :footer-props="{ 'items-per-page-options': (items_per_page = [10, 20, 50])}"
        >
          <template v-slot:item.timestamp="{ item }">
            <span>{{ convertDate(item.timestamp) }}</span>
          </template>
        </v-data-table>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "~/axios-client"
import util from "@/helpers/util";
import DepartmentPath from "@/components/DepartmentPath.vue";

export default {
  name: "CustomerAuditLog",
  components: { DepartmentPath },
  props: ["customer"],
  data() {
    return {
      loading: false,
      search: "",
      auditLog: [],
      headers: [
        { text: 'Date', value: 'timestamp' },
        { text: 'Change', value: 'message' },
        { text: 'Old value', value: 'oldValue' },
        { text: 'New value', value: 'newValue' },
        { text: 'Responsible', value: 'name' }
      ]
    }
  },
  async mounted() {
    await this.getAuditLog()
  },
  methods: {
    filterSearch(value, search, item) {
      search = search.toString().toLowerCase();
      return Object.keys(item).some(propName => {
        return item[propName]
          ?.toString()
          .toLowerCase()
          .includes(search);
      });
    },
    async getAuditLog() {
      this.loading = true;

      try {
        const { data: log } = await axios.get(`/api/customer/details?customerId=${this.customer.id}&type=auditLog`);
        this.auditLog = log.data;
      } catch {
        this.$eventBus.$emit("alert", { text: "Failed to retrieve audit log.", type: "error" });

      } finally {
        this.loading = false;
      }
    },
    convertDate(date) {
      return util.getDateTimeByCountry(date, this.customer.country)
    }
  }
}
</script>

<style scoped>

</style>
