<template>
  <v-container>
    <v-row>
      <v-col cols="lg-12">
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath clickable :department-path="dataSource.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                <span>Data source info (OEM)</span>
              </v-list-item-title>
              <v-list-item-subtitle v-if="roles.DEVELOPER_ASAP"> {{ dataSource.dataSourceId }} - {{ dataSource.simcardId }} - {{ dataSource.subscriptionNumber }} </v-list-item-subtitle>
              <v-list-item-subtitle v-if="dataSource.id && dataSource.subscriptionExpired">
                <h2 class="error--text">EXPIRED</h2>
              </v-list-item-subtitle>
              <v-list-item-subtitle class="mt-4" v-if="dataSource.pendingHotSwap">
                <h2 class="error--text"><v-icon class="mr-2" color="red">mdi-swap-horizontal-circle</v-icon> Hot-swap in progress</h2>
                <span class="error--text" v-if="dataSource.dataSourceId === dataSource.pendingHotSwap.oldSerialNumber"> This unit will be replaced with: {{ dataSource.pendingHotSwap.newSerialNumber }} </span>
                <span class="error--text" v-if="dataSource.dataSourceId === dataSource.pendingHotSwap.newSerialNumber"> This unit will replace: {{ dataSource.pendingHotSwap.oldSerialNumber }} </span>
              </v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="lg-12">
        <v-list min-width="100">
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-identifier" label="Data Source ID" :value="dataSource.dataSourceId" />
          </v-list-item>
          <v-list-item>
            <v-text-field readonly prepend-icon="mdi-drawing" label="Type" :value="dataSource.unitTypeId + (dataSource.bmnComments != null ? ', ' + dataSource.bmnComments : '')"></v-text-field>
          </v-list-item>
          <v-list-item>
            <ClickableSelectWithDialog :disabled="true" :fieldLabel="'Subscription number'" :itemText="dataSource.subscriptionNumber" :icon="'mdi-numeric'" :showAppendIcon="false"></ClickableSelectWithDialog>
          </v-list-item>
          <v-list-item v-if="dataSource.unitTypeId !== 'MINI'">
            <v-text-field readonly prepend-icon="mdi-calendar" label="Last contact" :value="dataSource.lastContact" />
          </v-list-item>
          <v-list-item v-if="dataSource.unitTypeId === 'MINI'">
            <v-text-field readonly prepend-icon="mdi-calendar" label="Last position" :value="dataSource.lastPositionUtc"></v-text-field>
          </v-list-item>
          <v-list-item v-if="dataSource.simcardId">
            <v-text-field readonly prepend-icon="mdi-numeric" label="Simcard ID" :value="dataSource.simcardId" />
          </v-list-item>
          <v-list-item v-if="type !== 'mini'">
            <ClickableSelectWithDialog
              @itemClicked="navigateToConnectedAsset"
              :fieldLabel="'Connected Asset'"
              :itemText="asset.licensePlate ? (asset.alias ? asset.alias : '') + ' - ' + asset.licensePlate : (asset.alias ? asset.alias : '') + ' - ' + id"
              :icon="'mdi-cable-data'"
              :showAppendIcon="false"
            ></ClickableSelectWithDialog>
          </v-list-item>
          <v-list-item v-if="dataSource.hardwareSerialNumber">
            <ClickableSelectWithDialog
              @itemClicked="navigateToConnectedRfid"
              :fieldLabel="'Connected RFID'"
              :itemText="dataSource.hardwareSerialNumber + ' - ' + dataSource.hardwareType"
              :icon="'mdi-access-point'"
              :showAppendIcon="false"
            ></ClickableSelectWithDialog>
          </v-list-item>
        </v-list>
      </v-col>
      <v-col>
        <v-bottom-navigation grow :background-color="'cardbg'" class="elevation-0">
          <v-btn @click="toggleFavorite">
            <span v-if="isFavorite">Favorite</span>
            <span v-if="!isFavorite">Add to favorites</span>
            <v-icon :color="isFavorite ? 'marked' : ''">mdi-heart</v-icon>
          </v-btn>
        </v-bottom-navigation>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <v-list-item>
          <v-list-item-content>
            <v-list-item-title class="heading">Configuration:</v-list-item-title>
            <feature-configuration :features="dataSource.features"></feature-configuration>
          </v-list-item-content>
        </v-list-item>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import DepartmentPath from "~/components/DepartmentPath";
import FeatureConfiguration from "~/components/FeatureConfiguration";
import ClickableSelectWithDialog from "@/components/ClickableSelectWithDialog";

export default {
  name: "DataSourceOemDetails",
  components: { FeatureConfiguration, DepartmentPath, ClickableSelectWithDialog },
  props: {
    id: String,
    expanded: Boolean
  },
  data: function() {
    return {
      asset: {},
      isLoading: true,
      unitFeatureReEvalRequested: false,
      simStatus: "",
      type: 'oem'
    };
  },
  mounted() {
    this.$store.dispatch("retrieveDataSource", { type: this.type, id: this.id });
    this.getConnectedAssetInfo();
  },
  watch: {
    id: function() {
      this.$store.dispatch("retrieveDataSource", { type: this.type, id: this.id });
      this.getConnectedAssetInfo();
    },
    dataSource: function() {
      if (this.dataSource.dataSourceId) {
        this.$emit("dataSourceIdChange", this.dataSource.dataSourceId);
      }
      if (this.dataSource.iccid) {
        this.getSimcardStatus(this.dataSource.iccid);
      }
    }
  },
  methods: {
    navigateToConnectedAsset() {
      if (this.asset.vehicleId) {
        this.$router.push({ path: `/customer/${this.$route.params.id}?type=vehicle&activeTab=2&id=${this.asset.vehicleId}` });
      } else {
        this.$router.push({ path: `/customer/${this.$route.params.id}?type=eq&activeTab=3&id=${this.id}` });
      }
    },
    navigateToConnectedSubscription() {
      if (this.dataSource.subscriptionNumber) {
        this.$router.push({ path: `/customer/${this.$route.params.id}?type=subscription&activeTab=4&id=${this.dataSource.subscriptionNumber}` });
      } else {
        this.$router.push({ path: `/customer/${this.$route.params.id}?type=eq&activeTab=5&id=${this.id}` });
      }
    },
    getConnectedAssetInfo() {
      axios.get(`/api/datasource/connectedasset/${this.id}`).then(res => (this.asset = res.data));
    },
    getSimcardStatus(iccid) {
      axios.get(`/api/datasource/simcardStatus/${iccid}`).then(res => (this.simStatus = res.data));
    },
    updateDataSourceInfo() {
      clearTimeout(this._timerId);

      this._timerId = setTimeout(() => {
        this.isLoading = true;
        axios
          .put(`/api/datasource/${this.type}`, this.dataSource)
          .catch(() => {
            this.$eventBus.$emit("alert", { template: "api-error" });
          })
          .finally(() => (this.isLoading = false));
      }, 500);
    },
    async toggleFavorite() {
      let favorite = {
        departmentPath: this.dataSource.departmentPath,
        id: this.dataSource.dataSourceId.toString(),
        name: this.dataSource.name,
        subName: this.dataSource.subName,
        type: this.dataSource.type
      };
      await this.$store.dispatch("toggleFavorite", favorite);
    },
  },
  computed: {
    isFavorite() {
      return this.$store.state.userSettings?.favorites?.some(x => x.type === this.dataSource.type && x.id === this.dataSource.dataSourceId?.toString());
    },
    dataSource() {
      return this.$store.state.SidebarModule.selectedDataSource;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    }
  }
};
</script>

<style scoped>
.fill-width {
  width: 100%;
}

.icon-button-wrap {
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
