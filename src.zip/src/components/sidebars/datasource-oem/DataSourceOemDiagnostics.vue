<template>
  <v-container>
    <v-row>
      <v-col cols="12">
        <v-list>
          <v-list-item>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath clickable :department-path="dataSource.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                <span>Unit diagnostics (OEM)</span>
              </v-list-item-title>
              <v-list-item-subtitle>
                <span>{{ dataSource.dataSourceId }} - {{ dataSource.unitTypeId }} - {{ dataSource.subscriptionNumber }}</span>
              </v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="12">
        <v-menu ref="menu" v-model="dateRangePickerOpen" :close-on-content-click="false" :return-value.sync="dateRange" transition="scale-transition" offset-y min-width="290px">
          <template v-slot:activator="{ on, attrs }">
            <v-text-field v-model="dateRangeText" label="Date range" prepend-icon="mdi-calendar" readonly v-bind="attrs" v-on="on"></v-text-field>
          </template>
          <v-date-picker v-model="dateRange" no-title scrollable range :first-day-of-week="1">
            <v-spacer></v-spacer>
            <v-btn text color="primary" @click="dateRangePickerOpen = false">
              Cancel
            </v-btn>
            <v-btn text color="primary" @click="dateRangeChanged">
              OK
            </v-btn>
          </v-date-picker>
        </v-menu>
      </v-col>
    </v-row>
    <v-row>
      <v-progress-linear indeterminate v-if="telemetryLoading"></v-progress-linear>
    </v-row>
    <v-row class="mb-4">
      <v-expansion-panels readonly>
        <v-expansion-panel class="elevation-2" >
          <v-expansion-panel-header hide-actions style="cursor: auto;" >
            <span>GPS position received last 72 hours</span>
            <span class="icon-right" v-tooltippy="`Last position: ${convertDateToCustomerCountry(lastPositionDate)}`">
                <v-icon v-if="positionState === 'Ok'"  medium color="success">mdi-check</v-icon>
                <v-icon v-if="positionState === 'Error'"  medium color="error">mdi-alert-circle</v-icon>
                <v-icon v-if="positionState === 'NotApplicable'"  medium color="primary">mdi-cancel</v-icon>
            </span>
          </v-expansion-panel-header>
        </v-expansion-panel>
      </v-expansion-panels>
    </v-row>

    <v-row>
      <v-card class="map-card">
        <MapWithPosition :position="currentPosition"></MapWithPosition>
      </v-card>
    </v-row>

    <v-row class="px-6">
      <v-btn icon class="" @click="positionDatePrevious()">
        <v-icon>mdi-chevron-left</v-icon>
      </v-btn>
      <v-spacer></v-spacer>
      <span class="my-2">{{ currentPositionDate }}</span>
      <v-spacer></v-spacer>
      <v-btn icon class="" @click="positionDateNext()">
        <v-icon>mdi-chevron-right</v-icon>
      </v-btn>
    </v-row>

    <v-row>
      <v-col cols="12">
        <v-progress-linear indeterminate v-if="positionsLoading"></v-progress-linear>
        <v-data-table height="360" :headers="positionTableHeaders" :items="positions" :items-per-page="10" class="elevation-0 datatable-scroll" loading-text="Loading positions..." dense>
          <template v-slot:body="{ items }">
            <tbody>
              <tr v-for="(item, index) in items" @click="positionRowClicked(item, index)" :key="index" :class="{ 'secondary--text': index === currentPosition.index }">
                <td>{{ convertDateToCustomerCountry(item.timestamp) }}</td>
                <td v-if="expanded">{{ item.latitude.toFixed(6) }} / {{ item.longitude.toFixed(6) }}</td>
                <td>{{ (item.speed * 1.852).toFixed(0) }} km/h</td>
                <td>
                  <v-chip pill small v-if="item.isManual" class="">Manual</v-chip>
                  <v-chip pill small v-if="item.positionType === 'GPS'" class="">GPS</v-chip>
                  <v-chip pill small v-if="item.positionType === 'GSM'" class="">GSM</v-chip>
                  <v-chip pill small v-if="item.isFix" class="">Is Fix</v-chip>
                </td>
              </tr>
            </tbody>
          </template>
        </v-data-table>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import DepartmentPath from "~/components/DepartmentPath";
import MapWithPosition from "@/components/map/MapWithPosition";

export default {
  name: "DataSourceOemDiagnostics",
  components: { MapWithPosition, DepartmentPath },
  props: {
    id: String,
    expanded: Boolean,
    customer: Object
  },
  data: function() {
    return {
      isLoading: true,
      positions: [],
      dateRange: null,
      dateRangePickerOpen: false,
      currentPositionDate: null,
      currentPosition: null,
      positionTableHeaders: [
        { text: "Date", value: "date" },
        { text: "Lat/Lng", value: "latLng" },
        { text: "Speed", value: "speed" },
        { text: "Info", value: "info" }
      ],
      positionsLoading: false,
      telemetryLoading: false,
      telemetry: {},
      resetBatteryCounterLoading: false,
      hasLockedConfig: null,
      lastPositionDate: null
    };
  },
  async mounted() {
    await this.init();
  },
  watch: {
    id: async function() {
      await this.init();
    },
    dateRange: async function() {
      this.currentPositionDate = this.dateRange[0];
    },
    expanded: async function() {
      if (this.expanded) {
        this.positionTableHeaders = [
          { text: "Date", value: "date" },
          { text: "Lat/Lng", value: "latLng" },
          { text: "Speed", value: "speed" },
          { text: "Info", value: "info" }
        ];
      } else {
        this.positionTableHeaders = [
          { text: "Date", value: "date" },
          { text: "Speed", value: "speed" },
          { text: "Info", value: "info" }
        ];
      }
    }
  },
  computed: {
    dateRangeText() {
      if (!this.dateRange || this.dateRange.length === 0) return "";
      return this.dateRange.join(" ➡ ");
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    dataSource() {
      return this.$store.state.SidebarModule.selectedDataSource;
    },
    configLocksIconColor() {
      if (this.hasLockedConfig === null) return "grey";
      if (this.hasLockedConfig) return "error";
      return "success";
    },
    positionState(){
      if(!this.lastPositionDate) return 'NotApplicable'

      let time72HoursAgo = Date.now() - (72 * 60 * 60 * 1000)
      let timeLastPosition = (new Date(this.lastPositionDate)).getTime()
      let lastPositionIsNewerThan72HoursAgo = timeLastPosition > time72HoursAgo

      if(lastPositionIsNewerThan72HoursAgo) return 'Ok'
      return 'Error'
    }
  },
  methods: {
    async init() {
      this.loading = true;
      await this.getLastPosition()
      let initialDate = this.lastPositionDate ?? new Date().toISOString();
      let fromDate = initialDate.substring(0, 10);
      this.dateRange = [fromDate];
      this.currentPositionDate = fromDate;
      await this.getPositionsDebounced();
      if (this.positions.length > 0) {
        this.currentPosition = this.positions[0];
        this.currentPosition.index = 0;
      }

      this.loading = false;
    },
    convertDateToCustomerCountry(date) {
      return this.$utils.getDateTimeByCountry(date, this.customer.country);
    },
    async dateRangeChanged() {
      this.$refs.menu.save(this.dateRange);
      if (this.dateRange.length > 1) {
        // Sort dates
        let startDate = new Date(this.dateRange[0]);
        let endDate = new Date(this.dateRange[1]);
        if (startDate > endDate) {
          this.dateRange = [this.dateRange[1], this.dateRange[0]];
          this.$refs.menu.save(this.dateRange);
        }
      }
      await this.getPositionsDebounced();
    },
    async getLastPosition() {
      try {
        let res = await axios.get(`/api/datasource/position/last/${this.id}/1`);
        if (res.data?.length > 0) {
          this.lastPositionDate = res.data[0].timestamp;
        }
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Unable to get last position for this OEM data source`, icon: 'mdi-alert-circle', type: 'error'});
      }
    },
    async getPositions() {
      this.positions = [];
      this.positionsLoading = true;
      try {
        let res = await axios.get(`/api/datasource/position/oem/${this.id}/${this.currentPositionDate}`);
        this.positions = res.data;
        if (this.positions?.length > 0) {
          this.currentPosition = this.positions[0];
          this.currentPosition.index = 0;
        } else this.currentPosition = null;
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Unable to get positions for this OEM data source`, icon: 'mdi-alert-circle', type: 'error'});
      }
      this.positionsLoading = false;
    },
    getPositionsDebounced() {
      clearTimeout(this._timerId);

      this._timerId = setTimeout(() => {
        this.getPositions();
      }, 500);
    },

    async positionDateNext() {
      let nextDate = this.$utils.addDays(this.currentPositionDate, 1);
      this.currentPositionDate = nextDate.toISOString().substring(0, 10);
      await this.getPositionsDebounced();
    },
    async positionDatePrevious() {
      let nextDate = this.$utils.addDays(this.currentPositionDate, -1);
      this.currentPositionDate = nextDate.toISOString().substring(0, 10);
      await this.getPositionsDebounced();
    },
    positionRowClicked(row, index) {
      this.currentPosition = row;
      this.currentPosition.index = index;
    },
  }
};
</script>

<style scoped>
.icon-right {
  position: absolute;
  right: 80px;
}
</style>
