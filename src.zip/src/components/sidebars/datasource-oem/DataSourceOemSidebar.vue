<template>
  <BaseSidebar :menuItems="menuItems" @sidebarSizeChanged="sidebarSizeChanged" @pageChanged="pageChanged">
    <span>
      <DataSourceOemDetails :id="id" :expanded="expanded" v-if="currentPage === 'datasource-details-oem'"></DataSourceOemDetails>
      <DataSourceOemDiagnostics :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'datasource-diagnostics-oem'"></DataSourceOemDiagnostics>
      <DataSourceTelemetry :id="id" :type="'oem'" :expanded="expanded" v-if="currentPage === 'datasource-telemetry'"></DataSourceTelemetry>
    </span>
  </BaseSidebar>
</template>

<script>
import BaseSidebar from "../BaseSidebar";
import DataSourceOemDetails from "./DataSourceOemDetails";
import DataSourceOemDiagnostics from "./DataSourceOemDiagnostics";
import DataSourceTelemetry from "@/components/sidebars/datasource/DataSourceTelemetry"
export default {
  props: ["id", "customer"],
  components: {
    DataSourceTelemetry,
    BaseSidebar,
    DataSourceOemDetails,
    DataSourceOemDiagnostics,
  },
  data() {
    return {
      expanded: false,
      currentPage: "datasource-details-oem",
      menuItems: [
        { page: "datasource-details-oem", icon: "mdi-information", expandedAsDefault: false, id: 0 },
        { page: "datasource-diagnostics-oem", icon: "mdi-heart-pulse", expandedAsDefault: true, id: 1 },
        { page: "datasource-telemetry", icon: "mdi-signal", expandedAsDefault: true, id: 2 },
      ]
    };
  },
  methods: {
    sidebarSizeChanged(state) {
      this.expanded = state;
    },
    pageChanged(page) {
      this.currentPage = page;
    },
  },
  computed: {
    dataSource() {
      return this.$store.state.SidebarModule.selectedDataSource;
    }
  }
};
</script>

<style></style>
