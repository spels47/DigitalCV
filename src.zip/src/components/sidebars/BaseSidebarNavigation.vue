<template>
  <v-navigation-drawer stateless temporary color="black" v-model="shown" dark app right mini-variant mini-variant-width="60" hide-overlay>
    <v-list-item>
      <v-list-item-avatar class="cursor-pointer">
        <UserAvatar></UserAvatar>
      </v-list-item-avatar>
    </v-list-item>

    <v-divider></v-divider>

    <v-list dense nav>
      <v-list-item-group :value="getIndex">
        <v-list-item v-for="item in menuItems" :key="item.id" @click="navigate(item.page)">
          <v-list-item-icon>
            <v-icon v-text="item.icon"></v-icon>
          </v-list-item-icon>
          <v-list-item-content @click="navigate(item.page)">
            <v-list-item-title v-text="item.page"></v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list-item-group>
    </v-list>

    <template v-slot:append>
      <v-list-item link @click="toggleExpand">
        <v-list-item-icon v-if="expanded">
          <v-icon>mdi-arrow-bottom-right</v-icon>
        </v-list-item-icon>
        <v-list-item-icon v-if="!expanded">
          <v-icon>mdi-arrow-top-left</v-icon>
        </v-list-item-icon>
      </v-list-item>
    </template>
  </v-navigation-drawer>
</template>

<script>
import UserAvatar from "~/components/UserAvatar";
export default {
  components: { UserAvatar },
  props: ["expanded", "shown", "menuItems", "initialPage"],
  methods: {
    navigate(page) {
      let expandedAsDefault = this.menuItems.find(i => i.page === page).expandedAsDefault;
      if (expandedAsDefault !== this.expanded) {
        this.toggleExpand();
      }
      this.$emit("pageChanged", page);
    },
    toggleExpand() {
      this.$emit("toggleExpand");
    }
  },
  computed: {
    getIndex() {
      return this.initialPage ? this.menuItems.findIndex(x => x.page === this.initialPage) : 0;
    },
  }
};
</script>

<style scoped>
.cursor-pointer {
  cursor: pointer;
}
</style>
