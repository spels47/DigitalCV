﻿<template>
  <v-container>
    <v-row>
      <v-col>
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath clickable :department-path="equipment.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                <span>Audit Log</span>
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <v-list>
          <v-data-table :headers="getHeaders()" :items="auditLog">
            <template v-slot:item.timestamp="{ item }"> {{ convertToCustomerDatetime(item.timestamp) }}</template>
          </v-data-table>
        </v-list>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "@/axios-client";
import util from "@/helpers/util";
import DepartmentPath from "~/components/DepartmentPath";

export default {
  name: "VehicleAuditDetails",
  props: ["expanded", "id", "customer"],
  components: { DepartmentPath },
  data: function() {
    return {
      isLoading: true,
      equipmentLog: [],
      miniLog: [],
      auditHeaders: [
        { text: "Date", value: "timestamp" },
        { text: "Change", value: "message" },
        { text: "New Value", value: "newValue" }
      ],
      auditHeadersLong: [
        { text: "Date", value: "timestamp" },
        { text: "Change", value: "message" },
        { text: "Old Value", value: "oldValue" },
        { text: "New Value", value: "newValue" },
        { text: "Responsible", value: "name" }
      ]
    };
  },
  mounted() {
    this.getAuditLog();
  },
  methods: {
    getHeaders() {
      if (this.expanded) {
        return this.auditHeadersLong;
      }
      return this.auditHeaders;
    },
    getAuditLog() {
      axios.get(`/api/audit?sourceType=equipment&id=` + this.equipment.id).then(res => {
        this.miniLog = res.data;
      });
    },
    convertToCustomerDatetime(date){
      return util.getDateTimeByCountry(date, this.customer.country )
    },
  },
  computed: {
    equipment() {
      return this.$store.state.SidebarModule.selectedEquipment;
    },
    auditLog() {
      return this.equipmentLog.concat(this.miniLog);
    }
  }
};
</script>

<style scoped></style>
