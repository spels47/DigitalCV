<template>
  <v-container>
    <v-row>
      <v-col cols="lg-12">
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath clickable :department-path="equipment.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                <span>Equipment info</span>
              </v-list-item-title>
              <v-list-item-title class="headline" v-if="equipment.id && !equipment.isMounted">
                <span class="error--text">INACTIVE</span>
              </v-list-item-title>
              <v-list-item-title class="headline ml-5" v-if="equipment.id && !equipment.assetId">
                <span class="error--text">Error: missing assetId</span>
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>

    <v-row>
      <v-col cols="lg-12">
        <v-list min-width="100">
          <v-list-item>
            <v-text-field @change="updateEquipmentInfo('alias', equipment.alias, 'Name')" :readonly="!roles.ASSET_EDIT" prepend-icon="mdi-identifier" label="Alias" v-model="equipment.alias" />
          </v-list-item>
          <v-list-item v-if="equipment.unitTypeId !== 'MINI'">
            <v-text-field @change="updateEquipmentInfo('simcardLicensePlateNumber', equipment.simcardLicensePlateNumber, 'RegistrationNumber')" :readonly="!roles.ASSET_EDIT" prepend-icon="mdi-numeric" label="License plate" v-model="equipment.simcardLicensePlateNumber" />
          </v-list-item>
          <v-list-item v-if="equipment.unitTypeId !== 'MINI'">
            <v-text-field @change="updateEquipmentInfo('customerReference', equipment.customerReference, 'EquipmentSerialNumber')" :readonly="!roles.ASSET_EDIT " prepend-icon="mdi-numeric" label="Sin/Pin/Vin" v-model="equipment.customerReference"> </v-text-field>
          </v-list-item>
          <v-list-item v-if="equipment.unitTypeId !== 'MINI'">
            <v-text-field readonly prepend-icon="mdi-identifier" label="Primary data source id" v-model="equipment.primaryDataSourceId" />
          </v-list-item>
          <v-list-item v-if="equipment.unitTypeId !== 'MINI'">
            <v-select :readonly="!roles.ASSET_EDIT" prepend-icon="mdi-power" label="Unit active" :items="[true, false]" v-model="isMounted"> </v-select>
          </v-list-item>
          <v-list-item>
            <ClickableSelectWithDialog @itemClicked="navigateToConnectedDataSource" :fieldLabel="'Connected DataSource'" :itemText="equipment.primaryDataSourceId" :icon="'mdi-cable-data'" :showAppendIcon="false"></ClickableSelectWithDialog>
          </v-list-item>
        </v-list>
      </v-col>

      <v-col cols="12">
        <v-bottom-navigation grow :background-color="'cardbg'" class="elevation-0">
          <v-btn v-if="roles.ASSET_MOVE" @click="moveAssetDialog = true">
            <span>Move asset</span>
            <v-icon>mdi-domain</v-icon>
          </v-btn>
          <MoveEntityDialog
            v-if="moveAssetDialog"
            :mainOfficeId="customer.mainOfficeId"
            :initialCustomerId="this.equipment.departmentId"
            :title="'Select Department to move asset to'"
            :loading="movePending"
            @closeDialog="moveAssetDialog = false"
            @confirm="assetMove"
          ></MoveEntityDialog>
          <v-btn @click="toggleFavorite">
            <span v-if="isFavorite">Favorite</span>
            <span v-if="!isFavorite">Add to favorites</span>
            <v-icon :color="isFavorite ? 'marked' : ''">mdi-heart</v-icon>
          </v-btn>
        </v-bottom-navigation>
      </v-col>
    </v-row>

    <v-row>
      <v-col>
        <v-list>
          <v-list-item>
            <v-text-field @change="updateEquipmentInfo('typeOfObject', equipment.typeOfObject, 'Model')" :readonly="!roles.ASSET_EDIT || equipment.unitTypeId === 'MINI'" prepend-icon="mdi-cog" label="Asset type" v-model="equipment.typeOfObject" />
          </v-list-item>
          <v-list-item>
            <v-text-field @change="updateEquipmentInfo('objectDescription', equipment.objectDescription, 'Make')" :readonly="!roles.ASSET_EDIT || equipment.unitTypeId === 'MINI'" prepend-icon="mdi-information-outline" label="Unit description" v-model="equipment.objectDescription" />
          </v-list-item>
          <v-list-item v-if="equipment.unitTypeId !== 'MINI'" >
            <v-text-field @change="updateEquipmentInfo('unitInfo', equipment.unitInfo, 'AdditionalComment')" :readonly="!roles.ASSET_EDIT || equipment.unitTypeId === 'MINI'" prepend-icon="mdi-information-outline" label="Unit info" v-model="equipment.unitInfo" />
          </v-list-item>
          <v-list-item v-if="equipment.unitTypeId !== 'MINI'">
            <v-text-field readonly prepend-icon="mdi-calendar" label="Last contact" :value="equipment.lastContact != null ? equipment.lastContact.replace('T', ' ') : ''" />
          </v-list-item>
          <v-list-item v-if="equipment.unitTypeId !== 'MINI'">
            <v-text-field readonly prepend-icon="mdi-calendar" label="Last inspection" :value="equipment.lastInspection" />
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import DepartmentPath from "~/components/DepartmentPath";
import ClickableSelectWithDialog from "@/components/ClickableSelectWithDialog";
import MoveEntityDialog from "@/components/widgets/dialogs/MoveEntityDialog";
export default {
  name: "EquipmentDetails",
  components: { DepartmentPath, ClickableSelectWithDialog, MoveEntityDialog },
  props: {
    id: String,
    expanded: Boolean,
    customer: Object,
    departmentId: Number
  },
  data: function() {
    return {
      initalLoadOfEquipment: null,
      isLoading: true,
      moveAssetDialog: false,
      movePending: false,
      assetMoveConnected: true,
      currentSelectedId: 0,
    };
  },
  async mounted() {
    await this.$store.dispatch("retrieveEquipment", {id: this.id});
  },
  watch: {
    id: async function () {
      await this.$store.dispatch("retrieveEquipment", {id: this.id});
    },
    equipment: function() {
      if(!this.equipment) console.log('ret??')
      this.$emit("dataSourceIdChange", this.equipment.primaryDataSourceId);
      if (this.initalLoadOfEquipment == null) this.initalLoadOfEquipment = JSON.parse(JSON.stringify(this.equipment));
    }
  },
  methods: {
    navigateToConnectedDataSource() {
      if(this.equipment.unitTypeId === 'Oem'){
        this.$router.push({ path: `/customer/${this.$route.params.id}?type=oem&activeTab=5&id=${this.equipment.simcardId}` }).catch(err => {});
      } else if(this.equipment.unitTypeId === 'MINI') {
        this.$router.push({ path: `/customer/${this.$route.params.id}?type=mini&activeTab=5&id=${this.equipment.primaryDataSourceId}` }).catch(err => {});
      }else {
        this.$router.push({ path: `/customer/${this.$route.params.id}?type=simcard&activeTab=5&id=${this.equipment.primaryDataSourceId}` }).catch(err => {});
      }
    },
    async assetMove(_, destinationDepartmentId) {
      this.movePending = true
      try{
        let moveToDepartmentHierarchyRes = await axios.get(`/api/customer/hierarchy/${destinationDepartmentId}/main-office-and-down`)
        await axios.post(`/api/asset/${this.equipment.assetId}/move/${destinationDepartmentId}`)
        await this.$store.dispatch("audit", { source: "equipment", entityId: this.equipment.id, message: "Move equipment to department", oldValue: this.equipment.departmentId, newValue: destinationDepartmentId })
        this.equipment.departmentId = this.currentSelectedDestinationId
        this.equipment.departmentPath = moveToDepartmentHierarchyRes.data.departmentPath
        this.equipment.departmentName = moveToDepartmentHierarchyRes.data.name
      } catch(ex){
        this.$eventBus.$emit("alert", {text: `Failed to move equipment`, type: "error"});
      }
      this.movePending = false
      this.moveAssetDialog = false;
    },
    async updateEquipmentInfo(propertyName, value, metadataKey) {
      let assetUpdateModel = {
        AssetId: this.equipment.assetId,
        AktorId: this.equipment.departmentId,
        Key: metadataKey,
        Value: value,
      }
      this.isLoading = true;
      try {
        await axios.put(`/api/equipment`, assetUpdateModel)
        await this.$store.dispatch("audit", {source: "equipment", entityId: this.equipment.id, message: `Update Equipment Info: ${metadataKey} (${propertyName})`, oldValue: this.initalLoadOfEquipment[propertyName], newValue: this.equipment[propertyName]});
      } catch (ex) {
        this.$eventBus.$emit("alert", {text: "Failed updating field", type: "error"});
      } finally {
        this.isLoading = false;
        this.initalLoadOfEquipment = JSON.parse(JSON.stringify(this.equipment));
      }
    },
    async toggleFavorite() {
      let favorite = {
        departmentPath: this.equipment.departmentPath,
        id: this.equipment.id.toString(),
        name: this.equipment.id.toString(),
        subName: this.equipment.alias ?? "",
        type: "EQ"
      };
      await this.$store.dispatch("toggleFavorite", favorite);
    }
  },
  computed: {
    isFavorite() {
      return this.$store.state.userSettings?.favorites?.some(x => x.type === "EQ" && x.id === this.equipment.id?.toString());
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    equipment() {
      return this.$store.state.SidebarModule.selectedEquipment;
    },
    isMounted: {
      get: function() {
        return this.equipment.isMounted;
      },
      set: async function (value) {
        try{
          await this.$store.dispatch("updateAssetIsMountedState", {isMounted: value, id: this.equipment.assetId});
          this.equipment.isMounted = value
        } catch(ex){
          this.$eventBus.$emit("alert", {text: "Failed updating equipment isMounted state", type: "error"});
        }
      }
    }
  }
};
</script>

<style scoped>
.fill-width {
  width: 100%;
}

.icon-button-wrap {
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
