<template>
  <BaseSidebar :menuItems="menuItems" @sidebarSizeChanged="sidebarSizeChanged" @pageChanged="pageChanged">
    <span>
      <EquipmentDetails :id="id" :department-id="departmentId" :customer="customer" :expanded="expanded" v-if="currentPage === 'equipment-details'"></EquipmentDetails>
      <EquipmentAuditDetails :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'audit-details'"></EquipmentAuditDetails>
    </span>
  </BaseSidebar>
</template>

<script>
import BaseSidebar from "../BaseSidebar";
import EquipmentDetails from "./EquipmentDetails";
import EquipmentAuditDetails from "./EquipmentAuditDetails";
export default {
  props: ["id", "departmentId", "customer"],
  components: { BaseSidebar, EquipmentDetails, EquipmentAuditDetails },
  data() {
    return {
      expanded: false,
      currentPage: "equipment-details",
      menuItems: [
        { page: "equipment-details", icon: "mdi-information", expandedAsDefault: false, id: 0 },
        { page: "audit-details", icon: "mdi-math-log", expandedAsDefault: false, id: 1 }
      ]
    };
  },
  methods: {
    sidebarSizeChanged(state) {
      this.expanded = state;
    },
    pageChanged(page) {
      this.currentPage = page;
    }
  }
};
</script>

<style></style>
