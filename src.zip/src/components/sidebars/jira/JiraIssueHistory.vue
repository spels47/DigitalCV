﻿<template>
  <v-container fluid>
    <v-row>
      <v-col cols="lg-12">
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <JiraIssuePath />
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                Issue history
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
          <v-divider></v-divider>
        </v-list>
      </v-col>
    </v-row>
    <v-col>
      <v-list>
        <v-data-table
          :items-per-page.sync="itemsPerPage"
          :footer-props="{ 'items-per-page-options': [15, 30, 45] }"
          :headers="getHeaders()"
          :items="changes"
          :page="tablePage"
          @pagination="updatePage"
          :loading="this.loadingChanges"
          loading-text="Fetching issue changes"
          no-data-text="Issue has no history">
          <template v-slot:item.timestamp="{ item }">{{ parseIsoDatetime(item.created) }}</template>
          <template v-slot:item.message="{ item }"><span style="font-weight: bold; white-space: pre-line" v-html="capitalizeFirstLetter(item)"></span></template>
          <template v-slot:item.newValue="{ item }"><span v-html="validateNewValue(item)" style="white-space: pre-line"></span></template>
          <template v-slot:item.oldValue="{ item }"><span style="white-space: pre-line" v-html="validateOldValue(item)"></span></template>
          <template v-slot:item.name="{ item }">
            <span>
               <v-avatar size="22">
                <img :src="getIssueReporterImageUrl(item)">
               </v-avatar>
              <a class="ml-1" :href="getProfileLink(item.jiraAuthor.key)" target="_blank" style="text-decoration: none">{{item.jiraAuthor.displayName}}</a>
            </span>
          </template>
        </v-data-table>
      </v-list>
    </v-col>
    <v-row>
    </v-row>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import JiraIssuePath from "@/components/JiraIssuePath";
import moment from "moment";

export default {
  components: {JiraIssuePath},
  props: {
    issueKey: String,
    expanded: Boolean
  },
  data: function () {
    return {
      changes: [],
      itemsPerPage: 15,
      tablePage: 0,
      loadingChanges: true,
      logHeaders: [
        { text: "Date", value: "timestamp" },
        { text: "Change(s)", value: "message" },
        { text: "New Value(s)", value: "newValue" }
      ],
      logHeadersLong: [
        { text: "Date", value: "timestamp" },
        { text: "Change(s)", value: "message" },
        { text: "Old Value(s)", value: "oldValue", width: "21%" },
        { text: "New Value(s)", value: "newValue" },
        { text: "Responsible", value: "name" }
      ],
      intervalId: 0,
    };
  },
  mounted() {
    this.getIssueChanges();
  },
  destroyed() {
    clearInterval(this.intervalId);
    this.intervalId = 0;
  },
  methods: {
    updatePage (pagination) {
      this.tablePage = pagination.pageCount;
    },
    capitalizeFirstLetter(item) {
      if (item.items.length === 1) {
        return item.items[0].field.charAt(0).toUpperCase() + item.items[0].field.slice(1);
      }
      let stringToReturn = "";
      let previousElement = {};
      item.items.forEach((element) => {
        if (previousElement.field !== element.field) {
          stringToReturn += (element.field.charAt(0).toUpperCase() + element.field.slice(1)) + "\n";
        }
        previousElement = element;
      });
      return stringToReturn.slice(0, stringToReturn.length - 1);
    },
    getIssueReporterImageUrl(item) {
      return item.jiraAuthor.avatarUrls.the16X16;
    },
    getProfileLink(key) {
      return `https://jira.planetabax.com/secure/ViewProfile.jspa?name=${key}`;
    },
    validateNewValue(change) {
      // TODO: refactor this method because this is a bad way of doing it

      if (change.items.length > 1) {
        let resultToReturn = "";
        let previousElement = {};
        change.items.forEach((element) => {
          previousElement = element;
          switch (element.field.toLowerCase()) {
            case "epic link":
              resultToReturn += `<a style="text-decoration: none" href="https://jira.planetabax.com/browse/${element.toString}" target="_blank" >${element.toString}</a><span> [ ${element.to} ]</span>`;
              break;
            case "duedate":
              resultToReturn += element.to;
              break;
            case "gitlab issue link":
              resultToReturn += `<a style="text-decoration: none" href="${element.toString}" target="_blank" >View link\n</a>`;
              break;
            case "link":
              /*eslint-disable */
              let issueId = null;
              if (element.toString.includes("This issue ownes (do not delete/change this link)")) {
                issueId = element.toString.substring(element.toString.indexOf("this link)")).replace("this link)", "").trim();
                resultToReturn += `<span>${element.toString.replace(issueId, "")} <a style="text-decoration: none" href="https://jira.planetabax.com/browse/${issueId}" target="_blank">${issueId}</a></span>`
                break;
              }
              else if (element.toString.includes("This issue relates to")) {
                issueId = element.toString.substring(element.toString.indexOf("to")).replace("to", "").trim();
                resultToReturn += `<span>${element.toString.replace(issueId, "")} <a style="text-decoration: none" href="https://jira.planetabax.com/browse/${issueId}" target="_blank">${issueId}</a></span>`
                break;
              }
              resultToReturn += element.toString + "\n";
              break;
            /*eslint-enable */
            case "cs ticket link":
              resultToReturn += `<a style="text-decoration: none" href="${element.toString}" target="_blank" >View link\n</a>`;
              break;
            default:
              if (previousElement.fromString === element.toString) break;

              if (element.toString !== null) {
                resultToReturn += element.toString + "\n";
              }
          }
        });
        return resultToReturn.slice(0, resultToReturn.length - 1);
      }

      if (change.items[0].toString == null) return change.items[0].toString;
      switch (change.items[0].field.toLowerCase()) {
        case "epic link":
          return `<a style="text-decoration: none" href="https://jira.planetabax.com/browse/${change.items[0].toString}" target="_blank" >${change.items[0].toString}</a><span> [ ${change.items[0].to} ]</span>`;
        case "duedate":
          return change.items[0].to;
        case "gitlab issue link":
          return `<a style="text-decoration: none" href="${change.items[0].toString}" target="_blank" >${change.items[0].toString}</a>`;
        case "link":
          /*eslint-disable */
          let issueId = null;
          if (change.items[0].toString.includes("This issue ownes (do not delete/change this link)")) {
            issueId = change.items[0].toString.substring(change.items[0].toString.indexOf("this link)")).replace("this link)", "").trim();
            return `<span>${change.items[0].toString.replace(issueId, "")} <a style="text-decoration: none" href="https://jira.planetabax.com/browse/${issueId}" target="_blank">${issueId}</a></span>`
          }
          else if (change.items[0].toString.includes("This issue relates to")) {
            issueId = change.items[0].toString.substring(change.items[0].toString.indexOf("to")).replace("to", "").trim();
            return `<span>${change.items[0].toString.replace(issueId, "")} <a style="text-decoration: none" href="https://jira.planetabax.com/browse/${issueId}" target="_blank">${issueId}</a></span>`
          }
          return change.items[0].toString;
          /*eslint-enable */
        case "cs ticket link":
          return `<a style="text-decoration: none" href="${change.items[0].toString}" target="_blank" >${change.items[0].toString}</a>`;
        default:
          return change.items[0].toString ?? `<b style="color: darkred">EMPTY</b>`;
      }
    },
    validateOldValue(change) {
      // TODO: refactor this method because this is a bad way of doing it

      if (change.items.length > 1) {
        let resultToReturn = "";
        let previousElement = {};
        change.items.forEach((element) => {
          previousElement = element;
          switch (element.field.toLowerCase()) {
            case "epic link":
              resultToReturn +=`<a style="text-decoration: none" href="https://jira.planetabax.com/browse/${element.toString}" target="_blank" >${element.toString}</a><span> [ ${element.to} ]</span>`;
              break;
            case "duedate":
              resultToReturn += element.to;
              break;
            case "gitlab issue link":
              resultToReturn += `<a style="text-decoration: none" href="${element.toString}" target="_blank" >View link\n</a>`;
              break;
            case "link":
              /*eslint-disable */
              let issueId = null;
              if (element.toString.includes("This issue ownes (do not delete/change this link)")) {
                issueId = element.toString.substring(element.toString.indexOf("this link)")).replace("this link)", "").trim();
                resultToReturn += `<span>${element.toString.replace(issueId, "")} <a style="text-decoration: none" href="https://jira.planetabax.com/browse/${issueId}" target="_blank">${issueId}</a></span>`
                break;
              }
              else if (element.toString.includes("This issue relates to")) {
                issueId = element.toString.substring(element.toString.indexOf("to")).replace("to", "").trim();
                resultToReturn += `<span>${element.toString.replace(issueId, "")} <a style="text-decoration: none" href="https://jira.planetabax.com/browse/${issueId}" target="_blank">${issueId}</a></span>`
                break;
              }
              resultToReturn += element.toString;
              break;
            /*eslint-enable */
            case "cs ticket link":
              if (element.fromString != null) {
                resultToReturn += `<a style="text-decoration: none" href="${element.toString}" target="_blank" >View link\n</a>`;
              }
              break;
            default:
              if (previousElement.toString === element.fromString) break;

              if (element.fromString != null) {
                resultToReturn += `${element.fromString}<br/>`;
              }
          }
        });
        return resultToReturn.slice(0, resultToReturn.length - 1);
      }

      if (change.items[0].fromString == null) return change.items[0].fromString;
      switch (change.items[0].field.toLowerCase()) {
        case "epic link":
          return `<a style="text-decoration: none" href="https://jira.planetabax.com/browse/${change.items[0].fromString}" target="_blank" >${change.items[0].fromString}</a>`
        case "duedate":
          return change.items[0].fromString;
        case "link":
          /*eslint-disable */
          let issueId = null;
          // TODO: refactor because this is a bad way of doing it
          if (change.items[0].fromString.includes("This issue ownes (do not delete/change this link)")) {
            issueId = change.items[0].fromString.substring(change.items[0].fromString.indexOf("this link)")).replace("this link)", "").trim();
            return `<span>${change.items[0].fromString.replace(issueId, "")} <a style="text-decoration: none" href="https://jira.planetabax.com/browse/${issueId}" target="_blank">${issueId}</a></span>`
          }
          else if (change.items[0].fromString.includes("This issue relates to")) {
            issueId = change.items[0].fromString.substring(change.items[0].fromString.indexOf("to")).replace("to", "").trim();
            return `<span>${change.items[0].fromString.replace(issueId, "")} <a style="text-decoration: none" href="https://jira.planetabax.com/browse/${issueId}" target="_blank">${issueId}</a></span>`
          }
          return change.items[0].fromString;
        /*eslint-enable */
        case "cs ticket link":
          return `<a style="text-decoration: none" href="${change.items[0].fromString}" target="_blank" >${change.items[0].fromString}</a>`;
        default:
          return change.items[0].fromString ?? `<b style="color: darkred">EMPTY</b>`;
      }
    },
    async getIssueChanges() {
      let changes = [];
      this.loadingChanges = true;

      try {
        const { data } = await axios.get(`/api/jira/issue/${this.issueKey}/changes`);
        changes = data;
      } catch {
        this.$eventBus.$emit("alert", { template: "api-error" });
      } finally { this.loadingChanges = false; }

      this.changes = changes;
    },
    getHeaders() {
      if (this.expanded) {
        return this.logHeadersLong;
      }
      return this.logHeaders;
    },
    parseIsoDatetime(dtstr) {
      if (dtstr === "" || dtstr == null) return;
      const dt = dtstr.split(/[: T-]/).map(parseFloat);
      return `${dt[0]}-${dt[1]}-${dt[2]} ${dt[3]}:${dt[4]}`;
    },
    getAvatarImage(comment) {
      return comment.author?.avatarUrls?.the24X24;
    },
    isValidAuthor(comment) {
      return !(comment.author == null || false);
    }
  },
  computed: {
    getIssueLink() {
      return `https://jira.planetabax.com/browse/${this.issueKey}`;
    },
    getIssueName() {
      return this.$store.state.JiraModule.selectedJiraIssue.key ?? "Unknown";
    },
  },

};
</script>

<style scoped>
.fill-width {
  width: 100%;
}

.container {
  top: 10px;
  left: 100px;
}

.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
}

.icon-button-wrap {
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
