﻿<template>
  <v-container>
    <v-row>
      <v-progress-linear
        absolute
        :active="jiraIssueBeingRetrieved"
        indeterminate
        rounded
        dark
      ></v-progress-linear>
      <v-col cols="lg-12">
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <JiraIssuePath />
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                <span>Issue details</span>
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
        <v-list-item>
          <v-select :items="availableTransitions" :loading="updatingStatus" item-text="name" item-value="name" label="Status" return-object v-model="getIssueStatus">
            <template slot="prepend">
              <v-img v-if="getIssueStatusImageUrl !== 'https://jira.planetabax.com/'" :src="getIssueStatusImageUrl" class="float-left mr-1" height="23" width="23"></v-img>
              <v-icon v-else class="float-left mr-2">mdi-format-list-checks</v-icon>
            </template>
            <template v-slot:item="data">
              <v-list-item-content>
                <v-list-item-title>{{ data.item.name }}</v-list-item-title>
                <v-list-item-subtitle>{{data.item.description}}</v-list-item-subtitle>
              </v-list-item-content>
            </template>
          </v-select>
        </v-list-item>
        <v-list-item>
          <v-text-field prepend-icon="mdi-text" label="Summary" @keyup.enter="saveSummary" :loading="savingSummary" single-line v-model="getIssueSummary" />
        </v-list-item>
        <v-list-item>
          <v-textarea
            v-model="getIssueDescription"
            label="Description"
            spellcheck="false"
            auto-grow
            counter
            prepend-icon="mdi-text-box">
            <template slot="append">
              <v-tooltip bottom>
                <template v-slot:activator="{ on }">
                  <v-btn v-on="on" @click="saveDescription" :loading="savingDescription" icon>
                    <v-icon>mdi-text-box-check</v-icon>
                  </v-btn>
                </template>
                <span>Save description</span>
              </v-tooltip>
            </template>
          </v-textarea>
        </v-list-item>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="lg-12">
        <v-divider></v-divider>
        <v-row cols="12" class="ml-5" no-gutters>
          <v-row>
            <v-list width="100%">
              <v-list-item>
                <v-select :loading="updatingIssueType" label="Type" item-text="name" v-model="getIssueType" :items="issueTypes"
                >
                  <template slot="selection" slot-scope="data">
                    <v-avatar size="20px">
                      <img :src="data.item.icon"/>
                    </v-avatar>
                    <span class="ml-2">{{ data.item.name }}</span>

                  </template>
                  <template slot="item" slot-scope="data">
                    <v-list-item-avatar size="20">
                      <img width="20" height="20"
                           :src="data.item.icon" />
                    </v-list-item-avatar>
                    <v-list-item-content class="ml-3">
                      <v-list-item-title v-html="data.item.name"></v-list-item-title>
                    </v-list-item-content>
                  </template>
                </v-select>
              </v-list-item>
              <v-list-item>
                <v-select :loading="updatingIssuePriority" label="Priority" item-text="name" v-model="getIssueTypePriority" :items="issuePriorities"
                >
                  <template slot="selection" slot-scope="data">
                    <v-avatar size="20px">
                      <img :src="data.item.icon"/>
                    </v-avatar>
                    <span class="ml-2">{{ data.item.name }}</span>

                  </template>
                  <template slot="item" slot-scope="data">
                    <v-list-item-avatar size="20">
                      <img width="20" height="20"
                           :src="data.item.icon" />
                    </v-list-item-avatar>
                    <v-list-item-content class="ml-3">
                      <v-list-item-title v-html="data.item.name"></v-list-item-title>
                    </v-list-item-content>
                  </template>
                </v-select>
              </v-list-item>
              <v-list-item>
                <v-select :loading="loadingSelectableItems || updatingIssueAssignee"
                          item-text="displayName" label="Assignee" v-model="getIssueAssignee" :items="availableAssignees"
                          return-object
                >
                  <template slot="selection" slot-scope="data">
                    <v-avatar size="22px">
                      <img :src="data.item.avatarUrls.the32X32"/>
                    </v-avatar>
                    <span class="ml-2">{{ data.item.displayName }}</span>

                  </template>
                  <template slot="item" slot-scope="data">
                    <v-list-item-avatar size="22">
                      <img width="20" height="20"
                           :src="data.item.avatarUrls.the32X32" />
                    </v-list-item-avatar>
                    <v-list-item-content class="ml-3">
                      <v-list-item-title v-html="data.item.displayName"></v-list-item-title>
                    </v-list-item-content>
                  </template>
                </v-select>
              </v-list-item>
              <v-list-item>
                <v-text-field readonly label="Developer" v-model="getIssueDeveloperName"
                >
                  <template v-if="getIssueDeveloperName !== 'None'" v-slot:prepend>
                    <v-avatar size="22">
                      <img
                        :src="getIssueDeveloperImageUrl"
                        :alt="getIssueDeveloperName"
                      >
                    </v-avatar>
                  </template>
                </v-text-field>
              </v-list-item>
              <v-list-item>
                <v-text-field readonly label="Reporter" v-model="getIssueReporterName"
                >
                  <template v-slot:prepend>
                    <v-avatar size="22">
                      <img
                        :src="getIssueReporterImageUrl"
                        :alt="getIssueReporterName"
                      >
                    </v-avatar>
                  </template>
                </v-text-field>
              </v-list-item>
              <v-list-item>
                <v-avatar size="20px">
                  <img src="https://jira.planetabax.com/images/icons/issuetypes/epic.svg"/>
                </v-avatar>
                <v-autocomplete
                  class="ml-2"
                  v-model="getIssueEpic"
                  item-value="name"
                  item-text="name"
                  persistent-hint
                  :hint="getIssueEpic === null ? 'Backstage-API lacks permission to view this Epic 😓' : ''"
                  clearable
                  :loading="loadingSelectableItems"
                  :items="availableEpics"
                  return-object
                  label="Epic"
                >
                  <template slot="selection" slot-scope="data">
                    <span>{{ data.item.name }} - <span style="color: grey">({{data.item.key}})</span></span>
                  </template>
                  <template slot="item" slot-scope="data">
                    <v-avatar size="20px">
                      <img src="https://jira.planetabax.com/images/icons/issuetypes/epic.svg"/>
                    </v-avatar>
                    <v-list-item-content>
                      <v-list-item-title class="ml-2">{{data.item.name}} - <span style="color: grey">({{data.item.key}})</span></v-list-item-title>
                    </v-list-item-content>
                  </template>
                </v-autocomplete>
              </v-list-item>
              <v-list-item>
                <v-text-field label="CS Ticket link" v-model="getTicketLink" :loading="updatingCsTicketLink" prepend-icon="mdi-link"/>
              </v-list-item>
              <v-list-item>
                <v-avatar size="22">
                  <v-img src="@/assets/Gitlab.svg"></v-img>
                </v-avatar>
                <v-text-field class="ml-2" label="GitLab issue link" v-model="getGitlabIssueLink" @keyup.enter="saveGitlabLink" :loading="updatingGitlabIssueLink" />
              </v-list-item>
              <v-list-item>
                <v-autocomplete
                  :loading="loadingSelectableItems || updatingIssueLabels"
                  chips
                  clearable
                  label="Labels"
                  deletable-chips
                  :search-input.sync="labelSearch"
                  :items="availableLabels"
                  v-model="getLabels"
                  prepend-icon="mdi-label-multiple"
                  multiple />
              </v-list-item>
              <v-list-item>
                <v-autocomplete
                  :loading="loadingSelectableItems || updatingLinkedCustomerTickets"
                  chips
                  deletable-chips
                  multiple
                  clearable
                  :search-input.sync="customerTicketSearch"
                  label="Linked Customer Support Ticket id's"
                  :items="availableLinkedCustomerTickets"
                  v-model="getLinkedCustomerSupportTicketIds"
                  prepend-icon="mdi-ticket-account"/>
              </v-list-item>
              <v-list-item>
                <v-select
                  clearable
                  multiple
                  deletable-chips
                  chips
                  :items="countriesAffected"
                  :loading="updatingCountriesAffected"
                  item-text="value"
                  label="Countries affected"
                  v-model="getCountriesAffected"
                  prepend-icon="mdi-flag"
                />
              </v-list-item>
              <v-list-item>
                <v-autocomplete
                  chips
                  multiple
                  deletable-chips
                  :loading="loadingSelectableItems || updatingIssueComponents"
                  clearable
                  :items="availableComponents"
                  :search-input.sync="componentSearch"
                  prepend-icon="mdi-alpha-c-circle"
                  item-text="name"
                  label="Components"
                  v-model="getIssueComponents"/>
              </v-list-item>
              <v-list-item>
                <v-avatar size="25">
                  <v-img src="@/assets/ASAP.svg"></v-img>
                </v-avatar>
                <v-checkbox class="ml-2" :readonly="pushingToAsap" label="Development issue" v-model="isADevelopmentIssue"></v-checkbox>
              </v-list-item>
              <v-divider></v-divider>
              <v-list-item class="mt-5">
                <v-text-field readonly label="Created" v-model="getIssueCreatedTimestamp"
                >
                  <template v-slot:prepend>
                    <v-icon size="25">mdi-calendar</v-icon>
                  </template>
                </v-text-field>
              </v-list-item>
              <v-list-item>
                <v-text-field
                  label="Due date"
                  v-model="getIssueDueDate"
                  prepend-icon="mdi-calendar-alert"
                  readonly
                ></v-text-field>
              </v-list-item>
              <v-list-item>
                <v-text-field readonly label="Last updated" v-model="getIssueUpdatedTimestamp"
                >
                  <template v-slot:prepend>
                    <v-icon size="25">mdi-calendar-edit</v-icon>
                  </template>
                </v-text-field>
              </v-list-item>
              <v-list-item>
                <v-text-field readonly label="Time to resolution" v-model="getIssueTtr"
                >
                  <template v-slot:prepend>
                    <v-icon size="25">mdi-clock-time-two-outline</v-icon>
                  </template>
                </v-text-field>
              </v-list-item>
            </v-list>
          </v-row>
        </v-row>
      </v-col>
      <v-col v-if="!hasGitlabLink">
        <v-bottom-navigation grow :background-color="'cardbg'" class="elevation-0">
          <v-btn v-if="!hasGitlabLink" @click="showDevDialog = true">
            <span>Forward issue to GitLab<br/>for further investigation</span>
            <v-img style="float: left; margin-top: 4px;" src="@/assets/Gitlab.svg"
                   contain height="25" width="25" class="mr-2 mb-2"></v-img>
          </v-btn>
        </v-bottom-navigation>
      </v-col>
    </v-row>
    <PushToGitlabDialog :show-dialog="showDevDialog" @success="handlePushSuccess" :issue="currentJiraIssue" @closeDevDialog="showDevDialog = false"/>
  </v-container>
</template>

<script>
import util from "@/helpers/util";
import axios from "@/axios-client";
import PushToGitlabDialog from "@/components/widgets/dialogs/PushToGitlabDialog";
import JiraIssuePath from "@/components/JiraIssuePath";

export default {
  name: "JiraIssueDetails",
  components: {
    JiraIssuePath,
    PushToGitlabDialog,
  },
  props: {
    issueKey: String,
    expanded: Boolean,
  },
  data: function () {
    return {
      countriesAffected:  [ "Norway", "Sweden", "UK", "Finland", "Netherland", "Denmark", "Poland", "Germany"],
      loadingSelectableItems: false,
      loadingIssue: false,
      pushingToAsap: false,
      updatingStatus: false,
      savingDescription: false,
      savingSummary: false,
      showNonSuccessfulDialog: false,
      showDevDialog: false,
      voteOperations: false,
      watchOperation: false,
      defaultAvatarUrl: 'https://jira.planetabax.com/secure/useravatar?size=small&avatarId=10123',
      dateOptions: { weekday: 'short', year: 'numeric', month: 'long', day: 'numeric' },
      attachmentRegex: new RegExp("\\!.*\\!", "g"), // eslint-disable-line
      descriptionFileTypes: [ ".png", ".jpeg", ".jpg", ".mp4", ".gif"],
      imageFileTypes: [".png", ".jpeg", ".jpg", ".gif"],
      videoFileTypes: [".mp4"],
      intervalId: 0,
      issueTypes: [
        {
          "name": "Initiative",
          "icon": "https://jira.planetabax.com/secure/viewavatar?size=xsmall&avatarId=10300&avatarType=issuetype",
        },
        {
          "name": "Story",
          "icon": "https://jira.planetabax.com/images/icons/issuetypes/story.svg",
        },
        {
          "name": "Task",
          "icon": "https://jira.planetabax.com/secure/viewavatar?size=xsmall&avatarId=10318&avatarType=issuetype",
        },
        {
          "name": "Bug",
          "icon": "https://jira.planetabax.com/secure/viewavatar?size=xsmall&avatarId=10303&avatarType=issuetype",
        },
        {
          "name": "Epic",
          "icon": "https://jira.planetabax.com/images/icons/issuetypes/epic.svg",
        },
        {
          "name": "Customer",
          "icon": "https://jira.planetabax.com/secure/viewavatar?size=xsmall&avatarId=13610&avatarType=issuetype",
        }
      ],
      issuePriorities: [
        {
          "name": "Extremely critical",
          "icon": "https://jira.planetabax.com/images/icons/priorities/blocker.svg",
        },
        {
          "name": "Highest",
          "icon": "https://jira.planetabax.com/images/icons/priorities/highest.svg",
        },
        {
          "name": "High",
          "icon": "https://jira.planetabax.com/images/icons/priorities/high.svg",
        },
        {
          "name": "Medium",
          "icon": "https://jira.planetabax.com/images/icons/priorities/medium.svg",
        },
        {
          "name": "Low",
          "icon": "https://jira.planetabax.com/images/icons/priorities/low.svg",
        },
        {
          "name": "Lowest",
          "icon": "https://jira.planetabax.com/images/icons/priorities/lowest.svg",
        },
        {
          "name": "Blocker",
          "icon": "https://jira.planetabax.com/images/icons/priorities/blocker.svg",
        },
        {
          "name": "Minor",
          "icon": "https://jira.planetabax.com/images/icons/priorities/trivial.svg",
        }
      ],
      availableTransitions: [
        { id: 11, name: "To Do", description: "This issue is waiting to be resolved. Take action." },
        { id: 21, name: "In Dev.", description: "This issue is being actively worked on at the moment by the assignee." },
        { id: 191, name: "Released", description: "The issue is considered finished, the resolution is correct. Issues which are closed can be reopened." },
        { id: 121, name: "Cancelled", description: "" },
        { id: 211, name: "Blocked", description: "" },
        { id: 231, name: "Awaiting feedback", description: "" },
        { id: 161, name: "Backlog", description: "" },
        { id: 201, name: "Shelved", description: "" },
        { id: 221, name: "Postponed", description: "This status is managed internally by JIRA Software" },
        { id: 41, name: "Start Progress" },
      ],
      autoGrowHack: false,
      newDescription: "",
      newSummary: "",
      newGitlabLink: "",
      availableAssignees: [],
      availableLabels: [],
      availableComponents: [],
      availableEpics: [],
      availableLinkedCustomerTickets: [],
      componentSearch: "",
      customerTicketSearch: "",
      labelSearch: "",
      updatingIssueType: false,
      updatingIssuePriority: false,
      updatingIssueAssignee: false,
      updatingLinkedCustomerTickets: false,
      updatingIssueLabels: false,
      updatingCountriesAffected: false,
      updatingIssueComponents: false,
      updatingCsTicketLink: false,
      updatingGitlabIssueLink: false,
    };
  },
  async mounted() {
    this.$emit("fetchJiraIssue");

    this.loadingSelectableItems = true;
    if (!this.availableTransitions.some(name => name === this.currentJiraIssue.fields.status.name)) {
      this.availableTransitions.unshift({
        id: this.currentJiraIssue.fields.status.id,
        name: this.currentJiraIssue.fields.status.name,
        description: this.currentJiraIssue.fields.status.description
      })
    }

    await Promise.all([
      this.fetchAvailableLabels(),
      this.fetchAvailableAssignees(),
      this.fetchAvailableComponents(),
      this.fetchAvailableLinkedCustomerTickets(),
      this.fetchAvailableEpics()
    ]).finally(() => this.loadingSelectableItems = false);

    this.forceReRender();

    this.newSummary = this.getIssueSummary;
    this.newDescription = this.getIssueDescription;

    this.intervalId = setInterval(async () => {
      this.$emit("fetchJiraIssue");
    }, 30 * 1000);
  },
  destroyed() {
    clearInterval(this.intervalId);
    this.intervalId = 0;
  },
  methods: {
    forceReRender() {
      this.autoGrowHack = !this.autoGrowHack;
    },
    async saveGitlabLink() {
      this.updatingGitlabIssueLink = true;
      const updateModel = {
        fields: {
          customfield_12900: this.newGitlabLink
        }
      }
      await axios.put(`/api/jira/issue/${this.currentJiraIssue.key}/gitlabLink`, updateModel)
        .then(() => {
          this.newGitlabLink !== "" ? this.$emit("modifiedGitlabLink", false) : this.$emit("modifiedGitlabLink", true);
        })
        .finally(() => this.updatingGitlabIssueLink = false);

    },
    async saveSummary() {
      try {
        this.savingSummary = true;
        const updateModel = {
          update: {
            summary: [
              {
                set: this.newSummary
              }
            ]
          }
        }
        await this.$store.dispatch("updateIssueWithJSON", { key: this.currentJiraIssue.key, updateModel: updateModel})
          .then(() => {
            this.$emit("fetchJiraIssue");
            this.$emit("fetchJiraList", true);
          })
      } catch {
        this.$eventBus.$emit("alert", {template: "api-error"});
      } finally {
        this.savingSummary = false;
      }
    },
    async saveDescription() {
      try {
        this.savingDescription = true;
        await axios.put(`/api/jira/issue/${this.currentJiraIssue.key}/description`, { fields: { description: this.newDescription } });
      } catch {
        this.$eventBus.$emit("alert", {template: "api-error"});
      } finally {
        this.$emit("fetchJiraIssue");
        this.$emit("fetchJiraList", true);
        this.savingDescription = false;
      }
    },
    async fetchAvailableAssignees() {
      try {
        const { data } = await axios.get("/api/jira/assignees");
        this.availableAssignees = data;
        this.availableAssignees.splice(0, 0, {
          displayName: "Unassigned",
          avatarUrls: {
            the32X32: "https://jira.planetabax.com/secure/useravatar?size=small&avatarId=10123",
          }
        });
      } catch {
        this.$eventBus.$emit("alert", {template: "api-error"});
      }
    },
    async fetchAvailableEpics() {
      try {
        const { data } = await axios.get("/api/jira/epics");
        this.availableEpics = data.epicLists[0].epicNames;
        if (this.getIssueEpic !== null && this.getIssueEpic !== "") {
          const key = this.currentJiraIssue.fields.epicIssueKey;
          const name = this.currentJiraIssue.fields.epicIssue.fields.epicName;
          if (!this.availableEpics.some(epic => epic.key === key)) {
            this.availableEpics.unshift({key: key, name: name});
          }
        }
      } catch {
        this.$eventBus.$emit("alert", {template: "api-error"});
      }
    },
    async fetchAvailableLabels() {
      try {
        const { data } = await axios.get("/api/jira/labels");
        this.availableLabels = data.suggestions.map(label => label.label);
      } catch {
        this.$eventBus.$emit("alert", {template: "api-error"});
      }
    },
    async fetchAvailableComponents() {
      try {
        const { data } = await axios.get("/api/jira/components");
        this.availableComponents = data;

        this.getIssueComponents.forEach(component => {
          if (!this.availableComponents.includes(component)) {
            this.availableComponents.unshift(component);
          }
        })
      } catch {
        this.$eventBus.$emit("alert", {template: "api-error"});
      }
    },
    async fetchAvailableLinkedCustomerTickets() {
      try {
        const { data } = await axios.get("/api/jira/linkedcustomertickets/suggestions");
        this.availableLinkedCustomerTickets = data.suggestions.map(ticket => ticket.label);

        this.getLinkedCustomerSupportTicketIds.forEach(ticket => {
          if (!this.availableLinkedCustomerTickets.includes(ticket)) {
            this.availableLinkedCustomerTickets.unshift(ticket);
          }
        })
      } catch {
        this.$eventBus.$emit("alert", {template: "api-error"});
      }
    },
    linkify(text) {
      return util.linkify(text);
    },
    async handlePushSuccess() {
      this.$emit("modifiedGitlabLink", false);
      await this.$store.dispatch("getPinnedIssues", { userKey: this.jiraUserToUse?.key, silent: true });
    },
    parseIsoDatetime(dtstr) {
      if (dtstr === "" || dtstr == null) return;
      const dt = dtstr.split(/[: T-]/).map(parseFloat);
      return new Date(dt[0], dt[1] - 1, dt[2], dt[3] || 0, dt[4] || 0, dt[5] || 0, 0).toLocaleString("en-US", this.dateOptions);
    },
    getProfileLink(name) {
      return `https://jira.planetabax.com/secure/ViewProfile.jspa?name=${name}`;
    },
  },
  computed: {
    sidebarState() {
      return this.$store.state.SidebarModule.sidebarState;
    },
    jiraUserToUse() {
      return this.$store.state.JiraModule.jiraUserToUse;
    },
    currentJiraIssue() {
      return this.$store.state.JiraModule.currentJiraIssue;
    },
    jiraIssueBeingRetrieved() {
      return this.$store.state.JiraModule.jiraIssueBeingRetrieved;
    },
    getIssueLink() {
      return `https://jira.planetabax.com/browse/${this.issueKey}`;
    },
    hasGitlabLink() {
      return this.currentJiraIssue.fields?.gitlabLink !== null;
    },
    getIssueName() {
      return this.currentJiraIssue.key ?? "Unknown";
    },
    getIssueStatus: {
      get() {
        return this.currentJiraIssue.fields?.status?.name ?? "";
      },
      async set(value) {
        try {
          this.updatingStatus = true;
          await axios.post(`/api/jira/issue/${this.currentJiraIssue.key}/transition`, {
            "transition": {
              "id": value.id.toString()
            }
          });
          this.$eventBus.$emit("alert", { text: "Status changed", type: "success"});
          this.$emit("fetchJiraIssue");
          this.$emit("fetchJiraList", true);
        } catch {
          this.$eventBus.$emit("alert", { template: "api-error"});
        } finally {
          this.updatingStatus = false;
        }
      }
    },
    getIssueStatusImageUrl() {
      return this.currentJiraIssue.fields?.status?.iconUrl;
    },
    getIssueResolution() {
      return this.currentJiraIssue.fields?.resolution?.name ?? "Unresolved";
    },
    getIssueCreatedTimestamp() {
      let timeStamp = this.currentJiraIssue.fields?.created;
      return `${this.parseIsoDatetime(timeStamp)} - ${util.getTimeSince(new Date(timeStamp))} ago`;
    },
    getIssueUpdatedTimestamp() {
      let timeStamp = this.currentJiraIssue.fields?.updated;
      return `${this.parseIsoDatetime(timeStamp)} - ${util.getTimeSince(new Date(timeStamp))} ago`;
    },
    getIssueResolvedTimestamp() {
      let timeStamp = this.currentJiraIssue.fields?.resolutionDate;
      return this.parseIsoDatetime(timeStamp);
    },
    getIssueReporterImageUrl() {
      const url = this.currentJiraIssue.fields?.reporter?.avatarUrls?.the16X16;
      if (url === null) return this.defaultAvatarUrl;
      return url;
    },
    getIssueReporterName() {
      return this.currentJiraIssue.fields?.reporter?.displayName;
    },
    getIssueDeveloperName() {
      return this.currentJiraIssue.fields?.developer?.displayName ?? "None";
    },
    getIssueDeveloperKey() {
      return this.currentJiraIssue.fields?.developer?.key ?? "";
    },
    getIssueDeveloperImageUrl() {
      const url = this.currentJiraIssue.fields?.developer?.avatarUrls?.the16X16;
      if (url === null) return this.defaultAvatarUrl;
      return url;
    },
    getIssueSummary: {
      get() {
        const summary = this.currentJiraIssue?.fields?.summary || "";
        if (summary.length > 70) {
          this.$emit("sidebarSizeChanged", true);
        }
        return summary;
      },
      set(value) {
        this.newSummary = value;
      }
    },
    getIssueDescription: {
      get() {
        let description = this.currentJiraIssue.fields?.description ?? "";
        if (description === "") return "";
        let formattedWithLinks = util.linkify(description);

        if (formattedWithLinks.includes("~")) {
          const usernames = formattedWithLinks.match("\\[(.*?)\\]");
          if (usernames) {
            let newString = "";
            usernames.forEach((username) => {
              newString = formattedWithLinks
                .replace(username.trim(), `<a href="${this.getProfileLink(username.trim().replace("~", ""))}" style="text-decoration: none"  target="_blank">${username.trim()}</a>`);
            });
            formattedWithLinks = newString;
          }
        }

        let attachments = formattedWithLinks.match(this.attachmentRegex);
        if (attachments !== null) {
          for (let i = 0; i < attachments.length; i++) {
            let fileName = "";
            if (attachments[i].includes(".png")) {
              fileName = attachments[i].replaceAll("!", "");
            } else {
              fileName = attachments[i].substr(0, attachments[i].indexOf("|")).replaceAll("|", "").replaceAll("!", "");
            }
            if (this.descriptionFileTypes.some(fileType => fileName.includes(fileType))) {
              if (this.imageFileTypes.some(fileType => fileName.includes(fileType))) {
                formattedWithLinks = formattedWithLinks.replace(attachments[i], `<img src="https://jira.planetabax.com/secure/attachment/56303/${fileName}"/>`);
              } else if (this.videoFileTypes.some(fileType => fileName.includes(fileType))) {
                formattedWithLinks = formattedWithLinks.replace(attachments[i], `<video controls src="https://jira.planetabax.com/secure/attachment/56303/${fileName}"/>`);
              } else {
                formattedWithLinks = formattedWithLinks.replace(attachments[i],
                  `<a style="text-decoration-line: none;" href="https://jira.planetabax.com/secure/attachment/56303/${fileName}" target="_blank">${fileName}</a>`);
              }
            }
          }
        }
        return formattedWithLinks.replace("[", "").replace("]", "");
      },
      set(value) {
        this.newDescription = value;
      }
    },
    getIssueTtr() {
      if (this.currentJiraIssue?.fields?.ttr?.cycle === null) return "None";
      try {
        if (this.currentJiraIssue?.fields?.ttr.cycle.remaining.milliseconds > 86400000 || this.currentJiraIssue.fields.ttr.cycle.remaining.milliseconds < 0) {
          return this.currentJiraIssue.fields.ttr.cycle.breach.friendlyTime
        } else {
          return this.currentJiraIssue.fields.ttr.cycle.remaining.friendly;
        }
      } catch {
        return null;
      }
    },
    isADevelopmentIssue: {
      get() {
        try {
          return this.currentJiraIssue.fields?.isDevelopmentIssue[0].value === "Development issue";
        } catch {
          return false;
        }
      },
      async set(value) {
        this.pushingToAsap = true;
        try {
          if (value) {
            const {data} = await axios.put(`api/jira/issue/${this.currentJiraIssue.key}/asap`);
            if (data) {
              await this.$store.dispatch("postCommentOnJiraIssue",
                {
                  key: this.currentJiraIssue.key, comment: "Issue has been moved to ASAP developers for further investigation.",
                  mentionAssignee: false
                });
              this.$eventBus.$emit("alert", {text: "Issue marked as ASAP issue", type: "success"});
              this.$emit("fetchJiraIssue");
              this.$emit("fetchIssueList", true);
            } else {
              this.$eventBus.$emit("alert", {text: "An error occured when trying to mark issue as ASAP issue", type: "error"});
            }
          } else {
            const updateModel = {
              fields: {
                customfield_12130: null
              }
            }

            await this.$store.dispatch("updateIssueWithJSON", { key: this.currentJiraIssue.key, updateModel: updateModel})
              .then(() => {
                this.$eventBus.$emit("alert", {text: "Removed 'development issue' field on issue", type: "success"});
                this.$emit("fetchJiraIssue");
                this.$emit("fetchIssueList", true);
              });
          }
        } catch {
          this.$eventBus.$emit("alert", {template: "api-error"});
        } finally {
          this.pushingToAsap = false;
        }
      },
    },
    getIssueEpic: {
      get() {
        if (this.currentJiraIssue.fields?.epicIssueKey === null) return "";
        else if (this.currentJiraIssue?.fields?.epicIssue === null) {
          // this happen when the issue has an epic issue key, but the backend most likely got a 401 or 403 error when trying to retrieve it
          return null;
        }
        return { key: this.currentJiraIssue.fields?.epicIssueKey, name: this.currentJiraIssue.fields.epicIssue.fields.epicName };
      },
      async set(value) {
        this.updatingIssueType = true;
        const updateModel = {
          fields: {
            customfield_10004: value?.key ?? null
          }
        }
        await this.$store.dispatch("updateIssueWithJSON", { key: this.currentJiraIssue.key, updateModel: updateModel})
          .then(() => {
            this.$emit("fetchJiraIssue");
            this.$emit("fetchIssueList", true);
          })
          .finally(() => this.updatingIssueType = false);
      }
    },
    getIssueType: {
      get() {
        return this.currentJiraIssue.fields?.issueType?.name;
      },
      async set(value) {
        this.updatingIssueType = true;
        const updateModel = {
          fields: {
            issuetype: {
              name: value
            },
          }
        }
        await this.$store.dispatch("updateIssueWithJSON", { key: this.currentJiraIssue.key, updateModel: updateModel})
          .then(() => {
            this.$emit("fetchJiraIssue");
            this.$emit("fetchIssueList", true);
          })
          .finally(() => this.updatingIssueType = false);
      }
    },
    getIssueDueDate: {
      get() {
        return this.parseIsoDatetime(this.currentJiraIssue?.fields?.dueDate);
      },
      set(value) {
        // after numerous attempts setting the due date through the API, it never work
        // there is probably a solution, but setting the due date itself is not that important
        // therefore this is ignored for now
      }
    },
    getIssueComponents: {
      get() {
        return this.currentJiraIssue.fields?.components ?? [];
      },
      async set(value) {
        this.componentSearch = "";
        this.updatingIssueComponents = true;
        let toSend = [];
        value.forEach((component) => {
          toSend.push({
            "name": component
          })
        });
        const updateModel = {
          update: {
            components: [
              {
                "set" : toSend
              }
            ]
          }
        }
        await this.$store.dispatch("updateIssueWithJSON", { key: this.currentJiraIssue.key, updateModel: updateModel})
          .then(() => {
            this.$emit("fetchJiraIssue");
            this.$emit("fetchIssueList", true);
          })
          .finally(() =>  this.updatingIssueComponents = false)
      }
    },
    getIssueAssignee: {
      get() {
        return this.currentJiraIssue?.fields?.assignee ?? {
          displayName: "Unassigned",
          avatarUrls: {
            the32X32: "https://jira.planetabax.com/secure/useravatar?size=small&avatarId=10123",
          }
        };
      },
      async set(value) {
        this.updatingIssueAssignee = true;
        const updateModel = {
          update: {
            assignee: [
              {
                set: {
                  name: value === null || value.displayName === "Unassigned" ? "" : value.name
                }
              }
            ],
          }
        }
        await this.$store.dispatch("updateIssueWithJSON", { key: this.currentJiraIssue.key, updateModel: updateModel})
          .then(() => {
            this.$emit("fetchJiraIssue");
            this.$emit("fetchIssueList", true);
          })
          .finally(() =>  this.updatingIssueAssignee = false)
      }
    },
    getIssueTypePriority: {
      get() {
        return this.currentJiraIssue.fields?.jiraIssuePriority?.name ?? "";
      },
      async set(value) {
        this.updatingIssuePriority = true;
        const updateModel = {
          update: {
            priority: [
              {
                set: {
                  name: value
                }
              }
            ],
          }
        }
        await axios.put(`/api/jira/issue/${this.currentJiraIssue.key}/update/${JSON.stringify(updateModel)}`)
          .then(async () => {
            if (this.currentJiraIssue.gitlabLink !== null) {
              await this.$store
                .dispatch("postCommentOnGitlabIssue",
                  { body: `Jira SD ticket changed priority from '${this.currentJiraIssue.fields.jiraIssuePriority.name}' to '${value}'` })
              .catch({
                /* this only fails if the linked gitlab issue is invalid, therefore not a big deal */
              });
            }

            this.$emit("fetchJiraIssue");
            this.$emit("fetchIssueList", true);
          })
          .finally(() => this.updatingIssuePriority = false);
      }
    },
    getLinkedCustomerSupportTicketIds: {
      get() {
        return this.currentJiraIssue.fields?.linkedCustomers ?? [];
      },
      async set(value) {
        this.customerTicketSearch = "";

        this.updatingLinkedCustomerTickets = true;
        const updateModel = {
          fields: {
            customfield_12124: value,
          }
        }
        await axios.put(`/api/jira/issue/${this.currentJiraIssue.key}/update/${JSON.stringify(updateModel)}`)
          .then(() => {
            this.$emit("fetchJiraIssue");
            this.$emit("fetchIssueList", true);
          })
          .finally(() => this.updatingLinkedCustomerTickets = false);
      }
    },
    getLabels: {
      get() {
        return this.currentJiraIssue?.fields?.labels;
      },
      async set(value) {
        this.labelSearch = "";
        this.updatingIssueLabels = true;
        const updateModel = {
          update: {
            labels: [
              {
                set: value
              }
            ],
          }
        }
        await axios.put(`/api/jira/issue/${this.currentJiraIssue.key}/update/${JSON.stringify(updateModel)}`)
          .then(() => {
            this.$emit("fetchJiraIssue");
            this.$emit("fetchIssueList", true);
          })
          .finally(() => this.updatingIssueLabels = false);
      }
    },
    getReleaseNotes: {
      get() {
        return this.currentJiraIssue?.fields?.releaseNotes ?? "";
      },
      set(value) {
        console.log(value);
      }
    },
    getCountriesAffected: {
      get() {
        return this.currentJiraIssue.fields?.countriesAffected ?? [];
      },
      async set(value) {
        this.updatingCountriesAffected = true;
        let toSend = [];
        if (value.length > 1) {
          value.forEach(country => {
            toSend.push({ "value": country });
          });
        } else if (value.length === 1) {
          toSend.push({ "value": value[0] });
        }

        const updateModel = {
          update: {
            customfield_12123: [
              {
                set: toSend
              }
            ]
          }
        }
        await axios.put(`/api/jira/issue/${this.currentJiraIssue.key}/update/${JSON.stringify(updateModel)}`)
          .then(() => {
            this.$emit("fetchJiraIssue");
            this.$emit("fetchIssueList", true);
          })
          .finally(() => this.updatingCountriesAffected = false)
      }
    },
    getGitlabIssueLink: {
      get() {
        return this.currentJiraIssue?.fields?.gitlabLink ?? "";
      },
      async set(value) {
        this.newGitlabLink = value;
      }
    },
    getTicketLink: {
      get() {
        return this.currentJiraIssue?.fields?.csTicketLink;
      },
      async set(value) {
        this.updatingCsTicketLink = true;
        const updateModel = {
          fields: {
            customfield_12120: value
          }
        }
        await axios.put(`/api/jira/issue/${this.currentJiraIssue.key}/csTicketLink`, updateModel)
          .then(() => {
            this.$emit("fetchJiraIssue");
            this.$emit("fetchIssueList", true);
          })
          .finally(() => this.updatingCsTicketLink = false);
      }
    },
  },

};
</script>

<style scoped>
.hover {
  cursor: pointer;
}
</style>
