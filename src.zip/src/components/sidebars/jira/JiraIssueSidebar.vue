﻿<template>
  <BaseSidebar :menuItems="menuItems" :current-page="currentPage" :normalWidth="700" @pageChanged="pageChanged" @sidebarSizeChanged="sidebarSizeChanged" @toggleExpand="toggleExpand">
    <span>
      <JiraIssueDetails
        @pageChanged="pageChanged"
        @fetchIssueList="fetchIssueList($event)"
        @fetchJiraIssue="fetchJiraIssue"
        @modifiedGitlabLink="modifiedGitlabLink($event)"
        @sidebarSizeChanged="sidebarSizeChanged($event)"
        :issueKey="this.issueKey"
        :expanded="expanded"
        v-if="currentPage === 'issue-details'">
      </JiraIssueDetails>
      <JiraIssueComments
        :issueKey="this.issueKey"
        v-if="currentPage === 'issue-comments'"
        :isDevelopmentIssue="this.isDevelopmentIssue"
        :expanded="expanded"
        @pageChanged="pageChanged">
      </JiraIssueComments>
      <JiraIssueLinks
        :issueKey="this.issueKey"
        @fetchIssueList="fetchIssueList($event)"
        @pageChanged="pageChanged"
        @modifiedGitlabLink="modifiedGitlabLink"
        :expanded="expanded"
        v-if="currentPage === 'issue-links'"
      ></JiraIssueLinks>
      <JiraIssueAttachments
        :issueKey="this.issueKey"
        :expanded="expanded"
        v-if="currentPage === 'issue-attachments'"
        @pageChanged="pageChanged">
      </JiraIssueAttachments>
      <JiraIssueLog
        :issueKey="this.issueKey"
        :expanded="expanded"
        v-if="currentPage === 'issue-log'"
        @pageChanged="pageChanged">
      </JiraIssueLog>
    </span>
  </BaseSidebar>
</template>

<script>
import BaseSidebar from "@/components/sidebars/BaseSidebar";
import JiraIssueDetails from "@/components/sidebars/jira/JiraIssueDetails";
import JiraIssueComments from '@/components/sidebars/jira/JiraIssueComments';
import JiraIssueLinks from '@/components/sidebars/jira/JiraIssueLinks';
import JiraIssueAttachments from '@/components/sidebars/jira/JiraIssueAttachments';
import JiraIssueLog from '@/components/sidebars/jira/JiraIssueHistory';

export default {
  props: ["issueKey", "hasGitlabTask", "isDevelopmentIssue", "currentPage"],
  components: {
    BaseSidebar,
    JiraIssueDetails,
    JiraIssueComments,
    JiraIssueLinks,
    JiraIssueAttachments,
    JiraIssueLog
  },
  data() {
    return {
      expanded: false,
    };
  },
  computed: {
    menuItems() {
      if (this.hasGitlabTask) {
        return [
          { page: "issue-details", icon: "mdi-information", expandedAsDefault: false, id: 0 },
          { page: "issue-comments", icon: "mdi-comment-text-multiple", expandedAsDefault: true, id: 1 },
          { page: "issue-attachments", icon: "mdi-attachment", expandedAsDefault: true, id: 2 },
          { page: "issue-log", icon: "mdi-history", expandedAsDefault: false, id: 3 },
          { page: "issue-links", icon: "mdi-gitlab", expandedAsDefault: false, id: 4 }
        ];
      } else {
        return [
          { page: "issue-details", icon: "mdi-information", expandedAsDefault: false, id: 0 },
          { page: "issue-comments", icon: "mdi-comment-text-multiple", expandedAsDefault: true, id: 1 },
          { page: "issue-attachments", icon: "mdi-attachment", expandedAsDefault: true, id: 2 },
          { page: "issue-log", icon: "mdi-history", expandedAsDefault: false, id: 3 },
        ];
      }
    },
  },
  methods: {
    fetchJiraIssue() {
      this.$emit("fetchJiraIssue");
    },
    fetchIssueList(silent) {
      this.$emit("fetchIssueList", silent);
    },
    pageChanged(page) {
      this.$emit("pageChanged", page);
    },
    modifiedGitlabLink(removed) {
      this.$emit("modifiedGitlabLink", removed);
    },
    sidebarSizeChanged(state) {
      this.expanded = state;
    },
    toggleExpand() {
      this.expanded = !this.expanded;
    },
  },
};
</script>

<style></style>
