﻿<template>
  <v-container>
    <v-progress-linear
      absolute
      :active="this.loadingAttachments"
      indeterminate
      dark
    ></v-progress-linear>
    <v-row>
      <v-col cols="lg-12">
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <JiraIssuePath />
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                Attachments
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-divider></v-divider>
    <v-row v-if="getAttachmentsLength > 0">
      <v-col
        v-for="attachment in this.attachments"
        :key="attachment.id"
        class="d-flex child-flex"
        cols="3"
      >
        <figure>
          <v-img v-if="attachmentIsImage(attachment)"
            contain
            aspect-ratio="1"
            style="margin: 1rem; cursor: pointer;"
            :src="attachment.thumbnail"
            @click="openImageInZoom(attachment.id)"
          >
          </v-img>
          <video v-if="attachmentIsVideo(attachment)" width="300" height="300" :src="attachment.content" controls></video>
          <div style="display: flex;">
            <figcaption style="margin: 1rem; width: 85%"><a style="text-decoration-line: none;" :href="attachment.content" target="_blank">{{attachment.fileName}}</a></figcaption>
            <v-btn :loading="deletingAttachment"
                   @click="deleteAttachment(attachment)" style="flex-grow: 1; margin-top: 0.5rem" icon><v-icon size="17">mdi-delete</v-icon></v-btn>
          </div>
          <div>
            <figcaption style="margin: 1rem; margin-top: -1rem; font-size: 13px">{{parseDate(attachment.created)}}</figcaption>
            <figcaption style="margin: 1rem; font-size: 13px; margin-top: -2.2rem; float: right;">{{parseAttachmentSize(attachment.size)}}</figcaption>
          </div>
        </figure>
      </v-col>
    <v-row>
    </v-row>
    </v-row>
    <div v-else style="margin: 0.5rem;">
      <span style="font-weight: bold;">This issue has no attachments.</span>
    </div>
    <DialogWithJiraAttachment
      :title="attachmentName"
      :created="attachmentCreated"
      :size="attachmentSize"
      :width="1500"
      :showDialog="zoomAttachmentImage"
      :imageUrl="attachmentImageUrl"
      @closeDialog="zoomAttachmentImage = false"/>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import util from "@/helpers/util";

import DialogWithJiraAttachment from "@/components/widgets/dialogs/DialogWithJiraAttachment";
import JiraIssuePath from "@/components/JiraIssuePath";

export default {
  components: {JiraIssuePath, DialogWithJiraAttachment },
  props: {
    issueKey: String,
    expanded: Boolean
  },
  data: function () {
    return {
      attachments: [],
      attachmentImageUrl: "",
      loadingAttachments: true,
      deletingAttachment: false,
      zoomAttachmentImage: false,
      attachmentName: "",
      attachmentCreated: "",
      files: [],
      attachmentSize: "",
      intervalId: 0,
    };
  },
  async mounted() {
    await this.loadAttachments();
    this.intervalId = setInterval(async () => await this.loadAttachments(true), 15000);
  },
  destroyed() {
    clearInterval(this.intervalId);
    this.intervalId = 0;
  },
  methods: {
    parseDate(dtsr) {
      return util.parseIsoDatetime(dtsr);
    },
    async loadAttachments(silent) {
      if (!silent) {
        this.loadingAttachments = true;
      }
      const attachments = [];
      await axios
        .get(`/api/jira/issue/${this.issueKey}/attachments`)
        .then((res) => {
          res.data.forEach(attachment => {
            attachments.push(attachment);
          });
        })
        .catch(() => {
          this.$eventBus.$emit("alert", { template: "api-error" });
        })
        .finally(() => {
          this.loadingAttachments = false;
          this.attachments = attachments;
        });
    },
    async deleteAttachment(attachment) {
      this.deletingAttachment = true;
      await this.$store.dispatch("deleteAttachment", { attachment: attachment })
        .then(async res => {
          if (res) {
            this.$eventBus.$emit("alert", { text: "Attachment deleted 😃", type: "success"})
            await this.loadAttachments();
          } else {
            this.$eventBus.$emit("alert", { text: "There was a problem deleting the attachment 😓", type: "error"});
          }
        })
        .catch(() => {
          this.$eventBus.$emit("alert", { template: "api-error"});
        })
        .finally(() => this.deletingAttachment = false);
    },
    async uploadAttachments() {

      /*
      await axios.post(`/api/jira/issue/${this.issueKey}/attachments`, attachments)
        .then((res) => {
          console.log(res);
        });

       */
    },
    openImageInZoom(id) {
      this.attachmentImageUrl = this.attachments.filter(x => x.id === id)[0].content;
      this.attachmentName = this.attachments.filter(x => x.id === id)[0].fileName;
      this.attachmentCreated = this.parseDate(this.attachments.filter(x => x.id === id)[0].created);
      this.attachmentSize = util.formatBytes(this.attachments.filter(x => x.id === id)[0].size);
      this.zoomAttachmentImage = true;
    },
    attachmentIsImage(attachment) {
      return attachment.content.toLowerCase().includes('.png') || attachment.content.includes('.jpeg') || attachment.content.includes('.jpg');
    },
    attachmentIsVideo(attachment) {
      return attachment.content.toLowerCase().includes('.mp4');
    },
    parseAttachmentSize(size) {
      return util.formatBytes(size, 1);
    },
  },
  computed: {
    getIssueLink() {
      return `https://jira.planetabax.com/browse/${this.issueKey}`;
    },
    getIssueName() {
      return this.issueKey;
    },
    getAttachmentsLength() {
      return this.attachments.length;
    }
  },

};
</script>

<style scoped>
.fill-width {
  width: 100%;
}

@keyframes textAnimation {
  0% {
    transform: scale(1,1);
  }
  50% {
    transform: scale(1.2,1.2);
  }
  100% {
    transform: scale(1,1);
  }
}

.icon-button-wrap {
  margin-top: 10px;
  display: flex;
  flex-direction: column;
  align-items: center;
}
</style>
