﻿<template>
  <v-container>
    <v-row>
      <v-progress-linear v-show="loadingComments" indeterminate></v-progress-linear>
      <v-col cols="lg-12">
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <JiraIssuePath />
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                Comments
              </v-list-item-title>
              <div>
                <v-textarea
                  :readonly="addingComment"
                  v-model="comment"
                  style="float: left; width: 1050px;"
                  auto-grow
                  clearable
                  class="mt-3"
                  color="deep-blue"
                  label="Add a comment"
                  prepend-icon="mdi-comment"
                  rows="1"
                ></v-textarea>
                <v-fab-transition>
                  <v-btn
                    v-show="!commentIsUnValid"
                    style=" float: right; margin-right: 70px; margin-top: 23px;"
                    color="grey darken-1"
                    fab
                    :loading="addingComment"
                    elevation="0"
                    dark
                    small
                    bottom
                    @click="addComment"
                  >
                    <v-icon>mdi-comment-plus</v-icon>
                  </v-btn>
                </v-fab-transition>
              </div>
              <div style="display: flex" v-if="comment.length > 0 && (hasLinkedGitlabTask || hasClonedIssue)">
                <div class="mt-2">
                  <v-img  src="@/assets/jira.png"
                         contain height="23" width="23" class="float-left mr-2 mt-1"></v-img>
                  <v-switch dense label="Post to Jira" style="margin: 0.1rem;" v-model="postToJira"></v-switch>
                </div>
                <div v-if="hasLinkedGitlabTask" class="ml-6 mt-2">
                  <v-img src="@/assets/Gitlab.svg"
                         contain height="23" width="23" class="float-left mr-2 mt-1"></v-img>
                  <v-switch dense v-model="postToGitlab" style="margin: 0.1rem;" label="Post to Gitlab"></v-switch>
                </div>
                <div v-if="hasClonedIssue" class="ml-6 mt-2">
                  <v-img style="float: left; margin-top: 4px;" src="@/assets/ASAP.svg"
                         contain height="23" width="23" class="float-left mr-2 mt-1"></v-img>
                  <v-switch dense v-model="postToAsap" style="margin: 0.1rem;" label="Post to linked ASAP issue"></v-switch>
                </div>
              </div>
            </v-list-item-content>
          </v-list-item>
          <v-divider></v-divider>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <div style="display: flex; width: 100%;">
        <v-switch v-if="getCommentsLength > 1" dense prepend-icon="mdi-sort-calendar-descending" v-model="sortByNewest" class="ml-4" style="margin: 0.1rem;" label="Sort by newest"></v-switch>
        <v-switch v-if="getCommentsLength > 3" dense prepend-icon="mdi-unfold-more-horizontal" v-model="expandAllComments" class="ml-8" style="margin: 0.1rem;" label="Expand all"></v-switch>
        <div v-if="hasGitlabComments && getJiraCommentsLength !== 0" class="ml-6">
          <v-img style="float: left; margin-top: 4px;" src="@/assets/Gitlab.svg"
                 contain height="23" width="23" class="mr-2"></v-img>
          <v-switch dense v-model="showGitlabActivity" style="margin: 0.1rem;" label="Show Gitlab activity"></v-switch>
        </div>

        <div v-if="hasClonedIssue && hasAsapComments && !this.loadingComments" class="ml-6">
          <v-img style="float: left; margin-top: 4px;" src="@/assets/ASAP.svg"
                 contain height="23" width="23" class="mr-2"></v-img>
          <v-switch dense v-model="showClonedIssueActivity" style="margin: 0.1rem;" label="Show ASAP activity"></v-switch>
        </div>
        <div v-if="getCommentsLength > 0" style="margin-left: auto;">
          <v-icon v-if="getCommentsLength > 1" style="margin-right: 10px;">mdi-comment-multiple</v-icon>
          <v-icon v-else style="margin-right: 10px;">mdi-comment</v-icon>
          <span style=" margin-right: 30px;">{{getCommentsLength}} {{getCommentsLength > 1 ? "comments" : "comment"}} total</span>
        </div>
      </div>
      <v-expansion-panels v-if="this.getCommentsLength !== 0" accordion multiple popout v-model="panel" style="margin: 0.6rem">
        <v-expansion-panel style="margin: 0.5rem"
          v-for="(comment, index) in getComments"
          :key="index"
        >
          <v-progress-linear absolute :active="comments[index].deleting" indeterminate dark></v-progress-linear>
          <v-expansion-panel-header>
            <div>
              <v-avatar size="20px">
                <img v-if="isValidAuthor(comment)"
                  :src="getAvatarImage(comment)"
                >
                <img v-else
                     src="https://jira.planetabax.com/secure/useravatar?size=xsmall&avatarId=10123"
                >
              </v-avatar>
              <span v-if="isValidAuthor(comment)" class="ml-2 mt-4">
                <a style="text-decoration-line: none;" :href="getProfileLink(comment)" target="_blank" >{{getAuthorName(comment)}}</a> added a comment - {{parseIsoDatetime(comment)}}
                <v-tooltip bottom>
                  <template v-slot:activator="{on}">
                    <v-icon v-on="on" class="mb-1 mr-3 float-right" v-if="determineIfNew(comment)">mdi-new-box</v-icon>
                  </template>
                  <span>Added less than 5 minutes ago</span>
                </v-tooltip>

                <v-tooltip v-if="comment.origin === 'GITLAB'" bottom>
                  <template v-slot:activator="{ on }">
                    <v-img v-on="on" style="float: right; margin-right: 1rem" src="@/assets/Gitlab.svg"
                           contain height="23" width="23"></v-img>
                  </template>
                  <span>From Gitlab</span>
                </v-tooltip>

                <v-tooltip v-if="comment.origin === 'ASAP'" bottom>
                  <template v-slot:activator="{ on }">
                    <v-img v-on="on" style="float: right; margin-right: 1rem" src="@/assets/ASAP.svg"
                           contain height="23" width="23"></v-img>
                  </template>
                  <span>From linked ASAP issue</span>
                </v-tooltip>

                <!--<v-chip v-if="comment.origin === 'GITLAB'" style="float:right; margin-right: 1rem" outlined color="yellow darken-2" small>From GitLab</v-chip>-->
                <v-chip v-if="comment.origin === 'GITLAB' && commentAuthorIsGitlabAssignee(comment)" style="float:right; margin-right: 1rem" outlined color="yellow darken-3" small>GitLab Assignee</v-chip>
                <v-chip v-if="commentAuthorIsReporter(comment)" style="float:right; margin-right: 1rem" outlined color="purple" small>Reporter</v-chip>
                <v-chip v-if="issueHasAuthor && commentAuthorIsAssignee(comment) && hasLinkedGitlabTask" style="float:right; margin-right: 1rem" outlined color="blue" small>Jira Assignee</v-chip>
                <v-chip v-if="issueHasAuthor && commentAuthorIsAssignee(comment) && !hasLinkedGitlabTask" style="float:right; margin-right: 1rem" outlined color="blue" small>Assignee</v-chip>
              </span>
              <span v-else class="ml-2 mt-4">Anonymous added a comment - {{parseIsoDatetime(comment)}}</span>
            </div>
          </v-expansion-panel-header>
          <v-expansion-panel-content>
            <span style="white-space: pre-line" v-html="formatCommentBody(comment)"></span>
            <div v-if="commentHasAttachments(comment)">
              <div v-if="attachmentIsImage(comment)">
                <img style="cursor: pointer; margin-right: 3rem" @click="showBiggerAttachmentImage(image.attachment.id)"
                     v-for="image in filterAttachmentsToAuthor(comment)"
                     :key="image.attachment.id"
                     :src="image.attachment.thumbnail">
              </div>
              <span v-else>
                <a style="text-decoration-line: none;"
                   :href="getAttachmentLink(filterAttachmentsToAuthor(comment))"
                   target="_blank">
                {{comment.comment.body.replace("^", "").replace("[", "").replace("]", "")}}
                </a>
              </span>
            </div>
            <v-btn v-if="comment.origin === 'JIRA' || comment.origin === 'ASAP'"
                   :disabled="comments[index].deleting" class="float-right" @click="deleteComment(comment, index)" icon><v-icon size="22">mdi-delete</v-icon></v-btn>
          </v-expansion-panel-content>
        </v-expansion-panel>
      </v-expansion-panels>
      <div v-if="!this.loadingComments && getCommentsLength === 0" style="margin-left: 1rem; font-weight: bold;">
        <span >This issue has no comments.</span>
      </div>
    </v-row>
    <DialogWithJiraAttachment
      :title="attachmentName"
      :created="attachmentCreated"
      :width="1500"
      :size="attachmentSize"
      :showDialog="showAttachmentImage"
      :imageUrl="attachmentImageUrl"
      @closeDialog="showAttachmentImage = false"/>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import util from "@/helpers/util";

import DialogWithJiraAttachment from "@/components/widgets/dialogs/DialogWithJiraAttachment";
import JiraIssuePath from "@/components/JiraIssuePath";

export default {
  components: {JiraIssuePath, DialogWithJiraAttachment },
  props: {
    issueKey: String,
    isDevelopmentIssue: Boolean,
    expanded: Boolean
  },
  data: function () {
    return {
      jiraUsers: [],
      gitlabUsers: [],
      comments: [],
      attachments: [],
      showAddCommentButton: true,
      showAttachmentImage: false,
      attachmentName: "",
      attachmentImageUrl: "",
      addingComment: false,
      attachmentCreated: "",
      attachmentSize: "",
      postToJira: true,
      postToGitlab: false,
      postToAsap: false,
      sortByNewest: JSON.parse(localStorage.getItem("sort_by_newest_comment")) ?? true,
      showGitlabActivity: JSON.parse(localStorage.getItem("show_gitlab_activity")) ?? true,
      expandAllComments: JSON.parse(localStorage.getItem("expand_all_comments")) ?? false,
      showClonedIssueActivity: JSON.parse(localStorage.getItem("show_asap_activity")) ?? true,
      // Expand 3 comments as default
      panel: [0, 1, 2],
      comment: "",
      loadingComments: true,
      attachmentFileTypes: [".png", ".jpeg", ".xlsx", ".xls", ".jpg", ".mp4", ".mp3", ".csv", ".txt"],
      imageFileTypes: [".png", ".jpg", ".jpeg"],
      videoFileTypes: [".mp4"],
      thumbnailRegex: new RegExp("![\\d\\D]*?thumbnail!", "g"),
      pngRegex: new RegExp("![\\d\\D]*?png!", "g"),
      jpgRegex: new RegExp("![\\d\\D]*?jpg!", "g"),
      otherRegex: new RegExp("^[\\d\\D]*?xlsx]", "g"),
      attachmentRegex: new RegExp("\\[.*\\]\\(.*\\)", "g"), //eslint-disable-line
      gitlabMentionRegex: new RegExp("@[^ ,]*", "g"),
      jiraMentionRegex: new RegExp("\\[~.*?]", "g"),
      intervalId: 0,
    };
  },
  async mounted() {
    await Promise.all([this.getAllJiraUsers(), this.getAllGitlabUsers(), this.getIssueComments()]);
    this.intervalId = setInterval(async () => await this.getIssueComments(true), 15000);
  },
  destroyed() {
    clearInterval(this.intervalId);
    this.intervalId = 0;
  },
  watch: {
    sortByNewest: {
      handler: function(newVal) {
        localStorage.setItem("sort_by_newest_comment", newVal);
        this.sortComments();
      }
    },
    showGitlabActivity: {
      handler: function(newVal) {
        localStorage.setItem("show_gitlab_activity", newVal);
        this.sortComments();
      }
    },
    expandAllComments: {
      handler: function(newVal) {
        localStorage.setItem("expand_all_comments", newVal);
        this.panel = newVal ? [...Array(this.comments.length).keys()] : [0, 1, 2];
      }
    },
    showClonedIssueActivity: {
      handler: function(newVal) {
        localStorage.setItem("show_asap_activity", newVal);
        this.sortComments();

      }
    },
    postToJira: {
      handler: function(newVal) {
        if (!newVal) this.postToGitlab = true;
      }
    },
    postToGitlab: {
      handler: function(newVal) {
        if (!newVal) this.postToJira = true;
      }
    },
  },
  methods: {
    async getIssueComments(silent) {
      this.attachments = [];
      if (!silent) {
        this.loadingComments = true;
      }

      const comments = [];
      const attachments = [];
      try {
        const { data } = await axios.get(`/api/jira/issue/${this.issueKey}/comments`);
        data.comments.forEach(comment => {
          comments.push({ origin: "JIRA", created: comment.created, comment, deleting: false });
        });

        data.attachments.forEach(attachment => {
          this.attachments.push({ origin: "JIRA", attachment });
        });

        // this issue is a development issue
        // fetch ASAP issue and display its comments
        if (this.isDevelopmentIssue && this.getJiraIssue?.fields?.links?.length > 0) {
          const { data } = await axios.get(`/api/jira/issue/${this.getJiraIssue.fields.links[0].outwardIssue.key}/comments`);
          data.comments.forEach(comment => {
            comments.push({ origin: "ASAP", created: comment.created, comment, deleting: false});
          });

          data.attachments.forEach(attachment => {
            this.attachments.push({ origin: "ASAP", attachment });
          });
        }

        // show comments from gitlab as well
        if (this.hasLinkedGitlabTask) {
          try {
            // this fails if the gitlab link is either invalid or not found
            // no big deal
            await this.refetchGitlabIssue();
            if (this.getGitlabIssue.notes.length !== 0) {
              this.$store.state.GitlabModule.linkedGitlabIssue.notes.forEach((note) => {
                if (note.body === "changed the description") return;
                if (note.body.startsWith("changed title from")) return;
                if (note.body.startsWith("changed due date to")) return;
                if (note.body.startsWith("mentioned in issue")) return;
                if (note.body.startsWith("marked")) return;

                comments.push({ origin: "GITLAB", created: note.createdAt, deleting: false, note})
              });
            }
          } catch {
            this.$store.commit("updateLinkedGitlabIssue", {});
            this.$eventBus.$emit("alert", {text: "Something is wrong with the linked GitLab issue.", type: "error"});
          }
        }
      } catch {
        this.$eventBus.$emit("alert", { template: "api-error" });
      } finally {
        this.loadingComments = false;
      }

      this.comments = comments;
      this.sortComments();
    },
    async getAllJiraUsers() {
      const { data } = await axios.get(`/api/jira/users`);
      this.jiraUsers = data;
    },
    async getAllGitlabUsers() {
      const { data } = await axios.get(`/api/gitlab/users`);
      this.gitlabUsers = data;
    },
    sortComments() {
      if (this.sortByNewest) {
        this.comments.sort((a,b) => new Date(b.created).getTime() - new Date(a.created).getTime());
      } else {
        this.comments.sort((a,b) => new Date(a.created).getTime() - new Date(b.created).getTime());
      }

      if (!this.expandAllComments) {
        this.panel = [0, 1, 2 ];
      } else {
        this.panel = [...Array(this.comments.length).keys()];
      }
    },
    commentAuthorIsReporter(comment) {
      if (comment.origin === "JIRA") {
        return this.$store.state.JiraModule.currentJiraIssue.fields.reporter.key === comment.comment.author.key;
      }
      return false;
    },
    commentAuthorIsAssignee(comment) {
      if (comment.origin === "JIRA") {
        return this.$store.state.JiraModule.currentJiraIssue.fields.assignee.key === comment.comment.author.key;
      }
      return false;
    },
    commentAuthorIsGitlabAssignee(comment) {
      const assignees = this.$store.state.GitlabModule.linkedGitlabIssue.assignees;
      return assignees.some(assignee => assignee.name === comment.note.author.name);
    },
    showBiggerAttachmentImage(id) {
      this.attachmentImageUrl = this.attachments.filter(x => x.attachment.id === id)[0].attachment.content;
      this.attachmentName = this.attachments.filter(x => x.attachment.id === id)[0].attachment.fileName;
      this.attachmentCreated = this.parseIsoDatetime(this.attachments.filter(x => x.attachment.id === id)[0].attachment.created);
      this.attachmentSize = util.formatBytes(this.attachments.filter(x => x.attachment.id === id)[0].attachment.size);
      this.showAttachmentImage = true;
    },
    getAttachmentLink(attachment) {
      if (attachment.length === 0) return;
      if (attachment.length > 1) {
        attachment.forEach((element) => {
          return element.attachment.content;
        });
      }
      return attachment[0].attachment.content;
    },
    async deleteComment(comment, indexOfComment) {
      this.comments[indexOfComment].deleting = true;
      try {
        const { data } =  await this.$store.dispatch("deleteComment", { key: this.issueKey, comment: comment.comment })
        if (data === false) {
          this.$eventBus.$emit("alert", { text: "There was a problem deleting the comment 😓", type: "error"});
        }
      } catch {
        this.$eventBus.$emit("alert", { template: "api-error"});
      } finally {
        this.comments[indexOfComment].deleting = false;
        this.comments.splice(indexOfComment, 1);
        await this.getIssueComments();
        await this.$store.dispatch("getPinnedIssues", { userKey: this.jiraUserToUse?.key, silent: true });
      }
    },
    async addComment() {
      this.addingComment = true;

      if(this.postToJira) {
        await this.$store.dispatch("postCommentOnJiraIssue", { key: this.issueKey, comment: this.comment })
          .then(res => {
            if (res.data === false) {
              this.$eventBus.$emit("alert", {text: "There was a problem posting the comment to Jira issue 😓", type: "error"});
            }
          })
          .catch(() => {
            this.$eventBus.$emit("alert", { template: "api-error"});
          })
      }

      if(this.postToAsap) {
        await this.$store.dispatch("postCommentOnJiraIssue", { key: this.getAsapIssueKey, comment: this.comment })
          .then(res => {
            if (res.data === true) {
              this.$eventBus.$emit("alert", { text: "Comment posted on linked ASAP issue", type: "success"})
            } else {
              this.$eventBus.$emit("alert", { text: "There was a problem posting the comment to linked ASAP issue 😓", type: "error"});
            }
          })
          .catch(() => {
            this.$eventBus.$emit("alert", { template: "api-error"});
          })
      }

      if (this.hasLinkedGitlabTask && this.postToGitlab) {
        let commentToPost = this.comment;
        if (Object.keys(this.getViewingAssignee).length !== 0) {
          const gitlabUser = this.gitlabUsers.find(user => user.name === this.getViewingAssignee.displayName);
          if (gitlabUser) {
            commentToPost += `<br/><br/>@${gitlabUser.username}`;
          } else {
            commentToPost += `<br/><br/>- ${this.getViewingAssignee.displayName}`;
          }
        }

        await this.$store.dispatch("postCommentOnGitlabIssue", { body: commentToPost })
          .then(res => {
            if (res.data === true) {
              this.$eventBus.$emit("alert", { text: "Comment posted on linked GitLab issue", type: "success"})
            } else {
              this.$eventBus.$emit("alert", { text: "There was a problem posting the comment to GitLab issue 😓", type: "error"});
            }
          })
          .catch(() => {
            this.$eventBus.$emit("alert", { template: "api-error"});
          })
          .finally(async () => {
            this.comment = "";
            this.addingComment = false;
            await this.getIssueComments();
          });
        return;
      }

      this.comment = "";
      this.addingComment = false;
      await this.getIssueComments();
      await this.$store.dispatch("getPinnedIssues", { userKey: this.jiraUserToUse?.key, silent: true });
    },
    async refetchGitlabIssue() {
      // try to fetch the gitlab issue so that we can get comments from issue
      // if it fails? no big deal
      const issue = this.getJiraIssue;
      const gitlabLink = issue.fields.gitlabLink;
      if (gitlabLink == null) return;

      await this.$store.dispatch("fetchGitlabIssueFromUrl", { url: gitlabLink });
    },
    attachmentIsImage(comment) {
      if (comment.origin === "GITLAB") return;
      return comment.comment.body.toLowerCase().includes(".png") || comment.comment.body.toLowerCase().includes(".jpeg")
        || comment.comment.body.toLowerCase().includes(".jpg");
    },
    commentHasAttachments(comment) {
      if (comment.origin === "GITLAB") return;
      return this.attachmentFileTypes.some(substring => comment.comment.body.toLowerCase().includes(substring));
    },
    formatCommentBody(comment) {
      let result = util.linkify(comment.origin === "JIRA" || comment.origin === "ASAP"
        ? comment.comment.body.charAt(0).toUpperCase() + comment.comment.body.slice(1)
        : comment.note.body.charAt(0).toUpperCase() + comment.note.body.slice(1));

      if (comment.origin === "JIRA" || comment.origin === "ASAP") {
        result = (comment.comment.body.replace(this.thumbnailRegex, "").trim())
          .replaceAll(this.pngRegex, "").trim()
          .replaceAll(this.jpgRegex, "").trim()
          .replaceAll("^", "")
          .replaceAll("[", "")
          .replaceAll("]", "").trim();
      } else {
        const parsedAttachments = comment.note.body.match(this.attachmentRegex);
        const userMentions = comment.note.body.match(this.gitlabMentionRegex);
        if (parsedAttachments !== null) {
          for (let i = 0; i < parsedAttachments.length; i++) {
            const fileName = parsedAttachments[i].substr(0, parsedAttachments[i].lastIndexOf("]")).replace("[", "");
            const url = parsedAttachments[i].substr(parsedAttachments[i].indexOf("(")).replace("(", "").replace(")", "");
            //this.attachments.push({ fileName: fileName, path: this.getAttachmentLinkGitlab(url) })

            if (this.imageFileTypes.some(x => fileName.includes(x) || this.imageFileTypes.some(x => url.includes(x)))) {
              comment.note.body = comment.note.body.replace("!" + parsedAttachments[i], `<img
                  style="max-width: 600px; max-height: 600px;"
                  src="${this.getAttachmentLinkGitlab(url)}"/>`)
            } else if (this.videoFileTypes.some(x => fileName.includes(x)) || this.videoFileTypes.some(x => url.includes(x))) {
              comment.note.body = comment.note.body.replace(parsedAttachments[i],
                `<video style="margin: 1rem" width="300" height="300" src="${this.getAttachmentLinkGitlab(url)}" controls></video>`);
            } else {
              comment.note.body = comment.note.body.replace(parsedAttachments[i],
                `<a class="text-decoration-none" href="${this.getAttachmentLinkGitlab(url)}" target="_blank">${fileName}</a>`)
            }
          }
        }

        if (userMentions !== null) {
          for (let i = 0; i < userMentions.length; i++) {
            try {
              const { name, source } = this.gitlabUsers.find(user => user.username === userMentions[i].replace("@", ""));
              if (source) {
                const link = `<a class="text-decoration-none" href="${source}" target="_blank">${name}</a>`;
                result = result.replace(userMentions[i], link);
              }
            } catch { /* ignored exception, no big deal if this fails */ }
          }
        }
      }

      // handle attachments inline in comment separately
      if (result.includes(".xlsx")) return "";
      if (result.includes(".xls")) return "";
      if (result.includes(".mp3")) return "";
      if (result.includes(".mp4")) return "";
      if (result.includes(".csv")) return "";
      if (result.includes(".txt")) return ""

      // if the comment contains some kind of tagged user, make it a link
      if ((comment.origin === "JIRA" || comment.origin === "ASAP") && comment.comment.body.includes("~")) {
        const usernames = comment.comment.body.match(this.jiraMentionRegex);
        let newString = result;
        if (usernames !== null) {
          usernames.forEach((username) => {
            const formattedUsername = username
              .replace("[", "")
              .replace("]", "")
              .replace("~", "");

            const jiraUser = this.jiraUsers.find(user => user.key === formattedUsername)?.displayName ?? null; // weird if the user didn't exist, but may happen
            if (jiraUser !== null) {
              newString = newString
                .replace(`~${formattedUsername}`, `<a href="${this.getProfileLink(formattedUsername)}" style="text-decoration: none" target="_blank">${jiraUser}</a>`);
            }
          });
        }
        return newString;
      }
      return result;
      //return util.linkify(result);
    },
    determineIfNew(comment) {
      if (comment.origin === "JIRA" || comment.origin === "ASAP") {
        return Math.floor((new Date() - new Date(comment.comment.updated)) / 1000) <= 300; // check if anything was updated less than 5 minutes ago
      } else {
        return Math.floor((new Date() - new Date(comment.note.updatedAt)) / 1000) <= 300; // check if anything was updated less than 5 minutes ago
      }
    },
    getProfileLink(comment) {
      // happens when we are formatting the comment
      if (!comment.origin) {
        return `https://jira.planetabax.com/secure/ViewProfile.jspa?name=${comment}`;
      }

      if (comment.origin === "JIRA" || comment.origin === "ASAP") {
        return `https://jira.planetabax.com/secure/ViewProfile.jspa?name=${comment.comment.author.key}`;
      } else {
        return comment.note.author?.source;
      }
    },
    getAttachmentLinkGitlab(url) {
      return `https://gitlab.planetabax.com/${this.getGitlabIssue.references.full.substring(0,
        this.getGitlabIssue.references.full.indexOf("#")).replace("#", "")}/${url.substr(1)}`;
    },
    filterAttachmentsToAuthor(comment) {
      if (comment.origin === "GITLAB") return;
      // filter out the attachments that has the same author as the comment
      return this.attachments.filter(x => x.attachment.jiraAuthor.name === comment.comment.author.name);
    },
    parseIsoDatetime(comment) {
      const dt = !comment.created ? comment.split(/[: T-]/).map(parseFloat) : comment.created.split(/[: T-]/).map(parseFloat);
      return new Date(dt[0],  dt[1] - 1, dt[2], dt[3] || 0, dt[4] || 0, dt[5] || 0, 0).toLocaleString();
    },
    getAvatarImage(comment) {
      return (comment.origin === "JIRA" || comment.origin === "ASAP") ? comment.comment.author?.avatarUrls?.the24X24 : comment.note.author?.avatarUrl;
    },
    isValidAuthor(comment) {
      return (comment.origin === "JIRA" || comment.origin === "ASAP") ? !(comment.comment.author == null || false) : !(comment.note.author == null || false);
    },
    getAuthorName(comment) {
      return (comment.origin === "JIRA" || comment.origin === "ASAP") ? comment.comment.author.displayName : comment.note.author.name;
    },
  },
  computed: {
    jiraUserToUse() {
      return this.$store.state.JiraModule.jiraUserToUse;
    },
    getViewingAssignee() {
      return this.$store.state.JiraModule.chosenAssignee;
    },
    hasAsapComments() {
      return this.comments.some(comment => comment.origin === "ASAP");
    },
    getComments() {
      let commentsToReturn = this.comments;

      if (!this.showGitlabActivity) {
        commentsToReturn = commentsToReturn.filter(comment => comment.origin !== "GITLAB");
      }
      if (!this.showClonedIssueActivity){
        commentsToReturn = commentsToReturn.filter(comment => comment.origin !== "ASAP");
      }
      else if (this.showClonedIssueActivity && this.showGitlabActivity) {
        return commentsToReturn;
      }
      return commentsToReturn;
    },
    getCommentsLength() {
      if (this.hasClonedIssue) {
        if (this.showGitlabActivity && this.showClonedIssueActivity) {
          return this.comments.length;
        } else if (!this.showGitlabActivity && this.showClonedIssueActivity) {
          return this.comments.filter(comment => comment.origin !== "GITLAB").length;
        } else if (this.showGitlabActivity && !this.showClonedIssueActivity) {
          return this.comments.filter(comment => comment.origin !== "ASAP").length;
        } else if (!this.showGitlabActivity && !this.showClonedIssueActivity) {
          return this.comments.filter(comment => comment.origin !== "GITLAB")
            .filter(comment => comment.origin !== "ASAP").length;
        }
      }

      if (this.showGitlabActivity) {
        return this.comments.length;
      } else {
        return this.comments.filter(comment => comment.origin !== "GITLAB").length;
      }
    },
    getJiraCommentsLength() {
      return this.comments.filter(comment => comment.origin === "JIRA").length;
    },
    getGitlabIssue() {
      return this.$store.state.GitlabModule.linkedGitlabIssue;
    },
    getJiraIssue() {
      return this.$store.state.JiraModule.currentJiraIssue;
    },
    hasLinkedGitlabTask() {
      return Object.keys(this.$store.state.GitlabModule.linkedGitlabIssue).length !== 0;
    },
    issueHasAuthor() {
      return this.$store.state.JiraModule.currentJiraIssue.fields.assignee !== null;
    },
    commentIsUnValid() {
      return !this.comment || !this.comment.trim();
    },
    getIssueLink() {
      return `https://jira.planetabax.com/browse/${this.issueKey}`;
    },
    hasGitlabComments() {
      try {
        return this.comments.some(comment => comment.origin === "GITLAB");
      } catch {
        return false;
      }
    },
    getAsapIssueKey() {
      return this.getJiraIssue.fields.links[0].outwardIssue.key;
    },
    hasClonedIssue() {
      try {
        return this.getJiraIssue.fields.links[0].outwardIssue.key !== null;
      } catch {
        return false;
      }
    },
  },
};
</script>

<style scoped>
.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
}
</style>
