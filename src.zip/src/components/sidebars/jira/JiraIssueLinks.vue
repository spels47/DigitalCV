﻿<template>
  <v-container fluid>
    <v-row>
      <v-progress-linear
        absolute
        :active="gitlabIssueBeingRetrieved"
        indeterminate
        rounded
        dark
      ></v-progress-linear>
      <v-col>
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <a class="secondary--text hover" style="text-decoration: none;" href="https://jira.planetabax.com/projects/ASAPSD/" target="_blank">ASAPSD</a> /
                Jira issue /
                <a class="secondary--text hover" style="text-decoration: none;" :href="getIssueLink" target="_blank">{{currentJiraIssue.key}}</a> /
                Linked GitLab issue /
                <a v-if="getGitlabIssue !== null" class="secondary--text hover" style="text-decoration: none;" :href="getLinkedIssueLink" target="_blank">{{getGitlabIssue.issueId}}</a>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
               Linked GitLab issue
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
        <v-divider></v-divider>
      </v-col>
    </v-row>
    <v-row>
      <v-col v-if="getGitlabIssue !== null">
        <v-list>
          <v-list-item>
            <v-chip
              :color="getColor(getGitlabIssue.state)"
              dark
            >
              {{ getGitlabIssue.state === "opened" ? "Open" : "Closed"}}
            </v-chip>
            <span class="ml-2">{{getIssueCreated}} <v-avatar class="ml-1" size="26">
              <img :src="getAuthorAvatarUrl"/></v-avatar> <a target="_blank" :href="getAuthorUrl">{{getAuthorName}}</a></span>
          </v-list-item>
          <v-list-item class="mt-2">
            <div>
              <h3 style="white-space: pre-line;">{{getGitlabIssue.title}}</h3>
              <p style="white-space: pre-line;" class="mt-2" v-html="formatDescription(getGitlabIssue.description)"></p>
            </div>
          </v-list-item>
          <v-divider></v-divider>
          <v-list-item>
            <div style="display: flex; width: 100%">
              <div style="margin: auto 0 auto auto;">
                <v-tooltip bottom>
                  <template v-slot:activator="{ on }">
                    <v-btn style="margin-top: 1rem;"
                           v-if="issueHasChanges"
                           color="yellow darken-4"
                           v-on="on"
                           @click="showIssueNotes = true"
                           fab
                           x-small
                           elevation="0"
                           dark
                    >
                      <v-icon>mdi-history</v-icon>
                    </v-btn>
                  </template>
                  <span>Issue history/notes</span>
                </v-tooltip>
                <v-tooltip bottom>
                  <template v-slot:activator="{ on }">
                    <v-btn class="ml-3" style="margin-top: 1rem;"
                           color="blue darken-2"
                           v-on="on"
                           @click="showEditDialog = true"
                           fab
                           x-small
                           elevation="0"
                           dark
                    >
                      <v-icon>mdi-pencil</v-icon>
                    </v-btn>
                  </template>
                  <span>Edit issue</span>
                </v-tooltip>
                <v-tooltip v-if="getGitlabIssue.state === 'opened'" bottom>
                  <template v-slot:activator="{ on }">
                    <v-btn class="ml-3" style="margin-top: 1rem;"
                           color="tablered"
                           fab
                           :loading="closingIssue"
                           v-on="on"
                           @click="closeIssue"
                           x-small
                           dark
                    >
                      <v-icon :disabled="discussionIsNotLocked">mdi-close</v-icon>
                    </v-btn>
                  </template>
                  <span>{{discussionIsNotLocked ? "Discussion is locked" : "Close issue"}}</span>
                </v-tooltip>
                <v-tooltip v-else bottom>
                  <template v-slot:activator="{ on }">
                    <v-btn class="ml-3" style="margin-top: 1rem;"
                           color="green darken-2"
                           fab
                           :loading="openingIssue"
                           @click="openIssue"
                           v-on="on"
                           elevation="0"
                           x-small
                           dark
                    >
                      <v-icon :disabled="discussionIsNotLocked">mdi-lock-open</v-icon>
                    </v-btn>
                  </template>
                  <span>{{discussionIsNotLocked ? "Discussion is locked" : "Re-open issue"}}</span>
                </v-tooltip>
              </div>
            </div>
          </v-list-item>
          <v-divider class="mt-2"></v-divider>
          <v-list-item class="mt-3">
            <div style="width: 50%; text-align: center">
              <span style="display: block; font-weight: bold" v-if="getIssueAssigneesLength !== 1">{{getIssueAssigneesLength}} Assignees</span>
              <span v-if="getIssueAssigneesLength === 0" class="mt-1 span-no-value">None</span>
              <div v-else-if="getIssueAssigneesLength === 1" style="overflow: auto;">
                <span style="display: block; font-weight: bold" >Assignee</span>
                <div>
                  <v-avatar size="36" class="mt-2 mr-3">
                    <img :src="getGitlabIssue.assignees[0].avatarUrl"/>
                  </v-avatar>
                  <a target="_blank" :href="getProfileLinkFromValue(getGitlabIssue.assignees[0])">
                    {{getGitlabIssue.assignees[0].name}}
                  </a>
                </div>
              </div>
              <v-menu v-else style="display: inline-block" v-for="assignee in getGitlabIssue.assignees" :key="assignee.id"
                      bottom
                      min-width="200px"
                      rounded
                      offset-y
              >
                <template v-slot:activator="{ on }">
                  <v-avatar
                    v-on="on"
                    style="cursor: pointer"
                    class="mt-2 mr-3"
                    size="36"
                  >
                    <img :src="assignee.avatarUrl" class="hover"/>
                  </v-avatar>
                </template>
                <v-card>
                  <v-list-item-content class="justify-center">
                    <div class="mx-auto text-center">
                      <v-avatar>
                        <img :src="assignee.avatarUrl"/>
                      </v-avatar>
                      <h3 class="mt-3">{{ assignee.name }}</h3>
                      <p class="text-caption mt-1">
                        @{{ assignee.username }}
                      </p>
                      <v-divider class="my-3"></v-divider>
                      <v-btn
                        depressed
                        rounded
                        text
                      >
                        <a :href="assignee.source" target="_blank" style="text-decoration: none; color: black;">Go to Profile</a>
                      </v-btn>
                    </div>
                  </v-list-item-content>
                </v-card>
              </v-menu>
            </div>
            <div style="width: 50%; text-align: center;">
              <span style="display: block; font-weight: bold" v-if="getIssueParticipantsLength !== 1">{{getIssueParticipantsLength}} participants</span>
              <span v-if="getIssueParticipantsLength === 0" class="mt-1 span-no-value">None</span>
              <div v-else-if="getIssueParticipantsLength === 1" style="overflow: auto;">
                <span style="display: block; font-weight: bold">Participant</span>
                <div>
                  <v-avatar size="36" class="mt-2 mr-3">
                    <img :src="getGitlabIssue.participants[0].avatarUrl"/>
                  </v-avatar>

                  <a target="_blank" :href="getProfileLinkFromValue(getGitlabIssue.participants[0])">
                    {{getGitlabIssue.participants[0].name}}
                  </a>
                  </div>
              </div>
              <v-menu style="display: inline-block" v-else v-for="participant in getGitlabIssue.participants" :key="participant.id"
                      bottom
                      min-width="200px"
                      rounded
                      offset-y
              >
                <template v-slot:activator="{ on }">
                  <v-avatar
                    v-on="on"
                    style="cursor: pointer"
                    class="mt-2 mr-3"
                    size="36"
                  >
                    <img :src="participant.avatarUrl" class="hover"/>
                  </v-avatar>
                </template>
                <v-card>
                  <v-list-item-content class="justify-center">
                    <div class="mx-auto text-center">
                      <v-avatar>
                        <img :src="participant.avatarUrl"/>
                      </v-avatar>
                      <h3 class="mt-3">{{ participant.name }}</h3>
                      <p class="text-caption mt-1">
                        @{{ participant.username }}
                      </p>
                      <v-divider class="my-3"></v-divider>
                      <v-btn
                        depressed
                        rounded
                        text
                      >
                        <a :href="participant.source" target="_blank" style="text-decoration: none; color: black;">Go to Profile</a>
                      </v-btn>
                    </div>
                  </v-list-item-content>
                </v-card>
              </v-menu>
            </div>
          </v-list-item>
          <v-divider v-if="getGitlabIssue.milestone || getGitlabIssue.iterations || hasLabels || getGitlabIssue.epic" class="mt-3"></v-divider>
          <v-list-item v-if="getGitlabIssue.milestone || getGitlabIssue.iterations || hasLabels || getGitlabIssue.epic" class="mt-2">
            <div>
              <IssueEpic v-if="getGitlabIssue.epic" :issue="getGitlabIssue"/>
              <IssueMilestone v-if="getGitlabIssue.milestone" :issue="getGitlabIssue"/>
              <IssueIteration v-if="getGitlabIssue.iterations" :issue="getGitlabIssue"/>
              <IssueLabels v-if="hasLabels" :issue="getGitlabIssue"/>
            </div>
          </v-list-item>
          <v-divider v-if="getGitlabIssue.milestone || getGitlabIssue.iterations || hasLabels" class="mt-3"></v-divider>
          <v-divider v-else class="mt-5"></v-divider>
          <v-list-item class="mt-3">
            <div style="width: 50%; text-align: center;">
              <span style="display: block; font-weight: bold">Time tracking</span>
              <div v-if="issueHasTimeEstimate">
                <span style="display: block">Estimated: {{getHumanTimeEstimate}}</span>
                <span v-if="getHumanTimeSpent !== null">Spent: {{getHumanTimeSpent}}</span>
              </div>
              <span v-else class="span-no-value">No estimate or time spent</span>
            </div>
            <div style="width: 50%; text-align: center;">
              <span style="display: block; font-weight: bold">Due date</span>
              <span v-if="getIssueDueDate !== ''">{{getIssueDueDate}}</span>
              <span v-else class="span-no-value">None</span>
            </div>
          </v-list-item>
          <v-divider class="mt-5"></v-divider>
          <v-list-item class="mt-3">
            <div style="width: 50%; text-align: center;">
              <span style="display: block; font-weight: bold">Confidentiality</span>
              <div class="mt-2">
                <v-icon v-if="getIssueConfidentiality">mdi-eye-off</v-icon>
                <v-icon v-else>mdi-eye</v-icon>
                <span class="ml-2">{{getIssueConfidentiality ? "Confidential" : "Not confidential"}}</span>
              </div>
            </div>
            <div style="width: 50%; text-align: center;">
              <span style="display: block; font-weight: bold">Discussion locked</span>
              <div class="mt-2">
                <v-icon v-if="getIsIssueLocked">mdi-lock</v-icon>
                <v-icon v-else>mdi-lock-open-variant</v-icon>
                <span class="ml-2">{{getIsIssueLocked ? "Locked" : "Unlocked"}}</span>
              </div>
            </div>
          </v-list-item>
        </v-list>
      </v-col>
      <div v-else style="width: 95%" class="mx-auto">
        <v-card elevation="0">
          <v-card-title>Something went wrong</v-card-title>
          <v-card-subtitle style="color: red;">Backstage couldn't fetch the linked GitLab issue</v-card-subtitle>
          <v-card-text v-html="issueError"></v-card-text>
          <v-card-actions>
            <v-btn  style="font-size: 13px" :loading="removingLink" @click="removeGitlabLink" rounded depressed>Remove issue link on JIRA ticket</v-btn>
          </v-card-actions>
        </v-card>
      </div>
    </v-row>
    <EditGitlabIssueDialog :show-dialog="showEditDialog" :issue="getGitlabIssue" @closeDialog="showEditDialog = false" @editSuccessful="editSuccessful"/>
    <IssueNotes :show-dialog="showIssueNotes" :issue="getGitlabIssue" @closeDialog="showIssueNotes = false"/>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import util from "@/helpers/util";

import IssueMilestone from "../gitlab/GitlabIssueMilestone";
import IssueLabels from "../gitlab/GitlabIssueLabels";
import IssueIteration from "../gitlab/GitlabIssueIteration";
import IssueNotes from "../gitlab/GitlabIssueNotes";
import IssueEpic from "../gitlab/GitlabIssueEpic";
import EditGitlabIssueDialog from "@/components/widgets/dialogs/EditGitlabIssueDialog";

export default {
  props: {
    issueKey: String,
    expanded: Boolean
  },
  components: {
    IssueMilestone,
    IssueLabels,
    IssueIteration,
    IssueNotes,
    IssueEpic,
    EditGitlabIssueDialog,
  },
  data: function () {
    return {
      isLoading: true,
      removingLink: false,
      showEditDialog: false,
      subscribing: false,
      issueError: null,
      issueId: 0,
      dateOptions: { weekday: 'short', year: 'numeric', month: 'long', day: 'numeric' },
      attachmentRegex: new RegExp("\\[.*\\]\\(.*\\)", "g"), //eslint-disable-line
      imageFileTypes: [".png", ".jpg", ".jpeg"],
      videoFileTypes: [".mp4"],
      attachmentImageUrl: "",
      attachmentName: '',
      showIssueNotes: false,
      closingIssue: false,
      openingIssue: false,
      attachments: [],
      intervalId: 0,
    };
  },
  async mounted() {
    await this.fetchIssueGroupAndProceed();
    this.intervalId = setInterval(async () => await this.fetchIssueGroupAndProceed(), 30 * 1000);
  },
  destroyed() {
    clearInterval(this.intervalId);
    this.intervalId = 0;
  },
  methods: {
    async editSuccessful() {
      await this.fetchIssueGroupAndProceed();
    },
    attachmentIsImage(attachment) {
      return attachment.url.includes('.png') || attachment.url.includes('.jpeg') || attachment.url.includes('.jpg');
    },
    attachmentIsVideo(attachment) {
      return attachment.url.includes(".mp4");
    },
    async removeGitlabLink() {
      this.removingLink = true;
      await axios.put(`/api/jira/issue/${this.getJiraIssue.key}/gitlablink`, {
        "fields": {
          "customfield_12900": ""
        }
      }).then(async (response) => {
        if (response.data === false) {
          this.$eventBus.$emit("alert", { text: "An error occured when removing GitLab link 😓", type: "error"});
        } else {
          this.$eventBus.$emit("alert", { text: "GitLab link removed", type: "success"})
          this.$emit("modifiedGitlabLink", true);
        }
      })
      .finally(() => this.removingLink = false)
      .catch(() => this.$eventBus.$emit("alert", { template: "api-error" }));
    },
    async closeIssue() {
      if (this.discussionIsNotLocked) return;

      this.closingIssue = true;
      await axios
        .post(`/api/gitlab/projectIssue/${this.$store.state.GitlabModule.linkedGitlabIssue.projectId}/${this.$store.state.GitlabModule.linkedGitlabIssue.issueId}/close`)
        .then(async res => {
          if (res.data) {
            this.$eventBus.$emit("alert", { text: "Issue closed - refreshing issue 😃", type: "success"})
            await this.fetchIssueGroupAndProceed();
          } else {
            this.$eventBus.$emit("alert", { text: "There was a problem closing the issue 😓", type: "error"});
          }
        })
        .catch(() => {
          this.$eventBus.$emit("alert", { template: "api-error" });
        })
        .finally(() => this.closingIssue = false);
    },
    async openIssue() {
      if (this.discussionIsNotLocked) return;

      this.openingIssue = true;
      await axios
        .post(`/api/gitlab/projectIssue/${this.$store.state.GitlabModule.linkedGitlabIssue.projectId}/${this.$store.state.GitlabModule.linkedGitlabIssue.issueId}/open`)
        .then(async res => {
          if (res.data) {
            this.$eventBus.$emit("alert", { text: "Issue re-opened - refreshing issue 😃", type: "success"})
            await this.fetchIssueGroupAndProceed();
          } else {
            this.$eventBus.$emit("alert", { text: "There was a problem re-opening the issue 😓", type: "error"});
          }
        })
        .catch(() => {
          this.$eventBus.$emit("alert", { template: "api-error" });
        })
        .finally(() => this.openingIssue = false);
    },
    linkify(text) {
      return util.linkify(text);
    },
    formatDescription(description) {
      if (description === undefined) return "";
      const parsedAttachments = description.match(this.attachmentRegex);
      let attachmentObject = [];

      if (parsedAttachments !== null) {
        for (let i = 0; i < parsedAttachments.length; i++) {
          const fileName = parsedAttachments[i].substr(0, parsedAttachments[i].lastIndexOf("]")).replace("[", "");
          const url = parsedAttachments[i].substr(parsedAttachments[i].indexOf("(")).replace("(", "").replace(")", "");
          attachmentObject.push({ fileName: fileName, path: this.getAttachmentLink(url) })

          if (this.imageFileTypes.some(x => fileName.includes(x) || this.imageFileTypes.some(x => url.includes(x)))) {
            description = description.replace("!" + parsedAttachments[i], `<img
                  style="max-width: 600px; max-height: 600px;"
                  src="${this.getAttachmentLink(url)}"/>`)
          } else if (this.videoFileTypes.some(x => fileName.includes(x)) || this.videoFileTypes.some(x => url.includes(x))) {
            description = description.replace(parsedAttachments[i], `<video style="margin: 1rem" width="300" height="300" src="${this.getAttachmentLink(url)}" controls></video>`);
          } else {
            description = description.replace(parsedAttachments[i], `<a style="text-decoration-line: none;" href="${this.getAttachmentLink(url)}" target="_blank">${fileName}</a>`)
          }
        }
      }

      description = description.trim();
      //this.attachments = attachmentObject;
      if (this.attachments.some(attachment => attachment.fileName.includes(".png" || ".jpeg"))) {
        this.$emit("forceExpandSidebar");
      }
      return util.linkify(description);
    },
    getAttachmentLink(url) {
      return `https://gitlab.planetabax.com/${this.getGitlabIssue.references.full.substring(0,
        this.getGitlabIssue.references.full.indexOf("#")).replace("#", "")}/${url.substr(1)}`;
    },
    getColor (state) {
      if (state === "opened") {
        return "green";
      }
      return "red";
    },
    parseIsoDatetime(dtstr) {
      return util.parseIsoDatetime(dtstr);
    },
    getProfileLinkFromValue(value) {
      return value.source;
    },
    getAuthorUrl() {
      return this.$store.state.GitlabModule.linkedGitlabIssue?.gitlabAuthor?.source;
    },
    invalidGitlabLink() {
      this.$store.commit("updateLinkedGitlabIssue", {});
      this.issueError = "<b>There are several reasons why this can fail.</b> " +
        "<br/>1. The GitLab issue is either deleted or the link is invalid. <br/> 2. The issue may have been moved to another project and Backstage couldn't find it." +
        "<br/> 3. GitLab servers may be down" +
        "<br/><br/> In case of a faulty link, would you like to remove the link from the JIRA issue?";
      //this.$eventBus.$emit("alert", { text: this.issueError, type: "error" });
    },
    async fetchIssueGroupAndProceed() {
      this.isLoading = true;

      const issue = this.getJiraIssue;
      const gitlabLink = issue.fields.gitlabLink;
      if (gitlabLink == null) return;

      if (!gitlabLink.includes("gitlab")) {
        this.$store.commit("updateLinkedGitlabIssue", {});
        this.issueError = "<b>The Gitlab issue link seems to be unvalid. (Ex: missing keyword gitlab)</b>";
      }

      await this.$store.dispatch("fetchGitlabIssueFromUrl", { url: gitlabLink }).catch(() => {
        this.invalidGitlabLink();
      }).finally(() => this.isLoading = false);
    },
  },
  computed: {
    currentJiraIssue() {
      return this.$store.state.JiraModule.currentJiraIssue;
    },
    discussionIsNotLocked() {
      return this.getGitlabIssue.discussionLocked !== null && this.getGitlabIssue.discussionLocked === true;
    },
    sidebarState: {
      get: function () {
        return this.$store.state.SidebarModule.sidebarState;
      },
      set: function (value) {
        this.$store.commit("updateSidebarState", value);
      }
    },
    hasLabels() {
      return this.getGitlabIssue?.labels?.length !== 0;
    },
    gitlabIssueBeingRetrieved() {
      return this.$store.state.GitlabModule.gitlabIssueBeingRetrieved;
    },
    getIssueAssigneesLength() {
     return this.$store.state.GitlabModule.linkedGitlabIssue?.assignees?.length;
    },
    getIssueParticipantsLength() {
      return this.$store.state.GitlabModule.linkedGitlabIssue?.participants?.length;
    },
    getJiraIssue() {
      return this.$store.state.JiraModule.currentJiraIssue;
    },
    getGitlabIssue() {
      return Object.keys(this.$store.state.GitlabModule.linkedGitlabIssue).length !== 0 ? this.$store.state.GitlabModule.linkedGitlabIssue : null;
    },
    getIssueLink() {
      return `https://jira.planetabax.com/browse/${this.issueKey}`;
    },
    getLinkedIssueLink() {
      return this.$store.state.GitlabModule.linkedGitlabIssue?.source;
    },
    getIssueName() {
      return this.issueKey;
    },
    getIssueCreated() {
      return `Created ${util.getTimeSince(new Date(this.$store.state.GitlabModule.linkedGitlabIssue.createdAt))} ago by`;
    },
    getAuthorName() {
      return this.$store.state.GitlabModule.linkedGitlabIssue?.gitlabAuthor?.name;
    },
    getAuthorAvatarUrl() {
      return this.$store.state.GitlabModule.linkedGitlabIssue?.gitlabAuthor?.avatarUrl;
    },
    getIssueDueDate() {
      const dueDate = this.$store.state.GitlabModule.linkedGitlabIssue?.dueDate;
      if (dueDate == null) return "";
      return this.parseIsoDatetime(dueDate);
    },
    getIssueConfidentiality() {
      return this.$store.state.GitlabModule.linkedGitlabIssue?.confidential;
    },
    getIsIssueLocked() {
      return this.$store.state.GitlabModule.linkedGitlabIssue?.discussionLocked !== null && this.$store.state.GitlabModule.linkedGitlabIssue?.discussionLocked === true;
    },
    issueHasTimeEstimate() {
      return this.$store.state.GitlabModule.linkedGitlabIssue?.issueTimeStats?.timeEstimate !== 0;
    },
    getHumanTimeEstimate() {
      return this.$store.state.GitlabModule.linkedGitlabIssue?.issueTimeStats?.humanTimeEstimate;
    },
    getHumanTimeSpent() {
      return this.$store.state.GitlabModule.linkedGitlabIssue?.issueTimeStats?.humanTotalTimeSpent;
    },
    issueHasChanges() {
      return this.$store.state.GitlabModule.linkedGitlabIssue?.notes?.length !== 0;
    },
  },
};
</script>

<style scoped>
.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
}

span {
  color: #303030;
}

.span-no-value {
  color: #666666;
}

a {
  text-decoration: none;
  color: #303030;
}

a:hover {
  color: #064787;
  text-decoration: underline;
}

img {
  cursor: pointer;
}
