<template>
  <v-container>
    <v-row no-gutters>
      <v-col cols="lg-12">
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath clickable :department-path="account.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline" v-if="account">
                <span>Account info</span>
              </v-list-item-title>
              <v-list-item-title class="headline" v-if="account && account.accountActive === false">
                <span class="error--text">INACTIVE</span>
              </v-list-item-title>
              <v-list-item-title class="headline" v-if="account && account.hasLeftCompany && account.accountActive">
                <span class="error--text">LEFT COMPANY</span>
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="lg-12">
        <v-list min-width="100">
          <v-list-item>
            <v-text-field
              :readonly="!roles.USER_EDIT"
              :rules="rules.nameRules"
              @change="updateAccountInfo('name', 'Name')"
              prepend-icon="mdi-account"
              label="Name"
              v-model="account.name"
              ref="accountNameTextField"
              :error="!isValidInfo('name')"
            ></v-text-field>
          </v-list-item>
          <v-list-item>
            <v-text-field
              :readonly="!roles.USER_EDIT"
              :rules="rules.usernameRules"
              @change="updateUsername"
              prepend-icon="mdi-account-box"
              label="Username"
              ref="accountUsernameTextField"
              v-model="account.username"
            ></v-text-field>
          </v-list-item>
          <v-list-item>
            <v-text-field @change="updateAccountInfo('userId', 'UserId')" readonly prepend-icon="mdi-numeric" label="UserId" v-model="account.userId"/>
          </v-list-item>
          <v-list-item>
            <v-text-field
              :readonly="!roles.USER_EDIT"
              @change="updateAccountInfo('mobile', 'Mobile')"
              @input="validatePhoneNumber"
              prepend-icon="mdi-phone"
              label="Mobile"
              ref="accountPhoneTextField"
              v-model="account.mobile"
              :error="!isValidPhoneNumber"
            ></v-text-field>
          </v-list-item>
          <v-list-item>
            <v-text-field
              :readonly="!roles.USER_EDIT"
              @change="updateAccountInfo('email', 'Email')"
              prepend-icon="mdi-email"
              label="Email"
              v-model="account.email"
              ref="accountEmailTextField"
              :error="!isValidInfo('email')"
            ></v-text-field>
          </v-list-item>
          <v-list-item>
            <v-text-field @change="updateAccountInfo('employeeNumber', 'Employee No')" prepend-icon="mdi-numeric" :readonly="!roles.USER_EDIT" label="Employee No" v-model="account.employeeNumber"></v-text-field>
          </v-list-item>
          <v-list-item v-if="!account.isAdminUser">
            <ClickableSelectWithDialog
              @itemClicked="navigateToAssignedVehicle"
              @appendIconClicked="assignDriverDialog = true"
              :fieldLabel="'Connected Asset (Vehicle / Equipment)'"
              :itemText="account.vehicleAssignedSimcardId ? account.vehicleAssignedAlias + ' - ' + account.vehicleAssignedLicensePlate : null"
              :icon="'mdi-car-connected'"
              :showCloseIcon="true"
              :hasEditRights="roles.USER_EDIT"
              @closeIconClicked="unassignDriverDialog = true"
            ></ClickableSelectWithDialog>
          </v-list-item>
        </v-list>
      </v-col>

      <v-col cols="12">
        <v-bottom-navigation grow :background-color="'cardbg'" class="elevation-0">
          <v-btn v-if="roles.USER_RESET" @click="resetPasswordsDialog = true" :disabled="!account.mobile && !account.email">
            <span>Reset password</span>
            <v-icon>mdi-lock-reset</v-icon>
          </v-btn>
          <v-dialog v-model="resetPasswordsDialog" persistent max-width="290">
            <v-card>
              <v-card-title class="headline">
                Reset password
              </v-card-title>
              <v-card-text>Are you sure you want to reset this user password</v-card-text>
              <v-card-actions>
                <v-spacer></v-spacer>
                <v-btn color="green darken-1" text @click="resetPasswordsDialog = false">
                  cancel
                </v-btn>
                <v-btn color="green darken-1" text @click="userResetPassword">
                  Ok
                </v-btn>
              </v-card-actions>
            </v-card>
          </v-dialog>
          <v-btn v-if="roles.USER_EDIT" @click="moveUserDialog = true">
            <span>Move account</span>
            <v-icon>mdi-account-arrow-right</v-icon>
          </v-btn>
          <MoveEntityDialog
            v-if="moveUserDialog"
            :mainOfficeId="customer.mainOfficeId"
            :initialCustomerId="this.account.departmentId"
            :title="'Select Department to move user to'"
            :checkboxLabel="'Also move vehicles connected to driver'"
            @closeDialog="moveUserDialog = false"
            @confirm="accountMove"
          ></MoveEntityDialog>
        </v-bottom-navigation>

        <v-dialog width="700" v-model="mergeUserDialog">
          <MergeUserWidget v-if="mergeUserDialog" :customerId="customer.id" :sourceUser="account" @closeMergeDialog="closeMergeDialog"></MergeUserWidget>
        </v-dialog>

        <v-dialog width="700" v-model="assignDriverDialog" persistent>
          <AssignVehicleWidget :customerId="customer.id" @closeMergeDialog="assignDriverDialog = false" @vehicleSelected="assignDriver"></AssignVehicleWidget>
        </v-dialog>

        <v-dialog v-model="unassignDriverDialog" max-width="30%" persistent>
          <v-card>
            <v-card-title class="headline">
              <span>Unassign Driver</span>
            </v-card-title>
            <v-card-text>
              Are you sure you want to unassign the driver of this vehicle?
            </v-card-text>
            <v-card-actions>
              <v-spacer></v-spacer>
              <v-btn color="primary" text @click="unassignDriverDialog = false">
                Cancel
              </v-btn>
              <v-btn color="primary" text @click="unassignDriver(account.vehicleAssignedVehicleId)">
                <v-icon>mdi-account-arrow-right</v-icon>
                Unassign
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-dialog>

        <v-bottom-navigation grow :background-color="'cardbg'" class="elevation-0">
          <v-btn @click="toggleFavorite">
            <span v-if="isFavorite">Favorite</span>
            <span v-if="!isFavorite">Add to favorites</span>
            <v-icon :color="isFavorite ? 'marked' : ''">mdi-heart</v-icon>
          </v-btn>
          <v-btn v-if="!account.isAdminUser && roles.USER_EDIT" @click="mergeUserDialog = true">
            <span>Merge account</span>
            <v-icon>mdi-set-merge</v-icon>
          </v-btn>
          <v-btn v-if="roles.USER_IMPERSONATE" @click="impersonate" :disabled="!account.accountActive">
            <span>Impersonate</span>
            <v-icon color="secondary">mdi-login-variant</v-icon>
          </v-btn>
        </v-bottom-navigation>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <v-list>
          <v-list-item>
            <v-select @change="updateAccountActiveState" :readonly="!roles.USER_EDIT" prepend-icon="mdi-power" label="Account active" :items="[true, false]" v-model="account.accountActive"></v-select>
          </v-list-item>
          <v-list-item>
            <v-select @change="toggleAccountLeftCompany" :readonly="!roles.USER_EDIT" prepend-icon="mdi-exit-run" label="Left the company" :items="[true, false]" v-model="account.hasLeftCompany"/>
          </v-list-item>
          <v-list-item>
            <v-select prepend-icon="mdi-flag" :readonly="!roles.USER_EDIT" @change="updateAccountInfo('language', 'Language')" :items="['NO', 'SE', 'DK', 'FI', 'UK', 'NL', 'PL', 'CN', 'DE', 'BE', 'FR', 'IT']" label="Language"
                      v-model="account.language"></v-select>
          </v-list-item>
          <v-list-item v-if="!account.isAdminUser">
            <ClickableSelectWithDialog
              @itemClicked="navigateToAttestationUser"
              @appendIconClicked="assignDriverDialog = true"
              :fieldLabel="'Attestation by'"
              :itemText="account.attestationId ? account.attestationName + ' - ' + account.attestationUsername : 'N/A'"
              :icon="'mdi-account'"
              :showCloseIcon="false"
              :show-append-icon="false"
              @closeIconClicked="unassignDriverDialog = true"
            ></ClickableSelectWithDialog>
          </v-list-item>
          <v-list-item>
            <v-text-field @change="updateRcid" :readonly="!roles.USER_EDIT" prepend-icon="mdi-numeric" label="RCID" v-model="account.rcid"/>
          </v-list-item>
          <v-list-item>
            <v-text-field @change="updateAccountInfo('address', 'Address')" :readonly="!roles.USER_EDIT" prepend-icon="mdi-map-marker" label="Address" v-model="account.address"/>
          </v-list-item>
          <v-list-item>
            <v-icon :color="account.isAdminUser ? 'secondary' : ''" left @click="toggleAdmin()">{{ account.isAdminUser ? "mdi-shield-account" : "mdi-account" }}</v-icon>
            <v-text-field @change="updateAccountInfo('title', 'Title')" :readonly="!roles.USER_EDIT" label="Title" v-model="account.title"/>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "~/axios-client";
import DepartmentPath from "~/components/DepartmentPath";
import MergeUserWidget from "@/components/widgets/MergeUserWidget";
import ClickableSelectWithDialog from "@/components/ClickableSelectWithDialog";
import AssignVehicleWidget from "@/components/widgets/AssignVehicleWidget";
import MoveEntityDialog from "@/components/widgets/dialogs/MoveEntityDialog";

export default {
  name: "AccountDetails",
  components: { DepartmentPath, MergeUserWidget, ClickableSelectWithDialog, AssignVehicleWidget, MoveEntityDialog },
  props: {
    id: String,
    expanded: Boolean,
    customer: Object,
    departmentId: Number
  },
  data: function () {
    return {
      initalLoadOfAccount: null,
      rules: {
        nameRules: [v => !!v || "Name is required", v => (v && v.length <= 250) || "Name is too long"],
        usernameRules: [v => !!v || "Username is required", v => (v && v.length <= 50) || "Username is too long"],
        phoneRules: [v => !!v || "Number is required", v => /^\+[0-9]+$/.test(v) || "Number must be valid", v => (v && v.length > 6) || "Number is too short", v => (v && v.length < 16) || "Number is too long"],
      },
      loginHistory: {},
      isLoading: true,
      loginHeaders: [
        { text: "Date", value: "signedInAt" },
        { text: "Ip-Address", value: "source" },
        { text: "Platform", value: "signedInUsing" }
      ],
      loginHeadersLong: [
        { text: "Date", value: "signedInAt" },
        { text: "Ip-Address", value: "source" },
        { text: "Platform", value: "signedInUsing" },
        { text: "Days since", value: "DaysSinceLogon" }
      ],
      isValidPhoneNumber: true,
      moveUserDialog: false,
      mergeUserDialog: false,
      customerId: 0,
      moveConnected: true,
      currentSelectedId: 0,
      resetPasswordsDialog: false,
      assignDriverDialog: false,
      unassignDriverDialog: false,
      originalUsername: "",
      originalRcid: "",
      validatePhoneNumberDebounce: null
    };
  },
  async mounted() {
    await this.$store.dispatch("retrieveAccount", { id: this.id });
  },
  watch: {
    id: async function () {
      await this.$store.dispatch("retrieveAccount", { id: this.id });
    },
    account: function () {
      if (this.account.vehicleAssignedVehicleId) this.$store.dispatch("retrieveVehicle", { id: this.account.vehicleAssignedVehicleId });
      if (this.initalLoadOfAccount == null) this.initalLoadOfAccount = JSON.parse(JSON.stringify(this.account));
      this.$emit("vehicleIdChange", this.account.vehicleAssignedVehicleId);
      this.originalUsername = this.account.username;
      this.originalRcid = this.account.rcid;
    }
  },
  methods: {
    closeMergeDialog(successfulMerge) {
      this.mergeUserDialog = false;
      if (successfulMerge) {
        this.$store.dispatch("retrieveAccounts", this.customer.mainOfficeId);
      }
    },
    async assignDriver(vehicle) {
      this.isLoading = true;
      if (vehicle.id && vehicle.id !== 0) {
        if (vehicle.currentDriverId) {
          await this.unassignDriver(vehicle.id);
        }
        let assignedDriver = {};
        assignedDriver.vehicleId = parseInt(vehicle.id);
        assignedDriver.userId = this.account.userId;

        await axios
          .put("/api/vehicle/assignDriver", assignedDriver)
          .then(() => {
            this.$store.dispatch("audit", { source: "vehicle", entityId: vehicle.id, message: "Vehicle Assigned To Driver", oldValue: vehicle.currentDriverId, newValue: this.id });
            this.$store.dispatch("audit", { source: "account", entityId: this.id, message: "Vehicle Assigned To Driver", oldValue: this.account.vehicleAssignedVehicleId, newValue: vehicle.id });
          })
          .catch(() => {
            this.$eventBus.$emit("alert", { template: "api-error" });
          })
          .finally(() => {
            this.isLoading = false;
            this.assignDriverDialog = false;
            this.$store.dispatch("retrieveAccount", { id: this.id });
          });
      } else this.$eventBus.$emit("alert", { template: "api-error" });
    },
    async unassignDriver(vehicleId) {
      await axios
        .put("/api/vehicle/unassignDriver/" + vehicleId)
        .then(() => {
          this.$store.dispatch("audit", { source: "vehicle", entityId: vehicleId, message: "Vehicle Unassigned from Driver", oldValue: this.id, newValue: "" });
          this.$store.dispatch("audit", { source: "account", entityId: this.id, message: "Vehicle Unassigned from Driver", oldValue: vehicleId, newValue: "" });
        })
        .catch(() => {
          this.$eventBus.$emit("alert", { template: "api-error" });
        });
      this.unassignDriverDialog = false;
      await this.$store.dispatch("retrieveAccount", { id: this.id });
    },
    navigateToAssignedVehicle() {
      this.$router.push({ path: `/customer/${this.$route.params.id}?type=vehicle&activeTab=2&id=${this.account.vehicleAssignedVehicleId}` });
    },
    navigateToAttestationUser() {
      if (!this.account.attestationId) return;
      this.$router.push({ path: `/customer/${this.$route.params.id}?activeTab=1&type=account&id=${this.account.attestationId}` });
    },
    async userResetPassword() {
      try {
        let res = await axios.post(`/api/user/resetPassword/${this.account.userId}`)
        if (res.data === 'Sms') {
          this.$eventBus.$emit('alert', { text: `Reset password info sent on ${res.data} to user`, icon: 'mdi-feature-search', type: 'success' });
        } else {
          this.$eventBus.$emit('alert', { text: `Reset password info sent on ${res.data} (unable to send Sms)`, icon: 'mdi-feature-search', type: 'success' });
        }
        await this.$store.dispatch("audit", { source: "account", entityId: this.id, message: "Reset password for user", oldValue: "", newValue: "" });
      } catch (e) {
        this.$eventBus.$emit('alert', { text: 'Failed to send reset password info to user', icon: 'mdi-alert-circle', type: 'error' });
      }
      this.resetPasswordsDialog = false;
    },
    async accountMove(moveConnectedVehicle, destinationDepartmentId) {
      try {
        let moveToDepartmentHierarchyRes = await axios.get(`/api/customer/hierarchy/${destinationDepartmentId}/main-office-and-down`)
        await axios.put("/api/user/moveUser", { SelectedId: [this.account.userId], DestinationId: destinationDepartmentId })
        await this.$store.dispatch("audit", { source: "account", entityId: this.id, message: "Move Account to new department", oldValue: this.account.departmentId, newValue: destinationDepartmentId });
        this.account.departmentId = destinationDepartmentId
        this.account.departmentPath = moveToDepartmentHierarchyRes.data.departmentPath
        this.account.departmentName = moveToDepartmentHierarchyRes.data.name
        if (moveConnectedVehicle && this.account.vehicleAssignedVehicleId) {
          try {
            let vehicleRes = await axios.get(`/api/vehicle/${this.account.vehicleAssignedVehicleId}`);
            let vehicle = vehicleRes.data
            await axios.post(`/api/asset/${vehicle.assetId}/move/${destinationDepartmentId}`)
            await this.$store.dispatch("audit", { source: "vehicle", entityId: this.account.vehicleAssignedVehicleId, message: "Move vehicle to department", oldValue: vehicle.departmentId, newValue: destinationDepartmentId })
            this.connectedVehicle.departmentId = destinationDepartmentId
            this.connectedVehicle.departmentPath = moveToDepartmentHierarchyRes.data.departmentPath
            this.connectedVehicle.departmentName = moveToDepartmentHierarchyRes.data.name
          } catch (e) {
            this.$eventBus.$emit("alert", { text: "Failed moving assigned vehicle", type: "error" });
          }
        }
      } catch (e) {
        this.$eventBus.$emit("alert", { text: "Failed moving account", type: "error" });
      }
      this.moveUserDialog = false;
    },
    async toggleAccountLeftCompany() {
      await axios
        .put(`api/user/toggleLeftCompany?value=${this.account.hasLeftCompany}`, [this.account.userId])
        .catch(() => {
          this.$eventBus.$emit("alert", { template: "api-error" });
        })
        .finally(() => {
          this.$store.dispatch("audit", {
            source: "account", entityId: this.id, message: "Left the company",
            oldValue: !this.account.hasLeftCompany,
            newValue: this.account.hasLeftCompany
          });

          this.$store.dispatch("retrieveAccounts", this.customer.id);
        });
    },
    async updateAccountActiveState() {
      this.account.accountActive ? await this.accountActivate() : await this.accountDeactivate();
    },
    async accountActivate() {
      let selectedId = [this.account.userId];
      await axios
        .put("api/user/activateUsers", selectedId)
        .catch(() => {
          this.$eventBus.$emit("alert", { template: "api-error" });
        })
        .finally(() => {
          this.$store.dispatch("audit", { source: "account", entityId: this.id, message: "Activate/Deactivate Account", oldValue: false, newValue: true });
          this.$store.dispatch("retrieveAccounts", this.customer.id);
          this.account.accountActive = true;
        });
    },
    async accountDeactivate() {
      let selectedId = [this.account.userId];
      await axios
        .put("api/user/deactivateUsers", selectedId)
        .catch(() => {
          this.$eventBus.$emit("alert", { template: "api-error" });
        })
        .finally(() => {
          this.$store.dispatch("audit", { source: "account", entityId: this.id, message: "Activate/Deactivate Account", oldValue: true, newValue: false });
          this.$store.dispatch("retrieveAccounts", this.customer.id);
          this.account.accountActive = false;
        });
    },
    getHeaders() {
      if (this.expanded) {
        return this.loginHeadersLong;
      }
      return this.loginHeaders;
    },
    async updateRcid() {
      let response = await axios({
        method: "post",
        url: "/api/user/verifyrcid",
        headers: {},
        data: {
          Username: "",
          RcidString: this.account.rcid
        }
      });
      if (response.data === false) {
        this.$eventBus.$emit("alert", { template: "invalid-rcid" });
        this.account.rcid = this.originalRcid;
      } else {
        await this.updateAccountInfo("rcid", "RCID");
      }
    },
    async updateUsername() {
      if (!this.$refs.accountUsernameTextField.validate())
        return;

      let response = await axios({
        method: "post",
        url: "/api/user/verifyuser",
        headers: {},
        data: {
          Username: this.account.username,
          RcidString: null
        }
      });
      if (response.data.success === false) {
        this.$eventBus.$emit("alert", { template: "invalid-username" });
        this.account.username = this.originalUsername;
      } else {
        await this.updateAccountInfo("username", "Username");
      }
    },
    isValidInfo(type) {
      switch (type) {
        case "name":
          return !this.account.name || (this.account.name.length > 0 && this.account.name.length < 251);
        case "email":
          return !this.account.email || (this.account.email.length < 251 && /\S+@\S+\.\S+/.test(this.account.email));
        default:
          return true;
      }
    },
    async updateAccountInfo(type, label) {
      if (!this.$refs.accountNameTextField.validate())
        return;

      if (!this.$refs.accountUsernameTextField.validate())
        return;

      if (!this.$refs.accountEmailTextField.validate())
        return;

      if (!this.$refs.accountPhoneTextField.validate())
        return;

      if (this.account.title?.toUpperCase() === "ADMIN")
        this.account.title = "ADMIN";

      this.account.isAdminUser = this.account.title === "ADMIN";

      if (this.account.rcid)
        this.account.rcid = this.account.rcid.toString().trim()

      clearTimeout(this._timerId);

      await this.startUpdateDebounce(type, label)
    },
    async validatePhoneNumber() {
      clearTimeout(this.validatePhoneNumberDebounce);

      this.validatePhoneNumberDebounce = setTimeout(async () => {
        const { data } = await axios.get(`api/user/validate/phone/${this.account.mobile}`);
        this.isValidPhoneNumber = data.isValid;
      }, 500);
    },
    async startUpdateDebounce(type, label) {
      this._timerId = setTimeout(async () => {
        this.isLoading = true;
        try {
          await axios.put(`/api/user`, this.account)
          await this.$store.dispatch("audit", { source: "account", entityId: this.id, message: "Update Account Info: " + label, oldValue: this.initalLoadOfAccount[type], newValue: this.account[type] });
          await this.$store.dispatch("retrieveAccounts", this.customer.id);
        } catch (ex) {
          this.$eventBus.$emit("alert", { text: "An error occurred trying to update account info", icon: "mdi-alert-circle", type: "error" });
        }
        this.isLoading = false;
        this.initalLoadOfAccount = JSON.parse(JSON.stringify(this.account));
      }, 500);
    },
    async impersonate() {
      if (this.customer.departmentPath[0].id === 99992) {
        let result = await axios.get(`api/user/oldImpersonate/${this.account.userId}`);
        let impersonateUrl = result.data;
        window.open(impersonateUrl, "_blank")
      } else {
        if (this.account.isAdminUser) window.open(`/start-impersonation-central?userId=${this.account.userId}&username=${this.account.username}`, "_blank");
        else window.open(`/start-impersonation-triplog?userId=${this.account.userId}&username=${this.account.username}`, "_blank");
      }
    },
    async toggleFavorite() {
      let favorite = {
        departmentPath: this.account.departmentPath,
        id: this.account.userId.toString(),
        name: this.account.name,
        subName: this.account.username,
        type: "Account"
      };
      await this.$store.dispatch("toggleFavorite", favorite);
    },
    async toggleAdmin() {
      if (this.account.isAdminUser) {
        this.account.isAdminUser = false;
        this.account.title = "USER";
      } else {
        this.account.isAdminUser = true;
        this.account.title = "ADMIN";
      }

      await this.updateAccountInfo();
    }
  },
  computed: {
    isFavorite() {
      return this.$store.state.userSettings?.favorites?.some(x => x.type === "Account" && x.id === this.account.userId?.toString());
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    account() {
      return this.$store.state.SidebarModule.selectedAccount;
    },
    connectedVehicle() {
      return this.account.vehicleAssignedVehicleId ? this.$store.state.SidebarModule.selectedVehicle : null;
    }
  }
};
</script>

<style lang="css" scoped></style>
