<template>
  <BaseSidebar
    :menuItems="menuItems"
    :normal-width="540"
    @sidebarSizeChanged="sidebarSizeChanged"
    @pageChanged="pageChanged"
  >
    <span>
      <AccountDetails :id="id" :department-id="departmentId" :customer="customer" :expanded="expanded" v-if="currentPage === 'account-details'"></AccountDetails>
      <LoginDetails :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'login-details'"></LoginDetails>
      <AccountAuditDetails :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'audit-details'"></AccountAuditDetails>
      <AccountSettings :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'settings-details'"></AccountSettings>
      <SmsDetails :id="id" :customer="customer" :expanded="expanded" v-if="currentPage === 'sms-details'"></SmsDetails>
    </span>
  </BaseSidebar>
</template>

<script>
import BaseSidebar from "../BaseSidebar";
import AccountDetails from "./AccountDetails";
import LoginDetails from "./LoginDetails";
import AccountAuditDetails from "./AccountAuditDetails";
import AccountSettings from "./AccountSettings";
import SmsDetails from "@/components/sidebars/account/SmsDetails";
export default {
  props: ["id", "departmentId", "customer"],
  components: { BaseSidebar, AccountDetails, LoginDetails, AccountAuditDetails, AccountSettings, SmsDetails },
  data() {
    return {
      expanded: false,
      currentPage: "account-details",
      menuItems: [
        { page: "account-details", icon: "mdi-information", expandedAsDefault: false, id: 0 },
        { page: "login-details", icon: "mdi-history", expandedAsDefault: false, id: 1 },
        { page: "audit-details", icon: "mdi-math-log", expandedAsDefault: false, id: 2 },
        { page: "settings-details", icon: "mdi-account-cog", expandedAsDefault: false, id: 3 },
        { page: "sms-details", icon: "mdi-cellphone-basic", expandedAsDefault: false, id: 4}
      ]
    };
  },
  mounted() {
    this.getMenuItems()
  },
  methods: {
    getMenuItems() {
      this.menuItems = [{ page: "account-details", icon: "mdi-information", expandedAsDefault: false, id: 0 },
        { page: "login-details", icon: "mdi-history", expandedAsDefault: false, id: 1 },
        { page: "audit-details", icon: "mdi-math-log", expandedAsDefault: false, id: 2 },
        { page: "sms-details", icon: "mdi-cellphone-basic", expandedAsDefault: false, id: 3}]
      if(this.roles.USER_SETTINGS_EDIT){
        this.menuItems.push({ page: "settings-details", icon: "mdi-account-cog", expandedAsDefault: false, id: 4 })
      }
    },
    sidebarSizeChanged(state) {
      this.expanded = state;
    },
    pageChanged(page) {
      this.currentPage = page;
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
  }
};
</script>

<style></style>
