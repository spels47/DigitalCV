﻿<template>
  <v-container>
    <v-row>
      <v-col>
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath clickable :department-path="account.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                <span>Login Log</span>
              </v-list-item-title>
              <v-list-item-subtitle>
                {{ account.name }} - {{ account.username }} - {{ account.userId }}
              </v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <v-list>
          <v-data-table
            :headers="headers"
            :items="history"
            :loading="isLoading"
            :loading-text="'Retrieving login log'"
            :footer-props="{ 'items-per-page-options': [10, 20, 100] }"
            sort-by="date"
            :sort-desc="true"
          >
            <template v-slot:item.date="{ item }">
              <span>{{ convertDateToCustomerCountry(item.date) | ntzDatetimeSeconds }}</span>
            </template>

            <template v-slot:item.source="{ item }">
              <span>{{ capitalizeFirstLetter(item) }}</span>
            </template>
          </v-data-table>
        </v-list>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "@/axios-client";
import DepartmentPath from "~/components/DepartmentPath";

export default {
  name: "LoginDetails",
  props: {
    id: String,
    customer: Object,
    expanded: Boolean
  },
  components: {
    DepartmentPath
  },
  data: function () {
    return {
      isLoading: true,
      history: [],
      headers: [
        { text: 'Date', value: 'date' },
        { text: 'Platform', value: 'source' }
      ],
    }
  },
  async mounted() {
    await this.$store.dispatch("retrieveAccount", { id: this.id });
  },
  watch: {
    account() {
      this.getLoginHistory()
    }
  },
  methods: {
    convertDateToCustomerCountry(date) {
      return this.$utils.getDateTimeByCountry(date, this.customer.country);
    },
    async getLoginHistory() {
      if (!this.account?.userId)
        return;

      try {
        const { data } = await axios.get(`api/user/login-log/${this.account.userId}`);
        this.history = data;
      } finally {
        this.isLoading = false;
      }
    },
    capitalizeFirstLetter({ source }) {
      return this.$utils.capitalizeFirstLetter(source);
    }
  },
  computed: {
    account() {
      return this.$store.state.SidebarModule.selectedAccount;
    },
  }
}
</script>

<style scoped>
.fill-width {
  width: 100%;
}
</style>
