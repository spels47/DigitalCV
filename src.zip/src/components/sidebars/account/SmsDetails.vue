﻿<template>
  <v-container>
    <v-row>
      <v-col>
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath clickable :department-path="account.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                <span>SMS Log</span>
              </v-list-item-title>
              <v-list-item-subtitle>
                {{ account.name }} - {{ account.username }} - {{ account.userId }}
              </v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <v-list>
          <v-data-table
            :headers="getHeaders()"
            :items="smsLog"
            :search="search"
            :custom-filter="filterSearch"
            :items-per-page.sync="itemsPerPage"
            :loading="isLoading"
            :loading-text="'Retrieving SMS log'"
            :footer-props="{ 'items-per-page-options': (items_per_page = [10, 20, 50])}"
          >
            <template v-slot:top>
              <v-text-field
                v-model="search"
                label="Search..."
                class="ma-2"
              ></v-text-field>
            </template>

            <template v-slot:item.timeSent="{ item }">
              <span>{{ item.timeSent | ntzDatetime }}</span>
            </template>
          </v-data-table>
        </v-list>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "@/axios-client";
import DepartmentPath from "~/components/DepartmentPath";

export default {
  name: "SmsDetails",
  props: {
    id: String,
    expanded: Boolean,
    customer: Object
  },
  components: {
    DepartmentPath
  },
  data() {
    return {
      smsLog: [],
      filteredLog: [],
      search: "",
      itemsPerPage: 10,
      isLoading: true,
      smsHeaders: [
        { text: 'Date', value: 'timeSent' },
        { text: 'I/O', value: 'io' },
        { text: 'Cellphone', value: 'phoneNumber' },
      ],
      smsHeadersLong: [
        { text: 'Date', value: 'timeSent' },
        { text: 'I/O', value: 'io' },
        { text: 'Cellphone', value: 'phoneNumber' },
        { text: 'SMS Content', value: 'body' },
      ]
    }
  },
  async mounted() {
    await this.$store.dispatch("retrieveAccount", { id: this.id });
  },
  watch: {
    async account() {
      await this.getSmsLog();
    }
  },
  methods: {
    filterSearch(value, search, item) {
      search = search.toString().toLowerCase();
      return Object.keys(item).some(propName => {
        return item[propName]
          ?.toString()
          .toLowerCase()
          .includes(search);
      });
    },
    getHeaders() {
      if (this.expanded) return this.smsHeadersLong
      return this.smsHeaders;
    },
    async getSmsLog() {
      if (!this.account?.mobile)
        return;

      try {
        const { data } = await axios.get(`api/user/smslog/${this.account.mobile}`);
        this.smsLog = data;
      } catch {
        this.$eventBus.$emit('alert', { template: 'api-error' })
      } finally {
        this.isLoading = false;
      }
    },
  },
  computed: {
    account() {
      return this.$store.state.SidebarModule.selectedAccount;
    },
  }
}
</script>

<style scoped>

</style>
