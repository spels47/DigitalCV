<template>
  <v-container fluid>
    <CreateUserSettingTemplate v-if="CreateUserSettingTemplateDialogOpen" @closeDialog="CreateUserSettingTemplateDialogOpen = false" @confirm="confirmCreateUserTemplate"></CreateUserSettingTemplate>
    <v-row>
      <v-progress-linear v-show="loading" indeterminate></v-progress-linear>
      <v-col>
        <v-list>
          <v-list-item three-line>
            <v-list-item-content>
              <v-list-item-subtitle>
                <DepartmentPath clickable :department-path="account.departmentPath"></DepartmentPath>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                <span>Account Settings</span>
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
        <v-list>
          <v-list-item>
            <v-select :menu-props="menuProps" :items="templates" item-text="label" label="Template" prepend-icon="mdi-dip-switch">
              <template v-slot:item="{ active, item, attrs, on }">
                <v-list-item v-on="on" v-bind="attrs" #default="{ active }">
                  <v-list-item-content @click="applyTemplate(item)">
                    <v-list-item-title>{{ item.label }}</v-list-item-title>
                  </v-list-item-content>
                  <v-list-item-icon v-if="!item.isPublicTemplate">
                    <v-icon color="red" @click="deleteUserSettingTemplate(item.label)">
                      mdi-delete
                    </v-icon>
                  </v-list-item-icon>
                </v-list-item>
              </template>

              <template v-slot:append-item>
                <v-divider class="mb-2"></v-divider>
                <v-list-item @click="CreateUserSettingTemplateDialogOpen = true">
                  <v-list-item-content>
                    <v-list-item-title class="font-weight-bold">Create a new template from this Account</v-list-item-title>
                  </v-list-item-content>
                  <v-list-item-icon>
                    <v-icon color="black">
                      mdi-plus-circle
                    </v-icon>
                  </v-list-item-icon>
                </v-list-item>
              </template>
            </v-select>
          </v-list-item>
          <v-list-item v-for="setting in editableSettings" v-bind:key="setting.label">
            <v-switch :disabled="loading === true" v-if="setting.editable" color="secondary" :label="setting.label" v-model="setting.value" dense @change="updateAccountSetting(setting)"> </v-switch>
          </v-list-item>
        </v-list>
        <v-divider></v-divider>
        <v-list>
          <v-list-item v-for="setting in nonEditableSettings" v-bind:key="setting.label">
            <v-switch disabled v-if="!setting.editable" color="primary" :label="setting.label" v-model="setting.value" dense> </v-switch>
          </v-list-item>
        </v-list>
      </v-col>
    </v-row>
    <v-row>
      <v-col class="mb-4">
        <v-btn @click="resetTcoCache()" :disabled="tcoCacheResetState" block><v-icon class="mr-1">mdi-account-network</v-icon>Reset account cache</v-btn>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "@/axios-client";
import DepartmentPath from "~/components/DepartmentPath";
import CreateUserSettingTemplate from "~/components/widgets/dialogs/CreateUserSettingTemplate";
export default {
  components: { DepartmentPath, CreateUserSettingTemplate },
  props: ["id", "customer"],
  async mounted() {
    this.loading = true
    await Promise.all([
      this.getAccountSettings(),
      this.getUserSettingsTemplates(),
      this.getTcoCacheResetState()
    ])
    this.loading = false
  },
  methods: {
    async getTcoCacheResetState() {
      try {
        let res = await axios.get(`/api/user/resetTcoCache/${this.id}`)
        this.tcoCacheResetState = res.data.cacheResetActionSet;
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to get reset cache state`, type: 'error'});
      }
    },
    async resetTcoCache() {
      this.loading = true
      try {
        await axios.post(`/api/user/resetTcoCache/${this.id}`)
        this.tcoCacheResetState = true
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to set reset cache state`, type: 'error'});
      }
      this.loading = false
    },
    async getUserSettingsTemplates() {
      try {
        let res = await axios.get(`/api/user/userSettingsTemplates/${this.username}/${this.customer.country}/${this.account.isAdminUser ? "ADMIN" : "USER"}`)
        this.templates = res.data
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to get user settings templates`, type: 'error'});
      }
    },
    applyTemplate(template) {
      this.loading = true;
      this.accountSettings.forEach(setting => {
        if (!setting.availableFor.includes(this.account.isAdminUser ? "Admin" : "User"))
          return;

        if (template.settings.includes(setting.accountSetting[0]) && setting.value === false) {
          setting.value = true;
          this.updateAccountSetting(setting);
        } else if (!template.settings.includes(setting.accountSetting[0]) && setting.value === true) {
          setting.value = false;
          this.updateAccountSetting(setting);
        }
      })
      this.loading = false;
    },
    async confirmCreateUserTemplate(templateName) {
      this.loading = true
      try {
        await axios.post(`/api/user/createUserSettingsTemplate`, {
          label: templateName,
          isPublicTemplate: false,
          country: this.customer.country,
          templateOwner: this.username,
          templateUserType: this.account.isAdminUser ? "ADMIN" : "USER",
          settings: this.accountSettings.filter(s => s.value === true).map(v => v.accountSetting[0])
        })
        await this.getUserSettingsTemplates();
        this.CreateUserSettingTemplateDialogOpen = false;
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to create user template`, type: 'error'});
      }
      this.loading = false
    },
    async deleteUserSettingTemplate(templateName) {
      this.loading = true
      try {
        await axios.delete(`/api/user/deleteUserSettingsTemplate/${this.username}/${templateName}`)
        await this.getUserSettingsTemplates();
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to create user template`, type: 'error'});
      }
      this.loading = false
    },
    async getAccountSettings() {
      try {
        let res = await axios.get(`/api/user/userSettings/${this.id}`)
        this.accountSettings.forEach(accountSetting => {
          let val = true;
          accountSetting.accountSetting?.forEach(setting => {
            if (res.data.userRights.find(s => s.userRightOptionId === setting) === undefined || res.data.userRights.find(s => s.userRightOptionId === setting).userRightOptionValue === "0") val = false;
          });
          accountSetting.value = val;
        });
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to get user settings`, type: 'error'});
      }
    },
    async updateAccountSetting(setting) {
      this.loading = true
      try {
        await axios.put(`/api/user/userSettings`, {
          AktorRefId: parseInt(this.id),
          UserRightOptionId: parseInt(setting.accountSetting[0]),
          Value: setting.value
        })
        await this.$store.dispatch("audit", {source: "user", entityId: this.customer.id, message: "Update User Setting: " + setting.label, oldValue: !setting.value, newValue: setting.value});
      } catch (ex) {
        this.$eventBus.$emit('alert', {text: `Failed to create user template`, type: 'error'});
      }
      this.loading = false
    }
  },
  computed: {
    editableSettings() {
      const conditionalSettings = [];
      return this.accountSettings
        .filter(i => i.editable === true)
        .concat(conditionalSettings)
        .filter(i => (this.account.isAdminUser && i.availableFor.includes("Admin")) || (!this.account.isAdminUser && i.availableFor.includes("User")));
    },
    nonEditableSettings() {
      const conditionalSettings = [];
      return this.accountSettings
        .filter(i => i.editable === false)
        .concat(conditionalSettings)
        .filter(i => (this.account.isAdminUser && i.availableFor.includes("Admin")) || (!this.account.isAdminUser && i.availableFor.includes("User")));
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    account() {
      return this.$store.state.SidebarModule.selectedAccount;
    },
    username() {
      return this.$store.getters.currentUser?.username;
    }
  },
  data() {
    return {
      loading: true,
      CreateUserSettingTemplateDialogOpen: false,
      templates: [],
      menuProps: {
        closeOnClick: false,
        closeOnContentClick: false,
        disableKeys: true,
        openOnClick: false,
        maxHeight: 500
      },
      accountSettings: [
        {
          label: "Access to settingsmenu",
          accountSetting: ["233"],
          availableFor: ["Admin", "User"],
          value: false,
          editable: true
        },
        {
          label: "Access to save value changes",
          accountSetting: ["234"],
          availableFor: ["Admin", "User"],
          value: false,
          editable: true
        },
        {
          label: "Access to manually enter meterreading from vehicle",
          accountSetting: ["235"],
          availableFor: ["Admin", "User"],
          value: false,
          editable: true
        },
        {
          label: "Access to change password",
          accountSetting: ["236"],
          availableFor: ["Admin", "User"],
          value: false,
          editable: true
        },
        {
          label: "Access to add ferry charge",
          accountSetting: ["223"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to add field for roadtoll",
          accountSetting: ["222"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to add parking charge",
          accountSetting: ["224"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to add passenger to the trip",
          accountSetting: ["220"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to add purpose of trip",
          accountSetting: ["219"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to add trailer (Yes/No)",
          accountSetting: ["221"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to add trip comment",
          accountSetting: ["217"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to cancel merged trips",
          accountSetting: ["342"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to change tripdata",
          accountSetting: ["214"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to create new trips manually",
          accountSetting: ["213"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to delete trips",
          accountSetting: ["215"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to merge trips",
          accountSetting: ["216"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to MS Excel export of triplog",
          accountSetting: ["227"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to Notifications for user",
          accountSetting: ["338"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to spesify private / business trips",
          accountSetting: ["218"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to view the triplog on monitor",
          accountSetting: ["226"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Export trips to CSV",
          accountSetting: ["232"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Export trips to MS Excel",
          accountSetting: ["230"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Export trips to XML",
          accountSetting: ["231"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to administrate the triplog",
          accountSetting: ["212"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to display unit in map",
          accountSetting: ["228"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to Show triplog",
          accountSetting: ["225"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to triplog export",
          accountSetting: ["229"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        {
          label: "Access to user areas",
          accountSetting: ["382"],
          availableFor: ["User"],
          value: false,
          editable: true
        },
        //////////////////////// ADMIN
        {
          label: "Access to triplog status",
          accountSetting: ["237"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to Show triplogs",
          accountSetting: ["238"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to show trips",
          accountSetting: ["239"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to Notifications",
          accountSetting: ["245"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to Departments",
          accountSetting: ["246"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to administrate global areas",
          accountSetting: ["286"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Acess to change purpose texts",
          accountSetting: ["324"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to scheduled reports",
          accountSetting: ["325"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to request invoice copies",
          accountSetting: ["328"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to show private miles in distance report",
          accountSetting: ["331"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to Export approved triplogs",
          accountSetting: ["349"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to company settings",
          accountSetting: ["355"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to user activity log",
          accountSetting: ["361"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Override API controlled user administration",
          accountSetting: ["365"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to Work trip",
          accountSetting: ["244"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to display cars in map",
          accountSetting: ["240"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to spotsearch",
          accountSetting: ["352"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to Drivers ID",
          accountSetting: ["247"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to tags",
          accountSetting: ["372"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to usage report based on areas",
          accountSetting: ["290"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to status report",
          accountSetting: ["309"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to time in area report",
          accountSetting: ["326"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to Förmånsbilrapport (Sweden)",
          accountSetting: ["350"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to trip stop report",
          accountSetting: ["363"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to submitted trips report",
          accountSetting: ["358"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to equipment temp report",
          accountSetting: ["381"],
          availableFor: ["Admin"],
          value: false,
          editable: true
        },
        {
          label: "Access to historical drivers",
          accountSetting: ["366"],
          availableFor: ["Admin"],
          value: false,
          editable: true,
        },
        {
          label: "Access to admin handling",
          accountSetting: ["394"],
          availableFor: ["Admin"],
          value: false,
          editable: true,
        }
      ],
      tcoCacheResetState: false
    };
  }
};
</script>

<style></style>
