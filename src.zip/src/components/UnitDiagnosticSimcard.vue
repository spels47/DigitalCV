<template>
  <div class="text-center">
    <v-tooltip bottom>
      <template v-slot:activator="{ on }">
        <v-progress-circular
          v-on="on"
          size="24"
          v-if="loading"
          :value="loadingValue"
          intermediate
          color="blue-grey"
          @click.stop="init(true)"
        ></v-progress-circular>
      </template>
      <span v-if="hidden">
        To conserve resources we will only <br/>
        load unit-diagnostic when there are max 10 row per page <br/>
        However, you can click the circle to make it load anyway 🙂
      </span>
    </v-tooltip>

    <v-tooltip bottom v-if="!loading" color="black lighten-2">
      <template v-slot:activator="{ on }">
        <v-icon v-if="failed" v-on="on" medium color="warning">mdi-alert-circle-outline</v-icon>
        <v-icon v-if="statusSummary === 'Ok'" v-on="on" medium color="success">mdi-check</v-icon>
        <v-icon v-if="statusSummary === 'Error' && statusSummaryIsError" v-on="on" medium color="error">mdi-alert-circle</v-icon>
        <v-icon v-if="statusSummaryIsNotApplicable" v-on="on" medium color="primary">mdi-cancel</v-icon>
      </template>
      <span v-if="failed">Failed to load unit diagnostic 😥</span>
      <span v-if="statusSummary === 'Ok'">Diagnostics shows this unit is in good health:</span>
      <span v-if="statusSummary === 'Error'">Diagnostic shows something is wrong:</span>
      <span v-if="statusSummary === 'NotApplicable'">Diagnostic is not available or not applicable:</span>
      <br/>
      <div v-if="!failed">
        <span v-if="!datasourceId.startsWith('MUG')">
          <span v-if="data.fix === 'Ok'" class="success--text">✔</span>
          <span v-if="data.fix === 'Error'">🔴</span>
          <span v-if="data.fix === 'NotApplicable'">➖</span>
          <span> Solid fix</span><br/>
        </span>
        <span v-if="!datasourceId.startsWith('MUG')">
          <span v-if="data.satellites === 'Ok'" class="success--text">✔</span>
          <span v-if="data.satellites === 'Error'">🔴</span>
          <span v-if="data.satellites === 'NotApplicable'">➖</span>
          <span> GPS satellites in view</span><br/>
        </span>
        <span v-if="!datasourceId.startsWith('MUG')">
          <span v-if="data.power === 'Ok'" class="success--text">✔</span>
          <span v-if="data.power === 'Error'">🔴</span>
          <span v-if="data.power === 'NotApplicable'">➖</span>
          <span> Connected to external power source</span><br/>
        </span>
        <span v-if="datasourceId.startsWith('MUG')">
          <span v-if="data.battery === 'Ok'" class="success--text">✔</span>
          <span v-if="data.battery === 'Error'">🔴</span>
          <span v-if="data.battery === 'NotApplicable'">➖</span>
          <span> Battery status</span><span>{{ data.batteryPercentLeft === null ? '' : ` (${data.batteryPercentLeft}%)` }}</span><br/>
        </span>
        <span v-if="!datasourceId.startsWith('MUG')">
          <span v-if="data.placement === 'Ok'" class="success--text">✔</span>
          <span v-if="data.placement === 'Error'">🔴</span>
          <span v-if="data.placement === 'NotApplicable'">➖</span>
          <span> Placed correctly</span><br/>
        </span>
        <span>
          <span v-if="data.positions === 'Ok'" class="success--text">✔</span>
          <span v-if="data.positions === 'Error'">🔴</span>
          <span v-if="data.positions === 'NotApplicable'">➖</span>
          <span> GPS position received in the last 72 hours</span><br/>
        </span>
      </div>

    </v-tooltip>

  </div>
</template>

<script>
  import axios from "~/axios-client";
  export default {
    name: "UnitDiagnosticSimcard",
    props:{
      simcardId: String,
      datasourceId: String,
      hide: Boolean
    },
    data: function(){
      return {
        loading: true,
        loadingValue: 0,
        failed: false,
        timeoutHolder: null,
        intervalHolder: null,
        data: {},
        hidden: true
      }
    },
    mounted() {
      this.init()
    },
    destroyed() {
      clearTimeout(this.timeoutHolder);
      clearInterval(this.intervalHolder);
    },
    methods: {
      init(forced){
        this.hidden = this.hide // Not allowed to modify props
        if(forced) this.hidden = false
        // We hide the widget if more than 10 items per page to avoid overload
        if (this.hidden) return;

      // The normal loading spinner moved too fast when there is many of them on the same page
      // This gives a more calm loading feel :)
      this.intervalHolder = setInterval(() => {
        if (this.loadingValue === 100) {
          return (this.loadingValue = 0);
        }
        this.loadingValue += 10;
      }, 250);

      // Since users might scroll thru the list we want to wait a little before we call the api
      // so don't do a million requests for no reason
      this.timeoutHolder = setTimeout(async () => {
        await axios.get(`/api/datasource/simcard/${this.simcardId}/${this.datasourceId}/unitDiagnostic`)
          .then(response => {
            this.data = response.data;
          })
          .catch(() => {
            this.failed = true;
          })
          .finally(() => this.loading = false);
      }, 1000);
    }
  },
  computed: {
    statusSummary() {
      return this.data.statusSummary;
    },
    statusSummaryIsError(){
      return this.data.battery == 'Error' || this.data.fix == 'Error' || this.data.placement == 'Error' || this.data.positions == 'Error' || this.data.power == 'Error' || this.data.satellites == 'Error';
    },
    statusSummaryIsNotApplicable(){
      return this.data.battery == 'NotApplicable' && this.data.fix == 'NotApplicable' && this.data.placement == 'NotApplicable' && this.data.positions == 'NotApplicable' && this.data.power == 'NotApplicable' && this.data.satellites == 'NotApplicable';
    }
  }
};
</script>

<style scoped>

</style>
