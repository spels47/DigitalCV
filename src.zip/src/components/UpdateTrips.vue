﻿<template>
  <v-dialog v-model="dialog" persistent max-width="80%">
    <v-main>
      <v-card>
        <v-row no-gutters>
          <v-col cols="3">
            <v-sheet dark class="pa-4 fill-height">
              <v-menu
                v-model="menuDateFrom"
                :close-on-content-click="false"
                :nudge-right="40"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="dateFrom"
                    label="Date From"
                    prepend-icon="mdi-calendar"
                    readonly
                    v-bind="attrs"
                    v-on="on"
                    color="secondary"
                    dark
                  ></v-text-field>
                </template>
                <v-date-picker
                  :first-day-of-week="1"
                  v-model="dateFrom"
                  @input="menuDateFrom = false"
                ></v-date-picker>
              </v-menu>
              <v-menu
                v-model="menuTimeFrom"
                :close-on-content-click="false"
                :nudge-right="40"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="timeFrom"
                    label="Time From"
                    prepend-icon="mdi-clock"
                    readonly
                    v-bind="attrs"
                    v-on="on"
                    color="secondary"
                    dark
                  ></v-text-field>
                </template>
                <v-time-picker
                  v-model="timeFrom"
                  format="24hr"
                  use-seconds
                ></v-time-picker>
              </v-menu>
              <v-menu
                v-model="menuDateTo"
                :close-on-content-click="false"
                :nudge-right="40"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="dateTo"
                    label="Date To"
                    prepend-icon="mdi-calendar"
                    readonly
                    v-bind="attrs"
                    v-on="on"
                    color="secondary"
                    dark
                  ></v-text-field>
                </template>
                <v-date-picker
                  :first-day-of-week="1"
                  v-model="dateTo"
                  @input="menuDateTo = false"
                ></v-date-picker>
              </v-menu>
              <v-menu
                v-model="menuTimeTo"
                :close-on-content-click="false"
                :nudge-right="40"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="timeTo"
                    label="Time to"
                    prepend-icon="mdi-clock"
                    readonly
                    v-bind="attrs"
                    v-on="on"
                    color="secondary"
                    dark
                  ></v-text-field>
                </template>
                <v-time-picker
                  v-model="timeTo"
                  format="24hr"
                  use-seconds
                ></v-time-picker>
              </v-menu>
              <v-select
                v-model="selectedItem"
                :items="items"
                item-text="action"
                item-value="id"
                label="Select Operation"
                return-object
                single-line
                dark
              ></v-select>
              <v-text-field
                v-model="newPurpose"
                label="New purpose"
                hint="New purpose"
                v-if="this.selectedItem && selectedItem.id === 5 || selectedItem.id === 6"
                persistent-hint
                return-object
                single-line
                dark
              ></v-text-field>
            </v-sheet>
          </v-col>

          <v-col cols="9" class="fill-height">
            <v-sheet>
              <v-data-table
                :headers="headers"
                :items="getTripsList"
                :loading="tripsLoading"
                :loading-text="'Fetching trips for this vehicle'"
                :footer-props="{ 'items-per-page-options': (items_per_page = [12, 20, 50, 100]) }"
              >
                <template v-slot:item.tripId="{ item }">
                  <span>{{ item.tripId }}</span><br/>
                  <span class="error--text">{{ item.enabled ? '' : 'Deleted' }}</span>
                </template>

                <template v-slot:item.tripType="{ item }">
                  <v-icon v-tooltippy="item.tripType">{{ item.tripType === "MERGED" ? "mdi-merge" : "mdi-cable-data" }}</v-icon>
                </template>

                <template v-slot:item.driverId="{ item }">
                  <span>{{ item.driverId }}</span><br/>
                  <span>{{ item.driverName }}</span>
                </template>

                <template v-slot:item.startDate="{ item }">
                  <span>{{ item.startDate | ntzDatetimeSeconds }}</span><br/>
                  <span>{{ item.endDate | ntzDatetimeSeconds }}</span>
                </template>

                <template v-slot:item.startAddress="{ item }">
                  <span>{{ item.startAddress }}</span><br/>
                  <span>{{ item.stopAddress }}</span>
                </template>

                <template v-slot:item.objectRegNo="{ item }">
                  <span>{{ item.objectRegNo }}</span><br/>
                  <span>{{ item.private ? 'PRIVATE' : 'CORPORATE' }}</span>
                </template>
              </v-data-table>
              <v-container class="d-flex flex-row align-end">
                <v-row class="d-flex flex-column align-end">
                  <div class="ma-4">
                    <v-btn
                      @click="closeDialog()"
                      text
                    >
                      <span>Cancel</span>
                    </v-btn>
                    <v-btn
                      :disabled="!inputsAreValid || tripsLoading"
                      :loading="updatingTrips"
                      class="elevation-1 ml-2"
                      color="secondary"
                      @click="updateTrips()"
                    >
                      <v-icon>mdi-content-save</v-icon>
                      <span>Update Trips</span>
                    </v-btn>
                  </div>
                </v-row>
              </v-container>
            </v-sheet>
          </v-col>
        </v-row>
      </v-card>
    </v-main>
  </v-dialog>
</template>
<script>
import axios from '~/axios-client';
import util from '~/helpers/util';

export default {
  props: {
    vehicle: Object,
    trigger: Number
  },
  data() {
    return {
      dialog: false,
      tripList: {},
      dateFrom: '',
      dateTo: '',
      timeFrom: '00:00:00',
      timeTo: '23:59:59',
      tripsLoading: false,
      updatingTrips: false,
      menuDateFrom: false,
      menuDateTo: false,
      menuTimeFrom: false,
      menuTimeTo: false,
      selectedItem: {},
      newPurpose: '',
      headers: [
        { text: 'Trip Id', value: 'tripId' },
        { text: 'Trip type id', value: 'tripType', align: "center" },
        { text: 'Driver/driverId', value: 'driverId' },
        { text: 'Start/Stop time', value: 'startDate' },
        { text: 'Start/stop address', value: 'startAddress' },
        { text: 'RegNo/trip type', value: 'objectRegNo' },
        { text: 'Purpose', value: 'comment' }
      ],
      items: [
        { action: 'Set all trips to Private', id: 1 },
        { action: 'Set all trips to Corporate', id: 2 },
        { action: 'Set private/corp on trips based on working hours', id: 3 },
        { action: 'Reset address information on trips', id: 4 },
        { action: 'Set fixed purpose on trips without purpose', id: 5 },
        { action: 'Set fixed purpose on trips with purpose (Override)', id: 6 },
        //{ action: 'Set purpose on trips based on areas (Reset)', id: 7 },
        { action: 'Undelete deleted trips', id: 8 },
        { action: 'Delete trips', id: 9 }
      ],
      _debounceHolder: null
    };
  },
  methods: {
    async getTrips() {
      this.tripsLoading = true;
      try {
        let fullDateFrom = this.dateFrom + ' ' + this.timeFrom;
        let fullDateTo = this.dateTo + ' ' + this.timeTo;
        let res = await axios.get(`/api/trip/searchByVehicle/${this.vehicle.vehicleId}/${fullDateFrom}/${fullDateTo}?suppressTimespanError=true`);
        this.tripList = res.data;
      } catch (ex) {
        this.tripList = {};
        this.$eventBus.$emit('alert', { template: 'api-error' });
      } finally {
        this.tripsLoading = false;
      }
    },
    async getTripsDebounced() {
      this.isLoading = true;
      clearTimeout(this._debounceHolder);
      this._debounceHolder = setTimeout(() => {
        this.getTrips();
      }, 500);

    },
    closeDialog() {
      this.dialog = false;
      this.tripList = {};
      this.tripsLoading = false;
      this.dateFrom = '';
      this.dateTo = '';
    },
    async updateTrips() {
      if (this.updatingTrips)
        return;

      this.updatingTrips = true;
      let fullDateFrom = this.dateFrom + ' ' + this.timeFrom;
      let fullDateTo = this.dateTo + ' ' + this.timeTo;
      switch (this.selectedItem.id) {
        case 1:
          await axios.put(`/api/trip/setTripsPrivate/${fullDateFrom}/${fullDateTo}/${this.vehicle.simcardId}`).catch(() => {
            this.$eventBus.$emit('alert', { template: 'api-error' });
          });
          break;

        case 2:
          await axios.put(`/api/trip/setTripsCorporate/${fullDateFrom}/${fullDateTo}/${this.vehicle.simcardId}`).catch(() => {
            this.$eventBus.$emit('alert', { template: 'api-error' });
          });
          break;

        case 3:
          await axios.put(`/api/trip/resetPrivateCorporateFromWorkingHours/${fullDateFrom}/${fullDateTo}/${this.vehicle.simcardId}`).catch(() => {
            this.$eventBus.$emit('alert', { template: 'api-error' });
          });
          break;

        case 4:
          this.$eventBus.$emit('alert', {text: 'Trip addresses may flicker while resetting address information.', type: 'warning'});
          await axios.put(`/api/trip/resetAddresses/${fullDateFrom}/${fullDateTo}/${this.vehicle.simcardId}`).catch(() => {
            this.$eventBus.$emit('alert', { template: 'api-error' });
          });
          break;

        case 5:
          await axios.put(`/api/trip/setNewPurposeWhereMissing/${fullDateFrom}/${fullDateTo}/${this.vehicle.simcardId}/${this.newPurpose}`).catch(() => {
            this.$eventBus.$emit('alert', { template: 'api-error' });
          });
          break;

        case 6:
          await axios.put(`/api/trip/setNewPurposeForAll/${fullDateFrom}/${fullDateTo}/${this.vehicle.simcardId}/${this.newPurpose}`).catch(() => {
            this.$eventBus.$emit('alert', { template: 'api-error' });
          });
          break;

        case 7:
          await axios.put(`/api/trip/resetPurposesFromArea/${fullDateFrom}/${fullDateTo}/${this.vehicle.simcardId}`).catch(() => {
            this.$eventBus.$emit('alert', { template: 'api-error' });
          });
          break;

        case 8:
          await axios.put(`/api/trip/undeleteTrips/${fullDateFrom}/${fullDateTo}/${this.vehicle.simcardId}`).catch(() => {
            this.$eventBus.$emit('alert', { template: 'api-error' });
          });
          break;

        case 9:
          await axios.put(`/api/trip/deleteTrips/${fullDateFrom}/${fullDateTo}/${this.vehicle.simcardId}`).catch(() => {
            this.$eventBus.$emit('alert', { template: 'api-error' });
          });
          break;
      }
      this.updatingTrips = false;
      await this.getTrips();
    }
  },
  watch: {
    trigger: function () {
      this.dialog = true;
      this.selectedItem = this.items[0];

      let lastTrip = new Date();
      if (this.vehicle.lastTrip && !this.vehicle.lastTrip.startsWith('0')) {
        lastTrip = new Date(this.vehicle.lastTrip);
      }
      this.dateFrom = util.getIsoDateString(util.addDays(lastTrip, -7));
      this.dateTo = util.getIsoDateString(lastTrip);
    },
    dateFrom: function () {
      if (this.dateFrom && this.dateTo) this.getTripsDebounced();
    },
    dateTo: function () {
      if (this.dateFrom && this.dateTo) this.getTripsDebounced();
    },
    timeFrom: function () {
      if (this.timeFrom) this.getTripsDebounced();
    },
    timeTo: function () {
      if (this.timeTo) this.getTripsDebounced();
    }
  },
  computed: {
    getTripsList() {
      return Object.keys(this.tripList).length === 0 ? [] : this.tripList.tripSearchResults;
    },
    inputsAreValid() {
      return this.dateFrom && this.dateTo && this.selectedItem;
    }
  }
};
</script>

<style lang="scss">
.fill-height {
  height: 100%;
  min-height: 800px;
}
</style>
