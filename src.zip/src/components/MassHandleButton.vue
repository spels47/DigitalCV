<template>
  <div class="mr-3">
    <v-tooltip bottom>
      <template v-slot:activator="{ on }">
        <v-btn
          :loading="loading"
          :color="buttonColor"
          class="elevation-1"
          small
          v-on="on"
          fab
          @click="buttonClicked"
        >
          <v-icon>{{ icon }}</v-icon>
        </v-btn>
      </template>
      <span>{{ tooltip }}</span>
    </v-tooltip>
  </div>
</template>

<script>
export default {
  props: ["icon", "tooltip", "buttonColor", "loading"],
  methods: {
    buttonClicked() {
      this.$emit("buttonClicked");
    }
  }
};
</script>

<style></style>
