<template>
  <div class="navbar">
    <v-toolbar color="black" dark>
      <v-tooltip bottom>
        <template v-slot:activator="{ on }">
          <router-link class="mb-9" :to="'/dashboard'">
            <v-img data-cy="abax-image-dashboard" v-on="on" width="100px" style="width: 100px; height: 100px" src="../../assets/logo.svg"></v-img>
          </router-link>
        </template>
        <span>Go to Dashboard</span>
      </v-tooltip>

      <div class="ml-8">
        <MultiSearchBar v-on:CUSTOMER_SELECTED="navigateToCustomer"></MultiSearchBar>
      </div>

      <v-spacer></v-spacer>

      <template v-for="(menuItem, index) in menuItemsComputed">
        <v-menu v-if="menuItem.subItems !== undefined" :key="index" offset-y rounded transition="slide-y-transition">
          <template v-slot:activator="{ on }">
            <v-btn color="white" text v-on="on">
              <v-icon left>{{ menuItem.icon }}</v-icon>
              {{ menuItem.header }}
              <v-icon right>mdi-menu-down</v-icon>
            </v-btn>
          </template>
          <v-list>
            <v-list-item :to="item.route"
              v-for="(item, index) in menuItem.subItems"
              :key="index"
            >
              <v-btn
                class="button-no-hover"
                tile
                depressed
                text
                :ripple="false"
                :retain-focus-on-click="false"
              >
                <v-icon left>{{ item.icon }}</v-icon>
                <span>{{ item.text }}</span>
              </v-btn>
            </v-list-item>
          </v-list>
        </v-menu>

        <v-btn v-else :key="menuItem.route" text color="white" :to="menuItem.route">
          <v-icon left>{{ menuItem.icon }}</v-icon>
          {{ menuItem.text }}
        </v-btn>
      </template>

      <v-list-item-avatar class="cursor-pointer">
        <UserAvatar></UserAvatar>
      </v-list-item-avatar>
    </v-toolbar>
  </div>
</template>

<script>
import MultiSearchBar from "@/components/MultiSearchBar";
import UserAvatar from "@/components/UserAvatar";
export default {
  name: "Navbar",
  components: {
    UserAvatar,
    MultiSearchBar
  },
  data() {
    return {
      drawer: true,
      mini: true,
      menuItems: [
        {
          header: "Development",
          icon: "mdi-developer-board",
          subItems: [
            {
              text: "Release management",
              route: "/release-management",
              icon: "mdi-calendar",
              userRights: ["DEVELOPER_RELEASE_MANAGEMENT"]
            },
            {
              text: "Tools",
              route: "/tools",
              icon: "mdi-toolbox",
              userRights: ["DEVELOPER_ASAP", "ERP_CLEANUP_HELPER", "BCS_ERROR_LIST", "VERSION_MANAGEMENT", "AUTO_SALE", "AREA_IMPORT"],
              requiresAllUserRights: false
            },
            {
              text: "TCO",
              route: "/tco",
              userRights: ["VIEW_TCO"],
              icon: "mdi-handshake",
            },
            {
              text: "Webtext",
              route: "/webtext-view",
              icon: "mdi-format-text-rotation-angle-up",
              userRights: ["WEBTEXT_EDIT"]
            },
            {
              text: "Poeditor",
              route: "/poeditor-view",
              icon: "mdi-translate",
              userRights: ["DEVELOPER_ASAP"]
            },
            {
              text: "Return to tech",
              route: "/return-handling/return-to-tech",
              icon: "mdi-recycle",
              userRights: ["RETURN_TO_TECH"]
            },
            /*
            {
              text: "Jira service desk",
              route: "/jira-explorer",
              icon: "mdi-jira",
              userRights: ["DEVELOPER_ASAP"]
            },
            {
              text: "Jira statistics",
              route: "/jira-statistics",
              icon: "mdi-chart-line",
              userRights: ["DEVELOPER_ASAP"]
            }
             */
          ]
        },
        {
          header: "Logistics",
          icon: "mdi-strategy",
          subItems: [
            {
              text: "Stock status",
              icon: "mdi-warehouse",
              route: "/logistics",
              userRights: ["LOGISTICS_STOCK_STATUS"]
            },
            {
              text: "Unit wash",
              icon: "mdi-wiper-wash",
              route: "/unit-wash",
              userRights: ["UNIT_WASH"]
            },
            {
              text: "Hot-swaps pending",
              icon: "mdi-swap-horizontal-circle",
              route: "/pending-hot-swaps",
              userRights: ["PENDING_HOT_SWAPS_LIST"]
            },
            {
              text: "Jasper list",
              icon: "mdi-cable-data",
              route: "/jasper",
              userRights: ["WORKHUB_JASPER"],
            },
            {
              text: "Return handling",
              icon: "mdi-forklift",
              route: "/return-handling",
              userRights: ["RETURN_HANDLING"],
            },
            {
              text: "Swap prioritization",
              icon: "mdi-cart-check",
              route: "/swap-prioritization",
              userRights: ["SWAP_PRIORITIZATION"],
            },
          ]
        },
        {
          header: "Portfolio",
          icon: "mdi-folder-account",
          route: "/portfolio",
          text: "Portfolio",
          userRights: ["PORTFOLIO_ACCESS", "PORTFOLIO_ADMIN", "PORTFOLIO_KEY_ACCOUNT"],
          requiresAllUserRights: false
        },
        {
          text: "Role management",
          route: "/role-management",
          icon: "mdi-account-key",
          userRights: ["ROLE_MANAGEMENT_VIEW"]
        },
        {
          text: "Workhub",
          route: "/Workhub",
          icon: "mdi-puzzle",
          userRights: [
            "WORKHUB_WELCOME_CALL",
            "WORKHUB_RENEWAL_CALL",
            "WORKHUB_TERMINATION_CALL",
            "WORKHUB_PRODUCTORDERED_CALL",
            "WORKHUB_NEW_SUBSCRIPTIONS",
            "WORKHUB_CHURN_PREDICTION",
            "WORKHUB_SWAP_REQUEST",],
          requiresAllUserRights: false
        },
        {
          route: "/kpi-hub",
          icon: "mdi-rhombus-split",
          text: "KPI Hub",
          userRights:  ["KPI_HUB_CUSTOMER", "KPI_HUB_PORTFOLIO", "KPI_HUB_WORKLISTS", "KPI_HUB_PORTFOLIO_WORKLISTS"],
          requiresAllUserRights: false
        },
        {
          route: "/myswaps",
          icon: "mdi-swap-horizontal-circle",
          text: "My Swaps",
          userRights:  ["DATASOURCE_SWAP"],
          requiresAllUserRights: true
        }
      ],
      menuItemsComputed: []
    };
  },
  async mounted() {
    await this.$store.dispatch("waitForRolesLoaded");
    this.menuItemsComputed = this.computeMenuItems()
  },
  methods: {
    navigateToCustomer(customer) {
      if (!customer || customer.id.toString() === this.$route.params.id) return;
      this.$router.push({ name: "customer", params: { id: customer.id } });
    },
    computeMenuItems() {
      const hasAccessToItem = (item) => {
        if (!item.userRights) return true;

        return item.requiresAllUserRights
          ? item.userRights?.every(right => this.roles[right])
          : item.userRights?.some(right => this.roles[right]);
      }

      let allowedMenuItems = [];
      this.menuItems.forEach(item => {
        if (!item.subItems) {
          if (hasAccessToItem(item))
            allowedMenuItems.push(item);
          return;
        }

        item.subItems = item.subItems.filter(i => hasAccessToItem(i));
        if (item.subItems.length === 0)
          return;

        if (item.subItems.length === 1) {
          const { text, icon, route } = item.subItems[0];
          item.text = text;
          item.icon = icon;
          item.route = route;
          item.subItems = undefined;
        }
        allowedMenuItems.push(item);
      });

      return allowedMenuItems;
    },
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
  },
};
</script>

<style scoped>
.button-no-hover::before {
  display: none;
}

.cursor-pointer {
  cursor: pointer;
}
</style>
