<template>
  <div class="text-center">
    <v-tooltip bottom>
      <template v-slot:activator="{ on }">
        <v-progress-circular
          v-on="on"
          size="24"
          v-if="loading"
          :value="loadingValue"
          intermediate
          color="blue-grey"
          @click.stop="init(true)"
        ></v-progress-circular>
      </template>
      <span v-if="hidden">
        To conserve resources we will only <br/>
        load unit-diagnostic when there are max 10 row per page <br/>
        However, you can click the circle to make it load anyway 🙂
      </span>
    </v-tooltip>
    <v-tooltip bottom v-if="!loading">
      <template v-slot:activator="{ on }">
        <v-icon v-if="failed" v-on="on" medium color="warning">mdi-alert-circle-outline</v-icon>
        <v-icon v-if="lastPositionDateString && lastPositionIsNewerThan72HoursAgo" v-on="on" medium color="success">mdi-check</v-icon>
        <v-icon v-if="lastPositionDateString && !lastPositionIsNewerThan72HoursAgo" v-on="on" medium color="error">mdi-alert-circle</v-icon>
        <v-icon v-if="!lastPositionDateString" v-on="on" medium color="primary">mdi-cancel</v-icon>
      </template>
      <span v-if="failed">Failed to load unit diagnostic 😥</span>
      <span v-if="lastPositionDateString">Last position: {{lastPositionDateString | datetimeSeconds}}</span>
      <span v-if="!lastPositionDateString">Last position not found</span>
    </v-tooltip>

  </div>
</template>

<script>
import axios from "~/axios-client";
export default {
  name: "UnitDiagnosticOem",
  props:{
    simcardId: String,
    hide: Boolean
  },
  data: function(){
    return {
      loading: true,
      loadingValue: 0,
      failed: false,
      timeoutHolder: null,
      intervalHolder: null,
      lastPositionDateString: null,
      lastPositionIsNewerThan72HoursAgo: false,
      hidden: true
    }
  },
  mounted() {
    this.init()
  },
  destroyed() {
    clearTimeout(this.timeoutHolder);
    clearInterval(this.intervalHolder);
  },
  methods: {
    init(forced){
      this.hidden = this.hide // Not allowed to modify props
      if(forced) this.hidden = false

      // We hide the widget if more than 10 items per page to avoid overload
      if(this.hidden) return

      // The normal loading spinner moved too fast when there is many of them on the same page
      // This gives a more calm loading feel :)
      this.intervalHolder = setInterval(() => {
        if (this.loadingValue === 100) {
          return (this.loadingValue = 0)
        }
        this.loadingValue += 10
      }, 250)

      // Since users might scroll thru the list we want to wait a little before we call the api
      // so don't do a million requests for no reason
      this.timeoutHolder = setTimeout(() => {
        axios.get(`/api/datasource/position/last/${this.simcardId}/1`)
          .then(response => {
            if(response?.data?.length > 0){
              this.lastPositionDateString = response.data[0].timestamp
            }
            if(this.lastPositionDateString){
              let time72HoursAgo = Date.now() - (72 * 60 * 60 * 1000)
              let timeLastPosition = (new Date(this.lastPositionDateString)).getTime()
              this.lastPositionIsNewerThan72HoursAgo = timeLastPosition > time72HoursAgo
            }
          })
          .catch(() => {
            this.failed = true
          })
          .finally(() => this.loading = false)
      }, 1000)
    }
  }
}
</script>

<style scoped>

</style>
