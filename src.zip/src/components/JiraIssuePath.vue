<template>
  <span>
     <a class="secondary--text hover" style="text-decoration: none;" href="https://jira.planetabax.com/projects/ASAPSD/" target="_blank">ASAPSD</a> /
     Jira issue /
     <a class="secondary--text hover" style="text-decoration: none;" :href="getIssueLink" target="_blank">{{currentJiraIssue.key}}</a>
  </span>
</template>

<script>
export default {
  computed: {
    getIssueLink() {
      return `https://jira.planetabax.com/browse/${this.currentJiraIssue.key}`;
    },
    currentJiraIssue() {
      return this.$store.state.JiraModule.currentJiraIssue;
    },
  }
};
</script>

<style scoped>
</style>
