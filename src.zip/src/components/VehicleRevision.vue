<template>
  <v-dialog v-model="dialog" persistent max-width="80%">
    <v-main>
      <v-card class="dialog-height-fixed">
        <v-row no-gutters>
          <v-col cols="3">
            <v-sheet dark class="pa-4 dialog-height-fixed">
              <v-menu
                v-model="menu1"
                :close-on-content-click="false"
                :nudge-right="40"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="dateFrom"
                    label="Date From"
                    prepend-icon="mdi-calendar"
                    readonly
                    v-bind="attrs"
                    v-on="on"
                    color="secondary"
                    dark
                  ></v-text-field>
                </template>
                <v-date-picker
                  :first-day-of-week="1"
                  v-model="dateFrom"
                  @input="menu1 = false"
                ></v-date-picker>
              </v-menu>
              <v-menu
                v-model="menuTimeFrom"
                :close-on-content-click="false"
                :nudge-right="40"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="timeFrom"
                    label="Time From"
                    prepend-icon="mdi-clock"
                    readonly
                    v-bind="attrs"
                    v-on="on"
                    color="secondary"
                    dark
                  ></v-text-field>
                </template>
                <v-time-picker
                  v-model="timeFrom"
                  format="24hr"
                  use-seconds
                ></v-time-picker>
              </v-menu>
              <v-menu
                v-model="menu2"
                :close-on-content-click="false"
                :nudge-right="40"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="dateTo"
                    label="Date To"
                    prepend-icon="mdi-calendar"
                    readonly
                    v-bind="attrs"
                    v-on="on"
                    color="secondary"
                    dark
                  ></v-text-field>
                </template>
                <v-date-picker
                  :first-day-of-week="1"
                  v-model="dateTo"
                  @input="menu2 = false"
                ></v-date-picker>
              </v-menu>
              <v-menu
                v-model="menuTimeTo"
                :close-on-content-click="false"
                :nudge-right="40"
                transition="scale-transition"
                offset-y
                min-width="auto"
              >
                <template v-slot:activator="{ on, attrs }">
                  <v-text-field
                    v-model="timeTo"
                    label="Time to"
                    prepend-icon="mdi-clock"
                    readonly
                    v-bind="attrs"
                    v-on="on"
                    color="secondary"
                    dark
                  ></v-text-field>
                </template>
                <v-time-picker
                  v-model="timeTo"
                  format="24hr"
                  use-seconds
                ></v-time-picker>
              </v-menu>
              <v-sheet dark class="pl-4 pr-4">
                <h3>Revise</h3>
                <v-checkbox v-model="reviseVehicleType" label="Vehicle type"></v-checkbox>
                <v-checkbox v-model="reviseRegistrationNumber" label="License plate"></v-checkbox>
                <v-checkbox v-model="reviseDepartment" label="Department"></v-checkbox>
                <v-checkbox v-model="reviseDriver" label="Driver"></v-checkbox>
                <v-select v-show="reviseDriver" v-model="selectedDriver" :items="driverList" item-text="name" item-value="id" menu-props="auto" label="Select Driver" clearable prepend-icon="mdi-seatbelt" single-line></v-select>
              </v-sheet>

              <v-divider></v-divider>
              <v-sheet dark class="pa-4">
                <h3>Current vehicle</h3>
                <v-text-field hint="Vehicle type" v-model="vehicle.objectType" persistent-hint disabled></v-text-field>
                <v-text-field hint="Current Reg.No" v-model="vehicle.licensePlate" persistent-hint disabled></v-text-field>
                <v-text-field hint="Current driver"  v-model="vehicle.currentDriverName" persistent-hint disabled></v-text-field>
                <v-text-field hint="Current department" v-model="vehicle.departmentName" persistent-hint disabled></v-text-field>
              </v-sheet>
            </v-sheet>
          </v-col>

          <v-col cols="9" class="d-flex flex-column justify-space-between">
            <v-data-table
              :items="revisions"
              :headers="headers"
              :sort-by.sync="sortBy"
              :sort-desc.sync="sortDesc"
              :footer-props="{ 'items-per-page-options': (items_per_page = [12]) }"
            >
              <template v-slot:item="{ item }">
                <tr @click="rowClick(item)">
                  <td>
                    <v-tooltip bottom>
                      <template v-slot:activator="{ on }">
                          <v-icon :color="item.isHistory ? 'primary' : 'secondary'" v-on="on">{{item.isHistory ? 'mdi-alpha-h-circle' : 'mdi-alpha-a-circle'}}</v-icon>
                      </template>
                      <span v-if="!item.isHistory">The currently active setting set</span>
                      <span v-if="item.isHistory">Historic setting set</span>
                    </v-tooltip>
                  </td>
                  <td>
                    <span>{{ item.versionDate | ntzDatetime }}</span>
                  </td>
                  <td>
                    <span>{{ item.lastTripDate | ntzDatetime }}</span>
                  </td>
                  <td>
                    <span>{{ item.registrationNumber }}</span><br/>
                    <span>{{ item.vehicleType }}</span>
                  </td>
                  <td>
                    <span>{{ item.driverName }}</span><br/>
                    <span>{{ item.customerPath }}</span>
                  </td>
                </tr>
              </template>
            </v-data-table>
            <v-container class="d-flex flex-row align-end">
              <v-row class="d-flex flex-column align-end">
                <div class="ma-4">
                  <v-btn @click="closeDialog()" text>
                    <span>Cancel</span>
                  </v-btn>
                  <v-btn class="elevation-1" color="secondary" @click="revision()" :disabled="!inputsAreValid || isLoading">
                    <v-icon>mdi-content-save</v-icon>
                    <span>Revision</span>
                  </v-btn>
                  <v-progress-circular v-show="isLoading" indeterminate color="secondary"> </v-progress-circular>
                </div>
              </v-row>
            </v-container>
          </v-col>
        </v-row>
      </v-card>
    </v-main>
  </v-dialog>
</template>
<script>
import axios from '~/axios-client'
import util from "@/helpers/util"

export default {
  props: {
    vehicle: Object,
    trigger: Number,
  },
  data() {
    return {
      dialog: false,
      revisions: [],
      dateFrom: '',
      dateTo: '',
      timeFrom: '00:00:00',
      timeTo: '23:59:59',
      isLoading: false,
      menu1: false,
      menuTimeFrom: false,
      menuTimeTo: false,
      menu2: false,
      selectedItem: {action: 'Vehicle type', id: 1},
      sortBy: 'versionDate',
      sortDesc: true,
      headers: [
        {text: '', value: 'isHistory'},
        {text: 'Version date', value: 'versionDate'},
        {text: 'Last trip', value: 'lastTripDate'},
        {text: 'RegNo / Vehicle type', value: 'vehicleType'},
        {text: 'Driver / Department', value: 'driverName'},
      ],
      items: [
        {action: 'Vehicle type', id: 1, revisionTypeEnum: 'VehicleType'},
        {action: 'Reg.No', id: 2, revisionTypeEnum: 'RegistrationNumber'},
        {action: 'Department', id: 3, revisionTypeEnum: 'Department'},
        {action: 'Driver', id: 4, revisionTypeEnum: 'Driver'}
      ],
      reviseVehicleType: false,
      reviseRegistrationNumber: false,
      reviseDepartment: false,
      reviseDriver: false,
      driverList: [],
      loadingDrivers: false,
      mainOffice: {},
      selectedDriver: null
    }
  },
  async mounted() {
  },
  methods: {
    async getVehicleSettings() {
      this.isLoading = true
      try{
        let res = await axios.get(`/api/vehicle/vehicleSettings/${this.vehicle.vehicleId}`)
        this.revisions = res.data
      } catch (ex){
        this.$eventBus.$emit('alert', {template: 'api-error'})
      } finally {
        this.isLoading = false
      }
    },
    async getDriverList(){
      this.loadingDrivers = true;
      try{
        let mainOffice = await axios.get(`/api/customer/mainoffice/${this.vehicle.departmentId}`);
        this.mainOffice = mainOffice.data;
        let result = await axios.get(`/api/customer/accounts/${this.mainOffice.id}`);
        let drivers = result.data.data.filter(user => !user.isAdmin && user.accountActive && !user.hasLeftCompany)
        drivers.sort((a, b) => (a.name > b.name) ? 1 : -1)
        this.driverList = drivers;
      }
      catch(e){
        this.$eventBus.$emit('alert', {text: 'Failed to get driver list from API 😯', icon: 'mdi-alert-circle', type: 'error'});
      }
      finally{
        this.loadingDrivers = false;
      }
    },
    async revision() {
      this.isLoading = true

      let revisionRequest = {
        reviseDepartment: this.reviseDepartment,
        reviseDriver: this.reviseDriver,
        driverId: this.selectedDriver,
        reviseRegistrationNumber: this.reviseRegistrationNumber,
        reviseVehicleType: this.reviseVehicleType,
      }

      try{
        let fullDateFrom = this.dateFrom + ' ' + this.timeFrom;
        let fullDateTo = this.dateTo + ' ' + this.timeTo;
        await axios.put(`/api/vehicle/vehicleSettings/reviseVehicle/${this.vehicle.vehicleId}/${fullDateFrom}/${fullDateTo}`, revisionRequest)
      } catch (ex){
        this.$eventBus.$emit('alert', {template: 'api-error'})
      } finally {
        await this.getVehicleSettings()
        this.isLoading = false
      }
    },
    closeDialog() {
      this.dialog = false
      this.revisions = []
      this.selectedItem = {}
      this.isLoading = false
      this.dateFrom = ''
      this.dateTo = ''

    },
    async updateTrips() {
      this.isLoading = true
      this.closeDialog()
    },
    rowClick(row){
      let xx = new Date(row.versionDate)
      this.dateFrom = util.getIsoDateString(xx)
      this.timeFrom = util.getTimeString(xx)
    }
  },
  watch: {
    trigger: async function () {
      this.dialog = true
      this.selectedItem = this.items[0]

      await this.getVehicleSettings()
      await this.getDriverList();

      let versionDates = this.revisions.map(x => new Date(x.versionDate))
      let minDate = new Date(Math.min.apply(null, versionDates))
      minDate.setHours(12) // Timezone support
      this.dateFrom = util.getIsoDateString(minDate)
      this.dateTo = util.getIsoDateString(new Date())
    },

  },
  computed: {
    inputsAreValid(){
      return this.dateFrom && this.dateTo && this.selectedItem && this.timeFrom && this.timeTo && (this.reviseVehicleType || this.reviseRegistrationNumber || this.reviseDepartment || this.reviseDriver)
    }
  }
}
</script>

<style lang="scss" scoped>
.fill-height{
  height: 100%;
}
.dialog-height-fixed{
  height: 935px;
}
</style>
