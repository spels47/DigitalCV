<template>
  <div class="impersonation-bar">
    <v-toolbar color="yellow" class="d-flex justify-space-around">
      <span>
        <b>Caution!</b> You are impersonating:
        <b>{{impersonationSubjectName}}</b>&nbsp;
        <button id="backstage-btn" @click="goToTriplog">Go to Triplog</button>&nbsp;
        <button id="backstage-btn" @click="stopImpersonation">Stop impersonating</button>
      </span>
    </v-toolbar>
  </div>
</template>

<script>
import { mapGetters, mapActions } from "vuex";
import { getTriplogConfig } from "~/config/config-service";

let configTriplog = getTriplogConfig();

export default {
  computed: {
    ...mapGetters("oidcStore", ["signOutOidc"]),
    ...mapGetters(["impersonationSubjectName"])
  },
  methods: {
    ...mapActions("oidcStore", ["authenticateOidc"]),
    goToTriplog: function() {
      window.open(configTriplog.clientUrl, "_self");
    },
    stopImpersonation: function() {
      this.authenticateOidc({
        options: {
          acr_values: `abax:impersonate:end`
        },
        redirectPath: "/impersonate"
      });
    }
  },
   // mounted () {
   //   window.open(configTriplog.clientUrl, "_self");
   // }
};
</script>

<style>
#backstage-btn {
  background-color: black;
  color: white;
  padding: 10px;
}
</style>
