<template>
  <div class="text-center">
    <v-tooltip bottom>
      <template v-slot:activator="{ on }">
        <v-progress-circular
          v-on="on"
          size="24"
          v-if="loading"
          :value="loadingValue"
          intermediate
          color="blue-grey"
          @click.stop="init(true)"
        ></v-progress-circular>
      </template>
      <span v-if="hidden">
        To conserve resources we will only <br/>
        load unit-diagnostic when there are max 10 row per page <br/>
        However, you can click the circle to make it load anyway 🙂
      </span>
    </v-tooltip>

    <v-tooltip bottom v-if="!loading && data">
      <template v-slot:activator="{ on }">
        <v-icon v-if="failed" v-on="on" medium color="warning">mdi-alert-circle-outline</v-icon>
        <v-icon v-if="data.voltage >= 3" v-on="on" medium color="success">mdi-battery</v-icon>
        <v-icon v-if="data.voltage < 3 && data.voltage >= 2.5" v-on="on" medium color="success">mdi-battery-80</v-icon>
        <v-icon v-if="data.voltage < 2.5 && data.voltage >= 2" v-on="on" medium color="warning">mdi-battery-50</v-icon>
        <v-icon v-if="data.voltage && data.voltage < 2" v-on="on" medium color="error">mdi-battery-10</v-icon>
        <v-icon v-if="!data.voltage" v-on="on" medium color="primary">mdi-cancel</v-icon>
      </template>
      <span v-if="failed">Failed to load unit diagnostic 😥</span>
      <span v-if="data.voltage >= 3">Battery full: {{data.voltage.toFixed(2)}}v</span>
      <span v-if="data.voltage < 3 && data.voltage >= 2.5">Good voltage: {{data.voltage.toFixed(2)}}v</span>
      <span v-if="data.voltage < 2.5 && data.voltage >= 2">Voltage getting low: {{data.voltage.toFixed(2)}}v</span>
      <span v-if="data.voltage && data.voltage < 2">Low voltage: {{data.voltage.toFixed(2)}}v</span>
      <span v-if="!data.voltage">No voltage data available</span>
    </v-tooltip>

  </div>
</template>

<script>
  import axios from "~/axios-client";
  export default {
    name: "UnitDiagnosticMini",
    props:{
      serialNumber: String,
      hide: Boolean
    },
    data: function(){
      return {
        loading: true,
        loadingValue: 0,
        failed: false,
        timeoutHolder: null,
        intervalHolder: null,
        data: {},
        hidden: true
      }
    },
    mounted() {
      this.init()
    },
    destroyed() {
      clearTimeout(this.timeoutHolder);
      clearInterval(this.intervalHolder);
    },
    methods: {
      init(forced){
        this.hidden = this.hide // Not allowed to modify props
        if(forced) this.hidden = false

        // We hide the widget if more than 10 items per page to avoid overload
        if(this.hidden) return

        // The normal loading spinner moved too fast when there is many of them on the same page
        // This gives a more calm loading feel :)
        this.intervalHolder = setInterval(() => {
          if (this.loadingValue === 100) {
            return (this.loadingValue = 0)
          }
          this.loadingValue += 10
        }, 250)

        // Since users might scroll thru the list we want to wait a little before we call the api
        // so don't do a million requests for no reason
        this.timeoutHolder = setTimeout(() => {
          axios.get(`/api/datasource/mini/${this.serialNumber}/unitDiagnostic`)
            .then(response => {
              this.data = response.data
            })
            .catch(() => {
              this.failed = true
            })
            .finally(() => this.loading = false)
        }, 1000)
      }
    }
  }
</script>

<style scoped>

</style>
