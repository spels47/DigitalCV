﻿<template>
  <v-select
      return-object
      clearable
      label="Assigned to"
      item-text="displayName"
      item-value="key"
      :loading="fetchingAvailableAssignees"
      v-model="selectedAssignee"
      :items="availableAssignees"
  >
    <template v-slot:selection="{ item }">
      <v-avatar v-if="item.avatarUrls" size="22px">
        <img :src="item.avatarUrls.the32X32" />
      </v-avatar>
      <span :class="item.avatarUrls ? 'ml-2' : ''" v-html="item.displayName"></span>
    </template>

    <template v-slot:item="{ item }">
      <v-list-item-avatar v-if="item.avatarUrls" size="22">
        <img width="20" height="20" :src="item.avatarUrls.the32X32"/>
      </v-list-item-avatar>
      <v-list-item-content :class="item.avatarUrls ? 'ml-3' : ''">
        <v-list-item-title v-html="item.displayName"></v-list-item-title>
      </v-list-item-content>
    </template>
  </v-select>
</template>
<script>
import axios from "@/axios-client";

export default {
  name: 'SelectJiraAssignee',
  props: ["useDefaultAssignee", "clearAssignee"],
  data() {
    return {
      fetchingAvailableAssignees: false,
      availableAssignees: [],
      selectedAssignee: {},
    }
  },
  async mounted() {
    this.fetchingAvailableAssignees = true;
    try {
      const { data } = await axios.get("/api/jira/assignees");
      this.availableAssignees = data;

      const assigneeToSet = this.availableAssignees.find(assignee => assignee.emailAddress === this.userEmail) ?? { key: "backstage-api" };
      await this.$store.dispatch("setJiraAssigneeToUse", assigneeToSet);
      if (assigneeToSet.key === "backstage-api") {
        this.$eventBus.$emit("alert", {text: "Not ASAPSD assignee. Acting behalf of Backstage-API", type: "warning"});
      }

      this.selectedAssignee = assigneeToSet;
    } finally {
      this.availableAssignees.splice(3, 0, { divider: true });
      this.fetchingAvailableAssignees = false;
    }
  },
  watch: {
    selectedAssignee(value) {
      this.$emit("selectedAssignee", value);
    },
    clearAssignee() {
      this.selectedAssignee = {};
    },
    useDefaultAssignee() {
     this.selectedAssignee = this.jiraUserToUse;
    }
  },
  computed: {
    userEmail() {
      return this.$store.getters.currentUsername === "bjarnebanan@abax.no" ? "backstage@abax.no" : this.$store.getters.currentUsername;
    },
    jiraUserToUse() {
      return this.$store.state.JiraModule.jiraUserToUse;
    },
  }
}
</script>
<style scoped>

/*.row-pointer >>> tbody tr :hover {*/
/*  cursor: pointer;*/
/*}*/

</style>
