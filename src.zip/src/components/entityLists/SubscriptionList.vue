<template>
  <v-sheet>
    <EntityListTable
      v-if="items && headers"
      :items="items"
      :headers="headers"
      :loading="loading"
      :sortDesc="false"
      loading-text="Loading... Please wait"
      @rowClicked="rowClicked"
    >
      <template v-slot:table-header>
        <MassHandleButton
          :icon="'mdi-microsoft-excel'"
          :tooltip="'Export to Excel'"
          :loading="exportingToExcel"
          :buttonColor="'success'"
          @buttonClicked="exportSubscriptionsToExcel"
          data-cy="export-excel-subscriptions"
        ></MassHandleButton>
      </template>
      <template v-slot:filter-buttons>
        <v-menu offset-y :close-on-content-click="false">
          <template v-slot:activator="{ on }">
            <v-icon class="filter-icon" :color="anyFilterChecked ? 'marked' : ''" v-on="on">
              mdi-filter
            </v-icon>
          </template>
          <v-list>
            <v-list-item>
              <v-list-item-title>
                <v-checkbox class="ml-2" dense label="Show terminated subscriptions" v-model="filter_ShowInactiveSubscription"></v-checkbox>
              </v-list-item-title>
            </v-list-item>
            <v-list-item>
              <v-list-item-title>
                <v-checkbox dense class="ml-2" label="Show MINI's" v-model="filter_ShowMiniDatasources"></v-checkbox>
              </v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
      </template>
    </EntityListTable>
  </v-sheet>
</template>

<script>
import EntityListTable from "./EntityListTable";
import MassHandleButton from "@/components/MassHandleButton";
import { exportToExcelFile } from "@/helpers/excel-util";

export default {
  components: { MassHandleButton, EntityListTable },
  props: ["customerId", "customer"],
  data() {
    return {
      loading: false,
      exportingToExcel: false,
      filter_ShowInactiveSubscription: false,
      filter_ShowMiniDatasources: false
    };
  },
  async mounted() {
    await this.$store.dispatch("retrieveSubscriptionList", this.customerId);
  },
  methods: {
    exportSubscriptionsToExcel() {
      let data = [];
      this.exportingToExcel = true;

      this.items.forEach(subscription => {
        data.push({
          SubscriptionNumber: subscription.contractNumber,
          MainItem: subscription.serialNumber,
          StartDate: subscription.createdDate,
          RenewalDate: subscription.renewalDate,
          TerminationDate: subscription.terminationDate
        });
      });

      const fileName = this.customer.name + " subscriptions.xlsx";
      const sheetName = "All subscriptions";
      exportToExcelFile(fileName, sheetName, data).finally(() => this.exportingToExcel = false);
    },
    rowClicked(row) {
      this.$emit("rowClicked", row);
    },
    filter(value, search, item) {
      if (!this.filter_ShowInactiveSubscription && item?.hasExpired) return false;
      if (!this.filter_ShowMiniDatasources && (item?.serialNumber?.startsWith("MUM") || item?.serialNumber?.startsWith("AM"))) return false;

      return true;
    }
  },
  computed: {
    items() {
      return this.$store.state.EntityModule.subscriptionList.items;
    },
    headers() {
      let headers = this.$store.state.EntityModule.subscriptionList.headers;
      if (headers.length > 0) {
        headers[0].filter = this.filter;
      }
      return headers;
    },
    anyFilterChecked() {
      return this.filter_ShowInactiveSubscription || this.filter_ShowMiniDatasources;
    }
  }
};
</script>

<style scoped>
.filter-icon:focus::after {
  opacity: 0;
}
</style>
