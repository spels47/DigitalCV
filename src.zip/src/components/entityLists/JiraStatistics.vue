<template>
  <v-container fluid class="py-0 d-flex">
    <v-row class="half">
      <v-col class="half">
        <IssuesCreatedChart />
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <ASAPSDAllCustomerIssues />
      </v-col>
      <v-col cols="6">
        <FrequentResolutionsChart />
        <ResolvedPerAssigneeChart />
      </v-col>
      <v-col cols="6">
        <ASAPResolvedNotCustomerIssuesChart />
        <ASAPResolvedCustomerIssuesChart />
      </v-col>
    </v-row>
  </v-container>
</template>
<script>

import IssuesCreatedChart from "@/components/widgets/JiraCharts/IssuesCreatedChart";
import FrequentResolutionsChart from "@/components/widgets/JiraCharts/FrequentResolutionsChart";
import ResolvedPerAssigneeChart from "@/components/widgets/JiraCharts/ResolvedPerAssigneeChart";
import ASAPResolvedNotCustomerIssuesChart from "@/components/widgets/JiraCharts/ASAPResolvedNotCustomerIssuesChart";
import ASAPResolvedCustomerIssuesChart from "@/components/widgets/JiraCharts/ASAPResolvedCustomerIssuesChart";
import ASAPSDAllCustomerIssues from "@/components/widgets/JiraCharts/ASAPSDAllCustomerIssues";
export default {
  components: {ASAPSDAllCustomerIssues, ASAPResolvedNotCustomerIssuesChart, ASAPResolvedCustomerIssuesChart, ResolvedPerAssigneeChart, IssuesCreatedChart, FrequentResolutionsChart},
  data() {
    return {}
  },
};
</script>

<style scoped>
.half {
  height: 100%;
  width: 50%;
}
</style>
