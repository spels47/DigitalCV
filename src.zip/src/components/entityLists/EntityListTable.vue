<template>
  <v-card>
    <v-card-title>
      <slot name="table-header"></slot>
      <v-spacer></v-spacer>
      <slot name="filter-buttons"></slot>
      <v-text-field class="mt-0 pt-0" v-model="search" append-icon="mdi-magnify" label="Search" single-line hide-details></v-text-field>
    </v-card-title>
    <v-data-table
      :headers="headers"
      :items="items"
      :search="search"
      :custom-filter="customFilter"
      :items-per-page.sync="itemsPerPage"
      :page.sync="page"
      :footer-props="{ 'items-per-page-options': [10, 20, 100] }"
      :multi-sort="shouldMultiSort"
      :sort-by="sortBy"
      :sort-desc="sortDescmodel"
      :item-class="getCustomItemClass"
      @click:row="rowClicked"
      :show-select="shouldShowSelect"
      v-model="itemsSelected"
      :loading="dataBeingRetrieved"
      loading-text="Loading... Please wait"
    >
      <template v-slot:item.serialNumber="{ item }">
        <span>{{ item.serialNumber }}</span>
        <v-icon class="ml-2" color="red" v-if="item.pendingHotSwap" v-tooltippy="`Pending hot-swap <br/> ${item.pendingHotSwap.newSerialNumber} will replace ${item.pendingHotSwap.oldSerialNumber}`">
          mdi-swap-horizontal-circle
        </v-icon>

        <v-icon class="ml-2" color="success" v-if="item.pendingSwap" v-tooltippy="'This unit has a pending swap on it'">
          mdi-swap-horizontal-circle
        </v-icon>
      </template>
      <template v-slot:item.assignedAsset="{ item }">
        <span v-if="item.assignedAsset" class="secondary--text hover" @click.stop="assignedAssetClicked(item)">
          <span>{{ item.assignedAsset.vehicleAssignedLicensePlate }}</span>
          <span v-if="item.assignedAsset.vehicleAssignedLicensePlate && item.assignedAsset.vehicleAssignedAlias"> - </span>
          <span>{{ item.assignedAsset.vehicleAssignedAlias }}</span>
        </span>
      </template>
      <template v-slot:item.isAdmin="{ item }">
        <v-tooltip bottom>
          <template v-slot:activator="{ on }">
            <v-icon v-on="on" v-if="item.isAdmin">mdi-shield-account</v-icon>
            <v-icon v-on="on" v-if="!item.isAdmin">mdi-account</v-icon>
          </template>
          <span>{{ item.isAdmin ? "AdminAccount" : "Account" }} {{ item.accountActive ? "" : " - inactive" }}</span>
        </v-tooltip>
      </template>
      <template v-slot:item.actions="{ item }">
        <v-tooltip bottom>
          <template v-slot:activator="{ on }">
            <v-icon v-on="on" medium color="purple" @click.stop="resetSingleUserPassword(item)" v-if="roles.USER_RESET">mdi-lock-reset</v-icon>
          </template>
          <span>Reset password</span>
        </v-tooltip>
        <v-tooltip bottom>
          <template v-slot:activator="{ on }">
            <v-icon v-on="on" medium class="mx-4" color="secondary" @click.stop="userImpersonate(item)" v-if="roles.USER_IMPERSONATE && item.accountActive">
              mdi-login-variant
            </v-icon>
          </template>
          <span>Impersonate</span>
        </v-tooltip>
      </template>
      <template v-slot:item.currentDriverName="{ item }">
        <span v-if="item.currentDriverId" @click.stop="currentDriverClicked(item)">
          <span class="secondary--text hover">{{ item.currentDriverUserName }} - {{ item.currentDriverName }}</span>
        </span>
      </template>
      <template v-slot:item.departmentLevel="{ item }">
        <template v-if="item.department">
          <v-tooltip bottom>
            <template v-slot:activator="{ on }">
              <v-chip
                v-on="on"
                small
                outlined
                class="accent--text font-weight-bold"
              >
                {{ item.departmentLevel - customer.customerLevel }}
              </v-chip>
              <span> - {{ item.department }}</span>
            </template>
            <span>Department level</span>
          </v-tooltip>
        </template>
      </template>

      <template v-slot:item.connectedAssetAlias="{ item }">
        <span @click.stop="connectedAssetClicked(item)">
<!--          <span :class="{'hover' : item.connectedAssetAlias, 'secondary&#45;&#45;text' : item.connectedAssetAlias}">{{ item.connectedAssetAlias ? item.connectedAssetAlias : "N/A" }}</span>-->
          <span :class="{'hover' : getConnectedAssetAliasString(item), 'secondary--text' : getConnectedAssetAliasString(item)}">{{ getConnectedAssetAliasString(item) ? getConnectedAssetAliasString(item) : "N/A" }}</span>
        </span>
      </template>
      <template v-slot:item.timestamp="{ item }">
        <span v-if="item.timestamp">
          <span>{{ convertDateToCustomerCountry(item.timestamp) }}</span>
        </span>
      </template>
      <template v-slot:item.lastContact="{ item }">
        <span v-if="item.lastContact !== '--'">{{ convertDateToCustomerCountry(item.lastContact) | ntzDate }}</span>
        <span v-else>{{ item.lastContact }}</span>
      </template>
      <template v-slot:item.timestamp="{ item }">
        <span v-if="item.timestamp">
          <span>{{ convertDateToCustomerCountry(item.timestamp) }}</span>
        </span>
      </template>
      <template v-slot:item.primaryDataSourceId="{ item }">
        <span v-if="item.primaryDataSourceId" @click.stop="currentDataSourceClicked(item)">
          <span class="secondary--text hover">{{ item.primaryDataSourceId }}</span>
        </span>
      </template>
      <template v-slot:item.configuration="{ item }">
        <FeatureConfiguration :features="item.features" simplified></FeatureConfiguration>
      </template>
      <template v-slot:item.unitDiagnostic="{ item }">
        <UnitDiagnosticSimcard v-if="item.type === 'simcard'" :hide="itemsPerPage > 10 || itemsPerPage <= 0" :simcard-id="item.simcardId" :datasource-id="item.id"></UnitDiagnosticSimcard>
        <UnitDiagnosticMini v-if="item.type === 'mini'" :hide="itemsPerPage > 10 || itemsPerPage <= 0" :serial-number="item.id"></UnitDiagnosticMini>
        <UnitDiagnosticOem v-if="item.type === 'oem'" :hide="itemsPerPage > 10 || itemsPerPage <= 0" :simcard-id="item.id"></UnitDiagnosticOem>
      </template>

      <template v-slot:item.createdAt="{ item }">
        <span>{{ convertDateToCustomerCountry(item.createdAt, false) }}</span>
      </template>
      <template v-slot:item.closedAt="{ item }">
        <span v-if="item.ticketStatusName !== 'Active'">{{ convertDateToCustomerCountry(item.closedAt, false) }}</span>
      </template>

      <template v-slot:item.title="{ item }">
        <WrappedTextWithTooltip
          :text="item.title"
        ></WrappedTextWithTooltip>
      </template>

      <template v-slot:item.categoryFullName="{ item }">
        <v-chip
          outlined
          small
        >
          <WrappedTextWithTooltip
            :text="item.categoryFullName"
            :max-length="45"
          ></WrappedTextWithTooltip>
        </v-chip>
      </template>

      <template v-slot:item.priorityName="{ item }">
        <v-chip
          v-if="determineTicketPriority(item) !== 'N/D'"
          outlined
          small
          :color="determineTicketPriorityColor(item)"
        >
          <v-icon
            left
            small
            v-text="determineTicketPriorityIcon(item)"
          ></v-icon>

          {{ determineTicketPriority(item) }}
        </v-chip>
      </template>

      <template v-slot:item.ticketStatusName="{ item }">
        <v-chip
          outlined
          small
          :color="item.ticketStatusName !== 'Active' ? '' : 'success darken-1'"
        >
          <v-icon
            left
            small
            v-text="item.ticketStatusName === 'Active' ? 'mdi-check' : 'mdi-archive'"
          ></v-icon>

          {{ item.ticketStatusName }}
        </v-chip>
      </template>

    </v-data-table>
  </v-card>
</template>

<script>
import UnitDiagnosticSimcard from "../UnitDiagnosticSimcard";
import UnitDiagnosticMini from "../UnitDiagnosticMini";
import FeatureConfiguration from "../FeatureConfiguration";
import UnitDiagnosticOem from "@/components/UnitDiagnosticOem";
import WrappedTextWithTooltip from "@/components/text/WrappedTextWithTooltip";

export default {
  props: ["items", "headers", "sortDesc", "customer", "SortBy", "multiSort", "showSelect"],
  components: { WrappedTextWithTooltip, UnitDiagnosticOem, UnitDiagnosticSimcard, UnitDiagnosticMini, FeatureConfiguration },
  data() {
    return {
      search: "",
      page: 1,
      itemsSelected: [],
      itemsPerPage: 10,
      sortDescmodel: this.sortDesc ? this.sortDesc : false
    };
  },
  methods: {
    determineTicketPriority({ priorityName }) {
      return priorityName === "" ? "N/D" : priorityName;
    },
    determineTicketPriorityIcon({ priorityName }) {
      switch (priorityName) {
        case "Low":
          return "mdi-priority-low";
        case "High":
          return "mdi-priority-high";
        case "Critical":
          return "mdi-exclamation"
        default:
          return ""
      }
    },
    determineTicketPriorityColor({ priorityName }) {
      switch (priorityName) {
        case "Low":
          return "secondary darken-1";
        case "":
        case "Normal":
          return "";
        case "High":
        case "Critical":
          return "error darken-1"
      }
    },
    convertDateToCustomerCountry(date, includeSeconds = true) {
      return this.$utils.getDateTimeByCountry(date, this.customer.country, includeSeconds);
    },
    rowClicked(row) {
      this.$emit("rowClicked", row);
    },
    resetSingleUserPassword(item) {
      if (this.roles.USER_RESET) {
        this.$emit("resetSingleUserPassword", item.id);
      }
    },
    userImpersonate(item) {
      if (this.roles.USER_IMPERSONATE) {
        this.$emit("userImpersonate", item);
      }
    },
    assignedAssetClicked(item) {
      this.$emit("assignedAssetClicked", item);
    },
    currentDriverClicked(item) {
      this.$emit("currentDriverClicked", item);
    },
    connectedAssetClicked(item) {
      this.$emit("connectedAssetClicked", item);
    },
    currentDataSourceClicked(item) {
      this.$emit("currentDataSourceClicked", item);
    },
    customFilter(value, search, item) {
      search = search
        ?.toString()
        ?.trim()
        ?.toLowerCase();

      if (!search)
        return;

      if (search?.includes(",")) {
        const toSearch = search
          .split(",")
          .filter(x => x !== ""); // remove trailing commas

        return toSearch.some(searchString => Object.values(item).some(value => value?.toString()?.toLowerCase().includes(searchString)));
      }

      return Object.keys(item).some(propName => {
        return item[propName]
          ?.toString()
          .toLowerCase()
          .includes(search);
      });
    },
    getCustomItemClass(item) {
      if (item.accountActive != null) {
        if (!item.accountActive) return "tablered";
      }
      if (item.hasLeftCompany) {
        return "tablered";
      }
      if (item.isMounted != null) {
        if (!item.isMounted) return "tablered";
      }
      if (item.hasExpired != null) {
        if (item.hasExpired) return "tablered";
      }

      if (item.terminationDate !== "") {
        const now = new Date();
        const terminationDate = new Date(item.terminationDate);
        if (terminationDate > now) {
          return this.darkMode ? "yellow darken-3" : "yellow lighten-4";
        }
      }

      if (item.subscriptionExpired != null) {
        if (item?.id?.startsWith("DLG")) return "tablered";
        if (item.subscriptionExpired) return "tablered";
      }
    },
    getConnectedAssetAliasString(item) {
      if (item.connectedAssetAlias) return item.connectedAssetAlias;
      if (item.connectedAssetId) return `(${item.connectedAssetId})`;     // Vehicle with Alias set to empty string
      if (item.features?.includes('3000')) return `(${item.simcardId})`;  // EQ with Alias set to empty string
      return null;
    }
  },
  watch: {
    itemsSelected() {
      this.$emit("itemSelected", this.itemsSelected);
    },
    search() {
      this.page = 1;
    }
  },
  computed: {
    shouldShowSelect() {
      return this.showSelect ?? true;
    },
    shouldMultiSort() {
      return this.multiSort ?? true;
    },
    darkMode() {
      return this.$store.getters.darkMode;
    },
    dataBeingRetrieved() {
      return this.$store.state.EntityModule.dataBeingRetrieved || this.$store.state.CustomerTicketsModule.fetchingTickets;
    },
    sortBy() {
      if (this.SortBy) return this.SortBy;
      else if (this.headers.length > 0) return this.headers[0].value;
      return "";
    },
    roles() {
      return this.$store.state.currentUserRoles;
    }
  }
};
</script>

<style>
.hover {
  cursor: pointer;
}
</style>
