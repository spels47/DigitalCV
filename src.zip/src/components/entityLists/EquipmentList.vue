<template>
  <v-sheet>
    <MoveEntityDialog
      v-if="displayMoveEquipmentDialog"
      :mainOfficeId="customerId"
      :multipleDepartmentSourcesIds="departmentIds"
      :title="'Select Department to move ' + itemsSelected.length + ' equipment to'"
      @closeDialog="displayMoveEquipmentDialog = false"
      :loading="loading"
      @confirm="moveEquipment">
    </MoveEntityDialog>
    <v-dialog v-model="displayMoveEquipmentProgressDialog" persistent max-width="490">
      <v-card>
        <v-progress-linear indeterminate :active="moveEquipmentDialogLoading" color="primary"></v-progress-linear>
        <v-card-title class="headline">
          <span v-if="moveEquipmentDialogLoading">Moves in progress...</span>
          <span v-if="!moveEquipmentDialogLoading">Moves processed</span>
        </v-card-title>
        <v-card-text>Moving {{ itemsSelected.length }} equipment</v-card-text>
        <v-card-text v-if="moveEquipmentDialogProcessedCount">Processed: {{ moveEquipmentDialogProcessedCount }} equipment</v-card-text>
        <v-card-text v-if="moveEquipmentDialogErrorsCount">Failed: {{moveEquipmentDialogErrorsCount}} Equipment: {{moveEquipmentDialogErrors}} </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="primary" text @click="displayMoveEquipmentProgressDialog = false" :disabled="moveEquipmentDialogLoading">Close</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <EntityListTable
      v-if="items && headers"
      :items="items"
      :headers="headers"
      :loading="loading"
      :SortBy="['alias']"
      :sortDesc="false"
      loading-text="Loading... Please wait"
      @itemSelected="itemSelected"
      @rowClicked="rowClicked"
      @currentDataSourceClicked="currentDataSourceClicked"
    >
      <template v-slot:table-header>
        <MassHandleButton
          :icon="'mdi-microsoft-excel'"
          :tooltip="'Export to Excel'"
          :loading="exportingToExcel"
          :buttonColor="'success'"
          @buttonClicked="exportEquipmentToExcel"
          data-cy="export-excel-equipment"
        ></MassHandleButton>
        <v-fade-transition>
          <MassHandleButton v-if="roles.ASSET_MOVE && itemsSelected.length > 0" :icon="'$vuetify.icons.assetMoveIcon'" :tooltip="'Move asset'" :buttonColor="'secondary'" @buttonClicked="displayMoveEquipmentDialog = true"></MassHandleButton>
        </v-fade-transition>
      </template>
      <template v-slot:filter-buttons>
        <v-menu offset-y :close-on-content-click="false">
          <template v-slot:activator="{ on }">
            <v-icon class="filter-icon" :color="anyFilterChecked ? 'marked' : ''" v-on="on">
              mdi-filter
            </v-icon>
          </template>
          <v-list>
            <v-list-item>
              <v-list-item-title>
                <v-checkbox dense class="ma-0" label="Show inactive equipment" v-model="filter_ShowInactiveEquipment"> </v-checkbox>
              </v-list-item-title>
            </v-list-item>
            <v-list-item>
              <v-list-item-title>
                <v-checkbox dense class="ma-0" label="Show Active equipment" v-model="filter_ShowActiveEquipment"></v-checkbox>
              </v-list-item-title>
            </v-list-item>
            <v-list-item>
              <v-list-item-title>
                <v-checkbox dense class="ma-0" label="Show MINI's" v-model="filter_ShowMini"></v-checkbox>
              </v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
      </template>
    </EntityListTable>
  </v-sheet>
</template>

<script>
import axios from "~/axios-client";
import { exportToExcelFile } from "@/helpers/excel-util";
import EntityListTable from "./EntityListTable";
import MassHandleButton from "../MassHandleButton";
import MoveEntityDialog from "../widgets/dialogs/MoveEntityDialog";

export default {
  components: { EntityListTable, MassHandleButton, MoveEntityDialog },
  props: ["customerId", "customer"],
  data() {
    return {
      itemsSelected: [],
      departmentIds: [],
      loading: false,
      exportingToExcel: false,
      displayMoveEquipmentDialog: false,
      displayMoveEquipmentProgressDialog: false,
      moveEquipmentDialogLoading: false,
      moveEquipmentDialogProcessedCount: 0,
      moveEquipmentDialogErrorsCount: 0,
      moveEquipmentDialogErrors: [],
      filter_ShowInactiveEquipment: false,
      filter_ShowActiveEquipment: true,
      filter_ShowMini: false
    };
  },
  mounted() {
    this.$store.dispatch("retrieveEquipmentList", this.customerId);
  },
  methods: {
    exportEquipmentToExcel() {
      const sortByIsActive = (a, b) => {
        return a.IsActive > b.IsActive ? -1 : 1;
      }

      let data = [];
      this.exportingToExcel = true;

      this.items.forEach(equipment => {
        data.push({
          AssetId: equipment.assetId,
          LicensePlate: equipment.simcardLicensePlateNumber,
          Alias: equipment.alias,
          PrimaryConnectedDataSource: equipment.primaryDataSourceId,
          "SN/Pin/Vin": equipment.customerReference,
          Department: equipment.departmentName,
          IsActive: equipment.isMounted ? "Yes" : "No",
        });
      });

      const fileName = this.customer.name + " equipment.xlsx";
      const sheetName = "Equipment";
      exportToExcelFile(fileName, sheetName, data.sort(sortByIsActive)).finally(() => this.exportingToExcel = false);
    },
    rowClicked(row) {
      this.$emit("rowClicked", row);
    },
    currentDataSourceClicked(item) {
      this.$emit("currentDataSourceClicked", item);
    },
    itemSelected(items) {
      this.itemsSelected = items;
      this.departmentIds = items.map(x => x.departmentId);
    },
    async moveEquipment(moveConnected, destinationDepartmentId) {
      this.moveEquipmentDialogProcessedCount = 0;
      this.moveEquipmentDialogErrorsCount = 0;
      this.moveEquipmentDialogErrors = [];
      this.displayMoveEquipmentDialog = false;
      this.displayMoveEquipmentProgressDialog = true;
      this.moveEquipmentDialogLoading = true
      let moveToDepartmentHierarchyRes = await axios.get(`/api/customer/hierarchy/${destinationDepartmentId}/main-office-and-down`)

      for (const equipment of this.itemsSelected) {
        try {
          await axios.post(`/api/asset/${equipment.assetId}/move/${destinationDepartmentId}`)
          await this.$store.dispatch("audit", { source: "vehicle", entityId: equipment.id, message: "Move equipment to department", oldValue: equipment.departmentId, newValue: destinationDepartmentId })
          equipment.departmentId = destinationDepartmentId
          equipment.departmentPath = moveToDepartmentHierarchyRes.data.departmentPath
          equipment.departmentName = moveToDepartmentHierarchyRes.data.name
        } catch (ex) {
          this.moveEquipmentDialogErrors.push(equipment.id);
          this.moveEquipmentDialogErrorsCount++;
        }
        this.moveEquipmentDialogProcessedCount++
      }

      if(this.moveEquipmentDialogErrors.length > 0){
        console.log('Errors:', this.moveEquipmentDialogErrors)
        this.$eventBus.$emit("alert", {text: `Failed to move ${this.moveEquipmentDialogErrors.length} equipment`, type: "error"});
      }

      this.moveEquipmentDialogLoading = false;
    },
    filter(value, search, item) {
      if (!this.filter_ShowInactiveEquipment && !item?.isMounted) return false;
      if (!this.filter_ShowActiveEquipment && item?.isMounted) return false;
      if (!this.filter_ShowMini && item?.unitTypeId === "MINI") return false;
      return true;
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
    items() {
      return this.$store.state.EntityModule.equipmentList.items;
    },
    headers() {
      var headers = this.$store.state.EntityModule.equipmentList.headers;
      if (headers.length > 0) {
        headers[0].filter = this.filter;
      }
      return headers;
    },
    anyFilterChecked() {
      return this.filter_ShowInactiveEquipment || this.filter_ShowMini;
    }
  }
};
</script>

<style scoped>
.filter-icon:focus::after {
  opacity: 0;
}
</style>
