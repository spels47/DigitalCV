<template>
  <v-card elevation="0">
    <v-card-subtitle>
      <v-data-table
        dense
        :loading="loading"
        :items-per-page="itemsPerPage"
        class="row-pointer"
        :headers="headers"
        :items="items"
        @click:row="issueClicked"
        loading-text="Fetching pinned issues. Please wait..."
        no-data-text="You have no pinned issues. You can add one by clicking the pin icon below 'quick actions'."
        :footer-props="{ 'items-per-page-options': [3] }"
      >
        <template v-slot:top>
          <v-switch v-if="items.length > 0" v-model="settings_autoUnpinResolvedIssues" class="ml-auto" label="Auto unpin resolved issues"></v-switch>
        </template>
        <template v-slot:item.key="{ item }">
          <v-icon dense class="mb-1" size="18">mdi-key-variant</v-icon>
          <span class="secondary--text ml-2">{{ item.issue.key }}</span>
        </template>

        <template v-slot:item.fields.summary="{ item }">
          <v-icon dense class="mb-1" size="18">mdi-text-box</v-icon>
          <span class="ml-1">
          {{ item.issue.fields.summary.length > 30 ? item.issue.fields.summary.substring(0, 30) + "..." : item.issue.fields.summary}}
        </span>
        </template>

        <template v-slot:item.fields.jiraIssuePriority.name="{ item }">
          <v-img :src="item.issue.fields.jiraIssuePriority.iconUrl"  style="float: left;" height="18" width="18"></v-img>
          <span class="ml-2">{{item.issue.fields.jiraIssuePriority.name}}</span>
        </template>

        <template v-slot:item.fields.issueType.name="{ item }">
        <span>
              <v-img :src="getIssueTypeImageUrl(item.issue)" class="ml-2" style="float: left;" height="18" width="18"></v-img>
              <span class="ml-1">{{item.issue.fields.issueType.name}}</span>
            </span>
        </template>

        <template v-slot:item.actions="{ item }">
          <v-tooltip bottom>
            <template v-slot:activator="{ on }">
              <v-icon v-on="on" class="mx-1" @click.stop="unpinIssue(item.issue)">mdi-pin</v-icon>
            </template>
            <span>Unpin</span>
          </v-tooltip>
        </template>

        <template v-slot:item.notifications="{ item }">
          <div class="d-flex">
            <v-tooltip bottom v-if="hasNewComments(item)">
              <template v-slot:activator="{ on }">
                <v-icon :class="!determineIfUpdated(item.issue) ? 'mx-4' : ''" @click.stop="goToComments(item.issue)" v-on="on">mdi-comment-outline</v-icon>
              </template>
              <span>New comment(s)</span>
            </v-tooltip>
            <v-tooltip bottom v-if="determineIfUpdated(item.issue)">
              <template v-slot:activator="{ on }">
                <v-icon :class="!hasNewComments(item) ? 'mx-4' : 'ml-2'" v-on="on">mdi-update</v-icon>
              </template>
              <span>{{getUpdateTimeSince(item.issue)}}</span>
            </v-tooltip>
          </div>
        </template>
      </v-data-table>
    </v-card-subtitle>
  </v-card>
</template>

<script>
import util from "@/helpers/util";

export default {
  data() {
    return {
      itemsPerPage: 4,
      intervalId: 0,
      settings_autoUnpinResolvedIssues: JSON.parse(localStorage.getItem("settings_auto_unpin_resolved_issues")) ?? true,
      headers: [
        {
          text: "Key",
          value: "key",
          sortable: false
        },
        {
          text: "Summary",
          value: "fields.summary",
          sortable: false
        },
        {
          text: "Type",
          value: "fields.issueType.name",
          sortable: false
        },
        {
          text: "Priority",
          value: "fields.priority.name",
          sortable: false
        },
        {
          text: "Notifications",
          value: "notifications",
          sortable: false
        },
        {
          text: "Action",
          value: "actions",
          sortable: false
        },
      ],
    };
  },
  watch: {
    settings_autoUnpinResolvedIssues(value) {
      localStorage.setItem("settings_auto_unpin_resolved_issues", value);
    },
    async jiraUserToUse(value) {
      await this.$store.dispatch("getPinnedIssues", { userKey: value.key });
    }
  },
  async mounted() {
    this.intervalId = setInterval(async () => {
      await this.$store.dispatch("getPinnedIssues", { userKey: this.jiraUserToUse.key, silent: true });
    }, 15 * 1000);
  },
  destroyed() {
    clearInterval(this.intervalId);
  },
  methods: {
    goToComments(issue) {
      this.$emit("issueClicked", { issue, action: "comments" });
    },
    issueClicked(item) {
      const { issue } = item;
      this.$emit("issueClicked", { issue, action: "" });
    },
    hasNewComments(issue) {
      let dates = [];
      this.items.forEach(x => {
        if (x.issue.key !== issue.issue.key) return;
        x.comments.forEach(comment => {
          if (comment.author.key === this.jiraUserToUse.key) return; // the comment was added outside backstage
          if (comment.body.endsWith(`[~${this.jiraUserToUse.key}]`)) return; // means that the comment was added through backstage and therefore have a mention at the end

          dates.push(new Date(comment.updated));
        })
      })
      return dates.length > 0 ? dates.some(date => Math.floor((new Date() - date) / 1000) <= 300) : false;
    },
    determineIfUpdated(issue) {
       // check if anything was updated less than 5 minutes ago
      return Math.floor((new Date() - new Date(issue.fields.updated)) / 1000) <= 300;
    },
    getUpdateTimeSince(issue) {
      return `Updated ${util.getTimeSince(new Date(issue.fields.updated))} ago`;
    },
    async unpinIssue(issue) {
      this.items = this.items.filter(item => item.issue.key !== issue.key);
      await this.$store.dispatch("unpinIssue", { user: { key: this.jiraUserToUse.key }, issue: issue });
      await this.$store.dispatch("getPinnedIssues", { userKey: this.jiraUserToUse.key, silent: true });
    },
    getIssueTypeImageUrl(item) {
      return item.fields?.issueType?.iconUrl ?? "None";
    },
  },
  computed: {
    jiraUserToUse() {
      return this.$store.state.JiraModule.jiraUserToUse;
    },
    loading() {
      return this.$store.state.JiraModule.retrievingPinnedIssues;
    },
    items: {
      get() {
        const issues = this.$store.state.JiraModule.pinnedIssues;
        const resolvedIssues = issues.filter(issue => issue.issue.fields.resolution?.name === "Done"); // issue is done & resolved

        if (this.settings_autoUnpinResolvedIssues) {
          resolvedIssues.forEach((issue => {
            this.$store.dispatch("unpinIssue", { user: { key: this.jiraUserToUse.key }, issue: issue.issue });
          }))
        }

        return issues;
      },
      set(value) {
        this.$store.state.JiraModule.pinnedIssues = value;
      }
    },
    getViewingAssignee() {
      return this.$store.state.JiraModule.chosenAssignee;
    },
  }
};
</script>

<style scoped>
/*.row-pointer >>> tbody tr :hover {*/
/*  cursor: pointer;*/
/*}*/

.filter-icon:focus::after {
  opacity: 0;
}
</style>
