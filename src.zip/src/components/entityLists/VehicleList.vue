<template>
  <v-sheet>
    <MoveEntityDialog
      v-if="displayMoveVehicleDialog"
      :mainOfficeId="customer.mainOfficeId"
      :multipleDepartmentSourcesIds="departmentIds"
      :title="'Select Department to move ' + itemsSelected.length + ' vehicles to'"
      :checkboxLabel="'Also move users connected to vehicles'"
      :sortDesc="false"
      :loading="loading"
      @closeDialog="displayMoveVehicleDialog = false"
      @confirm="moveVehicles"
    ></MoveEntityDialog>
    <v-dialog v-model="displayMoveVehicleProgressDialog" persistent max-width="490">
      <v-card>
        <v-progress-linear indeterminate :active="moveVehicleDialogLoading" color="primary"></v-progress-linear>
        <v-card-title class="headline">
          <span v-if="moveVehicleDialogLoading">Moves in progress...</span>
          <span v-if="!moveVehicleDialogLoading">Moves processed</span>
        </v-card-title>
        <v-card-text>Moving {{ itemsSelected.length }} vehicle(s)</v-card-text>
        <v-card-text v-if="moveVehicleDialogProcessedCount">Processed: {{ moveVehicleDialogProcessedCount }} vehicle(s)</v-card-text>
        <v-card-text v-if="moveVehicleDialogErrorsCount">Failed: {{moveVehicleDialogErrorsCount}} VehicleId's: {{moveVehicleDialogErrors}} </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="primary" text @click="displayMoveVehicleProgressDialog = false" :disabled="moveVehicleDialogLoading">Close</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <v-dialog v-model="displayChangeVehicleTypeDialog" persistent max-width="490">
      <v-progress-linear indeterminate :active="changeVehicleTypeDialogLoading" color="primary"></v-progress-linear>
      <v-card>
        <v-card-title class="headline">Change Vehicle Type</v-card-title>
        <v-card-text>Change vehicle type on {{ itemsSelected.length }} vehicle(s)</v-card-text>
        <v-card-text v-if="changeVehicleTypeDialogProcessedCount">Processed: {{ changeVehicleTypeDialogProcessedCount }} vehicle(s)</v-card-text>
        <v-card-text v-if="changeVehicleTypeDialogErrorsCount">Failed: {{changeVehicleTypeDialogErrorsCount}} VehicleId's: {{changeVehicleTypeDialogErrors}} </v-card-text>
        <v-card-text>
          <v-select :items="getVehicleTypesByCountry()" label="Vehicle type" v-model="newVehicleType"></v-select>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="primary" text @click="cancelChangeVehicleTypeDialog" :disabled="changeVehicleTypeDialogLoading">Close</v-btn>
          <v-btn color="secondary" text @click="massChangeVehicleType" :disabled="changeVehicleTypeDialogLoading">Process</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>
    <EntityListTable
      v-if="items && headers"
      :items="items"
      :headers="headers"
      :loading="loading"
      loading-text="Loading... Please wait"
      :SortBy="['licensePlate']"
      @itemSelected="itemSelected"
      @rowClicked="rowClicked"
      @currentDriverClicked="currentDriverClicked"
      @currentDataSourceClicked="currentDataSourceClicked"
    >
      <template v-slot:table-header>
        <MassHandleButton
          :icon="'mdi-microsoft-excel'"
          :tooltip="'Export to Excel'"
          :loading="exportingToExcel"
          :buttonColor="'success'"
          @buttonClicked="exportVehiclesToExcel"
          data-cy="export-excel-vehicles"
        ></MassHandleButton>
        <v-fade-transition>
          <MassHandleButton v-if="roles.ASSET_MOVE && itemsSelected.length > 0" :icon="'$vuetify.icons.assetMoveIcon'" :tooltip="'Move asset'" :buttonColor="'secondary'" @buttonClicked="displayMoveVehicleDialog = true"></MassHandleButton>
        </v-fade-transition>
        <v-fade-transition>
          <MassHandleButton v-if="roles.USER_EDIT && itemsSelected.length > 0" :icon="'mdi-car-cog'" :tooltip="'Change vehicle type'" :buttonColor="'warning'" @buttonClicked="displayChangeVehicleTypeDialog = true"></MassHandleButton>
        </v-fade-transition>
      </template>
      <template v-slot:filter-buttons>
        <v-menu offset-y :close-on-content-click="false">
          <template v-slot:activator="{ on }">
            <v-icon class="filter-icon" :color="anyFilterChecked ? 'marked' : ''" v-on="on">
              mdi-filter
            </v-icon>
          </template>
          <v-list>
            <v-list-item>
              <v-list-item-title>
                <v-checkbox dense label="Show inactive vehicles" v-model="filter_ShowInactiveVehicles"> </v-checkbox>
                <v-checkbox dense label="Show active vehicles" v-model="filter_ShowActiveVehicles"> </v-checkbox>
                <v-checkbox dense label="Show vehicles with driver" v-model="filter_ShowVehiclesWithDriver"> </v-checkbox>
                <v-checkbox dense label="Show vehicles without driver" v-model="filter_ShowVehiclesWithoutDriver"> </v-checkbox>
              </v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
      </template>
    </EntityListTable>
  </v-sheet>
</template>

<script>
import axios from "~/axios-client";
import { exportToExcelFile } from "@/helpers/excel-util";
import EntityListTable from "./EntityListTable";
import MassHandleButton from "../MassHandleButton";
import MoveEntityDialog from "../widgets/dialogs/MoveEntityDialog";

export default {
  components: { EntityListTable, MassHandleButton, MoveEntityDialog },
  props: ["customerId", "customer"],
  data() {
    return {
      itemsSelected: [],
      departmentIds: [],
      loading: false,
      exportingToExcel: false,
      newVehicleType: "PRIVATE",
      displayMoveVehicleDialog: false,
      displayMoveVehicleProgressDialog: false,
      moveVehicleDialogLoading: false,
      moveVehicleDialogProcessedCount: 0,
      moveVehicleDialogErrorsCount: 0,
      moveVehicleDialogErrors: [],
      displayChangeVehicleTypeDialog: false,
      changeVehicleTypeDialogLoading: false,
      changeVehicleTypeDialogProcessedCount: 0,
      changeVehicleTypeDialogErrorsCount: 0,
      changeVehicleTypeDialogErrors: [],
      filter_ShowInactiveVehicles: false,
      filter_ShowActiveVehicles: true,
      filter_ShowVehiclesWithDriver: true,
      filter_ShowVehiclesWithoutDriver: true
    };
  },
  mounted() {
    this.$store.dispatch("retrieveVehicles", this.customerId);
  },
  methods: {
    exportVehiclesToExcel() {
      let data = [];
      this.exportingToExcel = true;

      this.items.forEach(vehicle => {
        data.push({
          VehicleId: vehicle.id,
          LicensePlate: vehicle.licensePlate,
          Alias: vehicle.alias,
          IsActive: vehicle.isMounted ? "Yes" : "No",
          VehicleType: vehicle.objectType,
          Department: vehicle.departmentName,
          CurrentDriverId: vehicle.currentDriverId,
          ConnectedDriver: vehicle.currentDriverName,
          PrimaryConnectedDataSource: vehicle.primaryDataSourceId
        });
      });

      const fileName = this.customer.name + " vehicles.xlsx";
      const sheetName = "All vehicles";
      exportToExcelFile(fileName, sheetName, data).finally(() => this.exportingToExcel = false);
    },
    getVehicleTypesByCountry() {
      switch (this.customer.country) {
        case "DK":
          return [{ text: "PRIVATE" }, { text: "CORPORATE" }];
        case "NO":
          return [{ text: "PRIVATE" }, { text: "CORPORATE" }, { text: "CORPORATE2" }];
        case "FI":
          return [{ text: "PRIVATE" }, { text: "CORPORATE" }, { text: "COMPANY" }];
        case "GB":
          return [{ text: "PRIVATE" }, { text: "CORPORATE" }, { text: "COMPANY" }];
        case "NL":
          return [{ text: "PRIVATE" }, { text: "CORPORATE" }, { text: "COMPANY" }];
        case "SE":
          return [{ text: "PRIVATE" }, { text: "CORPORATE" }, { text: "COMPANY" }];
        default:
          return [];
      }
    },
    rowClicked(row) {
      this.$emit("rowClicked", row);
    },
    currentDataSourceClicked(item) {
      this.$emit("currentDataSourceClicked", item);
    },
    currentDriverClicked(item) {
      this.$emit("currentDriverClicked", item);
    },
    itemSelected(items) {
      this.itemsSelected = items;
      this.departmentIds = items.map(x => x.departmentId);
    },
    async moveVehicles(moveConnected, destinationDepartmentId) {
      this.moveVehicleDialogProcessedCount = 0;
      this.moveVehicleDialogErrorsCount = 0;
      this.moveVehicleDialogErrors = [];

      this.displayMoveVehicleDialog = false;
      this.displayMoveVehicleProgressDialog = true;
      this.moveVehicleDialogLoading = true
      let moveToDepartmentHierarchyRes = await axios.get(`/api/customer/hierarchy/${destinationDepartmentId}/main-office-and-down`)

      for (const vehicle of this.itemsSelected) {
        try {
          await axios.post(`/api/asset/${vehicle.assetId}/move/${destinationDepartmentId}`)
          await this.$store.dispatch("audit", { source: "vehicle", entityId: vehicle.id, message: "Move vehicle to department", oldValue: vehicle.departmentId, newValue: destinationDepartmentId })
          if(moveConnected && vehicle.currentDriverId) {
            await axios.put("/api/user/moveUser", { SelectedId: [vehicle.currentDriverId], DestinationId: destinationDepartmentId })
            await this.$store.dispatch("audit", { source: "vehicle", entityId: vehicle.id, message: "Move connected user to department", oldValue: vehicle.departmentId, newValue: destinationDepartmentId });
          }
          vehicle.departmentId = destinationDepartmentId
          vehicle.departmentPath = moveToDepartmentHierarchyRes.data.departmentPath
          vehicle.departmentName = moveToDepartmentHierarchyRes.data.name
        } catch (ex) {
          this.moveVehicleDialogErrors.push(vehicle.vehicleId);
          this.moveVehicleDialogErrorsCount++;
        }
        this.moveVehicleDialogProcessedCount++
      }

      if(this.moveVehicleDialogErrors.length > 0){
        console.log('Errors:', this.moveVehicleDialogErrors)
        this.$eventBus.$emit("alert", {text: `Failed to move ${this.moveVehicleDialogErrors.length} vehicles / connected users`, type: "error"});
      }

      this.moveVehicleDialogLoading = false;
    },
    async massChangeVehicleType() {
      this.changeVehicleTypeDialogProcessedCount = 0;
      this.changeVehicleTypeDialogErrorsCount = 0;
      this.changeVehicleTypeDialogErrors = [];
      this.changeVehicleTypeDialogLoading = true

      this.changeVehicleTypeDialogErrors = []
      for (const vehicle of this.itemsSelected) {
        let assetUpdateModel = {
          AssetId: vehicle.assetId,
          AktorId: vehicle.departmentId,
          Key: 'VehicleLegalType',
          Value: this.newVehicleType,
        }
        try {
          await axios.put(`/api/vehicle`, assetUpdateModel)
          await this.$store.dispatch("audit", {source: "vehicle", entityId: vehicle.vehicleId, message: `Update vehicle field: VehicleLegalType (objectType)`, oldValue: vehicle.objectType, newValue: this.newVehicleType});
          vehicle.objectType = this.newVehicleType
        } catch (ex) {
          this.changeVehicleTypeDialogErrorsCount++;
          this.changeVehicleTypeDialogErrors.push(vehicle.vehicleId)
        }
        this.changeVehicleTypeDialogProcessedCount++
      }
      if(this.changeVehicleTypeDialogErrors.length > 0){
        this.$eventBus.$emit("alert", {text: `Failed to update ${this.changeVehicleTypeDialogErrors.length} vehicle legal types`, type: "error"});
        this.changeVehicleTypeDialogLoading = false
      } else {
        this.$eventBus.$emit("alert", {text: `Updated legal type on ${this.itemsSelected.length} vehicles`, type: "success"});
        this.displayChangeVehicleTypeDialog = false
        this.changeVehicleTypeDialogLoading = false
      }
    },
    cancelChangeVehicleTypeDialog(){
      this.changeVehicleTypeDialogErrorsCount = 0;
      this.changeVehicleTypeDialogProcessedCount = 0;
      this.changeVehicleTypeDialogErrors = [];
      this.changeVehicleTypeDialogLoading = false;
      this.displayChangeVehicleTypeDialog = false;
    },
    filter(value, search, item) {
      if (!this.filter_ShowInactiveVehicles && !item?.isMounted) return false;
      if (!this.filter_ShowActiveVehicles && item?.isMounted) return false;
      if (!this.filter_ShowVehiclesWithDriver && item?.currentDriverId) return false;
      if (!this.filter_ShowVehiclesWithoutDriver && !item?.currentDriverId) return false;
      return true;
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
    items() {
      return this.$store.state.EntityModule.vehicles.items;
    },
    headers() {
      let headers = this.$store.state.EntityModule.vehicles.headers;
      if(!headers || headers.length < 1) return []
      headers[0].filter = this.filter;
      return headers
    },
    anyFilterChecked() {
      return this.filter_ShowInactiveVehicles;
    }
  }
};
</script>

<style scoped>
.filter-icon:focus::after {
  opacity: 0;
}
</style>
