<template>
  <v-container fluid>
    <v-row dense style="width: 100%">
      <v-card elevation="1" max-height="190">
        <v-col style="width: 100%">
          <v-row>
            <SelectJiraAssignee class="mx-4" @selectedAssignee="selectAssignee" :use-default-assignee="useDefaultAssignee" :clear-assignee="clearAssignee" />
          </v-row>
          <v-row >
            <v-col class="d-flex">
              <v-sheet
                v-for="(item, index) in getStatisticsElements" :key="index"
                class="rounded-pill ml-2"
                height="75"
                :elevation="item.selected ? 2 : 4"
                :outlined="item.selected"
                width="220"
                :style="determineStatisticStyle(item)"
                v-model="item.value"
                @click="statisticClick(item)"
              >
                <div style="text-align: center" class="mt-2">
                  <div style="display: inline-flex">
                    <v-img v-if="item.header_image" :src="item.header_image" contain height="25" width="25"></v-img>
                    <v-icon v-if="item.header_icon" size="20">{{item.header_icon}}</v-icon>
                    <v-tooltip v-if="item.tooltip" bottom>
                      <template v-slot:activator="{ on }">
                        <h4 v-on="on" class="ml-1 grey--text text--darken-1">{{item.info}}</h4>
                      </template>
                      <span>{{item.tooltip}}</span>
                    </v-tooltip>
                    <h4 v-else class="ml-1 grey--text text--darken-1">{{item.info}}</h4>
                  </div>
                  <div style="display: block">
                    <v-icon class="mb-1" v-if="item.bad_condition && item.bad_condition.icon && item.value > item.limit"
                            :color="item.bad_condition.color">{{item.bad_condition.icon}}
                    </v-icon>
                    <v-icon class="mb-1" v-if="item.good_condition && item.good_condition.icon && item.value <= item.limit"
                            :color="item.good_condition.color">{{item.good_condition.icon}}
                    </v-icon>

                    <span v-if="item.bad_condition && item.bad_condition.value && item.value > item.limit">{{item.bad_condition.value}}</span>
                    <span v-if="item.good_condition && item.good_condition.value && item.value <= item.limit">{{item.good_condition.value}}</span>

                    <span class="ml-2" style="font-size: 20px">{{item.value}}</span>
                  </div>
                </div>
              </v-sheet>
            </v-col>
          </v-row>
        </v-col>
      </v-card>
      <v-col>
        <v-card elevation="1" height="186">
          <JiraPinnedIssuesTable @issueClicked="rowClicked($event)" />
        </v-card>
      </v-col>
    </v-row>
    <v-row class="fill">
      <v-progress-linear indeterminate :active="dataBeingRetrieved || ((gitlabIssueBeingRetrieved || jiraIssueBeingRetrieved) && !sidebarState)"></v-progress-linear>
      <v-card elevation="3" class="mt-1" style="width: 100%;">
        <v-data-table
          :dense="settings_denseIssueList"
          class="row-pointer fill"
          :headers="headers"
          :items="items"
          :search="search"
          :items-per-page.sync="itemsPerPage"
          :footer-props="determineFooterProps()"
          :sort-by="sortBy"
          :multi-sort="true"
          :sort-desc="sortDesc"
          :item-class="getCustomItemClass"
          @click:row="rowClicked"
          no-results-text="No issues with the given search terms were found"
          loading-text="Fetching issues. Please wait..."
        >
          <template v-slot:top>
            <v-text-field class="mx-4" v-model="search" append-icon="mdi-magnify" label="Search for an issue" single-line hide-details>
              <template v-slot:prepend>
                <v-menu offset-y :close-on-content-click="false">
                  <template v-slot:activator="{ on }">
                    <v-icon class="filter-icon" :color="anyFilterChecked ? 'marked' : ''" v-on="on">
                      mdi-filter
                    </v-icon>
                  </template>
                  <v-list>
                    <v-list-item>
                      <v-list-item-title>
                        <v-checkbox dense label="Hide quick actions" v-model="filter_hideQuickActions"> </v-checkbox>
                        <v-checkbox dense label="Only show customer issues" v-model="filter_onlyCustomerIssues"> </v-checkbox>
                        <v-divider></v-divider>
                        <v-checkbox dense label="Dense issue list" v-model="settings_denseIssueList"> </v-checkbox>
                      </v-list-item-title>
                    </v-list-item>
                  </v-list>
                </v-menu>
              </template>
            </v-text-field>
          </template>
          <template v-slot:item.key="{ item }">
            <v-icon dense class="mb-1">mdi-key-variant</v-icon>
            <span v-if="item.key" class="secondary--text ml-2">{{ item.key }}</span>
          </template>

          <template v-slot:item.fields.summary="{ item }">
            <v-icon dense class="mb-1">mdi-text-box</v-icon>
            <span class="ml-2">
          {{ item.fields.summary.length > 85 ? item.fields.summary.substring(0, 85) + "..." : item.fields.summary}}
        </span>
          </template>

          <template v-slot:item.fields.jiraIssuePriority.name="{ item }">
            <v-img :src="item.fields.jiraIssuePriority.iconUrl"  style="float: left;" height="20" width="20"></v-img>
            <span class="ml-2">{{item.fields.jiraIssuePriority.name}}</span>
          </template>

          <template v-slot:item.fields.issueType.name="{ item }">
        <span>
              <v-img :src="getIssueTypeImageUrl(item)" class="ml-2" style="float: left;" height="20" width="20"></v-img>
              <span class="ml-1">{{item.fields.issueType.name}}</span>
            </span>
          </template>

          <template v-slot:item.fields.assignee.displayName="{ item }">
        <span>
              <v-avatar  v-if="getIssueAssigneeName(item) !== ''" size="20">
                <img :src="getIssueAssigneeImageUrl(item)" >
              </v-avatar>
              <span class="ml-1">{{getIssueAssigneeName(item)}}</span>
        </span>
          </template>

          <template v-slot:item.fields.isDevelopmentIssue="{ item }">
            <div>
              <v-tooltip bottom>
                <template v-slot:activator="{ on }">
                  <v-img style="float: left; margin: 0; padding: 0;" v-on="on" v-if="isDevelopmentIssue(item)" src="@/assets/ASAP.svg"
                         :class="item.fields.gitlabLink === null ? 'mx-8' : 'mx-4'"
                         contain height="25" width="25"></v-img>
                </template>
                <span>Has ASAP task</span>
              </v-tooltip>


              <v-tooltip bottom>
                <template v-slot:activator="{ on }">
                  <v-img style="float: left; margin: 0; padding: 0; margin-top: 0.2rem;"
                         v-on="on"
                         :class="isDevelopmentIssue(item) ? 'mr-1' : 'mx-8'"
                         v-if="item.fields.gitlabLink !== null" src="@/assets/Gitlab.svg"
                         contain height="23" width="23"></v-img>
                </template>
                <span>Has GitLab case</span>
              </v-tooltip>
            </div>
          </template>

          <template v-slot:item.fields.ttr.cycle.remaining.milliseconds="{ item }">
        <span v-if="item.fields.ttr.cycle.remaining.milliseconds !== null">
          <v-icon v-if="determineTtrColor(item.fields.ttr) !== ''"
                  size="20" :color="determineTtrColor(item.fields.ttr)">
            {{determineTtrIcon(item.fields.ttr)}}
          </v-icon>

          {{determineTtr(item.fields.ttr)}}
        </span>
          </template>

          <template v-slot:item.fields.created="{ item }">
        <span>
          <v-icon v-if="determineIfNew(item)" dense>mdi-new-box</v-icon>
          {{parseIsoDatetime(item.fields.created)}}
        </span>
          </template>

          <template v-slot:item.actions="{ item }">
            <div class="d-flex align-center">
              <v-tooltip bottom v-if="item.fields.assignee === null">
                <template v-slot:activator="{ on }">
                  <v-btn icon :loading="isAssigning">
                    <v-icon v-on="on" medium @click.stop="assignIssue(item)">mdi-account-arrow-right</v-icon>
                  </v-btn>
                </template>
                <span>Assign to me</span>
              </v-tooltip>
              <v-tooltip bottom v-if="!isPinned(item)">
                <template v-slot:activator="{ on }">
                  <v-btn icon :loading="getIssueFromKey(item.key).operations.pinOperation">
                    <v-icon
                            :class="item.fields.assignee !== null && item.fields.gitlabLink === null ? 'mx-5' : ''"
                            v-on="on"
                            @click.stop="pinIssue(item)"
                            size="23">mdi-pin-outline</v-icon>
                  </v-btn>
                </template>
                <span>Pin</span>
              </v-tooltip>
              <v-tooltip bottom v-else>
                <template v-slot:activator="{ on }">
                  <v-btn icon :loading="getIssueFromKey(item.key).operations.pinOperation">
                    <v-icon v-on="on"
                            @click.stop="unpinIssue(item)"
                            :class="item.fields.assignee !== null && item.fields.gitlabLink === null ? 'mx-5' : ''">mdi-pin</v-icon>
                  </v-btn>
                </template>
                <span>Unpin</span>
              </v-tooltip>
              <v-tooltip bottom v-if="item.fields.gitlabLink !== null">
                <template v-slot:activator="{ on }">
                  <v-img v-on="on" @click.stop="viewGitlabCase(item)" src="@/assets/Gitlab.svg"
                         contain :height="settings_denseIssueList ? 20 : 23" :width="settings_denseIssueList ? 20 : 23"></v-img>
                </template>
                <span>View GitLab case</span>
              </v-tooltip>
            </div>
          </template>
        </v-data-table>
      </v-card>

    </v-row>
  </v-container>
</template>
<script>
import axios from "~/axios-client";
import {sortIssueList} from "~/helpers/jira-issuelist-utils";
import moment from "moment";
import JiraPinnedIssuesTable from "@/components/entityLists/JiraPinnedIssuesTable";
import SelectJiraAssignee from "@/components/entityLists/SelectJiraAssignee";

export default {
  components: {SelectJiraAssignee, JiraPinnedIssuesTable },
  props: {
    issue: Object
  },
  data() {
    return {
      useDefaultAssignee: false,
      clearAssignee: false,
      isAssigning: false,
      longLoadingIssue: false,
      filterAssignee: false,
      filterNotAssignedIssues: false,
      filterNeedsAttention: false,
      filterGoalBelow30: false,
      clickedIssue: {},
      filteredIssueList: [],
      sortBy: ["fields.created"],
      sortDesc: [true],
      search: "",
      itemsPerPage: 13,
      selectedIssueKey: "",
      filter_hideQuickActions: JSON.parse(localStorage.getItem("filter_hide_quick_actions")) ?? false,
      filter_onlyCustomerIssues: JSON.parse(localStorage.getItem("filter_only_show_customer_issues")) ?? false,
      settings_denseIssueList: JSON.parse(localStorage.getItem("settings_dense_issue_list")) ?? true,
      selectedAssignee: {},
      minimumTtr: 86400000, // 24 hours
      statisticsElements: [
        {
          info: "Goal below 30",
          //"header_icon": "mdi-help-circle",
          value: 0,
          bad_condition: { icon: "mdi-alert", color: "orange" },
          good_condition: { icon: "mdi-check", color: "green" },
          limit: 30,
          navigable: true,
          selected: false
        },
        {
          info: "Needs attention",
          //"header_image": "@/assets/ASAP.svg",
          value: 0,
          bad_condition: { icon: "mdi-alert", color: "orange" },
          good_condition: { icon: "mdi-check", color: "green" },
          limit: 0,
          navigable: true,
          selected: false,
        },
        {
          info: "Assigned to you",
          value: 0,
          navigable: true,
        },
        {
          info: "Unassigned",
          //"header_image": "@/assets/ASAP.svg",
          value: 0,
          bad_condition: { icon: "mdi-alert", color: "orange" },
          good_condition: { value: "😃" },
          limit: 0,
          navigable: true,
          selected: false,
        },
      ],
    }
  },
  watch: {
    filter_hideQuickActions(value) {
      localStorage.setItem("filter_hide_quick_actions", value);
    },
    filter_onlyCustomerIssues(value) {
      localStorage.setItem("filter_only_show_customer_issues", value);
    },
    settings_denseIssueList(value) {
      localStorage.setItem("settings_dense_issue_list", value);
    },
    items(issues) {
      if (this.filterNotAssignedIssues && issues.length === 0) {
        this.filterNotAssignedIssues = false;
        this.statisticsElements[3].selected = false;
        this.selectedAssignee = this.jiraUserToUse;
      }
    },
    pinnedIssuesLength() {
      this.determineItemPerPage();
    },
    timesFetched() {
      this.setStatistics();
    },
  },
  async mounted() {
    this.determineItemPerPage();
    this.statisticsElements[2].selected = true;
  },
  methods: {
    getIssueFromKey(key) {
      return this.items.filter(issue => issue.key === key)[0];
    },
    selectAssignee(assignee) {
      this.filterAssignee = (assignee?.key !== this.jiraUserToUse.key) ?? false;
      this.$store.commit("updateChosenAssignee", assignee ?? {});
      this.selectedAssignee = assignee;

      if (assignee === undefined || Object.keys(assignee).length === 0) {
        if (!this.filterNotAssignedIssues) {
          this.filterNotAssignedIssues = false;
          this.statisticsElements[3].selected = false;
          this.filterGoalBelow30 = true;
          this.statisticsElements[0].selected = true;
        }
        this.filterNeedsAttention = false;
        this.statisticsElements[1].selected = false;
      } else {
        // means that we have selected an assignee (aka => filterAssignee === true)
        this.statisticsElements[0].selected = false;
        this.statisticsElements[3].selected = false;
        this.filterGoalBelow30 = false;
        this.filterNotAssignedIssues = false;
      }

      this.statisticsElements[2].selected = !this.filterAssignee;
      this.setStatistics();
    },
    rowClicked(item) {
      const issue = item.issue ?? item;
      this.$emit("issueClicked", { issue, action: item.action ?? "" });
    },
    pageChanged(event) {
      this.$emit("pageChanged", event);
    },
    determineStatisticStyle(item) {
      if (item.navigable || item.selected) {
        if (item.selected) {
          return "cursor: pointer; border: 0.5px solid black";
        }
        return "cursor: pointer"
      }
      return "";
    },
    determineItemPerPage() {
      if (this.settings_denseIssueList) {
        this.itemsPerPage = 19;
      } else {
        this.itemsPerPage = 13;
      }
    },
    determineFooterProps() {
      if (this.settings_denseIssueList) {
        return { 'items-per-page-options': [19, 35, 45, 60] };
      } else {
        return  { 'items-per-page-options': [13, 20, 30, 45] }
      }
    },
    isPinned(issue) {
      return this.$store.state.JiraModule.pinnedIssues.some(x => x.issue.key === issue.key);
    },
    async pinIssue(issue) {
      this.getIssueFromKey(issue.key).operations.pinOperation = true;
      await this.$store.dispatch("pinIssue", { user: { key: this.jiraUserToUse.key }, issue: issue });
      this.getIssueFromKey(issue.key).operations.pinOperation = false;
      await this.$store.dispatch("getPinnedIssues", { userKey: this.jiraUserToUse.key, silent: true });

      this.fetchIssueList();
    },
    async unpinIssue(issue) {
      this.getIssueFromKey(issue.key).operations.pinOperation = true;
      await this.$store.dispatch("unpinIssue", { user: { key: this.jiraUserToUse.key }, issue: issue });
      this.getIssueFromKey(issue.key).operations.pinOperation = false;
      await this.$store.dispatch("getPinnedIssues", { userKey: this.jiraUserToUse.key , silent: true });

      this.fetchIssueList();
    },
    fetchIssueList() {
      this.$emit('fetchIssueList', true);
    },
    viewGitlabCase(issue) {
      this.$emit("issueClicked", { issue, action: "gitlab" });
    },
    async assignIssue(issue) {
      const updateObject = {
        "update": {
          "assignee": [
            {
              "set": {
                "name": this.jiraUserToUse.name
              }
            }
          ]
        }
      }
      this.isAssigning = true;
      try {
        const {data} = await axios.put(`/api/jira/issue/${issue.key}/assignee?updateModel=${JSON.stringify(updateObject)}`);
        if (data) {
          await this.$store.dispatch("postCommentOnJiraIssue", {key: issue.key, comment: "On it!"})

          this.$eventBus.$emit("alert", {text: "Assignee updated", type: "success"});
          this.$emit("fetchIssueList");
        } else {
          this.$eventBus.$emit("alert", {text: "An error occured when trying to set you as the assignee", type: "error"});
        }
      } finally {
        this.isAssigning = false;
      }
    },
    determineTtrIcon(item) {
      return item.cycle.remaining.milliseconds > 0 ? "mdi-clock-time-two-outline" : "mdi-alert-octagon-outline";
    },
    determineTtr(item) {
      if (item.cycle.remaining.milliseconds > 86400000 || item.cycle.remaining.milliseconds < 0) {
        if (item.cycle.breached) {
          const daysSince = moment().diff(new Date(item.cycle.breach.isoTime), 'days');
          const timeToReturn = moment().subtract(daysSince, 'days').fromNow();
          if (timeToReturn !== "a few seconds ago") return timeToReturn;
          return item.cycle.breach.friendlyTime;
        }
        const dateToReturn = moment(new Date(item.cycle.breach.friendlyTime), "MMDD").fromNow(); // return like "in a month" or "5 days"
        return dateToReturn === "Invalid date" ? item.cycle.breach.friendlyTime : dateToReturn;
      } else {
        return item.cycle.remaining.friendly;
      }
    },
    determineTtrColor(item) {
      try {
        const milliseconds = item.cycle.remaining.milliseconds;
        if (milliseconds > 86400000) { // 24 hours
          return "blue darken-1";
        } else if (milliseconds <= 86400000 && milliseconds > 1800000) { // < 24 hours and > than 0,5 hours
          return "orange";
        } else if (milliseconds < 1800000) {
          return "red";
        }
      } catch {
        return "";
      }
    },
    statisticClick(item) {
      if (!item.navigable || item.value <= item.limit) return;
      switch (item.info.toLowerCase()) {
        case "goal below 30": {
          this.search = "";
          this.filterGoalBelow30 = !this.filterGoalBelow30;

          if (!this.filterGoalBelow30) {
            this.selectedAssignee = this.jiraUserToUse;
          } else {
            this.selectedAssignee = {};
          }
          this.filterNeedsAttention = false;
          this.filterNotAssignedIssues = false;

          this.statisticsElements[2].selected = false;
          this.statisticsElements[3].selected = false;
          this.statisticsElements[1].selected = false;
          this.statisticsElements[0].selected = this.filterGoalBelow30;

          // flip value to trigger watch
          this.clearAssignee = !this.clearAssignee;

          break;
        }
        case "unassigned": {
          this.search = "";

          this.filterGoalBelow30 = false;
          this.statisticsElements[0].selected = false;

          this.filterNeedsAttention = false;
          this.filterNotAssignedIssues = !this.filterNotAssignedIssues;
          this.search = "";

          if (this.filterNotAssignedIssues) {
            this.selectedAssignee = {};
            this.statisticsElements[1].selected = false;
            this.statisticsElements[2].selected = false;
          } else {
            this.selectedAssignee = this.jiraUserToUse;
          }

          this.statisticsElements[3].selected = this.filterNotAssignedIssues;

          // flip value to trigger watch
          this.clearAssignee = !this.clearAssignee;

          break;
        }
        case "needs attention": {
          this.search = "";

          if (this.selectedAssignee === undefined || Object.keys(this.selectedAssignee).length === 0) this.selectedAssignee = this.jiraUserToUse;

          this.filterGoalBelow30 = false;
          this.statisticsElements[0].selected = false;

          this.filterNeedsAttention = !this.filterNeedsAttention;

          this.filterNotAssignedIssues = false;
          this.statisticsElements[3].selected = false;

          this.statisticsElements[1].selected = this.filterNeedsAttention;
          break;
        }
        case "assigned to you": {
          this.search = "";

          this.filterGoalBelow30 = false;
          this.statisticsElements[0].selected = false;

          this.filterNotAssignedIssues = false;
          this.statisticsElements[3].selected = false;

          this.filterNeedsAttention = false;
          this.statisticsElements[1].selected = false;

          this.selectedAssignee = this.jiraUserToUse;
          this.statisticsElements[2].selected = true;
          this.filterAssignee = true;

          // flip value to trigger watch
          this.useDefaultAssignee = !this.useDefaultAssignee;
          break;
        }
      }
    },
    setStatistics() {
      if (this.$store.state.JiraModule.issueList.items.filter(issue => issue.fields.assignee === null).length === 0
        && this.filterNotAssignedIssues) this.filterNotAssignedIssues = false;

      this.statisticsElements[0].value = this.$store.state.JiraModule.issueList.items
        .filter(issue => issue.fields.issueType.name === "Customer" && issue.fields.resolution !== "Done").length; // goal below 30

      if (!this.filterNotAssignedIssues && !this.filterGoalBelow30) {
        this.statisticsElements[1].value = this.$store.state.JiraModule.issueList.items // needs attention
          .filter(issue => issue.fields.ttr.cycle.remaining.milliseconds !== null)
          .filter(issue => issue.fields.ttr.cycle.remaining.milliseconds <= this.minimumTtr)
          .filter(issue => issue.fields.assignee?.key === this.selectedAssignee.key).length;
      } else {
        this.statisticsElements[1].value = this.$store.state.JiraModule.issueList.items // needs attention
          .filter(issue => issue.fields.ttr.cycle.remaining.milliseconds !== null)
          .filter(issue => issue.fields.ttr.cycle.remaining.milliseconds <= this.minimumTtr)
          .filter(issue => issue.fields.assignee?.key === this.jiraUserToUse.key).length;
      }

      this.statisticsElements[2].value = this.$store.state.JiraModule.issueList.items // assigned to you
        .filter(issue => issue.fields.assignee?.key === this.jiraUserToUse.key).length;

      this.statisticsElements[3].value = this.$store.state.JiraModule.issueList.items // unassigned
        .filter(issue => issue.fields.assignee === null).length;
    },
    parseIsoDatetime(dtstr) {
      return new Date(dtstr).toLocaleDateString();
    },
    determineIfNew(issue) {
      // check if issue was created less than 5 minutes ago
      return Math.floor((new Date() - new Date(issue.fields.created)) / 1000) <= 300;
    },
    getCustomItemClass(item) {
      if (item.fields?.resolution?.name === "Done" && this.filter_showResolvedIssues) {
        return "green lighten-4";
      }

      if (item.fields?.resolution?.name === "Declined" && this.filter_showDeclinedIssues) {
        return "red lighten-3";
      }

      if (!item.fields?.resolution && this.filter_showUnresolvedIssues) {
        return "tablered";
      }
    },
    getIssueTypeImageUrl(item) {
      return item.fields?.issueType?.iconUrl ?? "None";
    },
    getIssueAssigneeImageUrl(item) {
      return item.fields?.assignee?.avatarUrls?.the16X16;
    },
    getIssueAssigneeName(issue) {
      const name = issue.fields.assignee?.displayName;
      if (name == null) {
        return '';
      }
      return name;
    },
    isDevelopmentIssue(issue) {
      try {
        return issue.fields?.isDevelopmentIssue[0].value === "Development issue";
      } catch {
        //return issue.fields.gitlabLink !== null && issue.fields.gitlabLink.includes("gitlab");
        return false;
      }
    },
  },
  computed: {
    jiraUserToUse() {
      return this.$store.state.JiraModule.jiraUserToUse;
    },
    getStatisticsElements() {
      return this.statisticsElements.filter(element => element.visible !== false);
    },
    sidebarState() {
      return this.$store.state.SidebarModule.sidebarState;
    },
    gitlabIssueBeingRetrieved() {
      return this.$store.state.GitlabModule.gitlabIssueBeingRetrieved;
    },
    jiraIssueBeingRetrieved() {
      return this.$store.state.JiraModule.jiraIssueBeingRetrieved;
    },
    previousIssueList() {
      return this.$store.state.JiraModule.previousIssueList;
    },
    startOfIssueList() {
      return this.$store.state.JiraModule.startOfIssueList;
    },
    items() {
      if (this.filterGoalBelow30) {
        return this.$store.state.JiraModule.issueList.items
          .filter(issue => issue.fields.issueType.name === "Customer");
      } else {
        let issuesToShow = sortIssueList(this.$store.state.JiraModule.issueList.items,
          this.filterAssignee, this.filterNeedsAttention, this.filterNotAssignedIssues, this.jiraUserToUse, this.selectedAssignee, this.minimumTtr);

        if (this.filter_onlyCustomerIssues) {
          return issuesToShow.filter(issue => issue.fields.issueType.name === "Customer");
        }
        return issuesToShow;
      }
    },
    timesFetched() {
      return this.$store.state.JiraModule.timesFetched;
    },
    headers() {
      if (!this.filter_hideQuickActions) {
        return this.$store.state.JiraModule.issueList.headers;
      } else {
        return this.$store.state.JiraModule.issueList.headers.slice(0, 8);
      }
    },
    dataBeingRetrieved() {
      return this.$store.state.EntityModule.dataBeingRetrieved;
    },
    anyFilterChecked() {
      return this.filter_hideQuickActions || this.filter_onlyCustomerIssues || !this.settings_denseIssueList;
    },
  }
};
</script>

<style scoped>
.fill {
  width: 100%;
  height: 100%;
}

/*.row-pointer >>> tbody tr :hover {*/
/*  cursor: pointer;*/
/*}*/

.filter-icon:focus::after {
  opacity: 0;
}
</style>
