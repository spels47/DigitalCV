<template>
  <v-sheet>
    <UserImport v-if="displayAddAccountDialog" :customer="customer" :department-list="departmentList" @closeDialog="displayAddAccountDialog = false"></UserImport>
    <MoveEntityDialog
      v-if="displayMoveAccountDialog"
      :mainOfficeId="customer.mainOfficeId"
      :multipleDepartmentSourcesIds="departmentIds"
      :loading="loading"
      :title="'Select Department to move ' + itemsSelected.length + ' user(s) to'"
      :checkboxLabel="'Also move vehicles connected to drivers'"
      @closeDialog="displayMoveAccountDialog = false"
      @confirm="moveAccounts"
    ></MoveEntityDialog>

    <v-dialog v-model="displayMoveAccountProgressDialog" persistent max-width="490">
      <v-card>
        <v-progress-linear indeterminate :active="moveAccountDialogLoading" color="primary"></v-progress-linear>
        <v-card-title class="headline">
          <span v-if="moveAccountDialogLoading">Moves in progress...</span>
          <span v-if="!moveAccountDialogLoading">Moves processed</span>
        </v-card-title>
        <v-card-text>Moving {{ itemsSelected.length }} account(s)</v-card-text>
        <v-card-text v-if="moveAccountDialogProcessedCount">Processed: {{ moveAccountDialogProcessedCount }} account(s)</v-card-text>
        <v-card-text v-if="moveAccountDialogErrorsCount">Failed: {{moveAccountDialogErrorsCount}} Account id's: {{moveAccountDialogErrors}} </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="primary" text @click="displayMoveAccountProgressDialog = false" :disabled="moveAccountDialogLoading">Close</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <SimpleDialog
      v-if="displayResetPasswordsDialog"
      :title="'Reset password'"
      :text="'Are you sure you want to reset ' + (itemsSelected.length === 0 && resetCurrentUserPasswordId != 0 ? ' this users password ' : itemsSelected.length + ' user password(s)')"
      :confirmLabel="'Ok'"
      :cancelLabel="'cancel'"
      @confirm="userResetPasswords"
      @cancel="cancelResetPasswords"
    ></SimpleDialog>

    <SimpleDialog
      v-if="displayActivateAccountsDialog"
      :title="'Activate users'"
      :text="'Are you sure you want to activate ' + itemsSelected.length + ' user(s)'"
      :confirmLabel="'Ok'"
      :cancelLabel="'cancel'"
      @confirm="accountActivate"
      @cancel="displayActivateAccountsDialog = false"
    ></SimpleDialog>

    <SimpleDialog
      v-if="displayDeactivateAccountsDialog"
      :title="'Deactivate user'"
      :text="'Are you sure you want to deactivate ' + itemsSelected.length + ' user(s)'"
      :confirmLabel="'Ok'"
      :cancelLabel="'cancel'"
      @confirm="accountDeactivate"
      @cancel="displayDeactivateAccountsDialog = false"
    ></SimpleDialog>

    <SimpleDialog
      v-if="displayRemoveFromVehicleDialog"
      :title="'Remove Vehicle'"
      :text="'Are you sure you want to remove vehicle on ' + itemsSelected.length + ' user(s)'"
      :confirmLabel="'Ok'"
      :cancelLabel="'cancel'"
      @confirm="accountRemoveVehicle"
      @cancel="displayRemoveFromVehicleDialog = false"
    ></SimpleDialog>

    <EntityListTable
      v-if="items && headers"
      :items="items"
      :headers="headers"
      :loading="loading"
      :sortDesc="[true, false]"
      :SortBy="['isAdmin', 'departmentLevel']"
      loading-text="Loading... Please wait"
      :customer="customer"
      @itemSelected="itemSelected"
      @resetSingleUserPassword="resetSingleUserPassword"
      @userImpersonate="userImpersonate"
      @rowClicked="rowClicked"
      @assignedAssetClicked="assignedAssetClicked"
    >
      <template v-slot:table-header>
        <MassHandleButton
          :icon="'mdi-microsoft-excel'"
          :tooltip="'Export to Excel'"
          :loading="exportingToExcel"
          :buttonColor="'success'"
          @buttonClicked="exportAccountsToExcel"
          data-cy="export-excel-accounts"
        ></MassHandleButton>
        <MassHandleButton class="mr-10" v-if="roles.USER_CREATE && customer && customer.id" data-cy="add-account-button" :icon="'mdi-account-plus'" :tooltip="'Add Accounts'" :buttonColor="'secondary'" @buttonClicked="displayAddAccountDialog = true"></MassHandleButton>
        <v-fade-transition>
          <MassHandleButton v-if="roles.USER_EDIT && itemsSelected.length > 0" :icon="'mdi-account-arrow-right'" :tooltip="'Move user'" :buttonColor="'secondary'" @buttonClicked="displayMoveAccountDialog = true"></MassHandleButton>
        </v-fade-transition>
        <v-fade-transition>
          <MassHandleButton v-if="roles.USER_RESET && itemsSelected.length > 0" :icon="'mdi-account-key'" :tooltip="'Reset password'" :buttonColor="'accent'" @buttonClicked="displayResetPasswordsDialog = true"></MassHandleButton>
        </v-fade-transition>
        <v-fade-transition>
          <MassHandleButton v-if="roles.USER_EDIT && itemsSelected.length > 0" :icon="'mdi-account-check'" :tooltip="'Activate user'" :buttonColor="'success'" @buttonClicked="displayActivateAccountsDialog = true"></MassHandleButton>
        </v-fade-transition>
        <v-fade-transition>
          <MassHandleButton v-if="roles.USER_EDIT && itemsSelected.length > 0" :icon="'mdi-account-remove'" :tooltip="'Deactivate user'" :buttonColor="'error'" @buttonClicked="displayDeactivateAccountsDialog = true"></MassHandleButton>
        </v-fade-transition>
        <v-fade-transition>
          <MassHandleButton
            v-if="roles.USER_EDIT && itemsSelected.length > 0"
            :icon="'mdi-car-connected'"
            :tooltip="'Remove from current vehicle'"
            :buttonColor="'warning'"
            @buttonClicked="displayRemoveFromVehicleDialog = true"
          ></MassHandleButton>
        </v-fade-transition>
      </template>
      <template v-slot:filter-buttons>
        <v-menu offset-y :close-on-content-click="false">
          <template v-slot:activator="{ on }">
            <v-icon class="filter-icon" :color="anyFilterChecked ? 'marked' : ''" v-on="on">
              mdi-filter
            </v-icon>
          </template>
          <v-list>
            <v-list-item>
              <v-list-item-title>
                <v-checkbox dense label="Show inactive accounts" v-model="filter_ShowInactiveAccounts"> </v-checkbox>
                <v-checkbox dense label="Show accounts that left the company" v-model="filter_leftCompany"> </v-checkbox>
                <v-checkbox dense label="Show active accounts" v-model="filter_ShowActiveAccounts"> </v-checkbox>
                <v-checkbox dense label="Show Admins" v-model="filter_ShowAdmins"> </v-checkbox>
                <v-checkbox dense label="Show Users" v-model="filter_ShowUsers"> </v-checkbox>
                <v-checkbox dense label="Show Users Assigned To Vehicles" v-model="filter_AssignedToVehicle"> </v-checkbox>
                <v-checkbox dense label="Show Users Not Assigned To Vehicles" v-model="filter_NotAssignedToVehicle"> </v-checkbox>
              </v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
      </template>
    </EntityListTable>
  </v-sheet>
</template>

<script>
import axios from "~/axios-client";
import { mapGetters } from 'vuex';
import { exportToExcelFile } from "@/helpers/excel-util";
import EntityListTable from "./EntityListTable";
import MassHandleButton from "../MassHandleButton";
import UserImport from "../UserImport";
import MoveEntityDialog from "../widgets/dialogs/MoveEntityDialog";
import SimpleDialog from "../widgets/dialogs/simpleDialog";

export default {
  components: { EntityListTable, MassHandleButton, UserImport, MoveEntityDialog, SimpleDialog },
  props: ["customerId", "customer"],
  data() {
    return {
      loading: false,
      exportingToExcel: false,
      itemsSelected: [],
      departmentIds: [],
      displayAddAccountDialog: false,
      displayResetPasswordsDialog: false,
      displayActivateAccountsDialog: false,
      displayDeactivateAccountsDialog: false,
      displayRemoveFromVehicleDialog: false,
      filter_ShowInactiveAccounts: false,
      filter_leftCompany: false,
      filter_ShowActiveAccounts: true,
      filter_ShowAdmins: true,
      filter_ShowUsers: true,
      filter_AssignedToVehicle: true,
      filter_NotAssignedToVehicle: true,
      displayMoveAccountDialog: false,
      moveAccountDialogProcessedCount: 0,
      moveAccountDialogErrorsCount: 0,
      moveAccountDialogErrors: [],
      displayMoveAccountProgressDialog: false,
      moveAccountDialogLoading: false,
    };
  },
  mounted() {
    this.$store.dispatch("retrieveAccounts", this.customerId);
  },
  methods: {
    exportAccountsToExcel() {
      const sortByActiveAccounts = (a, b) => {
        return a.AccountActive > b.AccountActive ? -1 : 1;
      }

      let data = [];
      this.exportingToExcel = true;

      this.items.forEach(account => {
        let accountObject = {
          UserId: account.id,
          Username: account.username,
          Name: account.name,
          Mobile: account.mobile,
          Email: account.email,
          RCID: account.rcid,
          DepartmentId: account.departmentId,
          Department: account.department,
          EmployeeNumber: account.employeeNumber,
          Type: account.isAdmin ? "Admin" : "Account",
          Title: account.title,
          AccountActive: account.accountActive ? "Yes" : "No",
          LastLogin: account.lastLoggedIn,
          LastLoginDate: account.lastLoginDate,
        }
        if (account.assignedAsset) {
          accountObject.VehicleAssignedLicensePlate = account.assignedAsset.vehicleAssignedLicensePlate
          accountObject.VehicleAssignedVehicleId = account.assignedAsset.vehicleAssignedVehicleId;
        }
        data.push(accountObject);
      });

      const fileName = this.customer.name + " accounts.xlsx";
      const sheetName = "All accounts";
      exportToExcelFile(fileName, sheetName, data.sort(sortByActiveAccounts)).finally(() => this.exportingToExcel = false);
    },
    rowClicked(row) {
      this.$emit("rowClicked", row);
    },
    assignedAssetClicked(item) {
      this.$emit("assignedAssetClicked", item);
    },
    itemSelected(items) {
      this.itemsSelected = items;
      this.departmentIds = items.map(account => account.departmentId);
    },
    async moveAccounts(moveConnectedVehicle, destinationDepartmentId) {
      this.displayMoveAccountDialog = false;
      this.moveAccountDialogProcessedCount = 0;
      this.moveAccountDialogErrorsCount = 0;
      this.moveAccountDialogErrors = [];
      this.displayMoveAccountProgressDialog = true;
      this.moveAccountDialogLoading = true
      let moveToDepartmentHierarchyRes = await axios.get(`/api/customer/hierarchy/${destinationDepartmentId}/main-office-and-down`)

      for (const account of this.itemsSelected) {
        try {
          await axios.put("/api/user/moveUser", { SelectedId: [account.id], DestinationId: destinationDepartmentId })
          await this.$store.dispatch("audit", { source: "account", entityId: account.id, message: "Move Account to new department", oldValue: account.departmentId, newValue: destinationDepartmentId });
          account.departmentLevel = moveToDepartmentHierarchyRes.data.departmentPath.length + 3
          account.department = moveToDepartmentHierarchyRes.data.name

          if(moveConnectedVehicle && account.vehicleAssignedVehicleId){
            let vehicleRes = await axios.get(`/api/vehicle/${account.vehicleAssignedVehicleId}`);
            let vehicle = vehicleRes.data
            await axios.post(`/api/asset/${vehicle.assetId}/move/${destinationDepartmentId}`)
            await this.$store.dispatch("audit", { source: "vehicle", entityId: account.vehicleAssignedVehicleId, message: "Move vehicle to department", oldValue: vehicle.departmentId, newValue: destinationDepartmentId })
          }
        } catch (ex) {
          this.moveAccountDialogErrors.push(account.id);
          this.moveAccountDialogErrorsCount++;
        }
        this.moveAccountDialogProcessedCount++
      }

      if(this.moveAccountDialogErrors.length > 0){
        console.log('Errors:', this.moveAccountDialogErrors)
        this.$eventBus.$emit("alert", {text: `Failed to move ${this.moveAccountDialogErrors.length} accounts / connected vehicles`, type: "error"});
      }
      this.moveAccountDialogLoading = false
    },
    resetSingleUserPassword(id) {
      this.displayResetPasswordsDialog = true;
      this.resetCurrentUserPasswordId = id;
    },
    cancelResetPasswords() {
      this.displayResetPasswordsDialog = false;
      this.resetCurrentUserPasswordId = 0;
    },
    async userResetPasswords() {
      if (this.resetCurrentUserPasswordId !== 0) {
        let resetList = [];
        resetList.push(this.resetCurrentUserPasswordId);
        await axios
          .put("api/user/resetPassword", resetList)
          .then(() => {
            this.$store.dispatch("audit", { source: "account", entityId: this.resetCurrentUserPasswordId, message: "Reset password for user", oldValue: "", newValue: "" });
          })
          .catch(() => {
            this.$eventBus.$emit("alert", { template: "api-error" });
          });
      } else {
        await axios
          .put(
            "api/user/resetPassword",
            this.itemsSelected.map(x => x.id)
          )
          .then(() => {
            this.itemsSelected.forEach(x => this.$store.dispatch("audit", { source: "account", entityId: x.id, message: "Reset password for user", oldValue: "", newValue: "" }));
          })
          .catch(() => {
            this.$eventBus.$emit("alert", { template: "api-error" });
          });
      }
      this.resetCurrentUserPasswordId = 0;
      this.displayResetPasswordsDialog = false;
    },
    async accountActivate() {
      await axios
        .put(
          "api/user/activateUsers",
          this.itemsSelected.map(x => x.id)
        )
        .then(() => {
          this.$store.dispatch("retrieveAccounts", this.customerId);
          this.itemsSelected.forEach(x => this.$store.dispatch("audit", { source: "account", entityId: x.id, message: "Activate user", oldValue: "", newValue: "" }));
        })
        .catch(() => {
          this.$eventBus.$emit("alert", { template: "api-error" });
        });
      this.displayActivateAccountsDialog = false;
    },
    async accountDeactivate() {
      await axios
        .put(
          "api/user/deactivateUsers",
          this.itemsSelected.map(x => x.id)
        )
        .then(() => {
          this.$store.dispatch("retrieveAccounts", this.customerId);
          this.itemsSelected.forEach(x => this.$store.dispatch("audit", { source: "account", entityId: x.id, message: "Deactivate user", oldValue: "", newValue: "" }));
        })
        .catch(() => {
          this.$eventBus.$emit("alert", { template: "api-error" });
        });
      this.displayDeactivateAccountsDialog = false;
    },
    async accountRemoveVehicle() {
      await axios
        .put(
          "api/user/removeVehicleFromUsers",
          this.itemsSelected.map(x => x.id)
        )
        .then(() => {
          this.$store.dispatch("retrieveAccounts", this.customerId);
          this.itemsSelected.forEach(x => this.$store.dispatch("audit", { source: "account", entityId: x.id, message: "Remove vehicle from user", oldValue: "", newValue: "" }));
        })
        .catch(() => {
          this.$eventBus.$emit("alert", { template: "api-error" });
        });

      this.displayRemoveFromVehicleDialog = false;
    },
    async userImpersonate(item) {
      if(this.customer.departmentPath[0].id === 99992) {
        let result = await axios.get(`api/user/oldImpersonate/${item.id}`);
        let impersonateUrl = result.data;
        window.open(impersonateUrl, "_blank")
      }
      else{
        if(item.isAdmin) window.open(`/start-impersonation-central?userId=${item.id}&username=${item.username}`, "_blank");
        else window.open(`/start-impersonation-triplog?userId=${item.id}&username=${item.username}`, "_blank");
      }
    },
    filter(value, search, item) {
      if (!this.filter_ShowInactiveAccounts && !item?.accountActive) return false;
      if (!this.filter_leftCompany && !this.filter_ShowInactiveAccounts && item?.hasLeftCompany) return false;
      if (!this.filter_ShowActiveAccounts && item?.accountActive) return false;
      if (!this.filter_ShowAdmins && item?.isAdmin) return false;
      if (!this.filter_ShowUsers && !item?.isAdmin) return false;
      if (!this.filter_AssignedToVehicle && item?.assignedAsset) return false;
      if (!this.filter_NotAssignedToVehicle && !item?.assignedAsset) return false;
      return true;
    },
    flatDepartmentHierarchy(node) {
      let childrenList = node.children.flatMap(this.flatDepartmentHierarchy);
      childrenList.unshift({ text: node.name, value: node.id });
      return childrenList;
    },
    getDepartmentIdByName(departmentName) {
      let returnValue = 0;
      this.departmentList.forEach(dep => {
        if (dep.text?.toLowerCase() === departmentName?.toLowerCase()) returnValue = dep.value;
      });
      return returnValue;
    }
  },
  computed: {
    ...mapGetters('customerStore', ['mainOfficeHierarchy']),
    roles() {
      return this.$store.state.currentUserRoles;
    },
    items() {
      return this.$store.state.EntityModule.accounts.items;
    },
    headers() {
      const headers = this.$store.state.EntityModule.accounts.headers;
      if (headers.length > 0) {
        headers[0].filter = this.filter;
      }
      return headers;
    },
    anyFilterChecked() {
      return this.filter_ShowInactiveAccounts || this.filter_leftCompany;
    },
    departmentList() {
      const list = this.flatDepartmentHierarchy(this.mainOfficeHierarchy);
      list.sort((a, b) => a?.text?.localeCompare(b?.text));
      return list
    }
  }
};
</script>

<style scoped>
.filter-icon:focus::after {
  opacity: 0;
}
</style>
