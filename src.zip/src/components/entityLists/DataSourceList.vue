<template>
  <v-sheet>
    <EntityListTable
      v-if="items && headers"
      :items="items"
      :headers="headers"
      :loading="loading"
      :sortDesc="false"
      :customer="customer"
      loading-text="Loading... Please wait"
      @itemSelected="itemSelected"
      @connectedAssetClicked="connectedAssetClicked"
      @rowClicked="rowClicked"
    >
      <template v-slot:table-header>
        <MassHandleButton
          :icon="'mdi-microsoft-excel'"
          :tooltip="'Export to Excel'"
          :loading="exportingToExcel"
          :buttonColor="'success'"
          @buttonClicked="exportDataSourcesToExcel"
          data-cy="export-excel-datasource"
        ></MassHandleButton>

        <v-fade-transition>
          <MassHandleButton
            v-if="roles.DATASOURCE_SWAP && itemsSelected.length > 0"
            :tooltip="selectedItemsValidForSwap ? `Can't swap ${swapValidationMessage.join(', ')} unit(s)` : itemsSelected.length === 1 ? 'Swap unit' : 'Swap units'"
            :buttonColor="selectedItemsValidForSwap ? 'error' : 'secondary'"
            :loading="fetchingSubscriptions"
            icon="mdi-swap-horizontal-circle"
            @buttonClicked="showSwapHandlingWizard"
          ></MassHandleButton>
        </v-fade-transition>

      </template>
      <template v-slot:filter-buttons>
        <v-menu offset-y :close-on-content-click="false">
          <template v-slot:activator="{ on }">
            <v-icon class="filter-icon" :color="anyFilterChecked ? 'marked' : ''" v-on="on">
              mdi-filter
            </v-icon>
          </template>
          <v-list>
            <v-list-item>
              <v-list-item-title>
                <v-checkbox dense class="ml-1 my-0" label="Show DLG data sources" v-model="filter_ShowDlgDatasources"></v-checkbox>
              </v-list-item-title>
            </v-list-item>
            <v-list-item>
              <v-list-item-title>
                <v-checkbox dense class="ml-1 my-0" label="Show FAKE data sources" v-model="filter_ShowFakeDatasources"></v-checkbox>
              </v-list-item-title>
            </v-list-item>
            <v-list-item>
              <v-list-item-title>
                <v-checkbox dense class="ml-1 my-0" label="Show MINI's" v-model="filter_ShowMiniDatasources"></v-checkbox>
              </v-list-item-title>
            </v-list-item>
            <v-list-item v-if="subscriptionsExpiredCount > 0">
              <v-list-item-title>
                <v-checkbox dense class="ml-1 my-0" :label="'Show ' + subscriptionsExpiredCount + ' expired data sources'" v-model="filter_ShowExpiredDatasources"></v-checkbox>
              </v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
      </template>
    </EntityListTable>

    <SwapHandlingWizard
      :customer="customer"
      :show="showSwapHandlingWizardDialog"
      :simcards="itemsSelected"
      :subscriptions="subscriptions"
      :key="showSwapHandlingWizardDialog"
      @closeDialog="showSwapHandlingWizardDialog = false"
    ></SwapHandlingWizard>
  </v-sheet>
</template>

<script>
/* eslint-disable vue/no-side-effects-in-computed-properties */
import EntityListTable from "./EntityListTable";
import MassHandleButton from "@/components/MassHandleButton";
import { exportToExcelFile } from "@/helpers/excel-util";
import SwapHandlingWizard from "@/components/dialogs/swap-handling/SwapHandlingWizard";
import axios from "@/axios-client";

export default {
  components: { SwapHandlingWizard, MassHandleButton, EntityListTable },
  props: ["customerId", "customer"],
  data() {
    return {
      loading: false,
      exportingToExcel: false,
      filter_ShowDlgDatasources: false,
      filter_ShowFakeDatasources: false,
      filter_ShowMiniDatasources: false,
      filter_ShowExpiredDatasources: false,
      showSwapHandlingWizardDialog: false,
      fetchingSubscriptions: false,
      itemsSelected: [],
      subscriptions: [],
      swapValidationMessage: []
    };
  },
  mounted() {
    this.$store.dispatch("retrieveDataSources", this.customerId);
  },
  methods: {
    async showSwapHandlingWizard() {
      if (this.selectedItemsValidForSwap)
        return;

      this.fetchingSubscriptions = true;
      try {
        const { data } = await axios.get(`/api/customer/details?customerId=${this.customerId}&type=subscription`);
        this.subscriptions = data.data;
      } finally {
        this.fetchingSubscriptions = false;
      }

      this.showSwapHandlingWizardDialog = true;
    },
    itemSelected(items) {
      this.itemsSelected = items;
    },
    exportDataSourcesToExcel() {
      const formatType = (dataSource) => {
        if (dataSource.type === "oem" || dataSource.type === "mini")
          return dataSource.unitTypeId;

        return dataSource.bmnComments
          ? `${dataSource.unitTypeId} / ${dataSource.bmnComments}`
          : dataSource.unitTypeId;
      };

      const sortByIsActive = (a, b) => {
        return a.IsActive > b.IsActive ? -1 : 1;
      };

      let data = [];
      this.exportingToExcel = true;

      this.items.forEach(dataSource => {
        if (dataSource.serialNumber.startsWith("FAKE"))
          return;

        data.push({
          SimcardId: dataSource.simcardId,
          SerialNumber: dataSource.serialNumber,
          Type: formatType(dataSource),
          SubscriptionNo: dataSource.subscriptionNumber,
          LastContact: dataSource.lastContact,
          PrimaryConnectedAsset: dataSource.connectedAssetId,
          PrimaryConnectedAssetRegno: dataSource.connectedAssetAlias,
          ConnectedRfid: dataSource.hardwareSerialNumber,
          GsmNumber: dataSource.msisdn,
          SIMICC: dataSource.iccid,
          IsActive: dataSource.subscriptionExpired ? "No" : "Yes",
          IMEI: dataSource.imei?.toUpperCase() ?? ""
        });
      });

      const fileName = this.customer.name + " datasources.xlsx";
      const sheetName = "All datasources";
      exportToExcelFile(fileName, sheetName, data.sort(sortByIsActive)).finally(() => this.exportingToExcel = false);
    },
    rowClicked(row) {
      this.$emit("rowClicked", row);
    },
    connectedAssetClicked(item) {
      this.$emit("connectedAssetClicked", item);
    },
    isDlgUnit(item) {
      return item?.features?.includes('10000') && !item?.features?.includes('1000');
    },
    filter(value, search, item) {
      if (!this.filter_ShowDlgDatasources && this.isDlgUnit(item)) return false;
      if (!this.filter_ShowFakeDatasources && item?.id?.startsWith("FAKE")) return false;
      if (!this.filter_ShowMiniDatasources && item?.type === "mini") return false;
      if (!this.filter_ShowExpiredDatasources && item?.subscriptionExpired) return false;
      return true;
    }
  },
  computed: {
    selectedItemsValidForSwap() {
      const containsOemUnits = this.itemsSelected.some(item => item.type === 'oem');
      const containsFakeUnits = this.itemsSelected.some(item => item.serialNumber.toLowerCase().startsWith("fake"));
      const containsDlgUnits = this.itemsSelected.some(item => this.isDlgUnit(item) || item.serialNumber.toLowerCase().startsWith("dlg"));
      const containsSwapsPending = this.itemsSelected.some(item => item.pendingSwap || item.pendingHotSwap !== null);

      this.swapValidationMessage = [];

      if (containsOemUnits)
        this.swapValidationMessage.push("OEM");

      if (containsFakeUnits)
        this.swapValidationMessage.push("FAKE");

      if (containsDlgUnits)
        this.swapValidationMessage.push("DLG");

      if (containsSwapsPending)
        this.swapValidationMessage.push("PENDING SWAP");

      return containsOemUnits || containsFakeUnits || containsDlgUnits || containsSwapsPending;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    items() {
      return this.$store.state.EntityModule.dataSources.items;
    },
    headers() {
      let headers = this.$store.state.EntityModule.dataSources.headers;
      if (headers.length > 0) {
        headers[0].filter = this.filter;
      }
      return headers;
    },
    anyFilterChecked() {
      return this.filter_ShowDlgDatasources || this.filter_ShowFakeDatasources || this.filter_ShowMiniDatasources || this.filter_ShowExpiredDatasources;
    },
    subscriptionsExpiredCount() {
      return this.items.filter(item => item.subscriptionExpired).length;
    }
  }
};
</script>

<style scoped>
.filter-icon:focus::after {
  opacity: 0;
}
</style>
