<template>
  <v-col cols="12">
    <v-row>
        <v-expansion-panels v-model="openPanelSolidFix" class="elevation-2" :class="{ 'rounded-lg ma-2': modern === true }">
          <v-expansion-panel v-if="telemetry.serialNumber && !telemetry.serialNumber.startsWith('MUG')" hide-actions>
            <v-expansion-panel-header >
              <span>Solid Fix</span>
              <v-tooltip bottom v-if="telemetry && telemetry.currentState">
                <template v-slot:activator="{ on }">
                  <span class="icon-right" v-on="on">
                    <v-icon v-if="telemetry.currentState.fix === 'Ok'"  medium color="success">mdi-check</v-icon>
                    <v-icon v-if="telemetry.currentState.fix === 'Error'"  medium color="error">mdi-alert-circle</v-icon>
                    <v-icon v-if="telemetry.currentState.fix === 'NotApplicable'"  medium color="primary">mdi-cancel</v-icon>
                  </span>
                </template>
                <span v-html="currentStateHoverMessage"></span>
              </v-tooltip>
            </v-expansion-panel-header>
            <v-expansion-panel-content v-if="telemetry && telemetry.history">
              <div class="sorrytext" v-if="telemetry.history.length === 0">{{noDataText}}</div>
              <telemetry-canvas v-if="telemetry.history.length > 0" :telemetry="telemetryFix"></telemetry-canvas>
            </v-expansion-panel-content>
          </v-expansion-panel>
        </v-expansion-panels>
    </v-row>

    <v-row>
      <v-expansion-panels v-model="openPanelPlacedCorrectly" class="elevation-2" :class="{ 'rounded-lg ma-2': modern === true }">
        <v-expansion-panel v-if="telemetry.serialNumber && !telemetry.serialNumber.startsWith('MUG')">
          <v-expansion-panel-header>
            <span>GPS satellites in view</span>
            <v-tooltip bottom v-if="telemetry && telemetry.currentState">
              <template v-slot:activator="{ on }">
                <span class="icon-right" v-on="on">
                  <v-icon v-if="telemetry.currentState.satellites === 'Ok'"  medium color="success">mdi-check</v-icon>
                  <v-icon v-if="telemetry.currentState.satellites === 'Error'"  medium color="error">mdi-alert-circle</v-icon>
                  <v-icon v-if="telemetry.currentState.satellites === 'NotApplicable'"  medium color="primary">mdi-cancel</v-icon>
                </span>
              </template>
              <span v-html="currentStateHoverMessage"></span>
            </v-tooltip>
          </v-expansion-panel-header>
          <v-expansion-panel-content v-if="telemetry && telemetry.history">
            <div class="sorrytext" v-if="telemetry.history.length === 0">{{noDataText}}</div>
            <telemetry-canvas v-if="telemetry.history.length > 0" :telemetry="telemetrySatellites"></telemetry-canvas>
          </v-expansion-panel-content>
        </v-expansion-panel>
      </v-expansion-panels>
    </v-row>

    <v-row>
      <v-expansion-panels class="elevation-2" >
        <v-expansion-panel style="cursor: auto;">
        <v-expansion-panel-header v-if="telemetry && telemetry.currentState && telemetry.serialNumber.startsWith('MUG')" hide-actions style="cursor: auto;" disabled>
          <span>Battery status</span>
          <v-tooltip bottom v-if="telemetry && telemetry.currentState">
            <template v-slot:activator="{ on }">
                <span class="icon-right">
                  <span class="mr-2">{{telemetry.currentState.batteryPercentLeft}}%</span>
                  <v-icon v-if="failed || telemetry.currentState.batteryPercentLeft < 0" v-on="on" medium color="warning">mdi-alert-circle-outline</v-icon>
                  <v-icon v-if="telemetry.currentState.batteryPercentLeft > 80" v-on="on" medium color="success">mdi-battery</v-icon>
                  <v-icon v-if="telemetry.currentState.batteryPercentLeft >= 50 && telemetry.currentState.batteryPercentLeft < 80" v-on="on" medium color="success">mdi-battery-80</v-icon>
                  <v-icon v-if="telemetry.currentState.batteryPercentLeft >= 30 && telemetry.currentState.batteryPercentLeft < 50" v-on="on" medium color="warning">mdi-battery-50</v-icon>
                  <v-icon v-if="telemetry.currentState.batteryPercentLeft >= 0 && telemetry.currentState.batteryPercentLeft < 30 && telemetry.currentState.batteryPercentLeft !== null" v-on="on" medium color="error">mdi-battery-10</v-icon>
                  <v-icon v-if="telemetry.currentState.batteryPercentLeft === null" v-on="on" medium color="primary">mdi-cancel</v-icon>
                </span>
            </template>
            <span>Battery reported as: {{telemetry.currentState.battery}}</span> <br/>
            <span v-if="telemetry.currentState.batteryPercentLeft !== null">Battery level at: {{telemetry.currentState.batteryPercentLeft}}%</span> <br/><br/>
            <span v-html="currentStateHoverMessage"></span>
          </v-tooltip>
        </v-expansion-panel-header>
        </v-expansion-panel>
      </v-expansion-panels>
    </v-row>

    <v-row>
      <v-expansion-panels v-model="openPanelReset" class="elevation-2">
        <v-expansion-panel style="cursor: auto;">
          <v-expansion-panel-header v-if="telemetry && telemetry.currentState && telemetry.serialNumber.startsWith('MUG')">
            <span>GSM resets</span>
            <span class="icon-right" v-if="telemetry && telemetry.history && telemetry.history.length > 0">
              <span class="mr-2">{{totalResetsCount}} resets during this timeframe</span>
              <v-icon v-if="totalResetsCount === 0"  medium color="success">mdi-check</v-icon>
              <v-icon v-if="totalResetsCount > 0"  medium color="error">mdi-alert-circle</v-icon>
            </span>
            <v-tooltip bottom v-if="telemetry && telemetry.history && telemetry.history.length === 0">
              <template v-slot:activator="{ on }">
                              <span class="icon-right" v-on="on">
                                <v-icon medium color="primary">mdi-cancel</v-icon>
                              </span>
              </template>
              <span>No data for this timeframe</span>
            </v-tooltip>
          </v-expansion-panel-header>
          <v-expansion-panel-content v-if="telemetry && telemetry.history && telemetry.currentState">
            <div class="sorrytext" v-if="telemetry.history.length === 0">{{noDataText}}</div>
            <telemetry-canvas v-if="telemetry.history.length > 0" :telemetry="telemetryGsmResets"></telemetry-canvas>
          </v-expansion-panel-content>
        </v-expansion-panel>
      </v-expansion-panels>
    </v-row>

    <v-row>
      <v-expansion-panels v-model="openPanelPower" class="elevation-2" :class="{ 'rounded-lg ma-2': modern === true }">
        <v-expansion-panel style="cursor: auto;">
          <v-expansion-panel-header
            v-if="telemetry && telemetry.currentState && (telemetry.serialNumber.startsWith('MUF') || telemetry.serialNumber.startsWith('MUS') || telemetry.unitType.startsWith('ABAX6') || telemetry.unitType.startsWith('FM'))">
            <span>Connected to external power source</span>
            <v-tooltip bottom v-if="telemetry && telemetry.currentState">
              <template v-slot:activator="{ on }">
                <span class="icon-right" v-on="on">
                  <v-icon v-if="telemetry.currentState.power === 'Ok'"  medium color="success">mdi-check</v-icon>
                  <v-icon v-if="telemetry.currentState.power === 'Error'"  medium color="error">mdi-alert-circle</v-icon>
                  <v-icon v-if="telemetry.currentState.power === 'NotApplicable'"  medium color="primary">mdi-cancel</v-icon>
                </span>
              </template>
              <span v-html="currentStateHoverMessage"></span>
            </v-tooltip>
          </v-expansion-panel-header>
          <v-expansion-panel-content v-if="telemetry && telemetry.history && telemetry.currentState">
            <div class="sorrytext" v-if="telemetry.history.length === 0">{{noDataText}}</div>
            <telemetry-canvas v-if="telemetry.history.length > 0" :telemetry="telemetryPower"></telemetry-canvas>
          </v-expansion-panel-content>
        </v-expansion-panel>
      </v-expansion-panels>
    </v-row>

    <v-row v-if="showPlacement">
      <v-expansion-panels class="elevation-2" readonly :class="{ 'rounded-lg ma-2': modern === true }">
        <v-expansion-panel v-if="telemetry.serialNumber && !telemetry.serialNumber.startsWith('MUG')">
          <v-expansion-panel-header hide-actions style="cursor: auto;">
            <span>Placed correctly</span>
            <v-tooltip bottom v-if="telemetry && telemetry.currentState">
              <template v-slot:activator="{ on }">
                <span class="icon-right" v-on="on">
                    <v-icon v-if="telemetry.currentState.placement === 'Ok'"  medium color="success">mdi-check</v-icon>
                    <v-icon v-if="telemetry.currentState.placement === 'Error'"  medium color="error">mdi-alert-circle</v-icon>
                    <v-icon v-if="telemetry.currentState.placement === 'NotApplicable'"  medium color="primary">mdi-cancel</v-icon>
                </span>
              </template>
              <span>
                This icon represents the current state, <br/>
                we don't have historic data for this property
              </span>
            </v-tooltip>
          </v-expansion-panel-header>
        </v-expansion-panel>
      </v-expansion-panels>
    </v-row>

    <v-row>
      <v-expansion-panels readonly :class="{ 'rounded-lg ma-2': modern === true }">
        <v-expansion-panel class="elevation-2" >
          <v-expansion-panel-header hide-actions style="cursor: auto;">
            <span>GPS position received last 72 hours</span>
            <v-tooltip bottom v-if="telemetry && telemetry.currentState">
              <template v-slot:activator="{ on }">
                  <span class="icon-right" v-on="on">
                      <v-icon v-if="telemetry.currentState.positions === 'Ok'"  medium color="success">mdi-check</v-icon>
                      <v-icon v-if="telemetry.currentState.positions === 'Error'"  medium color="error">mdi-alert-circle</v-icon>
                      <v-icon v-if="telemetry.currentState.positions === 'NotApplicable'"  medium color="primary">mdi-cancel</v-icon>
                  </span>
              </template>
              <span>
                This icon represents the current state, <br/>
                we don't have historic data for this property
              </span>
            </v-tooltip>
          </v-expansion-panel-header>
        </v-expansion-panel>
      </v-expansion-panels>
    </v-row>

  </v-col>
</template>

<script>

import TelemetryCanvas from "@/components/TelemetryCanvas"
export default {
  name: "TelemetryComponent",
  components: {TelemetryCanvas},
  props: {
    telemetry: Object,
    modern: {
      type: Boolean
    },
    showPlacement: {
      type: Boolean,
      default: true
    },
    noDataText: {
      type: String,
      default: "No data available for the selected period"
    },
    currentStateHoverMessage: {
      type: String,
      default: "This icon represents the current state, <br/>the dropdown shows the state for the time period selected"
    }
  },
  computed: {
    telemetryFix() {
      return this.telemetry.history.map(x => {
        let value = 1
        if(x.fix === 'Ok') value = 5
        if(x.fix === 'Error') value = 10
        return {
          date: x.date,
          value: value
        }
      })
    },
    telemetrySatellites() {
      return this.telemetry.history.map(x => {
        let value = 1
        if(x.satellites === 'Ok') value = 5
        if(x.satellites === 'Error') value = 10
        return {
          date: x.date,
          value: value
        }
      })
    },
    telemetryPower() {
      return this.telemetry.history.map(x => {
        let value = 1
        if(x.power === 'Ok') value = 5
        if(x.power === 'Error') value = 10
        return {
          date: x.date,
          value: value
        }
      })
    },
    telemetryGsmResets(){
      return this.telemetry.history.map(x => {
        let value = 1
        if(x.resetsSinceLastMessage === 0) value = 5
        if(x.resetsSinceLastMessage > 0 ) value = 10
        return {
          date: x.date,
          value: value
        }
      })
    },
    totalResetsCount(){
      return this.telemetry.history.reduce((acc, val) => acc + val.resetsSinceLastMessage, 0)
    }

  },
  data: function(){
    return {
      failed: false,
      openPanelSolidFix: true,
      openPanelPlacedCorrectly: false,
      openPanelSatellites: false,
      openPanelPower: false,
      openPanelPositions: false,
      openPanelReset: false
    }
  },
  methods: {
    getDateString(date){
      let dateObj = new Date(date)
      let month = dateObj.toLocaleString('en-US', { month: 'short' })
      let day = dateObj.toISOString().substring(8,10).replace('-', '.')
      let res = `${month} ${day}`
      return res
    },
  }
}
</script>

<style scoped lang="scss">

.icon-right{
  position: absolute;
  right: 80px;
}

.sorrytext{
  font-size: 12px;
  text-align: center;
}
</style>
