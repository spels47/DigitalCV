﻿<template>
  <v-container>
    <v-text-field label="Alert text" v-model="textToUse"></v-text-field>
    <v-text-field label="Color code" v-model="colorToUse"></v-text-field>

    <v-chip-group
      v-model="selectedRoles"
      column
      multiple
    >
      <v-chip
        v-for="role in userRoles"
        :key="role"
        :value="role"
        filter
        outlined
      >
        {{ role }}
      </v-chip>
    </v-chip-group>

    <v-checkbox
      label="Show info banner"
      v-model="showBanner"
    ></v-checkbox>
    <v-color-picker
      v-model="colorToUse"
      hide-inputs
    ></v-color-picker>

    <v-btn @click="commitChanges">Save</v-btn>
  </v-container>
</template>

<script>
import axios from "~/axios-client";

export default {
  name: "InfoBannerSettings",
  data() {
    return {
      textToUse: "",
      showBanner: false,
      colorToUse: "",
      selectedRoles: [],
      userRoles: []
    }
  },
  async mounted() {
    this.textToUse = this.infoBannerText;
    this.showBanner = this.showInfoBanner;
    this.colorToUse = this.colorCode;

    await this.getAllUserRoles();
  },
  methods: {
    async getAllUserRoles() {
      const { data } = await axios.get("/api/RoleManagement/distinct-user-roles");
      this.userRoles = data;
      this.selectedRoles = this.currentUserRoles;
    },
    commitChanges() {
      this.$store.dispatch("changeInfoBannerSettings", {
        show: this.showBanner,
        text: this.textToUse,
        colorCode: this.colorToUse,
        userRoles: this.selectedRoles
      });
    },
  },
  computed: {
    siteSettings() {
      return this.$store.state.SiteSettingsModule.siteSettings
    },
    currentUserRoles() {
      return this.siteSettings.siteSettingsInfoBanner?.userRoles;
    },
    infoBannerText() {
      return this.siteSettings.siteSettingsInfoBanner?.text
    },
    showInfoBanner() {
      return this.siteSettings.siteSettingsInfoBanner?.show
    },
    colorCode() {
      return this.siteSettings.siteSettingsInfoBanner?.colorCode ?? ""
    }
  }
}
</script>

<style scoped>
.v-text-field {
  width: 400px;
}
</style>
