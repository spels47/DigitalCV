﻿<template>
  <v-container>
    <v-list>
      <v-list-item>
        <v-text-field class="shrink" label="E-mail" v-model="email" prepend-icon="mdi-email-outline"></v-text-field>
      </v-list-item>
      <v-list-item>
        <v-text-field class="shrink" label="Person id" v-model="personId" prepend-icon="mdi-card-account-details-outline"></v-text-field>
      </v-list-item>
      <v-list-item>
        <v-text-field class="shrink" label="Associate id" v-model="associateId" prepend-icon="mdi-numeric"></v-text-field>
      </v-list-item>
      <v-list-item-action>
        <v-btn :disabled="allInformationAdded" @click="commitChanges" rounded :loading="savingChanges">Add SuperOffice info</v-btn>
      </v-list-item-action>
    </v-list>
  </v-container>
</template>

<script>
import axios from "~/axios-client";

export default {
  name: "SuperOfficePersonInfoSettings",
  data() {
    return {
      email: "",
      personId: "",
      associateId: "",
      savingChanges: false
    }
  },
  methods: {
    async commitChanges() {
      try {
        this.savingChanges = true;
        await axios.post(`api/UserSettings/superOfficePersonInfo/${this.email}`, {
          personId: this.personId,
          associateId: this.associateId
        });
        this.$eventBus.$emit("alert", { text: "SuperOfficePersonInfo updated", type: "success"});
        this.email = "";
        this.personId = "";
        this.associateId = "";
      } catch {
        this.$eventBus.$emit('alert', { text: `User does either not exist or you are trying to override existing info`, type: 'error'});
      } finally {
        this.savingChanges = false;
      }
    },
  },
  computed: {
    allInformationAdded() {
      return this.email === "" || this.personId === "" || this.associateId === "";
    }
  }
}
</script>

<style scoped>
.v-text-field {
  width: 400px;
}
</style>
