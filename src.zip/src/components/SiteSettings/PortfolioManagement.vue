﻿<template>
  <v-layout>
    <v-flex xs2>
      <v-tabs vertical>
        <v-tab v-for="team in getAllTeams" :key="team.id" @click="changeSelectedTeam(team)">
          {{team.teamName}}
        </v-tab>
      </v-tabs>
    </v-flex>
      <v-flex xs3>
        <v-card height="100%" flat>
          <v-card-title class="justify-center">
            {{getSelectedTeam.teamName}}
          </v-card-title>
          <v-card-text>
            <v-list v-for="member in getTeamMembers" :key="member.username">
              <v-list-item>
                <v-card class="pa-3" width="100%">
                  <v-row>
                    <v-col cols="11">
                    <v-icon>mdi-account</v-icon>{{member.memberType}}: {{member.username}}
                    </v-col>
                    <v-col cols="1">
                    <v-icon color="red" @click.stop="removeUser(member.username)">mdi-delete</v-icon>
                    </v-col>
                  </v-row>
                </v-card>
              </v-list-item>
            </v-list>
          </v-card-text>
        </v-card>
      </v-flex>
      <v-flex xs3>
        <v-card height="100%" flat>
          <v-card-title>
            Add new teammember
          </v-card-title>
          <v-card-text>
            <v-text-field label="Username" v-model="username"></v-text-field>
            <v-select :items="userTypes" v-model="defaultUserType"></v-select>
            <v-btn @click="adduser">Add user</v-btn>
          </v-card-text>
        </v-card>
        <ConfirmDialog ref="confirm"></ConfirmDialog>
      </v-flex>
    </v-layout>
</template>

<script>
import axios from "@/axios-client";
import ConfirmDialog from "@/components/widgets/dialogs/ConfirmDialog";
export default {
  name: "PortfolioManagement",
  components: {
    ConfirmDialog
  },
  data() {
    return {
      allTeams: [],
      isLoading: false,
      selectedTeam: {},
      userTypes: ['User', 'TeamLeader'],
      defaultUserType: 'User',
      username: '',
    }
  },
  async mounted() {
    await this.fetchAllTeams();
  },
  methods: {
    async adduser() {
      await axios.post(`/api/portfolio/addUserToTeam`, {TeamId: this.getSelectedTeam._id, Username: this.username, TeamMemberType: this.defaultUserType}).then(response => {
        let indexToReplace = this.allTeams.findIndex(x => x._id === response.data._id)
        if(indexToReplace === -1){
          this.$eventBus.$emit('alert', { text: `User already exists in a different portfolioteam`, type: 'error'});
        }
        else{
          this.allTeams.splice(indexToReplace, 1, response.data)
          this.selectedTeam = response.data
        }
      })
    },
    async removeUser(username) {
      let confirmResult = await this.$refs.confirm.open('Remove this user?', 'Confirm removal of this portfolio user.', { width: 500, confirmLabel: `Confirm`});
      if(confirmResult){
        await axios.post(`/api/portfolio/removeUserFromTeam`, {TeamId: this.getSelectedTeam._id, Username: username}).then(response => {
          let indexToReplace = this.allTeams.findIndex(x => x._id === response.data._id)
          this.allTeams.splice(indexToReplace, 1, response.data)
          this.selectedTeam = response.data
        })
      }
    },
    changeSelectedTeam(team) {
      this.selectedTeam = this.allTeams.find(x => x._id === team._id);
    },
    async fetchAllTeams() {
      this.isLoading = true;
      await axios.get(`/api/portfolio/teams/allTeams`).then(res => {
        this.allTeams = res.data;
        this.isLoading = false;
        this.selectedTeam = this.allTeams[0]
      });
    },
    open(title, text, options) {
      this.dialog = true
      this.title = title
      this.text = text
      this.options = Object.assign(this.options, options)
      return new Promise((resolve, reject) => {
        this.resolve = resolve
        this.reject = reject
      })
    },
    agree() {
      this.resolve(true)
      this.dialog = false
    },
    cancel() {
      this.resolve(false)
      this.dialog = false
    }
  },
  computed: {
    getAllTeams() {
      return this.allTeams ?? [];
    },
    getSelectedTeam() {
      return this.selectedTeam;
    },
    getTeamMembers() {
      if(!this.getSelectedTeam.teamMembers) return [];
      return this.getSelectedTeam.teamMembers;
    }
  }
}
</script>

<style scoped>

</style>
