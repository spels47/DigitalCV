<template>
  <div class="d-flex">

    <span @click="clicked(0)" :class="{ 'secondary--text clickable': clickable && departmentPath.length > 1 }" class="no-break faded-text" v-if="departmentPath && departmentPath.length > 0">
      {{ departmentPath[0].name }}
    </span>
    <span class="no-break" v-if="departmentPath && departmentPath.length > 1">&nbsp; / &nbsp;</span>

    <div v-if="departmentPath && departmentPath.length >= 1" class="left-ellipsis">
      <span v-for="(part, index) in departmentPath" :key="part.id">
        <span @click="clicked(index)" v-if="index !== 0" :class="{ 'faded--text': index !== departmentPath.length - 1, clickable: clickable && index !== departmentPath.length - 1 }">
          {{ part.name }}
          <span v-if="index !== departmentPath.length - 1"> / </span>
        </span>
      </span>
    </div>
  </div>
</template>

<script>
export default {
  name: "DepartmentPath",
  props: {
    departmentPath: Array,
    clickable: Boolean
  },
  methods: {
    clicked(index) {
      if (!this.clickable || index === this.departmentPath.length - 1) return;
      let id = this.departmentPath[index].id;
      this.$router.push({
        name: "customer",
        params: { id: id },
        query: { activeTab: this. $utils.getDefaultTab(this.defaultTable) }
      });
    }
  },
  computed: {
    defaultTable() {
      return this.$store.state.userSettings.defaultTable;
    }
  }
};
</script>

<style scoped>
/* The reason for these classes is to have ellipsis in the middle of the cPath */
/* That way you will always see the first and last element, and those are the most important (assumption) */

.no-break {
  margin-right: 4px;
  white-space: nowrap;
}
.left-ellipsis {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  text-align: left;
  direction: rtl;
}

.fade {
  /*color: darkgrey;*/
}

.clickable {
  cursor: pointer;
}
</style>
