<template>
  <div id="swagger-container">
    <div class="swagger" :class="{ darkmode: darkMode }" id="swagger"></div>
  </div>
</template>

<script>
import SwaggerUIBundle from 'swagger-ui';
import 'swagger-ui/dist/swagger-ui.css';
import axios from "@/axios-client";

export default {
  name: "Swagger",
  async mounted() {
    let res = await axios.get('/api/config/identity-server')
    let config = res.data

    const ui = SwaggerUIBundle({
      url: '/swagger/v1/swagger.json',
      dom_id: '#swagger',
      requestInterceptor: (request) => {
        request.headers['Authorization'] = 'Bearer ' + this.$store.state.oidcStore.access_token;
        return request;
      },
    })
    ui.initOAuth({
      clientId: config.clientId,
      appName: config.clientId,
      scopeSeparator: " ",
      scopes: config.backendScopes,
      usePkceWithAuthorizationCodeGrant: true
    })
  },
  computed: {
    darkMode() {
      return this.$store.getters.darkMode;
    }
  },
}
</script>

<style lang="scss">
#swagger-container{
  div .info {
    display: none !important;
  }
  div .information-container .wrapper{
    display: none !important;
  }
  code{
    background-color: rgb(51, 51, 51) !important;
  }

  .darkmode .swagger-ui {
    color: #b7b7b7 !important;
  }

  .darkmode .col_header {
    color: #b7b7b7 !important;
  }

  .darkmode tr td div {
    color: #b7b7b7 !important;
  }

  .darkmode div .btn-group button {
    color: #b7b7b7 !important;
  }

  .darkmode table tr td {
    color: #b7b7b7 !important;
  }

  .darkmode .swagger-ui .opblock .opblock-summary-operation-id {
    color: #b7b7b7 !important;
  }

  .darkmode .swagger-ui .opblock .opblock-summary-path__deprecated {
    color: #b7b7b7 !important;
  }

  .darkmode .swagger-ui .opblock .opblock-summary-path {
    color: #b7b7b7 !important;
  }
  .darkmode .swagger-ui .opblock-tag {
    color: white !important;
  }
}

</style>
