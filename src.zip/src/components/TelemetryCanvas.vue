<template>
  <div class="canvas-wrapper">
    <canvas ref="chartCanvas" width="600" height="50" class="chart-canvas"></canvas>
    <canvas ref="hoverCanvas" width="600" height="50" class="hover-canvas"></canvas>
  </div>
</template>

<script>
export default {
  name: "TelemetryCanvas",
  props: {
    telemetry: Array
  },
  watch: {
    telemetry: async (newVal, oldVal) => {
      if(this.telemetry?.length > 0){
        await this.renderChart()
      }
    },
  },
  data: function (){
    return {
      darkMode: false
    }
  },
  async mounted() {
    this.darkMode = this.$store.getters.darkMode;

    // Ensure canvas is loaded before draw
    setTimeout(async () => {
      if (this.telemetry?.length > 0) {
        await this.renderChart()
      }
    },0)

    this.$refs.hoverCanvas.onmousemove = this.handleMouseMove
    this.$refs.hoverCanvas.ontouchmove = this.handleTouchMove
    this.$refs.hoverCanvas.ontouchleave = this.handleMouseLeave
    this.$refs.hoverCanvas.onmouseleave = this.handleMouseLeave
  },
  methods: {
    handleTouchMove(e){
      if(!this.telemetry || this.telemetry.length === 0) return

      let touch = e.touches[0];
      this.handleMouseMove({clientX: touch.clientX, clientY: touch.clientY });
    },
    handleMouseMove(e) {
      if(!this.telemetry || this.telemetry.length === 0) return

      let c = this.$refs.hoverCanvas;
      let rect = c.getBoundingClientRect();
      c.width = rect.width
      c.height = rect.height
      let mouseX = parseInt(e.clientX - rect.left);
      let ctx = c.getContext("2d");
      let stepX = c.width / (this.telemetry.length-1)
      let point = Math.round(mouseX/stepX)
      // Drag events can drag outside the canvas while reporting position
      if(point < 0 || point > (this.telemetry.length-1)) return
      ctx.clearRect(0, 0, c.width, c.height)
      let textX = mouseX > c.width-150 ? mouseX-150 : mouseX
      let textY = c.height / 2
      ctx.font = "bold 16px Roboto";
      ctx.fillStyle = this.darkMode ? '#FFFFFF' : '#000000'
      ctx.fillText(this.telemetry[point].date.substring(0, 10), textX+15, textY+15);
      ctx.strokeStyle = this.darkMode ? '#FFFFFF' : '#000000'
      ctx.beginPath()
      ctx.moveTo(mouseX, 0)
      ctx.lineTo(mouseX, c.height)
      ctx.stroke();
    },
    handleMouseLeave() {
      let c = this.$refs.hoverCanvas;
      let rect = c.getBoundingClientRect();
      c.width = rect.width
      c.height = rect.height
      let ctx = c.getContext("2d");
      ctx.clearRect(0, 0, c.width, c.height)
    },
    async renderChart() {
      let c = this.$refs.chartCanvas
      let rect = c.getBoundingClientRect();
      c.width = rect.width
      c.height = rect.height
      let ctx = c.getContext("2d");
      ctx.clearRect(0, 0, c.width, c.height);
      ctx.height = c.innerHeight
      ctx.width = c.innerWidth
      let stepX = c.width / (this.telemetry.length-1)
      if(this.telemetry.length === 1) stepX = c.width
      let max = 13
      let min = 0
      let stepY = c.height / (max - min)

      // Set origin bottom left
      ctx.translate(0, c.height);
      ctx.scale(1, -1);
      ctx.beginPath();
      ctx.moveTo(0, (this.telemetry[0].value-min)*stepY);

      for(let i = 0; i < this.telemetry.length; i++){
        let color = '#737373'
        if(this.telemetry[i].value === 10) color = '#e5043a'
        if(this.telemetry[i].value === 5) color = '#25BACA'
        ctx.fillStyle = color
        ctx.strokeStyle = color
        ctx.beginPath();
        ctx.rect(i*stepX, min, stepX, (this.telemetry[i].value-min)*stepY);
        // Uncomment to fill:
        // ctx.fillRect(i*stepX, min, stepX+0.5, (this.telemetry[i].value-min)*stepY+0.5);
        ctx.closePath();
        ctx.stroke()
      }
      ctx.stroke()
    }
  },
}
</script>

<style scoped>
.canvas-wrapper{
  position: relative;
  width: 100%;
  height: 50px;
}
.chart-canvas{
  width: 100%;
  height: 100%;
}
.hover-canvas{
  position: absolute;
  width: 100%;
  height: 100%;
  left: 0;
  top: 0;
}
</style>
