<template>
  <v-card class="customer-score-card" max-width="200px">
      <div class="card-header" style="min-height:145px;">
        <v-list-item>
          <v-list-item-content>
            <v-list-item-title class="headline white--text">{{ getTitle }}</v-list-item-title>
            <v-list-item-subtitle class="white--text" style="white-space: pre-wrap;">{{ getDescription }}</v-list-item-subtitle>
            <v-list-item-title v-if="iconForTotal" >
              <v-icon x-large color="white" class="mt-7">{{iconInsteadOfTotal}}</v-icon>
            </v-list-item-title>
            <v-list-item-title v-if="!iconForTotal && showAsPercentage" :class="getClass">
              <strong>{{ getResult }}%</strong>
            </v-list-item-title>
            <v-list-item-title v-if="!iconForTotal && !showAsPercentage" :class="getClass">
              <strong>{{ getResult }}</strong>
            </v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </div>
    <div>
      <v-list dense v-if="getListItems !== '' && !featuresList">
        <v-list-item v-for="(item, index) in getListItems" v-bind:key="item.name + index">
          <v-list-item-title style="overflow: visible;" width="50" class="text-left">{{ item.name }}</v-list-item-title>
          <v-list-item-subtitle class="text-right">
            <strong v-if="item.check == null && showAsPercentage">{{ item.value }}%</strong>
            <strong v-if="item.check == null && !showAsPercentage">{{ item.value }}</strong>
            <v-icon v-if="item.check != null && item.check" color="secondary">mdi-check-circle</v-icon>
            <v-icon v-if="item.check != null && !item.check" color="error">mdi-close-circle</v-icon>
          </v-list-item-subtitle>
        </v-list-item>
      </v-list>
      <v-list dense v-if="getListItems !== '' && featuresList">
        <v-list-item @click="showFeatureListDialog = true">
          <v-list-item-title style="overflow: visible;" width="50" class="text-left">Show all</v-list-item-title>
          <v-list-item-subtitle class="text-right">
            <strong><v-icon>mdi-arrow-down-drop-circle</v-icon></strong>
          </v-list-item-subtitle>
        </v-list-item>
      </v-list>
    </div>
    <v-dialog v-if="showFeatureListDialog" width="700" value="true" @click:outside="showFeatureListDialog = false">
      <v-card>
        <v-container>
        <v-card-title>Active Features</v-card-title>
        <v-row>
          <v-col>
            <v-list dense v-if="getListItems !== ''">
              <v-list-item v-for="(item, index) in getListItems" v-bind:key="item.name + index">
                <v-list-item-title class="text-left">{{ item.name }}</v-list-item-title>
              </v-list-item>
            </v-list>
          </v-col>
        </v-row>
        <v-row>
          <v-col class="text-center">
            <v-btn color="primary" text @click="showFeatureListDialog = false">Close</v-btn>
          </v-col>
        </v-row>
        </v-container>
      </v-card>
    </v-dialog>
    </v-card>
</template>

<script>
export default {
  props: ["card", "title", "description", "listItems", "totalScore", "showValuesAsPercentage", "iconInsteadOfTotal", "resultColor", "featuresList"],
  data() {
    return {
      showFeatureListDialog: false,
      scoreBrackets: {
        ok: 60,
        error: 30
      }
    };
  },
  methods: {
    getScoreColor() {
      if (this.card?.result <= this.scoreBrackets.error) return "error--text";
      else if (this.card?.result >= this.scoreBrackets.ok) return "success--text";
      else return "warning--text";
    },
  },
  computed: {
    getTitle() {
      if(this.title !== undefined) return this.title;
      if(this.card !== undefined) return this.card.header;
      return ""
    },
    getDescription() {
      if(this.description !== undefined) return this.description;
      if(this.card !== undefined) return this.card.desc;
      return ""
    },
    getResult() {
      if(this.totalScore !== undefined) return this.totalScore;
      if(this.card !== undefined) return this.card.result;
      return ""
    },
    getListItems() {
      if(this.listItems !== undefined) return this.listItems;
      if(this.card !== undefined && this.card.details.length > 0) return this.card.details;
      return ""
    },
    showAsPercentage() {
      return this.showValuesAsPercentage ?? true;
    },
    iconForTotal() {
      return this.iconInsteadOfTotal !== undefined;
    },
    getClass() {
      let setup = "";
      let color = "";
      if(this.showAsPercentage){
        setup = "display-3 ";
      }
      else{
        if(this.getResult.length > 4){
          setup = "mt-5";
        }
        else{
          setup = "display-3"
        }
      }

      if(this.resultColor !== undefined){
        color = this.resultColor;
      }
      else{
        if(this.showAsPercentage){
          color = this.getScoreColor()
        }
        else{
          color = "success--text"
        }
      }
      return setup + " " + color;
    }
  }
};
</script>

<style scss-scoped>
.customer-score-card {
  text-align: center;
}
.card-header {
  background-color: black;
}
</style>
