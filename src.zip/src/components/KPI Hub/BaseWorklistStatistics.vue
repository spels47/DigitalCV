<template>
  <v-container fluid>
    <v-row class="text-center">
      <v-col class="d-flex justify-center mt-3 mb-5">
        <v-icon>mdi-flag-variant</v-icon>
        <h3 class="ml-2">Statistics for {{ statisticsFor }}</h3>
      </v-col>
    </v-row>
    <v-row
      no-gutters
    >
      <v-col class="d-flex justify-center">
        <v-menu
          :close-on-content-click="false"
          :return-value.sync="dateRange"
          v-model="showDateRangeMenu"
          transition="scale-transition"
          ref="menu"
          offset-y
        >
          <template v-slot:activator="{ on, attrs }">
            <v-text-field
              :value="dateRangeText"
              label="Date range"
              prepend-icon="mdi-calendar"
              style="max-width: 220px"
              class="centered-input"
              readonly
              v-on="on"
              v-bind="attrs"
            ></v-text-field>
          </template>

          <v-card
            class="mx-auto rounded-lg"
            max-width="375"
          >
            <v-card-title>Choose date-range</v-card-title>
            <v-card-subtitle>Only show data between a certain range.</v-card-subtitle>

            <v-divider></v-divider>

            <v-card-text class="px-1">
              <v-date-picker
                v-model="dateRange"
                color="secondary darken-1"
                scrollable
                width="375"
                :first-day-of-week="1"
                range
                no-title
              ></v-date-picker>

              <div class="d-flex justify-center">
                <v-chip-group>
                  <v-chip small @click="changeDateRangeToMonthsBack(3)">Last 3 months</v-chip>
                  <v-chip small @click="changeDateRangeToMonthsBack(6)">Last 6 months</v-chip>
                  <v-chip small @click="changeDateRangeToMonthsBack(12)">Last 12 months</v-chip>
                </v-chip-group>
              </div>
            </v-card-text>

            <v-card-actions>
              <v-spacer></v-spacer>

              <v-btn
                text
                color="primary"
                @click="showDateRangeMenu = false"
              >
                Cancel
              </v-btn>
              <v-btn
                text
                color="secondary"
                @click="changeDateRange"
              >
                Select
              </v-btn>
            </v-card-actions>
          </v-card>
        </v-menu>
      </v-col>
    </v-row>

    <v-divider class="pa-2"></v-divider>

    <v-row>
      <v-col cols="3">
        <SimpleCardStatistic :title="getStatisticsHeaders.totalCompleted + ' in period'" :icon="'mdi-check'" :loading="loading" :statistics="totalCompletedForPeriod"/>
      </v-col>
      <v-col cols="3">
        <SimpleCardStatistic :title="getStatisticsHeaders.totalPending + ' in period'" :icon="'mdi-circle'" :loading="loading" :statistics="totalPendingForPeriod"/>
      </v-col>
      <v-col cols="3">
        <SimpleCardStatistic :title="getStatisticsHeaders.totalIgnored + ' in period'" :icon="'mdi-cancel'" :loading="loading" :statistics="totalIgnoredForPeriod"/>
      </v-col>
      <v-col cols="3">
        <SimpleCardStatistic :title="getStatisticsHeaders.totalCreated + ' in period'" :icon="'mdi-clipboard'" :loading="loading" :statistics="totalCreatedForPeriod"/>
      </v-col>
    </v-row>
    <v-layout row>
      <v-flex xs6 class="pa-1">
          <ApexTimeChart
            :statistic="worklistCreatedStatistics"
            :chart-type="'line'"
            :name="getStatisticsHeaders.tasksCreated"
            :sub-title="'Total ' + getStatisticsHeaders.tasksCreated.toLowerCase() + ' in period: ' + totalCreatedForPeriod"
            :date-range="dateRangeToShare"
            :loading="isLoading"
            @update:values="totalCreatedForPeriod = $event"
            use-date-range-filter
          />
      </v-flex>
      <v-flex xs6 class="pa-1">
        <ApexTimeChart
          :statistic="worklistIgnoredStatistics"
          :date-range="dateRangeToShare"
          :chart-type="'line'"
          :name="getStatisticsHeaders.tasksIgnored"
          :sub-title="'Total ' + getStatisticsHeaders.tasksIgnored.toLowerCase() + ' in period: ' + totalIgnoredForPeriod"
          :chartColor="'#4CAA71'"
          :loading="isLoading"
          @update:values="totalIgnoredForPeriod = $event"
          use-date-range-filter
        />
      </v-flex>
      <v-flex xs6 class="pa-1">
        <ApexTimeChart
          :statistic="worklistCompletedStatistics"
          :date-range="dateRangeToShare"
          :chart-type="'line'"
          :name="getStatisticsHeaders.tasksCompleted"
          :sub-title="'Total ' + getStatisticsHeaders.tasksCompleted.toLowerCase() + ' in period: ' + totalCompletedForPeriod"
          :chartColor="'#4CAA71'"
          :loading="isLoading"
          @update:values="totalCompletedForPeriod = $event"
          use-date-range-filter
        />
      </v-flex>
      <v-flex xs6 class="pa-1" v-if="worklistType !== 'Swap'">
        <ApexBarChart
          :title="getStatisticsHeaders.completedBy"
          subtitle="Top 5 performers in period"
          :statistics="worklistCallsCompletedBy"
          :loading="isLoading"
          :item-description="'Tasks'"
          :date-range="dateRangeToShare"
          use-date-range-filter
        ></ApexBarChart>
      </v-flex>
      <template v-if="worklistType === 'Swap'">
      <TopSwappersKpi :statistics="worklistStatistics" :loading="isLoading" :dateRangeToShare="dateRangeToShare"></TopSwappersKpi>
      <SwapReasonsKpi :statistics="worklistStatistics" :loading="isLoading"></SwapReasonsKpi>
      <PendingHotSwapsKpi :statistics="worklistStatistics" :loading="isLoading"></PendingHotSwapsKpi>
      </template>
    </v-layout>
    <v-row>
      <WelcomeCallStatistics v-if="worklistType === 'WelcomeCall'" :statistics="worklistStatistics" :loading="isLoading"></WelcomeCallStatistics>
    </v-row>
  </v-container>
</template>
<script>
import axios from "@/axios-client";
import ApexTimeChart from "@/components/widgets/Charts/ApexTimeChart";
import WelcomeCallStatistics from "@/components/KPI Hub/WorklistStatistics/WelcomeCall/WelcomeCallStatistics";
import SimpleCardStatistic from "@/components/KPI Hub/widgets/SimpleCardStatistic";
import ApexBarChart from "@/components/widgets/Charts/ApexBarChart.vue";
import TopSwappersKpi from "@/components/KPI Hub/WorklistStatistics/SwapRequests/TopSwappersKpi";
import PendingHotSwapsKpi from "@/components/KPI Hub/WorklistStatistics/SwapRequests/PendingHotSwapsKpi";
import moment from "moment/moment";
import SwapReasonsKpi from "@/components/KPI Hub/WorklistStatistics/SwapRequests/SwapReasonsKpi";

export default {
  name: "BaseWorklistStatistics",
  props: ["worklistType"],
  components: {
    SwapReasonsKpi,
    ApexBarChart,
    ApexTimeChart,
    WelcomeCallStatistics,
    SimpleCardStatistic,
    TopSwappersKpi,
    PendingHotSwapsKpi
  },
  data() {
    return {
      showDateRangeMenu: false,
      loading: false,
      worklistStatistics: {},
      worklistCreatedStatistics: {},
      worklistCompletedStatistics: {},
      worklistIgnoredStatistics: {},
      worklistCallsCompletedBy: {},
      dateRange: [new Date(moment().subtract(1, "month").format()).toISOString_ntz().substring(0, 10), new Date(moment().format()).toISOString_ntz().substring(0, 10)],
      dateRangeToShare: [new Date(moment().subtract(1, "month").format()).toISOString_ntz().substring(0, 10), new Date(moment().format()).toISOString_ntz().substring(0, 10)],
      totalCreatedForPeriod: 0,
      totalIgnoredForPeriod: 0,
      totalCompletedForPeriod: 0
    }
  },
  async mounted() {
    await this.$store.dispatch("PortfolioTeamModule/retrieveAllTeams")
    await this.fetchWorklistStatistics();
  },
  methods: {
    changeDateRangeToMonthsBack(months) {
      this.dateRange = [new Date(moment().subtract(months, "month").format()).toISOString_ntz().substring(0, 10), new Date(moment().format()).toISOString_ntz().substring(0, 10)];
    },
    changeDateRange() {
      this.$refs.menu.save(this.dateRange);
      this.dateRangeToShare = this.dateRange;
    },
    async fetchWorklistStatistics() {
      try {
        this.loading = true;
        let query = ""
        if (!this.worklistType) return;
        if (this.worklistType === "WelcomeCall" || this.worklistType === "Swap") {
          query = `api/worklist/overview/${this.worklistType}?country=${this.defaultCountry}`
        } else {
          if (this.myTeam._id.length === 2) {
            query = `api/worklist/overview/${this.worklistType}?country=${this.myTeam._id}`
          } else {
            query = `api/worklist/overview/${this.worklistType}?teamId=${this.myTeam._id}`
          }
        }
        const { data } = await axios.get(query);
        this.worklistStatistics = data;
        this.worklistCreatedStatistics = data.CreatedPerUniqueDateTimeCount;
        this.worklistCompletedStatistics = data.CompletedPerUniqueDateTimeCount;
        this.worklistIgnoredStatistics = data.IgnoredPerUniqueDateTimeCount;
        this.worklistCallsCompletedBy = data.CompletedByList;
      } finally {
        this.loading = false;
      }
    },
  },
  watch: {
    defaultCountry: {
      deep: true,
      async handler() {
        await this.fetchWorklistStatistics();
      }
    },
    worklistType: {
      deep: true,
      async handler() {
        await this.fetchWorklistStatistics();
      }
    },
    myTeam: {
      deep: true,
      async handler() {
        await this.fetchWorklistStatistics();
      }
    },
  },
  computed: {
    dateRangeText() {
      const localCopy = this.dateRange;
      return localCopy.sort().map(date => moment(date).format("DD/MM/YYYY")).join(" - ");
    },
    myTeam() {
      if (this.roles.KPI_HUB_PORTFOLIO_WORKLISTS || this.roles.KPI_HUB_WORKLISTS) return this.selectedTeamOrCountry;
      return this.$store.state.PortfolioTeamModule.myTeam;
    },
    currentCountry() {
      return this.$store.state.PortfolioTeamModule.currentCountry;
    },
    currentTeam() {
      return this.$store.state.PortfolioTeamModule.currentTeam
    },
    selectedTeamOrCountry() {
      let result = {}
      if (this.currentTeam === null) {
        result = this.currentCountry
      } else {
        result = this.currentTeam;
      }
      return result;
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    statisticsFor() {
      if (this.isLoading) return "";
      let statsFor = this.worklistStatistics.StatisticsFor;
      if (statsFor === undefined) statsFor = this.defaultCountry
      switch (statsFor) {
        case "NO":
          return "Norway";
        case "SE":
          return "Sweden";
        case "FI":
          return "Finland";
        case "DK":
          return "Denmark";
        case "GB":
          return "UK";
        case "FR":
          return "France";
        case "BE":
          return "Belgium";
        case "NL":
          return "Netherlands";
        case "PL":
          return "Poland";
        case "ALL":
          return "all countries";
        default:
          return statsFor;
      }
    },
    defaultCountry() {
      return this.$store.state.userSettings.defaultCountry
    },
    isLoading() {
      return this.loading;
    },

    getStatisticsHeaders() {
      let headers = {};
      switch (this.worklistType) {
        default: {
          headers.totalCompleted = "Total completed";
          headers.completedBy = "Tasks completed by"
          headers.totalIgnored = "Total ignored";
          headers.totalPending = "Total pending";
          headers.totalCreated = "Total created";
          headers.tasksCreated = "Tasks created";
          headers.tasksIgnored = "Tasks ignored";
          headers.tasksCompleted = "Tasks completed";
          return headers;
        }
        case 'Swap': {
          headers.totalCompleted = "Total completed by logistics";
          headers.totalIgnored = "Total declined by logistics";
          headers.totalPending = "Total pending on logistics";
          headers.totalCreated = "Total requests sent to logistics";
          headers.tasksCreated = "Requests sent to logistics";
          headers.tasksIgnored = "Requests declined by logistics";
          headers.tasksCompleted = "Requests completed by logistics";
          return headers;
        }
      }
    },
    totalPendingForPeriod() {
      let pending = (this.totalCreatedForPeriod - (this.totalCompletedForPeriod + this.totalIgnoredForPeriod));
      return pending > 0 ? pending : 0;
    }
  }
}
</script>

<style lang="scss">
.v-text-field.centered-input .v-label {
  left: 45% !important;
  top: 5px;
  transform: translateX(-50%);

  &.v-label--active {
    transform: translateY(-18px) scale(.75) translateX(-50%);
  }
}

.centered-input > > > label {
  text-align: center;
}

.centered-input > > > input {
  text-align: center;
}
</style>
