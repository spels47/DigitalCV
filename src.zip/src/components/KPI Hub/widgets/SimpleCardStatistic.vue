﻿<template>
  <v-card :loading="loading" class="text-center">
    <v-list>
      <v-list-item-title class="font-weight-bold">{{ title }}</v-list-item-title>
      <v-list-item>
        <v-list-item-content>
          <v-list-item-title>
            <v-icon class="mr-1">{{ icon }}</v-icon>
            {{statistics}}
          </v-list-item-title>
        </v-list-item-content>
      </v-list-item>
    </v-list>
  </v-card>
</template>

<script>

export default {
  props: ["title", "icon", "statistics", "loading"],
}
</script>

<style scoped>

</style>
