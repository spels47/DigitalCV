﻿<template>
  <v-flex xs6 class="pa-1">
    <ApexBarChart
      title="Top swappers"
      :subtitle="'Requests in period'"
      :statistics="topSwappers"
      :loading="loading"
      :item-description="'Tasks'"
      :date-range="dateRange"
      use-date-range-filter
    ></ApexBarChart>
  </v-flex>
</template>

<script>
import ApexBarChart from "@/components/widgets/Charts/ApexBarChart";

export default {
  name: "TopSwappersKpi",
  props: {
    statistics: {
      type: Array,
      required: true,
    },
    loading: {
      type: Boolean,
      required: true,
    },
    dateRangeToShare: {
      type: Array,
      required: true,
    }
  },
  components: {
    ApexBarChart
  },
  data() {
    return {
    }
  },
  computed: {
    topSwappers() {
      return this.statistics.RequestedBy
    },
    dateRange() {
      return this.dateRangeToShare
    }
  }
}
</script>

<style scoped>

</style>
