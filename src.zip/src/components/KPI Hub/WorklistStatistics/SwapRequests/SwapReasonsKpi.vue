﻿<template>
  <v-flex xs6 class="pa-1">
    <ApexBarChart
      :statistics="swapReasonUniqueCount"
      :title="'Swap reasons (completed)'"
      :subtitle="'Top 5 most common swap reasons'"
      :loading="loading"
      :item-description="'Amount'"
    />
  </v-flex>
</template>

<script>
import ApexBarChart from "@/components/widgets/Charts/ApexBarChart";
export default {
  name: "SwapReasonsKpi",
  props: {
    statistics: {
      type: Array,
      required: true,
    },
    loading: {
      type: Boolean,
      required: true,
    },
  },
  components: {
    ApexBarChart
  },
  computed: {
    swapReasonUniqueCount() {
      return this.statistics.SwapReasonUniqueCount
    },
  }
}
</script>

<style scoped>

</style>
