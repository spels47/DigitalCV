﻿<template>
  <v-flex xs6 class="pa-1">
    <ApexTimeChart
      :statistic="pendingHotSwapsUniqueCount"
      :name="'Pending hot-swaps'"
      :subTitle="'Total pending hot-swaps: ' + totalPendingHotSwaps"
      :chart-type="'line'"
      :strokeType="'smooth'"
      :loading="loading"
    >
    </ApexTimeChart>
  </v-flex>
</template>

<script>
import ApexTimeChart from "@/components/widgets/Charts/ApexTimeChart";
export default {
  name: "PendingHotSwapsKpi",
  props: {
    statistics: {
      type: Array,
      required: true,
    },
    loading: {
      type: Boolean,
      required: true,
    },
  },
  components: {
    ApexTimeChart
  },
  computed: {
    pendingHotSwapsUniqueCount() {
      return this.statistics.PendingHotSwapsDateCount
    },
    totalPendingHotSwaps() {
      return this.statistics.TotalPendingHotSwaps
    },
  }
}
</script>

<style scoped>

</style>
