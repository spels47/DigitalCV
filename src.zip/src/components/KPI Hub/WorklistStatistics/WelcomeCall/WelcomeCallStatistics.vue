﻿<template>
  <v-container fluid>
    <v-row>
      <v-col>
        <SimpleCardStatistic :title="'Average amount of units'" :icon="'mdi-cable-data'" :loading="loading" :statistics="averageNumberOfUnits"/>
      </v-col>
      <v-col>
        <SimpleCardStatistic :title="'Average amount of minis'" :icon="'mdi-hockey-puck'" :loading="loading" :statistics="averageNumberOfMinis"/>
      </v-col>
    </v-row>
    <v-row>
      <v-col>
        <ApexRadialChart
          :title="'Average installation degree before call'"
          :statistics="[averageInstallationDegreePreCall]"
          :loading="loading"
        ></ApexRadialChart>
      </v-col>
      <v-col>
        <ApexRadialChart
          :title="'Average installation degree after call'"
          :statistics="[averageInstallationDegreeAfterCall]"
          :loading="loading"
        ></ApexRadialChart>
      </v-col>
      <v-col>
        <ApexRadialChart
          :title="'Average regno degree before call'"
          :statistics="[averageAddedRegnoDegreePreCall]"
          :loading="loading"
        ></ApexRadialChart>
      </v-col>
      <v-col>
        <ApexRadialChart
          :title="'Average regno degree after call'"
          :statistics="[averageAddedRegnoDegreeAfterCall]"
          :loading="loading"
        ></ApexRadialChart>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import SimpleCardStatistic from "@/components/KPI Hub/widgets/SimpleCardStatistic";
import ApexRadialChart from "@/components/widgets/Charts/ApexRadialChart";

export default {
  name: "WelcomeCallStatistics",
  props: ["statistics", "loading"],
  components: {
    SimpleCardStatistic,
    ApexRadialChart
  },
  data: () => ({

  }),
  computed: {
    averageInstallationDegreePreCall() {
      return this.statistics.InstallationDegreePreCall
    },
    averageInstallationDegreeAfterCall() {
      return this.statistics.InstallationDegreePostCall
    },
    averageAddedRegnoDegreePreCall() {
      return this.statistics.RegNoDegreePreCall
    },
    averageAddedRegnoDegreeAfterCall() {
      return this.statistics.RegNoDegreePostCall
    },
    averageNumberOfUnits() {
      return this.statistics.AverageNumberOfUnits
    },
    averageNumberOfMinis() {
      return this.statistics.AverageNumberOfMinis
    }

  }
}
</script>

<style scoped>

</style>
