﻿<template>
  <v-container fluid>
    <v-row class="text-center">
      <v-col class="d-flex justify-center mb-5 mt-3">
        <v-icon>mdi-flag-variant</v-icon>
        <h3 class="ml-2">Statistics for {{ getCountryFromCode() }}</h3>
      </v-col>
    </v-row>
    <v-divider></v-divider>
    <v-row>
      <v-col>
        <ApexTimeChart
          :name="'Average MRR per customer'"
          :statistic="averageMrr"
          :chartColor="'#00b7bd'"
          :xAxis="{ format: 'MMM YYYY' }"
          :loading="loading"
          :format-as-currency="{ value: true, country: this.defaultCountry }"
        />
      </v-col>
      <v-col>
        <ApexTimeChart
          :name="'Average amount of main subscriptions'"
          :statistic="averageActiveMainSubscriptions"
          :chartColor="'#00b7bd'"
          :xAxis="{ format: 'MMM YYYY' }"
          :loading="loading"
        />
      </v-col>
      <v-col>
        <ApexTimeChart
          :name="'Average price per. main subscription'"
          :statistic="averagePricePerMainSubscription"
          :chartColor="'#00b7bd'"
          :xAxis="{ format: 'MMM YYYY' }"
          :loading="loading"
          :format-as-currency="{ value: true, country: this.defaultCountry }"
        />
      </v-col>
    </v-row>
    <v-row @click="toTheMoon()">
      <v-col>
        <ApexTimeChart
          :name="'Total MRR'"
          :statistic="totalMRR"
          :chartColor="'#00b7bd'"
          :xAxis="{ format: 'MMM YYYY' }"
          :loading="loading"
          :format-as-currency="{ value: true, country: this.defaultCountry }"
        />
      </v-col>
      <!--
      <v-col>
        <ApexTimeChart
          :name="'Total customers'"
          :statistic="totalCustomers"
          :chartColor="'#00b7bd'"
          :xAxis="{ format: 'MMM YYYY' }"
          :loading="loading"
        />
      </v-col>
      -->
      <v-col>
        <ApexTimeChart
          :name="'Average installation degree'"
          :statistic="averageInstallationDegree"
          :chartColor="'#00b7bd'"
          :xAxis="{ format: 'MMM YYYY' }"
          :percent="true"
          :loading="loading"
        />
      </v-col>
      <v-col>
        <ApexTimeChart
          :name="'Average customer score'"
          :statistic="averageCustomerScore"
          :chartColor="'#00b7bd'"
          :xAxis="{ format: 'MMM YYYY' }"
          :percent="true"
          :loading="loading"
        />
      </v-col>
    </v-row>
    <v-row>
      <v-col cols="8">
        <div @click="toTheMoon()" class="hidden-button"></div>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import axios from "@/axios-client";
import ApexTimeChart from "@/components/widgets/Charts/ApexTimeChart";

export default {
  name: "CustomerKPI",
  components: { ApexTimeChart },
  data() {
    return {
      loading: false,
      statistics: null,
      easterEggMode: false,
      moonClicks: 0
    };
  },
  async mounted() {
    await this.fetchCustomerStatistics();
  },
  watch: {
    async defaultCountry() {
      await this.fetchCustomerStatistics();
    },
  },
  methods: {
    async fetchCustomerStatistics() {
      this.loading = true;

      try {
        const { data } = await axios.get(`api/customerStatistics/history?country=${this.defaultCountry}`);
        this.statistics = data.statistics;
      } catch {
        this.$eventBus.$emit('alert', { text: 'Failed retrieving history statistics', type: 'error' });
      } finally {
        this.loading = false;
      }
    },
    getCountryFromCode() {
      return this.$utils.getCountryFromCode(this.defaultCountry);
    },
    toTheMoon() {
      this.moonClicks++;
      if (this.moonClicks != 5) return;

      let canvases = document.getElementsByClassName('apexcharts-canvas');

      for (const element of canvases) {
        element.classList.add('to-the-moon-graph');
      }

      setTimeout(x => {
        let img = document.createElement("img");
        img.classList.add('moon1');
        img.src = "/easter-eggs/moon1.gif";
        document.body.appendChild(img);

        let img2 = document.createElement("img");
        img2.classList.add('money1');
        img2.src = "/easter-eggs/money1.gif";
        document.body.appendChild(img2);

        let img3 = document.createElement("img");
        img3.classList.add('money2');
        img3.src = "/easter-eggs/money1.gif";
        document.body.appendChild(img3);

        this.$confetti.start({
          defaultSize: 5,
          particles: 5,
          defaultDropRate: 5,
          defaultType: 'rect'
        });

      }, 3000);

      setTimeout(x => {
        let audio1 = new Audio('/easter-eggs/airhorn.mp4');
        audio1.volume = 0.5;
        audio1.play();
      }, 2100);

      setTimeout(x => {
        let audio2 = new Audio('/easter-eggs/money-boom.webm');
        audio2.currentTime = 63;
        audio2.play();
        audio2.currentTime = 63;
      }, 3500);

      // this.easterEggMode = true
      // setTimeout(x => {
      //   this.easterEggMode = false
      // }, 5000)
    }
  },
  computed: {
    averageMrr() {
      return (this.statistics === null || this.statistics === undefined) ? [] : this.statistics[0].valueSet;
    },
    averagePricePerMainSubscription() {
      return (this.statistics === null || this.statistics === undefined) ? [] : this.statistics[2].valueSet;
    },
    averageActiveMainSubscriptions() {
      return (this.statistics === null || this.statistics === undefined) ? [] : this.statistics[3].valueSet;
    },
    averageInstallationDegree() {
      return (this.statistics === null || this.statistics === undefined) ? [] : this.statistics[4].valueSet;
    },
    averageCustomerScore() {
      return (this.statistics === null || this.statistics === undefined) ? [] : this.statistics[5].valueSet;
    },
    totalMRR() {
      return (this.statistics === null || this.statistics === undefined) ? [] : this.statistics[6].valueSet;
    },
    totalCustomers() {
      return this.statistics === null ? [] : this.statistics[7].valueSet;
    },
    defaultCountry() {
      return !this.$store.state.userSettings.defaultCountry ? "NO" : this.$store.state.userSettings.defaultCountry;
    }
  }
};
</script>

<style>

.money1 {
  position: absolute;
  bottom: 10px;
  left: 50px;
}

.money2 {
  position: absolute;
  bottom: 10px;
  right: 50px;
}

.moon1 {
  position: absolute;
  top: 800px;
  left: 100px;
  animation-name: moon1-animation;
  animation-duration: 3s;
  animation-iteration-count: infinite;
  animation-timing-function: ease-in-out;
}

@keyframes moon1-animation {
  0% {
    transform: translate(0, 0px);
  }
  50% {
    transform: translate(500px, -150px) rotate(-40deg);
  }
  100% {
    transform: translate(2800px, -3050px) rotate(-40deg);
  }
}

.to-the-moon-graph {
  transform: rotate(-40deg);
  animation-name: to-the-moon-graph-animation;
  animation-duration: 4s;
  animation-timing-function: ease-out;
}

@keyframes to-the-moon-graph-animation {
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(-40deg);
  }
}

.hidden-button {
  width: 100%;
  height: 100%;
}


</style>
