﻿<template>
  <v-container fluid>
    <v-row justify="center">
      <v-col md="12">
        <TeamDetails v-if="showTeamDetails" :currentTeam="selectedTeamOrCountry"/>
      </v-col>
    </v-row>
    <v-row>
      <v-col v-for="(item, index) in stats" cols="3" :key="index">
        <v-card class="rounded-lg">
          <ApexTimeChart
            :name="cleanupHeaderName(item.propertyName)"
            :statistic="item.valueSet"
            :format-as-currency="{ value: shouldFormatAsCurrency(item.propertyName), country: selectedTeamOrCountry.country }"
            :loading="loading"
          ></ApexTimeChart>
        </v-card>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
import ApexTimeChart from "@/components/widgets/Charts/ApexTimeChart";
import TeamDetails from "@/components/Portfolio/widgets/TeamDetails";
import axios from "@/axios-client";
import CustomerStatisticsHelpers from "@/helpers/CustomerStatisticsHelpers";

export default {
  name: "BasePortfolioStatistics",
  components: {ApexTimeChart, TeamDetails},
  props: ["showTeamDetails"],
  data() {
    return {
      statistics: {},
      loading: false,
    };
  },
  async mounted() {
    await this.getTeamStatistics()
  },
  watch: {
    selectedTeamOrCountry: {
      handler: function () {
        this.getTeamStatistics();
      },
      deep: true
    }
  },
  methods: {
    shouldFormatAsCurrency(propertyName) {
      switch (propertyName.toLowerCase()) {
        case "mrr":
        case "averagepricepermainsub":
        case "totalmrr":
          return true;
        default:
          return false;
      }
    },
    async getTeamStatistics() {
      this.loading = true;
      try {
        if(!this.selectedTeamOrCountry._id) return null;
        if(this.selectedTeamOrCountry._id.length === 2){
          const { data } = await axios.get(`/api/portfolio/team/statistics?country=${this.selectedTeamOrCountry._id}`);
          this.statistics = data;
        }
        else{
          const { data } = await axios.get(`/api/portfolio/team/statistics?teamId=${this.selectedTeamOrCountry._id}`);
          this.statistics = data;
        }
      } catch {
        this.$eventBus.$emit('alert', {template: 'api-error'});
      } finally {
        this.loading = false;
      }
    },
    cleanupHeaderName(statTitle) {
      return CustomerStatisticsHelpers.cleanupStatisticHeaderName(statTitle);
    }
  },
  computed: {
    currentTeam() {
      return this.$store.state.PortfolioTeamModule.currentTeam;
    },
    currentCountry() {
      return this.$store.state.PortfolioTeamModule.currentCountry;
    },
    stats() {
      if (this.statistics === undefined || Object.keys(this.statistics).length === 0) return [];
      return this.statistics.statistics;
    },
    selectedTeamOrCountry() {
      let result = {}
      if(this.currentTeam === null){
        result = this.currentCountry
      }
      else{
        result = this.currentTeam;
      }
      return result;
    }
  }
}
</script>

<style scoped>

</style>
