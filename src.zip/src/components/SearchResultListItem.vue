<template>
  <v-list-item ripple two-line class="hover" @click="$emit('click')">
    <v-tooltip bottom>
      <template v-slot:activator="{ on }">
        <v-icon class="mr-2" v-on="on" v-if="item.type === 'MainOfficeCustomer'" color="secondary">mdi-office-building</v-icon>
        <v-icon class="mr-2" v-on="on" v-else-if="item.type === 'Customer'">mdi-domain</v-icon>
        <v-icon class="mr-2" v-on="on" v-else-if="item.type === 'Vehicle'">mdi-car-hatchback</v-icon>
        <v-icon class="mr-2" v-on="on" v-else-if="item.type === 'EQ'">mdi-bulldozer</v-icon>
        <v-icon class="mr-2" v-on="on" v-else-if="item.type === 'Mini'">mdi-toolbox-outline</v-icon>
        <v-icon class="mr-2" v-on="on" v-else-if="item.type === 'AdminAccount'" color="secondary">mdi-shield-account</v-icon>
        <v-icon class="mr-2" v-on="on" v-else-if="item.type === 'Account'">mdi-account</v-icon>
        <v-icon class="mr-2" v-on="on" v-else-if="item.type === 'Simcard' || item.type === 'SimcardStorageUnit'">mdi-cable-data</v-icon>
        <v-icon class="mr-2" v-on="on" v-else-if="item.type === 'Subscription'">mdi-clipboard-list</v-icon>
        <v-icon class="mr-2" v-on="on" v-else-if="item.type === 'RFID'">mdi-clipboard-list</v-icon>
        <v-icon class="mr-2" v-on="on" v-else-if="item.type === 'Oem'">mdi-access-point</v-icon>
        <v-icon class="mr-2" v-on="on" v-else>mdi-help</v-icon>
      </template>
      <span>{{ item.type }}</span>
    </v-tooltip>

    <v-list-item-content>
      <v-list-item-title v-if="item.type === 'RFID'">
        <span class="font-weight-bold primary--text">{{ item.id }}</span>
         <span class="faded--text"> - {{ item.attachedSerialNumber }}</span>
        <slot name="action"></slot>
      </v-list-item-title>
      <v-list-item-title v-if="item.type !== 'RFID'">
        <span class="font-weight-bold primary--text" >{{ item.name }}</span>
        <span v-if="item.name && item.subName"> - </span><span class="faded--text">{{ item.subName }}</span>
        <slot name="action"></slot>
      </v-list-item-title>
      <v-list-item-subtitle>
        <DepartmentPath :department-path="item.departmentPath" :clickable="false"></DepartmentPath>
        <span v-if="item.type === 'SimcardStorageUnit'" class="font-weight-bold warning--text text--darken-1">Storage unit</span>
      </v-list-item-subtitle>
    </v-list-item-content>
  </v-list-item>
</template>

<script>
import DepartmentPath from "./DepartmentPath";
export default {
  name: "SearchResultListItem",
  components: { DepartmentPath },
  props: {
    item: Object
  }
};
</script>

<style scoped></style>
