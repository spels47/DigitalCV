﻿<template>
  <v-container fluid>
  <v-layout
    class="mt-2"
  >
    <v-flex xs2>
      <v-card rounded height="100vh">
        <v-tabs vertical>
          <v-tab v-for="(setting, index) in settings" :key="index" @click="selected = index">
            {{ setting.text }}
          </v-tab>
        </v-tabs>
      </v-card>
    </v-flex>
    <v-flex xs10 class="ml-2">
      <v-card rounded height="100vh">
        <InfoBannerSettings v-if="selected === 0"></InfoBannerSettings>
        <SuperOfficePersonInfoSettings v-if="selected === 1"></SuperOfficePersonInfoSettings>
        <PortfolioManagement v-if="selected === 2"></PortfolioManagement>
      </v-card>
    </v-flex>
  </v-layout>
  </v-container>
</template>

<script>
import InfoBannerSettings from "@/components/SiteSettings/InfoBannerSettings";
import SuperOfficePersonInfoSettings from "@/components/SiteSettings/SuperOfficePersonInfoSettings";
import PortfolioManagement from "@/components/SiteSettings/PortfolioManagement";

export default {
  name: "SiteSettings",
  components: {PortfolioManagement, SuperOfficePersonInfoSettings, InfoBannerSettings },
  data() {
    return {
      selected: 0,
      settings: [
        { text: "Info Banner" },
        { text: "Set SO person/associate id" },
        { text: "Portfolio management"}
      ]
    }
  }
}
</script>

<style scoped>

</style>
