<template>
  <v-menu v-model="menuOpen" offset-y bottom close-on-click class="py-10" :max-height="menuMaxHeight">
    <template v-slot:activator="{ on }">
      <v-text-field
        prepend-inner-icon="mdi-magnify"
        class="search-bar"
        placeholder="Search..."
        auto-select-first
        hide-details
        single-line v-on="on"
        autocomplete="off"
        ref="focus"
        v-model="search"
      >
      </v-text-field>
    </template>
    <v-list dense v-if="search.length > 3" width="400">
      <v-progress-linear indeterminate color="primary" v-if="isLoading"></v-progress-linear>

      <v-list-item-group v-if="customers.length > 0">
        <v-subheader
          >Customers
          <v-icon class="px-2" size="12">mdi-folder-multiple-outline</v-icon>
        </v-subheader>
        <template v-for="customer in customersFiltered">
          <search-result-list-item :item="customer" @click="goTo(customer)" :key="customer.id"></search-result-list-item>
        </template>
        <v-subheader class="justify-center hover" v-if="customers.length > 3 && customersFiltered.length < customers.length" @click.stop="customersSliceSize += 10">
          Show more customers ({{ customers.length - customersFiltered.length }})
          <v-icon class="px-2" size="12">mdi-magnify</v-icon>
        </v-subheader>
        <v-divider></v-divider>
      </v-list-item-group>

      <v-list-item-group v-if="accounts.length > 0">
        <v-subheader
          >Accounts
          <v-icon class="px-2" size="12">mdi-folder-multiple-outline</v-icon>
        </v-subheader>
        <template v-for="account in accountsFiltered">
          <search-result-list-item :item="account" @click="goTo(account)" :key="account.id"></search-result-list-item>
        </template>
        <v-subheader class="justify-center hover" v-if="accounts.length > 3 && accountsFiltered.length < accounts.length" @click.stop="accountsSliceSize += 10">
          Show more accounts ({{ accounts.length - accountsFiltered.length }})
          <v-icon class="px-2" size="12">mdi-magnify</v-icon>
        </v-subheader>
        <v-divider></v-divider>
      </v-list-item-group>

      <v-list-item-group v-if="units.length > 0">
        <v-subheader
          >Units
          <v-icon class="px-2" size="12">mdi-folder-multiple-outline</v-icon>
        </v-subheader>
        <template v-for="unit in unitsFiltered">
          <search-result-list-item :item="unit" @click="goTo(unit)" :key="unit.id"></search-result-list-item>
        </template>
        <v-subheader class="justify-center hover" v-if="units.length > 3 && unitsFiltered.length < units.length" @click.stop="unitsSliceSize += 10">
          Show more units ({{ units.length - unitsFiltered.length }})
          <v-icon class="px-2" size="12">mdi-magnify</v-icon>
        </v-subheader>
        <v-divider></v-divider>
      </v-list-item-group>
      <v-list-item-group v-if="minis.length > 0">
        <v-subheader
        >Units
          <v-icon class="px-2" size="12">mdi-folder-multiple-outline</v-icon>
        </v-subheader>
        <template v-for="mini in minisFiltered">
          <search-result-list-item :item="mini" @click="goTo(mini)" :key="mini.id"></search-result-list-item>
        </template>
        <v-subheader class="justify-center hover" v-if="minis.length > 3 && minisFiltered.length < minis.length" @click.stop="miniSliceSize += 10">
          Show more units ({{ minis.length - minisFiltered.length }})
          <v-icon class="px-2" size="12">mdi-magnify</v-icon>
        </v-subheader>
        <v-divider></v-divider>
      </v-list-item-group>
      <v-list-item-group v-if="vehicles.length > 0">
        <v-subheader
        >Vehicles
          <v-icon class="px-2" size="12">mdi-folder-multiple-outline</v-icon>
        </v-subheader>
        <template v-for="vehicle in vehiclesFiltered">
          <search-result-list-item :item="vehicle" @click="goTo(vehicle)" :key="vehicle.id"></search-result-list-item>
        </template>
        <v-subheader class="justify-center hover" v-if="vehicles.length > 3 && vehiclesFiltered.length < vehicles.length" @click.stop="vehiclesSliceSize += 10">
          Show more vehicles ({{ vehicles.length - vehiclesFiltered.length }})
          <v-icon class="px-2" size="12">mdi-magnify</v-icon>
        </v-subheader>
        <v-divider></v-divider>
      </v-list-item-group>
      <v-list-item-group v-if="subscriptions.length > 0">
        <v-subheader
          >Subscriptions
          <v-icon class="px-2" size="12">mdi-folder-multiple-outline</v-icon>
        </v-subheader>
        <template v-for="sub in subscriptionsFiltered">
          <search-result-list-item :item="sub" @click="goTo(sub)" :key="sub.id"></search-result-list-item>
        </template>
        <v-subheader class="justify-center hover" v-if="subscriptions.length > 3 && subscriptionsFiltered.length < subscriptions.length" @click.stop="subscriptionSliceSize += 10">
          Show more subscriptions ({{ subscriptions.length - subscriptionsFiltered.length }})
          <v-icon class="px-2" size="12">mdi-magnify</v-icon>
        </v-subheader>
        <v-divider></v-divider>
      </v-list-item-group>

      <v-list-item-group v-if="attachedHardware.length > 0">
        <v-subheader
          >Attached Hardware
          <v-icon class="px-2" size="12">mdi-folder-multiple-outline</v-icon>
        </v-subheader>
        <template v-for="attachedhw in attachedHardwareFiltered">
          <search-result-list-item :item="attachedhw" @click="goTo(attachedhw)" :key="attachedhw.id"></search-result-list-item>
        </template>
        <v-subheader class="justify-center hover" v-if="attachedHardware.length > 3 && attachedHardwareFiltered.length < attachedHardware.length" @click.stop="attachedHardwareSliceSize += 10">
          Show more attached hardware ({{ attachedHardware.length - attachedHardwareFiltered.length }})
          <v-icon class="px-2" size="12">mdi-magnify</v-icon>
        </v-subheader>
        <v-divider></v-divider>
      </v-list-item-group>
      <v-list-item-group v-if="!isLoading && customers.length === 0 && accounts.length === 0 && units.length === 0 && subscriptions.length === 0">
        <v-subheader class="px-5">
          <v-icon class="px-2" size="16">mdi-head-question</v-icon>
          Sorry, could not find any results...
        </v-subheader>
      </v-list-item-group>
    </v-list>
  </v-menu>
</template>

<script>
import axios from "../axios-client";
import SearchResultListItem from "./SearchResultListItem";

export default {
  props: {
    emitItemOnClick: { type: Boolean, default: false }, // Let's you use the search in component context, emitting the item instead of navigating to it'
    menuMaxHeight: { type: String, default: "80vh" }
  },
  components: { SearchResultListItem },
  mounted() {
    this.$nextTick(() => {
      // Yes, there is a autofocus prop, but it has a bug when used in a dialog
      this.$refs.focus.focus();
    });
  },
  data() {
    return {
      search: "",
      customers: [],
      customersSliceSize: 3,
      accounts: [],
      accountsSliceSize: 3,
      units: [],
      unitsSliceSize: 3,
      subscriptions: [],
      attachedHardware: [],
      attachedHardwareSliceSize: 3,
      subscriptionSliceSize: 3,
      vehicles: [],
      minis: [],
      miniSliceSize: 3,
      vehiclesSliceSize: 3,
      selectedCustomer: null,
      menuOpen: false,
      isSearching: false,
      isLoading: false
    };
  },
  watch: {
    search(val) {
      if (!val || val.length < 3) return;
      this.customers = [];
      this.customersSliceSize = 3;
      this.accounts = [];
      this.accountsSliceSize = 3;
      this.units = [];
      this.unitsSliceSize = 3;
      this.attachedHardware = [];
      this.attachedHardwareSliceSize = 3;
      this.vehicles = [];
      this.minis = [];
      this.miniSliceSize = 3;
      this.vehiclesSliceSize = 3;
      this.fetchSearchResultsDebounced();
    }
  },
  computed: {
    defaultTable() {
      return this.$store.state.userSettings.defaultTable;
    },
    customersFiltered: function() {
      return this.customers.slice(0, this.customersSliceSize);
    },
    accountsFiltered: function() {
      return this.accounts.slice(0, this.accountsSliceSize);
    },
    unitsFiltered: function() {
      return this.units.slice(0, this.unitsSliceSize);
    },
    subscriptionsFiltered: function() {
      return this.subscriptions.slice(0, this.subscriptionSliceSize);
    },
    attachedHardwareFiltered: function() {
      return this.attachedHardware.slice(0, this.attachedHardwareSliceSize);
    },
    vehiclesFiltered: function() {
      return this.vehicles.slice(0, this.vehiclesSliceSize);
    },
    minisFiltered: function() {
      return this.minis.slice(0, this.miniSliceSize);
    }
  },
  methods: {
    fetchSearchResultsDebounced() {
      this.isLoading = true;
      clearTimeout(this._timerId);

      this._timerId = setTimeout(() => {
        this.fetchSearchResults();
      }, 500);
    },
    async fetchSearchResults() {
      let searchQuery = {
        SearchString: this.search,
      }
      this.isLoading = true;
      let promises = [];
      promises.push(this.searchCustomers(searchQuery));
      promises.push(this.searchUnits(searchQuery));
      promises.push(this.searchMinis(searchQuery));
      promises.push(this.searchAccounts(searchQuery));
      promises.push(this.searchSubscriptions(searchQuery));
      promises.push(this.searchAttachedHardware(searchQuery));
      promises.push(this.searchVehicles(searchQuery));

      Promise.any(promises).then(() => {
        this.menuOpen = true;
      })
      Promise.all(promises)
        .catch(() => {})
        .finally(() => {
          this.isLoading = false;
        });
    },
    async searchCustomers(searchQuery) {
      await axios.post("/api/search/customer", searchQuery).then(x => {
        this.customers = x.data.filter(z => z.isTulleDepartment === false);
      });
    },
    async searchUnits(searchQuery) {
      await axios.post("/api/search/dataSource", searchQuery).then(x => {
        this.units = x.data;
      });
    },
    async searchMinis(searchQuery) {
      await axios.post("/api/search/mini", searchQuery).then(x => {
        this.minis = x.data;
      });
    },
    async searchAccounts(searchQuery) {
      await axios.post("/api/search/user", searchQuery).then(x => {
        this.accounts = x.data;
      });
    },
    async searchSubscriptions(searchQuery) {
      await axios.post("/api/search/subscription", searchQuery).then(x => {
        this.subscriptions = x.data;
      });
    },
    async searchAttachedHardware(searchQuery) {
      await axios.post("/api/search/attachedhardware", searchQuery).then(x => {
        this.attachedHardware = x.data;
      });
    },
    async searchVehicles(searchQuery) {
      await axios.post("/api/search/vehicle", searchQuery).then(x => {
        this.vehicles = x.data;
      });
    },
    goTo(item) {
      if (!item) return;

      if (this.emitItemOnClick) {
        this.$emit("click", item);
        return;
      }
      if (["MainOfficeCustomer", "Customer"].includes(item.type))
        this.$router
          .push({
            name: "customer",
            params: { id: item.id },
            query: { activeTab: this.$utils.getDefaultTab(this.defaultTable) }
          })
          .catch(err => {});
      if (["RFID"].includes(item.type))
        this.$router.push({
          name: "customer",
          params: { id: item.departmentPath[item.departmentPath.length-1].id },
          query: { activeTab: this.$utils.getDefaultTab(item.type.toLowerCase()), type: "simcard", id: item.id, r: this.random() }
        });
      if (["SimcardStorageUnit"].includes(item.type))
        this.$router.push({
          name: "customer-placeholder",
          query: { dataSourceId: item.id }
        });
      if (["Triplog", "Simcard", "EQ", "Mini", "Subscription", "Oem"].includes(item.type))
        this.$router
          .push({
            name: "customer",
            params: { id: item.departmentPath[item.departmentPath.length-1].id },
            query: { activeTab: this.$utils.getDefaultTab(item.type.toLowerCase()), type: item.type.toLowerCase(), id: item.id, r: this.random() }
          })
          .catch(err => {});
      if (["AdminAccount", "Account"].includes(item.type))
        this.$router
          .push({
            name: "customer",
            params: { id: item.departmentPath[item.departmentPath.length - 1].id },
            query: { type: "account", id: item.id, r: this.random() }
          })
          .catch(err => {});
      if (["Vehicle"].includes(item.type))
        this.$router
          .push({
            name: "customer",
            params: { id: item.departmentPath[item.departmentPath.length - 1].id },
            query: { activeTab: this.$utils.getDefaultTab(item.type.toLowerCase()), type: "vehicle", id: item.id, r: this.random() }
          })
          .catch(err => {});
    },
    random(){
      // This is a hack to make sure the route is changed on every click, to force sidebar update
      // a permanent solution would be to move state out of the customer component and into vuex, using eventbus for updates
      return Math.floor((Math.random() * 1000) + 1);
    },
  }
};
</script>

<style lang="css" scoped>
.search-bar {
  width: 350px;
}

.hover {
  cursor: pointer;
}

.margin-y {
  margin-top: 4px;
}
</style>
