﻿<template>
  <v-dialog
    :value="showDialog"
    :max-width="maxWidth"
    :persistent="isActionType"
    @click:outside="handleOutsideClick"
  >
    <v-card rounded>
      <v-card-title>{{ title }}</v-card-title>
      <v-card-subtitle
        v-if="subtitle"
        class="pt-1"
      >
        {{ subtitle }}
      </v-card-subtitle>

      <v-divider></v-divider>

      <v-card-text>
        <slot name="content"></slot>
      </v-card-text>

      <v-card-actions v-if="isActionType">
        <v-spacer></v-spacer>

        <v-btn
          :disabled="actionButtonOptions.loading"
          color="primary"
          rounded
          text
          @click="$emit('close')"
        >
          Cancel
        </v-btn>

        <v-btn
          :loading="actionButtonOptions.loading"
          :color="actionButtonOptions.color"
          elevation="1"
          rounded
          @click="$emit('action:clicked')"
        >
          <v-icon
            v-if="actionButtonOptions.icon"
            left
          >
            {{ actionButtonOptions.icon }}
          </v-icon>

          {{ actionButtonOptions.text }}
        </v-btn>
      </v-card-actions>
    </v-card>

  </v-dialog>
</template>
<script>

/*
A dialog that fits with Backstage design.
- Props:
    show: A boolean that tells the dialog whether to show or not.
    type: The type of dialog this is. Type 'info' has no card action buttons, while 'action' shows a cancel and an action button.
    maxWidth: The maximum width the dialog is allowed to take.
    title: The v-card-title of the dialog.
    subtitle: An optional v-card-subtitle.
    actionButton: An object describing how the action button should look.
 */

export default {
  name: "BackstageDialog",
  props: {
    show: {
      type: Boolean,
      required: true
    },
    type: {
      type: String,
      required: true
    },
    maxWidth: {
      type: Number,
      default: 500
    },
    title: {
      type: String,
      required: true
    },
    subtitle: {
      type: String
    },
    actionButton: {
      type: Object,
    },
  },
  emits: ["action:clicked", "close"],
  data() {
    return {
      types: ["info", "action"],
    }
  },
  watch: {
    showDialog(value) {
      if (value) {
        if (!this.types.some(x => x === this.type))
          console.error(`Type '${this.type}' is not a valid dialog type.`);
      }
    }
  },
  methods: {
    handleOutsideClick() {
      if (!this.isActionType)
        this.$emit("close")
    }
  },
  computed: {
    actionButtonOptions() {
      return Object.assign({
        text: "",
        icon: "mdi-check-circle-outline",
        color: "secondary",
        loading: false,
      }, this.actionButton)
    },
    isActionType() {
      return this.type?.toLocaleLowerCase() ?? "" === 'action';
    },
    showDialog: {
      get() {
        return this.show;
      },
      set(value) {
        if (!value)
          this.$emit("close");
      }
    },
  }
}
</script>

<style scoped>

</style>
