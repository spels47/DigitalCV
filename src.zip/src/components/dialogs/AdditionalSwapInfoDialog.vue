﻿<template>
  <v-dialog
    v-model="showDialog"
    width="700"
  >
    <v-card class="rounded-lg">
      <v-card-title>Additional swap info</v-card-title>
      <v-card-subtitle>View relevant information about this swap.</v-card-subtitle>
      <v-divider></v-divider>

      <v-card-text class="mt-4">
        <v-text-field label="Delivery Address" v-model="swapWorkItem.confirmedAddress" readonly></v-text-field>
        <v-text-field label="Name" :value="name" readonly></v-text-field>
        <v-text-field label="Phone" :value="phone" readonly></v-text-field>
        <v-text-field label="Email" :value="email" readonly></v-text-field>

        <v-textarea
          :value="swapWorkItem.otherInformation"
          label="Other information"
          class="mt-4"
          readonly
          no-resize
        ></v-textarea>
      </v-card-text>
    </v-card>
  </v-dialog>
</template>

<script>
export default {
  name: "AdditionalSwapInfoDialog",
  props: {
    show: {
      type: Boolean,
      required: true
    },
    swapWorkItem: {
      type: Object,
      required: true
    }
  },
  computed: {
    showDialog: {
      get() {
        return this.show;
      },
      set(value) {
        if (!value)
          this.$emit("close");
      }
    },
    name() {
      return this.swapWorkItem.contactPerson?.name;
    },
    phone() {
      return this.swapWorkItem.contactPerson?.phone
    },
    email() {
      return this.swapWorkItem.contactPerson?.email
    }
  }
}
</script>

<style scoped>

</style>
