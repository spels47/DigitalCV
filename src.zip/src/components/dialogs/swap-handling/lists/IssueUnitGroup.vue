<template>
  <v-card
    elevation="12"
    class="rounded-lg"
  >
    <v-list>
        <v-list-item
          v-for="simcard in simcards"
          :key="simcard.serialNumber"
          dense
        >
          <template v-slot:default="{ active }">
            <v-list-item-avatar>
              <v-icon v-text="determineIcon(simcard)"></v-icon>
            </v-list-item-avatar>

            <v-list-item-content>
              <v-list-item-title>
                {{ determineSimcardDatasourceId(simcard) }}
              </v-list-item-title>
              <v-list-item-subtitle>
                {{ getUnitHardwareType(determineSimcardDatasourceId(simcard)) == null ? simcard.unitTypeId : getUnitHardwareType(determineSimcardDatasourceId(simcard)) }}
              </v-list-item-subtitle>
            </v-list-item-content>

            <v-list-item-action>
              <div class="d-flex available">
                <v-tooltip
                  v-if="isSwapComplete"
                  bottom
                >
                  <template v-slot:activator="{ on, attrs }">
                    <v-icon
                      v-on="on"
                      v-bind="attrs"
                      class="ml-4"
                      :color="wasValidSwap(simcard.serialNumber) ? 'success' : 'error'"
                    >
                      mdi-swap-horizontal
                    </v-icon>
                  </template>
                  <span>{{ wasValidSwap(simcard.serialNumber) ? 'Started swap process' : 'This unit was not swapped.' }}</span>
                </v-tooltip>

                <template v-else>
                  <SwapSimcardUnitDiagnostic
                    v-if="isTechnicalReason && checkIfApplicableSimcardType(simcard)"
                    class="ml-2 available"
                    :serialNumber="simcard.serialNumber"
                    :unitDiagnostic="getTroubleShootingBySerialNumber(simcard.serialNumber)"
                  ></SwapSimcardUnitDiagnostic>

                  <UnitDiagnosticMini
                    v-else-if="isTechnicalReason && !checkIfApplicableSimcardType(simcard)"
                    class="ml-2 available"
                    :serial-number="simcard.id"
                  ></UnitDiagnosticMini>

                  <ContractSwapValidationStatus
                    v-if="!isTechnicalReason"
                    class="ml-2 available"
                    :serialNumber="simcard.serialNumber"
                    :unitValidation="getValidationBySerialNumber(simcard.serialNumber)"
                    :reason="reason"
                  ></ContractSwapValidationStatus>
                </template>
              </div>
            </v-list-item-action>
          </template>
        </v-list-item>
    </v-list>
  </v-card>
</template>

<script>
import UnitDiagnosticMini from "@/components/UnitDiagnosticMini";
import SwapSimcardUnitDiagnostic from "@/components/dialogs/swap-handling/SwapSimcardUnitDiagnostic";
import ContractSwapValidationStatus from "@/components/dialogs/swap-handling/ContractSwapValidationStatus";
import { mapState } from "vuex";

export default {
  name: "IssueUnitGroup",
  components: {
    UnitDiagnosticMini,
    SwapSimcardUnitDiagnostic,
    ContractSwapValidationStatus
  },
  props: {
    simcards: {
      type: Array,
      required: true
    },
    terminatedSubscriptions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      invalidSwaps: []
    };
  },
  watch: {
    troubleShootingData(newValue, oldValue) {
      if (!newValue) {
        this.invalidSwaps = [];
        return;
      }

      for (const unit of this.simcards) {
        const serialNumber = unit.serialNumber ?? unit.dataSourceId;
        const entry = newValue.find(x => x.serialNumber === serialNumber);
        if (entry?.validSwap === false)
          this.invalidSwaps.push(entry);
      }
    },
    validationData(newValue, oldValue) {
      if (!newValue) {
        this.invalidSwaps = [];
        return;
      }

      for (const unit of this.simcards) {
        const serialNumber = unit.serialNumber ?? unit.dataSourceId;
        const entry = newValue.find(x => x.serialNumber === serialNumber);
        if (entry?.validSwap === false) this.invalidSwaps.push(entry);
      }
    }
  },
  methods: {
    determineIcon(simcard) {
      return simcard.unitTypeId.includes("EQ") ? "mdi-bulldozer" : "mdi-cable-data";
    },
    isInvalidSwap(unit) {
      const serialNumber = unit.serialNumber ?? unit.dataSourceId;
      return this.invalidSwaps.findIndex(x => x.serialNumber === serialNumber || x.dataSourceId === serialNumber) !== -1;
    },
    getInvalidSwapReasons(unit) {
      const serialNumber = unit.serialNumber ?? unit.dataSourceId;
      const entry = this.invalidSwaps.find(x => x.serialNumber === serialNumber);
      return entry.validationReasons;
    },
    checkIfApplicableSimcardType(simcard) {
      return simcard?.type?.toLowerCase() === "simcard";
    },
    determineSimcardDatasourceId(simcard) {
      const id = simcard.id ? simcard.id : simcard.dataSourceId;
      return id.toString();
    },
    getTroubleShootingBySerialNumber(serialNumber) {
      if(this.troubleShootingData == null || this.troubleShootingData.length === 0) return null;
      for (const troubleShooting of this.troubleShootingData) {
        if (troubleShooting.serialNumber === serialNumber) return troubleShooting;
      }
    },
    wasValidSwap(serialNumber) {
      return this.swappedUnits.swappedSerialNumbers.findIndex(x => x === serialNumber) !== -1;
    },
    getValidationBySerialNumber(serialNumber){
      if(this.validationData == null || this.validationData[0]?.serialNumber == null) return null;

      for (const validation of this.validationData) {
        if(validation.serialNumber === serialNumber) return validation;
      }
    },
    getUnitHardwareType(serialNumber){
      for (let i = 0; i < this.unitHardwareTypes.length; i++) {
        const hardwareType = this.unitHardwareTypes[i];
        if(hardwareType.serialNumber == serialNumber) return hardwareType.unitType;
      }
      return null;
    }
  },
  computed: {
    ...mapState('SwapHandlingWizardModule', ['swapData', 'swappedUnits', 'unitHardwareTypes']),

    troubleShootingData() {
      const data = this.$store.state.SwapHandlingWizardModule.troubleShootingData;
      if (data == null) return;
      return data.troubleShootingPerUnit;
    },
    isTechnicalReason() {
      return this.swapData.reason.reason === "technical";
    },
    reason(){
      return this.swapData.reason.reason;
    },
    validationData() {
      const data = this.$store.state.SwapHandlingWizardModule.issueValidationData;
      if(data == null) return;
      return data;
    },
    swapType() {
      return this.swapData.type;
    },
    isSwapComplete() {
      return this.swappedUnits?.swappedSerialNumbers?.length ?? 0 > 0;
    }
  }
};
</script>

<style scoped lang="scss">
$f: 1.5;
$w: 13em;

.card {
	overflow: hidden;
	position: relative;
	border-radius: 5px;
	box-shadow: 2px 2px 5px rgba(#000, .5);
	background: linear-gradient(to left top, #ec014b88, #06caed7a);
	isolation: isolate;

	&::before, &::after {
		position: absolute;
		top: 0; right: 0; bottom: 0; left: 0;
		z-index: 0;
		content: ''
	}

	&::before {
		background: linear-gradient(30deg, rgba(119, 119, 119, 0.75), rgba(0, 0, 0, 0.75)), repeating-linear-gradient(30deg, rgba(0, 0, 0, 0.5), rgba(153, 153, 153, 0.5), rgba(0, 0, 0, 0.5) 5%), repeating-conic-gradient(rgba(0, 0, 0, 0.5), rgba(153, 153, 153, 0.5), rgba(0, 0, 0, 0.5) 5%);
	background-blend-mode: screen, difference;
		filter: contrast(19);
		mix-blend-mode: multiply;
	}

	&::after {
		background: linear-gradient(90deg, #0000005b, #25b9ca86);
		mix-blend-mode: screen
	}
}

.available{
  position: relative;
  z-index: 5;
}
</style>
