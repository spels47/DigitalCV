﻿<template>
  <div class="d-block text-center align-center justify-center">
    <v-icon size="100">mdi-cable-data</v-icon>

    <v-card-title class="font-weight-bold">{{ serialNumber }}</v-card-title>
    <v-card-subtitle>{{ unitTypeId }}</v-card-subtitle>
  </div>
</template>

<script>
export default {
  name: "SingleSwapBanner",
  props: {
    serialNumber: {
      type: String,
      required: true
    },
    unitTypeId: {
      type: String,
      required: true
    }
  }
};
</script>

<style scoped>
.test {
  height: 100%
}
</style>
