﻿<template>
  <v-card
    elevation="12"
    class="rounded-lg"
  >
    <v-list>
        <v-list-item
          v-for="simcard in simcards"
          :key="simcard.serialNumber"
          dense
        >
          <template v-slot:default="{ active }">
            <v-list-item-avatar>
              <v-icon v-text="determineIcon(simcard)"></v-icon>
            </v-list-item-avatar>

            <v-list-item-content>
              <v-list-item-title>
                {{ determineSimcardDatasourceId(simcard) }}
              </v-list-item-title>
              <v-list-item-subtitle>
                {{ getUnitHardwareType(determineSimcardDatasourceId(simcard)) == null ? simcard.unitTypeId : getUnitHardwareType(determineSimcardDatasourceId(simcard)) }}
              </v-list-item-subtitle>
            </v-list-item-content>

            <v-list-item-action>
              <div class="d-flex available">
                <v-tooltip
                  v-if="isSwapComplete"
                  bottom
                >
                  <template v-slot:activator="{ on, attrs }">
                    <v-icon
                      v-on="on"
                      v-bind="attrs"
                      class="ml-4"
                      :color="wasValidSwap(simcard.serialNumber) ? 'success' : 'error'"
                    >
                      mdi-swap-horizontal
                    </v-icon>
                  </template>
                  <span>{{ wasValidSwap(simcard.serialNumber) ? 'Started swap process' : 'This unit was not swapped.' }}</span>
                </v-tooltip>

                <template v-else>
                  <v-menu
                    v-if="isInvalidSwap(simcard) && swapType === 'contract'"
                    open-on-hover
                    top
                  >
                    <template v-slot:activator="{ on, attrs }">
                      <v-icon
                        v-on="on"
                        v-bind="attrs"
                        color="error"
                        class="mr-2 available"
                      >
                        mdi-alert
                      </v-icon>
                    </template>

                    <v-list>
                      <v-subheader>This unit does not meet the requirements for a swap:</v-subheader>
                      <v-list-item
                        v-for="(reason, index) in getInvalidSwapReasons(simcard)"
                        :key="index"
                      >
                        <v-list-item-icon>
                          <v-icon>mdi-information</v-icon>
                        </v-list-item-icon>
                        <v-list-item-content>
                          <v-list-item-title>{{ reason }}</v-list-item-title>
                        </v-list-item-content>
                      </v-list-item>
                    </v-list>
                  </v-menu>

                  <UnitDiagnosticSimcard
                    v-if="isTechnicalReason && checkIfApplicableSimcardType(simcard) && swapType === 'issue'"
                    class="ml-2 available"
                    :simcard-id="simcard.simcardId.toString()"
                    :datasource-id="determineSimcardDatasourceId(simcard)"
                  ></UnitDiagnosticSimcard>

                  <UnitDiagnosticMini
                    v-else-if="isTechnicalReason && !checkIfApplicableSimcardType(simcard) && swapType === 'issue'"
                    class="ml-2 available"
                    :serial-number="simcard.id"
                  ></UnitDiagnosticMini>
                </template>
              </div>
            </v-list-item-action>
          </template>
        </v-list-item>
    </v-list>
  </v-card>
</template>

<script>
import UnitDiagnosticMini from "@/components/UnitDiagnosticMini";
import UnitDiagnosticSimcard from "@/components/UnitDiagnosticSimcard";
import { mapState } from "vuex";

export default {
  name: "UnitGroup",
  components: {
    UnitDiagnosticMini,
    UnitDiagnosticSimcard
  },
  props: {
    simcards: {
      type: Array,
      required: true
    },
    terminatedSubscriptions: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      invalidSwaps: []
    };
  },
  watch: {
    troubleShootingInfo(newValue, oldValue) {
      if (!newValue) {
        this.invalidSwaps = [];
        return;
      }

      for (const unit of this.simcards) {
        const serialNumber = unit.serialNumber ?? unit.dataSourceId;
        const entry = newValue.find(x => x.serialNumber === serialNumber);
        if (entry?.validSwap === false)
          this.invalidSwaps.push(entry);
      }
    }
  },
  methods: {
    determineIcon(simcard) {
      return simcard.unitTypeId.includes("EQ") ? "mdi-bulldozer" : "mdi-cable-data";
    },
    isInvalidSwap(unit) {
      const serialNumber = unit.serialNumber ?? unit.dataSourceId;
      return this.invalidSwaps.findIndex(x => x.serialNumber === serialNumber || x.dataSourceId === serialNumber) !== -1;
    },
    getInvalidSwapReasons(unit) {
      const serialNumber = unit.serialNumber ?? unit.dataSourceId;
      const entry = this.invalidSwaps.find(x => x.serialNumber === serialNumber);
      return entry.validationReasons;
    },
    checkIfApplicableSimcardType(simcard) {
      return simcard?.type?.toLowerCase() === "simcard";
    },
    determineSimcardDatasourceId(simcard) {
      const id = simcard.id ? simcard.id : simcard.dataSourceId;
      return id.toString();
    },
    getTroubleShootingBySerialNumber(serialNumber){
      for (const troubleShooting of this.troubleShootingInfo) {
        if(troubleShooting.serialNumber == serialNumber) return troubleShooting;
      }
    },
    wasValidSwap(serialNumber) {
      return this.swappedUnits.swappedSerialNumbers.findIndex(x => x === serialNumber) !== -1;
    },
    getUnitHardwareType(serialNumber){
      for (let i = 0; i < this.unitHardwareTypes.length; i++) {
        const hardwareType = this.unitHardwareTypes[i];
        if(hardwareType.serialNumber == serialNumber) return hardwareType.unitType;
      }
      return null;
    }
  },
  computed: {
    ...mapState('SwapHandlingWizardModule', ['swapData', 'swappedUnits', 'unitHardwareTypes']),

    isSwapComplete() {
      return this.swappedUnits?.swappedSerialNumbers?.length ?? 0 > 0;
    },
    troubleShootingInfo() {
      const data = this.$store.state.SwapHandlingWizardModule.swapData.troubleShootingInfo;
      if(data == null) return;
      return Object.entries(data).length > 0 ? data : null;
    },
    isTechnicalReason() {
      return this.swapData.reason.reason === "technical";
    },
    swapType() {
      return this.swapData.type;
    }
  }
};
</script>

<style scoped lang="scss">
$f: 1.5;
$w: 13em;

.card {
	overflow: hidden;
	position: relative;
	border-radius: 5px;
	box-shadow: 2px 2px 5px rgba(#000, .5);
	background: linear-gradient(to left top, #ec014b88, #06caed7a);
	isolation: isolate;

	&::before, &::after {
		position: absolute;
		top: 0; right: 0; bottom: 0; left: 0;
		z-index: 0;
		content: ''
	}

	&::before {
		background: linear-gradient(30deg, rgba(119, 119, 119, 0.75), rgba(0, 0, 0, 0.75)), repeating-linear-gradient(30deg, rgba(0, 0, 0, 0.5), rgba(153, 153, 153, 0.5), rgba(0, 0, 0, 0.5) 5%), repeating-conic-gradient(rgba(0, 0, 0, 0.5), rgba(153, 153, 153, 0.5), rgba(0, 0, 0, 0.5) 5%);
	background-blend-mode: screen, difference;
		filter: contrast(19);
		mix-blend-mode: multiply;
	}

	&::after {
		background: linear-gradient(90deg, #0000005b, #25b9ca86);
		mix-blend-mode: screen
	}
}

.available{
  position: relative;
  z-index: 5;
}
</style>
