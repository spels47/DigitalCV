﻿<template>
  <v-card
    class="mb-12"
    height="600px"
  >
    <v-card-title class="justify-center">
      <span class="headline secondary--text font-weight-medium">What kind of SWAP is this?</span>
    </v-card-title>

    <v-card-text style="height: 85%">
      <v-container
        style="height: 100%"
        fluid
      >
        <v-row
          align="center"
          style="height: 100%"
        >
          <v-col
            cols="6"
            class="d-flex justify-center"
          >
            <v-card
              :loading="validatingTechnical"
              width="50%"
              height="250"
              class="clickable-card rounded-xl"
              hover
              @click="chooseSwapType('issue')"
            >
              <v-card-title class="justify-center">Issue related</v-card-title>
              <v-card-subtitle class="text-center mt-1">SWAP related to an issue with the hardware, carrier or customer.</v-card-subtitle>
              <v-card-text class="d-flex justify-center mt-6">
                <v-icon size="50">
                  mdi-alert-circle-outline
                </v-icon>
              </v-card-text>
            </v-card>
          </v-col>
          <v-col
            cols="6"
            class="d-flex justify-center"
          >
            <v-card
              :loading="validationContract"
              width="50%"
              height="250"
              class="clickable-card rounded-xl"
              rounded
              hover
              @click="chooseSwapType('contract')"
            >
              <v-card-title class="justify-center">Contract related</v-card-title>
              <v-card-subtitle class="text-center mt-1">SWAP in order to support new features bought by the customer.</v-card-subtitle>
              <v-card-text class="d-flex justify-center mt-6">
                <v-icon size="50">
                  mdi-file-document-outline
                </v-icon>
              </v-card-text>
            </v-card>
          </v-col>
        </v-row>
      </v-container>
    </v-card-text>
  </v-card>
</template>

<script>
import { mapActions } from "vuex";
import axios from "../../../axios-client";

export default {
  name: "ChooseSwapType",
  props: {
    fetchingDataFailed: Boolean
  },
  data() {
    return {
      validatingTechnical: false,
      validationContract: false
    }
  },
  methods: {
    ...mapActions({
      setSwapType: 'SwapHandlingWizardModule/setSwapType',
      setSwapChoices: 'SwapHandlingWizardModule/setSwapChoices'
    }),
    async chooseSwapType(type) {
      if(this.fetchingDataFailed) return;
      if(this.swapType && type != this.swapType) this.setSwapChoices([]);
      this.setSwapType(type);

      const serialNumbers = this.currentUnits.map(simcard => simcard.serialNumber ?? simcard.dataSourceId);

      let response = null;
      try {
        if (type === "contract") {
          this.validationContract = true;
          const { data } = await axios.post("api/swap/mass/validateContractSwap", serialNumbers);
          response = data;
          await this.$store.dispatch("SwapHandlingWizardModule/setContractValidationData", { response });
        } else {
          this.validatingTechnical = true;
          const { data } = await axios.post("api/swap/mass/validateIssueSwap", serialNumbers);
          response = data;
          await this.$store.dispatch("SwapHandlingWizardModule/setIssueValidationData", { response });
        }
      } catch(error) {
        this.$eventBus.$emit('alert', { text: `Failed to contact validation 🤦‍♂️🤷‍♂️`, type: 'error' });
      }
      finally {
        this.validationContract = false;
        this.validatingTechnical = false;
      }

      this.nextStep(type);
    },
    nextStep(type) {
      this.$emit("nextStep", type);
    },
  },
  computed: {
    currentUnits() {
      return this.$store.state.SwapHandlingWizardModule.currentUnits;
    },
    swapType() {
      return this.$store.state.SwapHandlingWizardModule.swapData.type;
    }
  }
};
</script>

<style scoped>
.clickable-card {
  cursor: pointer;
}
</style>
