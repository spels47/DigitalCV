﻿<template>
  <v-dialog
    v-model="shouldShow"
    max-width="80%"
    @click:outside="resetState()"
  >
    <v-row no-gutters>
      <v-col cols="3">
        <v-sheet
          height="100%"
          :class="simcards.length === 1 ? 'd-flex justify-center align-center' : ''"
          dark
        >
          <v-list
            v-if="simcards.length > 1"
            class="fixed-list"
            shaped
          >
          <div v-if="!chosenSwapType">
            <UnitGroup
              :simcards="simcards"
              :terminated-subscriptions="simcardsWithTerminationDate"
              class="ma-2"
            ></UnitGroup>
          </div>
          <div v-if="chosenSwapType === 'Issue related'">
            <IssueUnitGroup
              :simcards="simcards"
              :terminated-subscriptions="simcardsWithTerminationDate"
              class="ma-2"
            ></IssueUnitGroup>
          </div>
          <div v-if="chosenSwapType === 'Contract related'">
            <ContractUnitGroup
              :simcards="simcards"
              :terminated-subscriptions="simcardsWithTerminationDate"
              class="ma-2"
            ></ContractUnitGroup>
          </div>

          </v-list>

          <SingleSwapBanner
            v-else-if="simcards.length === 1"
            :serial-number="determineSimcardDatasourceId(simcards[0])"
            :unit-type-id="singleUnitTypeId"
          ></SingleSwapBanner>
        </v-sheet>
      </v-col>
      <v-col cols="9">
        <div v-if="!chosenSwapType">
          <v-stepper
            v-model="stepperIndex"
          >
            <v-stepper-header>
              <v-stepper-step
                :complete="chosenSwapType != null"
                :rules="[() => !shouldWarnSwapType]"
                color="secondary"
                step="1"
              >
                Choose swap type
                <small>{{ chosenSwapType }}</small>
              </v-stepper-step>
            </v-stepper-header>

            <v-stepper-items>
              <v-stepper-content step="1">
                <ChooseSwapType :fetchingDataFailed="unitQualificationsFailed"></ChooseSwapType>
              </v-stepper-content>
            </v-stepper-items>
          </v-stepper>
        </div>
        <div v-if="chosenSwapType === 'Issue related'">
          <v-stepper
            v-model="issueStepperIndex"
          >
            <v-stepper-header>
              <v-stepper-step
                :complete="issueStepperIndex > 1"
                @click="jumpToIssueStep(1)"
                :rules="[() => !shouldWarnSwapType]"
                :color="issueStepperIndex === 1 ? 'secondary' : 'primary'"
                step="1"
              >
                Choose swap type
                <small>{{ chosenSwapType }}</small>
              </v-stepper-step>

              <v-divider></v-divider>

              <v-stepper-step
                :complete="issueStepperIndex > 2"
                @click="jumpToIssueStep(2)"
                :rules="[() => !shouldWarnSwapReason]"
                :color="issueStepperIndex === 2 ? 'secondary' : 'primary'"
                step="2"
              >
                Swap reason
                <small>{{ chosenSwapReason }}</small>
              </v-stepper-step>

              <v-divider></v-divider>

              <v-stepper-step
                :complete="issueStepperIndex > 3"
                @click="jumpToIssueStep(3)"
                :color="issueStepperIndex === 3 ? 'secondary' : 'primary'"
                step="3"
              >
                Troubleshooting
              </v-stepper-step>

              <v-divider></v-divider>

              <v-stepper-step
                :complete="issueStepperIndex > 4"
                @click="jumpToIssueStep(4)"
                :color="issueStepperIndex === 4 ? 'secondary' : 'primary'"
                step="4"
              >
                Choose hardware
              </v-stepper-step>

              <v-divider></v-divider>

              <v-stepper-step
                :complete="issueStepperIndex > 5"
                @click="jumpToIssueStep(5)"
                :color="issueStepperIndex === 5 ? 'secondary' : 'primary'"
                step="5"
              >
                Additional information
              </v-stepper-step>

              <v-divider></v-divider>

              <v-stepper-step
                :color="issueStepperIndex === 6 ? 'secondary' : 'primary'"
                @click="jumpToIssueStep(6)"
                step="6"
              >
                Send to logistics
              </v-stepper-step>

            </v-stepper-header>

            <v-stepper-items>
              <v-stepper-content step="1">
                <ChooseSwapType :fetchingDataFailed="unitQualificationsFailed" @nextStep="$event === 'issue' ? issueStepperIndex++ : contractStepperIndex = 2"></ChooseSwapType>
              </v-stepper-content>
              <v-stepper-content step="2">
                <SwapReason
                  @nextStep="issueStepperIndex++"
                  @previousStep="issueStepperIndex--"
                ></SwapReason>
              </v-stepper-content>
              <v-stepper-content step="3">
                <SwapTroubleshooting
                  @nextStep="issueStepperIndex++"
                  @previousStep="issueStepperIndex--"
                ></SwapTroubleshooting>
              </v-stepper-content>
              <v-stepper-content step="4">
                <ChooseHardware
                  :customer="customer"
                  :render="issueStepperIndex === 4"
                  @nextStep="issueStepperIndex++"
                  @previousStep="issueStepperIndex--"
                ></ChooseHardware>
              </v-stepper-content>
              <v-stepper-content step="5">
                <AdditionalInformation
                  :customer="customer"
                  @nextStep="issueStepperIndex++"
                  @previousStep="issueStepperIndex--"
                ></AdditionalInformation>
              </v-stepper-content>
              <v-stepper-content step="6">
                <SendToLogistics
                  @previousStep="issueStepperIndex--"
                  @displayFinishScreen="displayFinishScreen"
                ></SendToLogistics>
              </v-stepper-content>
            </v-stepper-items>
          </v-stepper>
        </div>
        <div v-if="chosenSwapType === 'Contract related'">
          <v-stepper
            v-model="contractStepperIndex"
          >
            <v-stepper-header>
              <v-stepper-step
                :complete="contractStepperIndex > 1"
                @click="jumpToContractStep(1)"
                :rules="[() => !shouldWarnSwapType]"
                :color="contractStepperIndex === 1 ? 'secondary' : 'primary'"
                step="1"
              >
                Choose swap type
                <small>{{ chosenSwapType }}</small>
              </v-stepper-step>

              <v-divider></v-divider>

              <v-stepper-step
                :complete="contractStepperIndex > 2"
                @click="jumpToContractStep(2)"
                :rules="[() => !shouldWarnSwapReason]"
                :color="contractStepperIndex === 2 ? 'secondary' : 'primary'"
                step="2"
              >
                Validation
              </v-stepper-step>

              <v-divider></v-divider>

              <v-stepper-step
                :complete="contractStepperIndex > 3"
                @click="jumpToContractStep(3)"
                :color="contractStepperIndex === 3 ? 'secondary' : 'primary'"
                step="3"
              >
                Choose hardware
              </v-stepper-step>

              <v-divider></v-divider>

              <v-stepper-step
                :complete="contractStepperIndex > 4"
                @click="jumpToContractStep(4)"
                :color="contractStepperIndex === 4 ? 'secondary' : 'primary'"
                step="4"
              >
                Additional information
              </v-stepper-step>

              <v-divider></v-divider>

              <v-stepper-step
                :color="contractStepperIndex === 5 ? 'secondary' : 'primary'"
                @click="jumpToContractStep(5)"
                step="5"
              >
                Send to logistics
              </v-stepper-step>

            </v-stepper-header>

            <v-stepper-items>
              <v-stepper-content step="1">
                <ChooseSwapType :fetchingDataFailed="unitQualificationsFailed" @nextStep="$event === 'contract' ? contractStepperIndex++ : issueStepperIndex = 2"></ChooseSwapType>
              </v-stepper-content>
              <v-stepper-content step="2">
                <ContractValidation
                  :simcards="simcards"
                  @nextStep="contractStepperIndex++"
                  @previousStep="contractStepperIndex--"
                ></ContractValidation>
              </v-stepper-content>
              <v-stepper-content step="3">
                <ChooseHardware
                  :customer="customer"
                  :render="contractStepperIndex === 3"
                  @nextStep="contractStepperIndex++"
                  @previousStep="contractStepperIndex--"
                ></ChooseHardware>
              </v-stepper-content>
              <v-stepper-content step="4">
                <AdditionalInformation
                  :customer="customer"
                  @nextStep="contractStepperIndex++"
                  @previousStep="contractStepperIndex--"
                ></AdditionalInformation>
              </v-stepper-content>
              <v-stepper-content step="5">
                <SendToLogistics
                  @previousStep="contractStepperIndex--"
                  @displayFinishScreen="displayFinishScreen"
                ></SendToLogistics>
              </v-stepper-content>
            </v-stepper-items>
          </v-stepper>
        </div>
      </v-col>
    </v-row>
  </v-dialog>
</template>

<script>
import ChooseSwapType from "@/components/dialogs/swap-handling/ChooseSwapType";
import SwapReason from "@/components/dialogs/swap-handling/SwapReason";
import ContractValidation from "@/components/dialogs/swap-handling/ContractValidation"
import ChooseHardware from "@/components/dialogs/swap-handling/ChooseHardware";
import AdditionalInformation from "@/components/dialogs/swap-handling/AdditionInformation";
import SendToLogistics from "@/components/dialogs/swap-handling/SendToLogistics";
import SwapTroubleshooting from "@/components/dialogs/swap-handling/SwapTroubleshooting";

import util from "@/helpers/util";

import { mapState } from "vuex";
import SingleSwapBanner from "@/components/dialogs/swap-handling/lists/SingleSwapBanner";
import UnitGroup from "@/components/dialogs/swap-handling/lists/UnitGroup";
import IssueUnitGroup from "@/components/dialogs/swap-handling/lists/IssueUnitGroup";
import ContractUnitGroup from "@/components/dialogs/swap-handling/lists/ContractUnitGroup";

export default {
  name: "SwapHandlingWizard",
  components: {
    UnitGroup,
    IssueUnitGroup,
    ContractUnitGroup,
    SingleSwapBanner,
    SwapTroubleshooting,
    SendToLogistics,
    AdditionalInformation,
    ChooseHardware,
    SwapReason,
    ContractValidation,
    ChooseSwapType
  },
  props: {
    show: {
      type: Boolean,
      required: true
    },
    simcards: {
      type: Array,
      required: true
    },
    subscriptions: {
      type: Array,
      required: true
    },
    customer: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      stepperIndex: 1,
      contractStepperIndex: 1,
      issueStepperIndex: 1,
      simcardsWithTerminationDate: [],
      now: new Date(),
      unitQualificationsFailed: false
    };
  },
  async mounted() {
    await this.commitSimcardsAsUnitList();
    await this.fetchUnitQualifications();
    await this.fetchUnitHardwareTypes();

    for (let { terminationDate, serialNumber } of this.subscriptions) {
      if (terminationDate === "")
        continue;

      if (new Date(terminationDate) < this.now)
        continue;

      const simcard = this.simcards.length === 1
        ? this.simcards[0]
        : this.simcards.find(simcard => simcard.serialNumber === serialNumber);

      if (!simcard)
        continue;

      simcard.terminationDate = terminationDate;
      this.simcardsWithTerminationDate.push(simcard);
    }
  },
  methods: {
    async fetchUnitQualifications() {
      try {
        const serialNumbers = this.currentUnits.map(simcard => simcard.serialNumber ?? simcard.dataSourceId);
        if(serialNumbers.length === 0)
          return;

        await this.$store.dispatch("SwapHandlingWizardModule/getUnitQualifications", {
          serialNumbers: serialNumbers
        });
        this.unitQualificationsFailed = false;
      } catch {
        this.$eventBus.$emit('alert', { text: 'Failed retrieving available hardware', type: 'error' });
        this.unitQualificationsFailed = true;
      }
    },
    async fetchUnitHardwareTypes() {
      try {
        const serialNumbers = this.currentUnits.map(simcard => simcard.serialNumber ?? simcard.dataSourceId);
        const unitTypeIds = this.currentUnits.map(simcard => simcard.unitTypeId);
        var units = [];
        for (let i = 0; i < serialNumbers.length; i++) {
          const sn = serialNumbers[i];
          const utid = unitTypeIds[i];
          units.push({
            serialNumber: sn,
            unitTypeId: utid
          });
        }
        if(serialNumbers.length === 0)
          return;

        await this.$store.dispatch("SwapHandlingWizardModule/getUnitHardwareTypes", {
          units: units
        });
      } catch(error) {
        this.$eventBus.$emit('alert', { text: `Failed retrieving unit types (╯°□°）╯︵ ┻━┻`, type: 'warning' });
      }
    },
    displayFinishScreen() {
      this.$eventBus.$emit('alert', {text: `Swap(s) initiated`, type: 'success'});
      this.resetState();
      setTimeout(() => {
        this.$store.dispatch("retrieveDataSources", this.customer.id);
      }, 3000);
      this.shouldShow = false;
      //TODO: this might need more work if we are supposed to display an actual screen or something saying all swaps are done.
    },
    determineSimcardDatasourceId(simcard) {
      if (!simcard)
        return "";

      const id = simcard.id ? simcard.id : (simcard.dataSourceId ?? simcard.serialNumber);
      return id?.toString();
    },
    async commitSimcardsAsUnitList(){
      await this.$store.dispatch("SwapHandlingWizardModule/setCurrentUnits", this.simcards);
    },
    async resetState(){
      await this.$store.dispatch("SwapHandlingWizardModule/resetSwapState");
    },
    jumpToIssueStep(jumpToStep){
      if(this.issueStepperIndex > jumpToStep) this.issueStepperIndex = jumpToStep;
    },
    jumpToContractStep(jumpToStep){
      if(this.contractStepperIndex > jumpToStep) this.contractStepperIndex = jumpToStep;
    }
  },
  computed: {
    ...mapState('SwapHandlingWizardModule', ['swapData', 'swappedUnits', 'swapChoices', 'unitHardwareTypes']),

    singleUnitTypeId() {
      return this.unitHardwareTypes?.length > 0 ? this.unitHardwareTypes[0]?.unitType?.toString() : this.simcards[0]?.unitTypeId?.toString();
    },
    currentUnits() {
      return this.$store.state.SwapHandlingWizardModule.currentUnits;
    },
    swapType() {
      return this.swapData.type;
    },
    chosenSwapType() {
      return this.swapData.type === "" ? "" : `${util.capitalizeFirstLetter(this.swapData.type)} related`;
    },
    chosenSwapReason() {
      return this.swapData.reason.text;
    },
    shouldWarnSwapType() {
      return this.stepperIndex > 1 && this.swapData.type === "";
    },
    shouldWarnSwapReason() {
      return this.stepperIndex > 2 && this.swapData.reason === "";
    },
    shouldShow: {
      get() {
        return this.show;
      },
      set(value) {
        value ? this.stepperIndex = 1 : this.$emit("closeDialog");
      }
    }
  }
};
</script>

<style scoped>
.fixed-list {
  height: 760px;
  max-height: 800px;
  overflow-y: auto;
}
</style>
