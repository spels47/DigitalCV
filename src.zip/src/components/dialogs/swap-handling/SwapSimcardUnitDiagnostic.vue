<template>
  <div class="text-center">
    <v-tooltip bottom color="black lighten-2">
      <template v-slot:activator="{ on }">
        <v-icon v-if="diagnosticsNotApplicable" v-on="on" medium color="grey lighten-1">mdi-minus</v-icon>
        <v-icon v-else-if="isValidSwap" v-on="on" medium color="success">mdi-check</v-icon>
        <v-icon v-else-if="!isValidSwap" v-on="on" medium color="error">mdi-close</v-icon>
      </template>
      <span v-if="diagnosticsNotApplicable">Diagnostic is not available or not applicable:</span>
      <span v-else-if="statusSummary === 'Ok'">Diagnostics shows this unit is in good health:</span>
      <span v-else-if="statusSummary === 'Error'">Diagnostic shows something is wrong:</span>
      <br/>
      <span v-if="!serialNumber.startsWith('MUG')">
        <span v-if="computedDiagnostic.fix === 'Ok'" class="success--text">✔</span>
        <span v-if="computedDiagnostic.fix === 'Error'">🔴</span>
        <span v-if="computedDiagnostic.fix === 'NotApplicable'">➖</span>
        <span> Solid fix</span><br/>
      </span>
      <span v-if="!serialNumber.startsWith('MUG')">
        <span v-if="computedDiagnostic.satellites === 'Ok'" class="success--text">✔</span>
        <span v-if="computedDiagnostic.satellites === 'Error'">🔴</span>
        <span v-if="computedDiagnostic.satellites === 'NotApplicable'">➖</span>
        <span> GPS satellites in view</span><br/>
      </span>
      <span v-if="!serialNumber.startsWith('MUG')">
        <span v-if="computedDiagnostic.power === 'Ok'" class="success--text">✔</span>
        <span v-if="computedDiagnostic.power === 'Error'">🔴</span>
        <span v-if="computedDiagnostic.power === 'NotApplicable'">➖</span>
        <span> Connected to external power source</span><br/>
      </span>
      <span v-if="serialNumber.startsWith('MUG')">
        <span v-if="computedDiagnostic.battery === 'Ok'" class="success--text">✔</span>
        <span v-if="computedDiagnostic.battery === 'Error'">🔴</span>
        <span v-if="computedDiagnostic.battery === 'NotApplicable'">➖</span>
        <span> - Battery status</span><span>{{ computedDiagnostic.batteryPercentLeft === null ? '' : ` (${computedDiagnostic.batteryPercentLeft}%)` }}</span><br/>
      </span>
      <span>
        <span v-if="computedDiagnostic.positions === 'Ok'" class="success--text">✔</span>
        <span v-if="computedDiagnostic.positions === 'Error'">🔴</span>
        <span v-if="computedDiagnostic.positions === 'NotApplicable'">➖</span>
        <span> GPS position received in the last 72 hours</span><br/>
      </span>
      <br>
      <span v-for="reason in validationReasons" :key="reason">
        <span v-show="isValidSwap === true" class="success--text">✔</span>
        <span v-show="!isValidSwap">🔴</span>
        <span> {{ reason }}</span><br/>
      </span>

    </v-tooltip>

  </div>
</template>

<script>
export default {
  name: "SwapSimcardUnitDiagnostic",
  props: {
    serialNumber: String,
    unitDiagnostic: {
      type: Object,
      default: () => {}
    },
    hide: Boolean
  },
  computed: {
    statusSummary() {
      return this.computedDiagnostic?.statusSummary ?? null;
    },
    validationReasons() {
      return this.computedDiagnostic.validationReasons;
    },
    isValidSwap() {
      return this.computedDiagnostic.validSwap;
    },
    computedDiagnostic() {
      return this.unitDiagnostic ?? {};
    },
    diagnosticsNotApplicable() {
      let fix = this.computedDiagnostic.fix === 'NotApplicable';
      let satellites = this.computedDiagnostic.satellites === 'NotApplicable';
      let power = this.computedDiagnostic.power === 'NotApplicable';
      let battery = this.computedDiagnostic.battery === 'NotApplicable';
      let positions = this.computedDiagnostic.positions === 'NotApplicable';

      return fix && satellites && power && battery && positions;
    }
  }
};
</script>

<style scoped>

</style>
