<template>
  <v-list class="overflow-y-auto" height="450">
    <v-list-item v-for="item in validSwaps" :key="item.serialNumber" :id="item.serialNumber" @click="emitSelectedUnit(item)" class="unselectedUnit">
        <template v-slot:default="{ active }">
          <v-list-item-avatar>
            <v-icon v-text="determineIcon(item)"></v-icon>
          </v-list-item-avatar>

          <v-list-item-content>
            <v-list-item-title>
              {{ determineUnitDatasourceId(item) }}
            </v-list-item-title>
            <v-list-item-subtitle>
              {{ getUnitHardwareType(determineUnitDatasourceId(item)) == null ? item.unitTypeId : getUnitHardwareType(determineUnitDatasourceId(item)) }} <v-icon v-if="getSwapChoiceUnitBySerialNumber(item.serialNumber) != null">mdi-arrow-right</v-icon> <span v-if="getSwapChoiceUnitBySerialNumber(item.serialNumber) != null">{{getSwapChoiceUnitBySerialNumber(item.serialNumber)}}</span>
            </v-list-item-subtitle>
          </v-list-item-content>
        </template>
    </v-list-item>
  </v-list>
</template>

<script>
import { mapState } from "vuex";
export default {
  name: "DisplayUnits",
  emits: ["selectedUnitType"],
  components: {

  },
  props: {
    validSwaps: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      selectedUnit: null
    };
  },
  methods: {
    determineIcon(unit) {
      return unit.unitTypeId.includes("EQ") ? "mdi-bulldozer" : "mdi-cable-data";
    },
    determineUnitDatasourceId(unit) {
      const id = unit.id ? unit.id : unit.serialNumber;
      return id.toString();
    },
    emitSelectedUnit(unit){
      var list = document.getElementsByClassName("selectedUnit");
      if(list.length > 0) list[0].classList.remove("selectedUnit");

      document.getElementById(unit.serialNumber).classList.add("selectedUnit");
      this.selectedUnit = unit;
      this.$emit("selectedUnitType", unit);
    },
    getSwapChoiceUnitBySerialNumber(serialNumber){
      for (let i = 0; i < this.swapChoices.length; i++) {
        const swapChoice = this.swapChoices[i];
        if(swapChoice.serialNumber == serialNumber) return swapChoice.unitQualification.unitType.replaceAll("_", " ");
      }
      return null;
    },
    getUnitHardwareType(serialNumber){
      for (let i = 0; i < this.unitHardwareTypes.length; i++) {
        const hardwareType = this.unitHardwareTypes[i];
        if(hardwareType.serialNumber == serialNumber) return hardwareType.unitType;
      }
      return null;
    }
  },
  computed: {
    ...mapState('SwapHandlingWizardModule', ['swapData', 'troubleShootingData', 'issueValidationData', 'contractValidationData', 'validSwapUnits', 'swapChoices', 'unitQualifications', 'unitHardwareTypes']),
  },
  watch: {

  },
  mounted(){
    this.$nextTick(() => {
      document.getElementsByClassName("unselectedUnit")[0].classList.add("selectedUnit");
    });
  }
};
</script>

<style scoped>
.unselectedUnit{
  border-radius: 5px;
  margin-bottom: 5px;
}
.unselectedUnit::hover{
  background-color:rgba(255, 255, 255, 0.5);
}
.selectedUnit{
  background-color: rgba(155, 155, 155, 0.75);
}
</style>
