﻿<template>
  <div>
    <v-card
      class="mb-12"
      height="600px"
    >
      <v-card-title class="justify-center">
        <span class="headline secondary--text font-weight-medium">Why is SWAP needed?</span>
      </v-card-title>

      <v-card-text style="height: 85%">
        <v-container
          style="height: 100%"
          fluid
        >
          <v-row
            align="center"
            style="height: 50%"
          >
            <v-col
              v-for="reason in firstTwoReasons"
              :key="reason.id"
              cols="6"
              class="d-flex justify-center"
            >
              <v-card
                width="50%"
                class="clickable-card rounded-xl"
                hover
                ripple
                @click="setSwapReason(reason)"
              >
                <v-card-title class="justify-center">{{ reason.text }}</v-card-title>
                <v-card-text class="d-flex justify-center">
                  <v-icon size="40">
                    {{ reason.icon }}
                  </v-icon>
                </v-card-text>
              </v-card>
            </v-col>
          </v-row>

          <v-row
            align="center"
            style="height: 50%"
          >
            <v-col
              v-for="reason in remainingReasons"
              :key="reason.id"
              cols="6"
              class="d-flex justify-center"
            >
              <v-card
                width="50%"
                class="clickable-card rounded-xl"
                hover
                ripple
                @click="setSwapReason(reason)"
              >
                <v-card-title class="justify-center">{{ reason.text }}</v-card-title>
                <v-card-text class="d-flex justify-center">
                  <v-icon size="40">
                    {{ reason.icon }}
                  </v-icon>
                </v-card-text>
              </v-card>

            </v-col>
          </v-row>
        </v-container>
      </v-card-text>
    </v-card>
    <div class="d-flex justify-end mr-2">
      <v-btn tex @click="previousStep" class="mb-1">Previous</v-btn>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from "vuex";

export default {
  name: "SwapReason",
  data() {
    return {
      reasons: [
        {
          text: "Technical error",
          icon: "mdi-cable-data",
          reason: "technical",
          id: 0
        },
        {
          text: "Carrier issue",
          icon: "mdi-truck",
          reason: "carrier",
          id: 1
        },
        {
          text: "Customer blunder",
          icon: "mdi-account-question",
          reason: "customer-blunder",
          id: 2
        },
        {
          text: "ABAX blunder",
          icon: "mdi-domain",
          reason: "abax-blunder",
          id: 3
        }
      ]
    }
  },
  methods: {
    ...mapActions({
      saveSwapReason: 'SwapHandlingWizardModule/setSwapReason'
    }),

    setSwapReason({ reason, text }) {
      this.saveSwapReason({ reason: reason, text: text});
      this.nextStep();
    },
    nextStep() {
      this.$emit("nextStep");
    },
    previousStep() {
      this.$emit("previousStep");
    }
  },
  computed: {
    ...mapState('SwapHandlingWizardModule', ['swapData']),
    firstTwoReasons() {
      return this.reasons.filter(reason => reason.id <= 1);
    },
    remainingReasons() {
      return this.reasons.filter(reason => reason.id > 1);
    },
    currentUnits() {
      return this.$store.state.SwapHandlingWizardModule.currentUnits;
    },
    hasSwapReason(){
      return this.swapData.reason?.reason ?? false;
    }
  }
};
</script>

<style scoped>
</style>
