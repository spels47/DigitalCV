<template>
  <div class="text-center">
    <v-tooltip
      color="black lighten-2"
      bottom
      v-if="isValidSwap === true && reason != null"
    >
      <template v-slot:activator="{ on }">
        <v-icon v-on="on" medium color="success">mdi-check</v-icon>
      </template>
      <span v-show="!isValidSwap">Validation shows this unit does not qualify for swap:</span>
      <br v-if="!isValidSwap"/>
      <span v-for="reason in validationReasons" :key="reason">
        <span v-show="isValidSwap === true" class="success--text">✔</span>
        <span v-show="!isValidSwap">🔴</span>
        <span> {{ reason }}</span><br/>
      </span>
    </v-tooltip>
    <v-tooltip
      color="black lighten-2"
      bottom
      v-if="!isValidSwap && reason === 'contract'"
    >
      <template v-slot:activator="{ on }">
        <v-icon v-on="on" medium color="error">mdi-alert</v-icon>
      </template>
      <span v-show="!isValidSwap">Validation shows this unit does not qualify for swap:</span>
      <br v-if="!isValidSwap"/>
      <span v-for="reason in validationReasons" :key="reason">
        <span v-show="isValidSwap === true" class="success--text">✔</span>
        <span v-show="!isValidSwap">🔴</span>
        <span> {{ reason }}</span><br/>
      </span>
    </v-tooltip>
    <v-tooltip
      color="black lighten-2"
      bottom
      v-if="!isValidSwap && reason == 'carrier'"
    >
      <template v-slot:activator="{ on }">
        <v-icon v-on="on" medium color="error">mdi-alert-octagon</v-icon>
      </template>
      <span v-show="!isValidSwap">Validation shows this unit does not qualify for swap:</span>
      <br v-if="!isValidSwap"/>
      <span v-for="reason in validationReasons" :key="reason">
        <span v-show="isValidSwap === true" class="success--text">✔</span>
        <span v-show="!isValidSwap">🔴</span>
        <span> {{ reason }}</span><br/>
      </span>
    </v-tooltip>
    <v-tooltip
      color="black lighten-2"
      bottom
      v-if="!isValidSwap && reason == 'abax-blunder'"
    >
      <template v-slot:activator="{ on }">
        <v-icon v-on="on" medium color="error">mdi-alert-decagram</v-icon>
      </template>
      <span v-show="!isValidSwap">Validation shows this unit does not qualify for swap:</span>
      <br v-if="!isValidSwap"/>
      <span v-for="reason in validationReasons" :key="reason">
        <span v-show="isValidSwap === true" class="success--text">✔</span>
        <span v-show="!isValidSwap">🔴</span>
        <span> {{ reason }}</span><br/>
      </span>
    </v-tooltip>
    <v-tooltip
      color="black lighten-2"
      bottom
      v-if="!isValidSwap && reason == 'customer-blunder'"
    >
      <template v-slot:activator="{ on }">
        <v-icon v-on="on" medium color="error">mdi-alert-rhombus</v-icon>
      </template>
      <span v-show="!isValidSwap">Validation shows this unit does not qualify for swap:</span>
      <br v-if="!isValidSwap"/>
      <span v-for="reason in validationReasons" :key="reason">
        <span v-show="isValidSwap === true" class="success--text">✔</span>
        <span v-show="!isValidSwap">🔴</span>
        <span> {{ reason }}</span><br/>
      </span>
    </v-tooltip>
  </div>
</template>

<script>
export default {
  name: "ContractSwapValidationStatus",
  props: {
    serialNumber: String,
    unitValidation: Object,
    hide: Boolean,
    reason: String
  },
  computed: {
    isValidSwap() {
      return this.unitValidation?.validSwap;
    },
    validationReasons() {
      return this.unitValidation?.validationReasons ?? [];
    }
  }
};
</script>

<style scoped>

</style>
