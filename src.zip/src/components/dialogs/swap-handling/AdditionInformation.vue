﻿<template>
  <div>
    <v-card
      class="mb-12"
      height="600px"
    >
      <v-card-title class="justify-center">
        <span class="headline secondary--text font-weight-medium">Additional information</span>
      </v-card-title>

      <v-card-text class="d-flex justify-center pt-0">
        <v-form
          ref="form"
          class="form"
        >
          <div class="d-flex flex-row justify-space-between">
            <div class="field-width">
              <v-text-field
                :rules="[rules.required, rules.number, rules.integer]"
                v-model="ticketId"
                label="SuperOffice ticket ID *"
                hint="ID from relevant ticket in SuperOffice"
                append-icon="mdi-identifier"
                class="mr-4"
              ></v-text-field>
            </div>

            <div class="field-width">
              <v-text-field
                :rules="[rules.required, rules.whitespace]"
                v-model="contactPerson.name"
                label="Name *"
                hint="The name of the contact person"
                append-icon="mdi-account-edit"
                class="ml-4"
              ></v-text-field>
            </div>
            
          </div>
          
          <div class="d-flex flex-row justify-space-between">
            <div class="field-width">
              <v-text-field
                :value="getShouldInvoiceCustomer"
                label="Invoice customer"
                append-icon="mdi-receipt"
                width="calc(50% - 4px)"
                class="mr-4"
                readonly
              ></v-text-field>
            </div>

            <div class="field-width">
              <v-text-field
                :rules="[rules.required, rules.phone]"
                v-model="inputtedPhoneNumber"
                width="calc(50% - 4px)"
                label="Phone *"
                :prefix="phoneNumberPrefix()"
                hint="The phone number of the contact person"
                append-icon="mdi-account-edit"
                class="ml-4"
              ></v-text-field>
            </div>
          </div>

          <div class="d-flex flex-row justify-space-between">
            <div class="field-width">
              <v-select width="calc(50% - 4px)" class="mr-4" v-model="selectedConsignmentType" :items="consignmentTypes" item-text="text" item-value="value" label="Consignment type *"></v-select>
            </div>

            <div class="field-width">
              <v-text-field
                :rules="[rules.email, rules.ascii]"
                v-model="contactPerson.email"
                width="calc(50% - 4px)"
                label="Email"
                hint="The email of the contact person"
                append-icon="mdi-account-edit"
                class="ml-4"
              ></v-text-field>
            </div>
          </div>

          <div class="d-flex flex-row justify-space-between">
            <div class="field-width">
              <v-checkbox
                v-model="includeReturnLabel"
                width="calc(50% - 4px)"
                label="Include return label?"
                color="primary"
                class="mr-4"
              ></v-checkbox>
            </div>

            <div class="field-width">
              <v-text-field
                :rules="[rules.required, rules.whitespace]"
                v-model="confirmedAddress"
                width="calc(50% - 4px)"
                label="Confirmed address *"
                hint="Desired delivery address"
                append-icon="mdi-map-marker"
                class="ml-4"
              ></v-text-field>
            </div>
          </div>

          <v-textarea
            v-model="otherInformation"
            label="Other information"
            append-icon="mdi-information-variant"
            height="200"
            :rules="[v => v.length <= 2000 || 'Please stay within the 2000 char limit']"
            outlined
            no-resize
          >
          </v-textarea>
        </v-form>
      </v-card-text>
    </v-card>

    <div class="d-flex justify-end mr-2">
      <v-btn
        tex
        @click="previousStep"
      >
        Previous
      </v-btn>
      <v-btn
        color="secondary"
        width="150px"
        class="mb-1 ml-2"
        @click="nextStep"
        :disabled="ticketId.length === 0 || confirmedAddress.length === 0 || otherInformation.trim().length > 2000 || !selectedConsignmentType || contactPerson.name.trim().length == 0 || contactPerson.phone.trim().length == 0"
      >
        Next
      </v-btn>
    </div>
  </div>
</template>

<script>
/* eslint-disable */

import { mapActions, mapState } from "vuex";

export default {
  name: "AdditionalInformation",
  props: {
    customer: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      rules: {
        required: v => !!v || "Field is required.",
        number: v => /^\d+$/.test(v) || 'A number is required.',
        integer: v => v <= 2147483647 || 'Maximum valid value is 2147483647',
        whitespace: v => v?.trim()?.length > 0 || 'Field must consist of more than just white space',
        email: v => (/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(v) || !v) || 'this is not a valid email',
        ascii: v => /^[\x00-\x7F]*$/.test(v) || 'the text must contain only ASCII characters',
        phone: v => this.validatePhone(v) || 'this is not a valid phone number'
      },
      ticketId: "",
      confirmedAddress: "",
      otherInformation: "",
      contactPerson: {
        name: "",
        phone: "",
        email: ""
      },
      consignmentTypes: [
        {
          text: "Pick up point",
          value: "PuP"
        },
        {
          text: "Business to business",
          value: "B2B"
        }
      ],
      selectedConsignmentType: null,
      inputtedPhoneNumber: "",
      includeReturnLabel: false
    }
  },
  async mounted() {
    await this.getMainOfficeAddress(this.customer);
    this.confirmedAddress = this.customerAddress;
  },
  methods: {
    ...mapActions({
      saveAdditionalInformation: 'SwapHandlingWizardModule/setAdditionalInformation',
      getMainOfficeAddress: 'SwapHandlingWizardModule/getMainOfficeAddress'
    }),

    nextStep() {
      if (!this.$refs.form.validate())
        return;

      this.saveAdditionalInformation({
        ticketId: this.ticketId,
        invoiceCustomer: this.getShouldInvoiceCustomer.toLowerCase().startsWith("yes"),
        confirmedAddress: this.confirmedAddress,
        otherInformation: this.otherInformation,
        consignmentType: this.selectedConsignmentType,
        contactPerson: this.contactPerson,
        includeReturnLabel: this.includeReturnLabel
      });
      this.$emit("nextStep");
    },
    previousStep() {
      this.$emit("previousStep");
    },
    validatePhone(phoneInput) {
        var phoneformat = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
        let inputWithCountryCode = this.getPhoneCountryCode(this.customer.country) + phoneInput;

        if(inputWithCountryCode?.trim().match(phoneformat)){
          this.contactPerson.phone = this.formatPhoneNumber(inputWithCountryCode?.trim());
          return true;
        }
        else if(phoneInput?.trim().match(phoneformat)){
          this.contactPerson.phone = this.formatPhoneNumber(phoneInput?.trim());
          return true;
        }
        else {
          this.contactPerson.phone = this.formatPhoneNumber(phoneInput?.trim());
          return false;
        }
      },
    formatPhoneNumber(number){
        if(!number) return;
        let result = number;
        let countryCode = this.getPhoneCountryCode(this.country);
        if(result.substring(3, 4) == ' ') result = '+' + result;
        if(result.substring(3, 4) == '-') result = '+' + result;
        if(result.substring(3, 4) == '.') result = '+' + result;
        result = result.replaceAll('(', '+');
        result = result.replaceAll(')', '');
        result = result.replaceAll(' ', '');
        result = result.replaceAll('-', '');
        result = result.replaceAll('.', '');
        if(result.substring(0,1) != '+' && countryCode != '') result = countryCode + result;
        else if(result.substring(0,1) != '+') result = '+' + result;
        return result;
    },
    getPhoneCountryCode(countryCode){
        if(countryCode == null || countryCode == "") return '';
        switch(countryCode.toUpperCase()){
          case 'NO': return '+47';
          case '+47': return '+47';
          case 'SE': return '+46';
          case '+46': return '+46';
          case 'DK': return '+45';
          case '+45': return '+45';
          case 'BE': return '+32';
          case '+32': return '+32';
          case 'DE': return '+49';
          case '+49': return '+49';
          case 'FI': return '+358';
          case '+358': return '+358';
          case 'FR': return '+33';
          case '+33': return '+33';
          case 'UK': return '+44';
          case '+44': return '+44';
          case 'NL': return '+31';
          case '+31': return '+31';
          case 'PL': return '+48';
          case '+48': return '+48';
          case 'IT': return '+39';
          case '+39': return '+39';
          default: return countryCode;
        }
    },
    phoneNumberPrefix(){
      return this.inputtedPhoneNumber.substring(0,1) != '+' ? this.getPhoneCountryCode(this.customer.country) : '';
    }
},
  computed: {
    ...mapState('SwapHandlingWizardModule', ['swapData', 'mainOfficeAddress']),

    customerAddress() {
      if(!this.customer.address || !this.customer.zip || !this.customer.city) {
        if(!this.mainOfficeAddress.address || !this.mainOfficeAddress.zip || !this.mainOfficeAddress.city) return null
        return `${this.mainOfficeAddress.address}, ${this.mainOfficeAddress.zip} ${this.mainOfficeAddress.city}`;
      }
      return `${this.customer.address}, ${this.customer.zip} ${this.customer.city}`;
    },
    getShouldInvoiceCustomer() {
      switch (this.swapReason) {
        case "customer-blunder":
          return "Yes, send receipt.";
        default:
          return "ABAX pays based on swap reason.";
      }
    },
    swapReason() {
      return this.swapData.reason.reason;
    }
  }
};
</script>

<style scoped>
.form {
  width: 100%;
}
.field-width {
  width: calc(50% - 4px);
}
</style>
