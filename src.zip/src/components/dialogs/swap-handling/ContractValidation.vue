<template>
  <div>
    <v-card
      class="mb-12"
      height="600px"
    >
      <v-card-title class="justify-center">
        <span class="headline secondary--text font-weight-medium">Validation</span>
      </v-card-title>
      <v-card-subtitle
        v-if="invalidSwaps.length !== 0"
        class="text-center"
      >
        Some units are not eligible for swapping. You can continue with the wizard, but you will only be able to initiate swaps on valid units.
      </v-card-subtitle>

      <v-card-text>
        <v-container
          fluid
        >
          <v-row
            align="center"
          >
            <v-col
              cols="6"
            >
              <v-card
                width="85%"
              >
                <v-card-title>Invalid swaps</v-card-title>
                <v-card-subtitle>These units will <b>not</b> be swapped.</v-card-subtitle>
                <v-card-text>
                  <v-list
                    class="fixed-list"
                    shaped
                  >
                    <v-list-item
                      v-for="unit in invalidSwaps"
                      :key="unit.serialNumber"
                    >
                      <template v-slot:default="{ active }">
                        <v-list-item-avatar>
                          <v-icon>mdi-cable-data</v-icon>
                        </v-list-item-avatar>

                        <v-list-item-content>
                          <v-list-item-title>
                            {{ unit.serialNumber }}
                          </v-list-item-title>
                        </v-list-item-content>

                        <v-list-item-action>
                          <div class="d-flex">
                            <v-menu
                              open-on-hover
                              top
                            >
                              <template v-slot:activator="{ on, attrs }">
                                <v-icon
                                  v-on="on"
                                  v-bind="attrs"
                                  color="error"
                                  class="mr-2"
                                >
                                  mdi-information
                                </v-icon>
                              </template>

                              <v-list>
                                <v-subheader>This unit does not meet the requirements for a swap:</v-subheader>
                                <v-list-item
                                  v-for="(reason, index) in unit.validationReasons"
                                  :key="index"
                                >
                                  <v-list-item-icon>
                                    <v-icon>mdi-information</v-icon>
                                  </v-list-item-icon>
                                  <v-list-item-content>
                                    <v-list-item-title>{{ reason }}</v-list-item-title>
                                  </v-list-item-content>
                                </v-list-item>
                              </v-list>
                            </v-menu>
                          </div>
                        </v-list-item-action>
                      </template>
                    </v-list-item>
                  </v-list>
                </v-card-text>
              </v-card>

            </v-col>

            <v-col
              cols="6"
              class="d-flex justify-center"
            >
              <v-card
                width="95%"
              >
                <v-card-title>Valid swaps</v-card-title>
                <v-card-subtitle>{{ validSwaps.length }} units are eligible for swapping.</v-card-subtitle>
                <v-card-text>
                  <v-list
                    v-if="validSwaps.length > 0"
                    class="fixed-list"
                    shaped
                  >
                    <v-list-item
                      v-for="unit in validSwaps"
                      :key="unit.serialNumber"
                      dense
                    >
                      <template v-slot:default="{ active }">
                        <v-list-item-avatar>
                          <v-icon>mdi-cable-data</v-icon>
                        </v-list-item-avatar>

                        <v-list-item-content>
                          <v-list-item-title>
                            {{ unit.serialNumber }}
                          </v-list-item-title>
                        </v-list-item-content>
                      </template>
                    </v-list-item>
                  </v-list>

                  <div
                    v-else
                    class="d-flex justify-center align-center"
                    style="height: 375px"
                  >
                    <v-icon size="150">mdi-emoticon-sad-outline</v-icon>
                  </div>
                </v-card-text>
              </v-card>
            </v-col>
          </v-row>
        </v-container>
      </v-card-text>
    </v-card>

    <div class="d-flex justify-end mr-2">
      <v-btn
        tex
        @click="previousStep"
      >
        Previous
      </v-btn>
      <v-btn
        color="secondary"
        width="150px"
        class="mb-1 ml-2"
        :disabled="validSwaps.length === 0"
        @click="nextStep"
      >
        Next
      </v-btn>
    </div>
  </div>
</template>

<script>
export default {
  name: "ContractValidation",
  props: {
    simcards: {
      type: Array,
      required: true
    }
  },
  data() {
    return {
      validSwaps: [],
      invalidSwaps: []
    };
  },
  watch: {
    contractValidationData(newValue, oldValue) {
      this.invalidSwaps = [];
      this.validSwaps = [];
      if (!newValue) return;

      for (const unit of newValue) {
        const serialNumber = unit.serialNumber ?? unit.dataSourceId;
        const entry = newValue.find(x => x.serialNumber === serialNumber);

        if (entry.validSwap === false)
          this.invalidSwaps.push(entry);
        else
          this.validSwaps.push(entry);
      }
    }
  },
  methods: {
    nextStep() {
      this.commitValidUnits();
      this.$emit("nextStep");
    },
    previousStep() {
      this.$emit("previousStep");
    },
    isInvalidSwap(unit) {
      const serialNumber = unit.serialNumber ?? unit.dataSourceId;
      return this.invalidSwaps.findIndex(x => x.serialNumber === serialNumber || x.dataSourceId === serialNumber) !== -1;
    },
    async commitValidUnits() {
      let validUnits = [];
      validUnits = this.contractValidationData.filter(unit => unit.validSwap).map(unit => unit.serialNumber);

      let data = [];

      for (let i = 0; i < this.currentUnits.length; i++) {

        const currentUnit = this.currentUnits[i];
        for (let k = 0; k < validUnits.length; k++) {
          const validUnit = validUnits[k];

          const serialNumber = currentUnit.serialNumber ?? currentUnit.dataSourceId;
          if (currentUnit.dataSourceId) {
            delete currentUnit['dataSourceId']
          }

          currentUnit.serialNumber = serialNumber;

          if (validUnit === currentUnit.serialNumber)
            data.push(currentUnit);
        }
      }

      await this.$store.dispatch("SwapHandlingWizardModule/setValidSwapUnits", { data });
    }
  },
  computed: {
    firstTwoReasons() {
      return this.reasons.filter(reason => reason.id <= 1);
    },
    remainingReasons() {
      return this.reasons.filter(reason => reason.id > 1);
    },
    contractValidationData() {
      const data = this.$store.state.SwapHandlingWizardModule.contractValidationData;
      return Object.entries(data).length > 0 ? data : null;
    },
    currentUnits(){
      return this.$store.state.SwapHandlingWizardModule.currentUnits;
    }
  }
};
</script>

<style scoped>
.fixed-list {
  height: 375px;
  max-height: 375px;
  overflow-y: auto;
}
</style>
