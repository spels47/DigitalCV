﻿<template>
  <div>
    <v-card
      class="mb-12"
      height="600px"
    >
      <v-card-title class="justify-center">
        <span class="headline secondary--text font-weight-medium">Unit troubleshooting</span>
      </v-card-title>

      <v-card-text>
        <v-row>
          <v-col
            v-if="isTechnicalReason"
            cols="6"
          >
            <v-card
              v-if="currentSimcardIfApplicable"
              :loading="loadingTelemetry"
              width="85%"
              elevation="1"
            >
              <v-card-title
                class="subtitle-2"
              >
                Latest diagnostic for {{ currentSimcardIfApplicableSerialNumber }}

                <v-spacer></v-spacer>

                <SwapSimcardUnitDiagnostic
                  :serialNumber="singleTroubleshootingData.serialNumber"
                  :unitDiagnostic="singleTroubleshootingData"
                ></SwapSimcardUnitDiagnostic>
              </v-card-title>

              <v-divider></v-divider>

              <v-card-text>
                <TelemetryComponent
                  :telemetry="telemetry"
                  :showPlacement="false"
                  :noDataText="'No data available'"
                  :currentStateHoverMessage="'This icon represents the current state, <br/>the dropdown shows the state'"
                  modern
                ></TelemetryComponent>
              </v-card-text>
            </v-card>

            <v-card
              v-else
              :loading="loadingTroubleShooting"
              rounded
              width="85%"
              elevation="1"
            >
              <v-card-title class="font-weight-regular">Aggregated status for the selected units</v-card-title>
              <v-card-text v-if="constructedTroubleShootingData">
                <v-list>
                  <v-list-item
                    v-for="(status, index) in constructedTroubleShootingData"
                    :key="index"
                  >
                    <v-list-item-content>
                      <v-list-item-title>{{ status.text }}</v-list-item-title>
                    </v-list-item-content>

                    <v-list-item-action class="mb-1">
                      <template v-if="status.value === null">
                        <v-tooltip bottom>
                          <template v-slot:activator="{ on, attrs }">
                            <v-icon
                              color="success"
                              v-on="on"
                              v-bind="attrs"
                            >
                              mdi-check
                            </v-icon>
                          </template>
                          <span>Not applicable for this unit-type</span>
                        </v-tooltip>
                      </template>

                      <v-badge
                        v-else
                        class="ml-1"
                        :content="status.value"
                        color="error"
                      >
                      </v-badge>
                    </v-list-item-action>
                  </v-list-item>
                </v-list>
              </v-card-text>
            </v-card>
          </v-col>
          <v-col :cols="isTechnicalReason ? 6 : 12">
            <v-form ref="form">
              <v-checkbox
                label="Troubleshooting has been conducted"
                color="secondary"
                :rules="[v => !!v || 'You have to troubleshoot the units thoroughly, and confirm that troubleshooting has been conducted by checking off this checkbox.']"
                v-model="confirmTroubleshooting"
                @update:error="troubleShootingHasError = $event"
                :style="troubleShootingHasError ? 'margin-bottom: 12px;' : ''"
              >
              </v-checkbox>

              <v-textarea
                :disabled="confirmTroubleshooting === false"
                :rules="[v => !!v || 'Please elaborate on how you troubleshooted the issue.', v => v.trim().length <= 2000 || 'Please stay within the 2000 char limit']"
                v-model="troubleShootingInfo"
                label="What have you done to troubleshoot the issue?"
                height="335"
                outlined
                no-resize
              >
              </v-textarea>

              <v-card-text class="text-center text-size">
                <span v-if="faultyUnitsCount === 0 && validSwapsCount === 0">
                  You cannot continue as there are <b>0</b> units that are eligible for swap.
                </span>

                <template v-else>
                  <span v-if="isTechnicalReason">
                    <b>{{ faultyUnitsCount }}</b> out of <b>{{ currentUnits.length }}</b> units are eligible for swapping.
                  </span>
                  <span v-else>
                    <b>{{ validSwapsCount }}</b> out of <b>{{ currentUnits.length }}</b> units are eligible for swapping.
                  </span>
                </template>
              </v-card-text>
            </v-form>
          </v-col>
        </v-row>
      </v-card-text>
    </v-card>

    <div class="d-flex justify-end mr-2">
      <v-btn
        tex
        @click="previousStep"
      >
        Previous
      </v-btn>
      <v-btn
        color="secondary"
        width="150px"
        class="mb-1 ml-2"
        :disabled="isTechnicalReason && faultyUnitsCount === 0 || !isTechnicalReason && validSwapsCount === 0 || confirmTroubleshooting === false || troubleShootingInfo.trim().length === 0 || troubleShootingInfo.trim().length > 2000"
        @click="nextStep"
      >
        Next
      </v-btn>
    </div>
  </div>
</template>

<script>
import TelemetryComponent from "@/components/TelemetryComponent";
import axios from "@/axios-client";
import moment from "moment";
import { mapActions, mapState } from "vuex";
import SwapSimcardUnitDiagnostic from "@/components/dialogs/swap-handling/SwapSimcardUnitDiagnostic";

export default {
  name: "SwapTroubleshooting",
  components: { SwapSimcardUnitDiagnostic, TelemetryComponent },
  data() {
    return {
      loadingTelemetry: false,
      loadingTroubleShooting: false,
      confirmTroubleshooting: false,
      troubleShootingHasError: false,
      telemetry: {},
      troubleShootingInfo: "",
      currentSimcardIfApplicable: null,
      constructedTroubleShootingData: null
    };
  },
  methods: {
    ...mapActions({
      saveTroubleshooting: 'SwapHandlingWizardModule/setTroubleShootingInfo',
      troubleShootUnits: 'SwapHandlingWizardModule/troubleShootUnits'
    }),

    async getTelemetry(id) {
      const date = moment(new Date()).format("yyyy-MM-DD");
      if(!id) return;
      if(id.substring(0,2) == "AM" || id.substring(0,3) == "MUM") {
        this.telemetry = {
          currentState: {
            battery: "NotApplicable",
            batteryPercentLeft: null,
            fix: "NotApplicable",
            placement: "NotApplicable",
            positions: "NotApplicable",
            power: "NotApplicable",
            resetsSinceLastMessage: 0,
            satellites: "NotApplicable",
            statusSummary: "NotApplicable"
          },
          history: [],
          serialNumber: id,
          simcardId: 0,
          unitType: "MINI"
        };
        return;
      } 

      this.loadingTelemetry = true;
      try {
        const { data } = await axios.get(`/api/telemetry/${id}/${date}/${date}`);
        this.telemetry = data;
      } catch {
        this.$eventBus.$emit("alert", { text: `Failed to fetch telemetry data for the swap handling wizard 😒`, type: "error" });
      } finally {
        this.loadingTelemetry = false;
      }
    },
    async massTroubleshootUnits(simcards) {
      this.loadingTroubleShooting = true;
      try {
        const serialNumbers = simcards.map(simcard => simcard.serialNumber ?? simcard.dataSourceId);
        await this.troubleShootUnits(serialNumbers);
      } catch (e) {
        this.$eventBus.$emit("alert", { text: `Failed to get troubleshooting data 🤢😢`, type: "error" });
      } finally {
        this.loadingTroubleShooting = false;
      }
    },
    nextStep() {
      if (!this.$refs.form.validate())
        return;

      this.saveTroubleshooting({
        hasTroubleshooted: this.confirmTroubleshooting,
        troubleshootingInfo: this.troubleShootingInfo
      })
      this.commitValidUnits();
      this.$emit("nextStep");
    },
    previousStep() {
      this.$emit("previousStep");
    },
    async commitValidUnits() {
      let validUnits = [];

      if (this.isTechnicalReason) {
        validUnits = this.troubleShootingData.troubleShootingPerUnit.filter(unit => unit.validSwap).map(unit => unit.serialNumber);
      } else if (!this.isTechnicalReason) {
        validUnits = this.issueValidationData.filter(unit => unit.validSwap).map(unit => unit.serialNumber);
      }

      let data = [];

      for (let i = 0; i < this.currentUnits.length; i++) {

        const currentUnit = this.currentUnits[i];
        for (let k = 0; k < validUnits.length; k++) {
          const validUnit = validUnits[k];

          const serialNumber = currentUnit.serialNumber ?? currentUnit.dataSourceId;
          if (currentUnit.dataSourceId) {
            delete currentUnit['dataSourceId']
          }

          currentUnit.serialNumber = serialNumber;

          if (validUnit === currentUnit.serialNumber)
            data.push(currentUnit);
        }
      }

      await this.$store.dispatch("SwapHandlingWizardModule/setValidSwapUnits", { data });
    }
  },
  computed: {
    ...mapState('SwapHandlingWizardModule', ['swapData', 'troubleShootingData', 'issueValidationData', 'currentUnits']),

    aggregatedTroubleShootingInfo() {
      return this.troubleShootingData.troubleShootingSummary;
    },
    singleTroubleshootingData() {
      return this.troubleShootingData?.troubleShootingPerUnit[0] ?? {};
    },
    faultyUnitsCount() {
      var unitsWithErrors = [];
      if (!this.isTechnicalReason || !this.troubleShootingData?.troubleShootingPerUnit) return 0;
      for (let index = 0; index < this.troubleShootingData.troubleShootingPerUnit.length; index++) {
        const troubleShootingUnit = this.troubleShootingData.troubleShootingPerUnit[index];
        if (troubleShootingUnit.validSwap) unitsWithErrors.push(troubleShootingUnit);
      }
      return unitsWithErrors?.length ?? 0;
    },
    validSwapsCount() {
      var validSwaps = [];
      if (this.isTechnicalReason || !this.issueValidationData) return 0;
      for (let i = 0; i < this.issueValidationData.length; i++) {
        const validation = this.issueValidationData[i];
        if (validation.validSwap) validSwaps.push(validation);
      }
      return validSwaps?.length ?? 0;
    },
    currentUnits() {
      return this.$store.state.SwapHandlingWizardModule.currentUnits;
    },
    isTechnicalReason() {
      return this.swapData.reason.reason === "technical";
    },
    currentSimcardIfApplicableSerialNumber() {
      return this.currentSimcardIfApplicable.dataSourceId ?? this.currentSimcardIfApplicable.serialNumber;
    }
  },
  watch: {
    currentUnits: {
      handler: function (newValue, oldValue) {
        if (newValue.length === 1) {
          const id = !newValue[0].id ? newValue[0].dataSourceId : newValue[0].id;
          this.currentSimcardIfApplicable = newValue[0];
          this.getTelemetry(id);
        } else
          this.currentSimcardIfApplicable = null;

        this.massTroubleshootUnits(newValue);
      },
      deep: true,
      immediate: true
    },
    aggregatedTroubleShootingInfo(newValue, oldValue) {
      this.constructedTroubleShootingData = [];
      this.constructedTroubleShootingData.push({ text: "Battery errors:", value: newValue.battery.errorCount });
      this.constructedTroubleShootingData.push({ text: "Batteries below ten percent:", value: newValue.batteryBelowTenPercent.errorCount });
      this.constructedTroubleShootingData.push({ text: "Solid fix:", value: newValue.fix.errorCount });
      this.constructedTroubleShootingData.push({ text: "Units with > 1000 resets since last message:", value: newValue.moreThanOneThousandResetsSinceLastMessage.errorCount });
      this.constructedTroubleShootingData.push({ text: "Positions:", value: newValue.positions.errorCount });
      this.constructedTroubleShootingData.push({ text: "Power:", value: newValue.power.errorCount });
      this.constructedTroubleShootingData.push({ text: "Satellites:", value: newValue.satellites.errorCount });
      this.constructedTroubleShootingData = this.constructedTroubleShootingData.sort((a, b) => b.value - a.value);
    }
  },
}
</script>

<style scoped>
.text-size {
  font-size: 16px;
}
</style>
