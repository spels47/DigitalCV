﻿<template>
  <div v-if="render">
    <v-card
      class="mb-12"
      height="600px"
    >
      <v-card-title class="justify-center">
        <span class="headline secondary--text font-weight-medium">Choose hardware</span>
      </v-card-title>
      <v-card-text>
        <v-container fluid>
          <v-row>
            <v-col cols="5">
              <v-card class="rounded-lg">
                <DisplayUnits :validSwaps="validSwaps" @selectedUnitType="setSelectedUnit($event.serialNumber)"></DisplayUnits>
              </v-card>
            </v-col>
            <v-col cols="4">
              <v-card class="rounded-lg">
                <v-list
                  class="overflow-y-auto"
                  height="450"
                >
                  <v-list-item
                    v-for="(item, index) in qualifiedUnitsForSelectedUnit"
                    :key="index"
                    three-line
                    :inactive="item.qualified === false"
                    :ripple="item.qualified !== false"
                    @click="setSwapChoiceForSpecificUnit(item)"
                    class="unitTypesList"
                    :id="item.unitType"
                  >
                    <v-list-item-content>
                      <v-list-item-title class="font-weight-medium">
                        <span>
                          {{ item.unitType.replaceAll("_", " ") }}
                          <TooltipIconButton v-if="item.prioritizedByLogistics" :clickable="false" icon="mdi-crown-outline" color="secondary lighten-1" tooltip="Prioritized by logistics team"/>
                        </span>
                      </v-list-item-title>
                      <!-- <v-list-item-subtitle v-if="item.prioritizedByLogistics"><span class="blue--text font-weight-black">Prioritized by logistics team</span><v-icon color="blue">mdi-crown-outline</v-icon></v-list-item-subtitle> -->
                      <v-list-item-subtitle :class="!item.qualified || item.currentStock <= 0 ? 'error--text' : ''">{{ itemQualificationText(item) }}</v-list-item-subtitle>
                      <v-list-item-subtitle>{{ item.currentStock }} in stock</v-list-item-subtitle>
                    </v-list-item-content>
                  </v-list-item>
                </v-list>
              </v-card>
            </v-col>

            <v-col cols="3">
              <v-card class="rounded-lg">
                <v-list
                  class="overflow-y-auto"
                  height="450"
                >
                  <v-list-item
                    v-for="(item, index) in getSelectedUnitsShoppingCart"
                    :key="index"
                    three-line
                    inactive
                    disabled
                  >
                    <v-list-item-content>
                      <v-list-item-title class="font-weight-medium">{{ item.unitType.replaceAll("_", " ") }}</v-list-item-title>
                      <v-list-item-subtitle :class="item.currentStock - item.selectedQuantity < 0 ? 'error--text' : ''">{{ item.currentStock }} in stock</v-list-item-subtitle>
                      <v-list-item-subtitle :class="item.currentStock - item.selectedQuantity < 0 ? 'error--text' : ''">{{ item.selectedQuantity }} picked</v-list-item-subtitle>
                      <!-- <v-list-item-subtitle v-if="item.currentStock - item.selectedQuantity < 0" :class="'error--text'">Not enough units to fulfill order</v-list-item-subtitle> -->
                    </v-list-item-content>
                  </v-list-item>
                </v-list>
              </v-card>
            </v-col>
          </v-row>
        </v-container>
      </v-card-text>
    </v-card>

    <div class="d-flex justify-end mr-2">
      <v-btn
        tex
        @click="previousStep"
      >
        Previous
      </v-btn>
      <v-btn
        color="secondary"
        width="150px"
        class="mb-1 ml-2"
        :disabled="!validSwap || validSwaps.length > swapChoices.length"
        @click="nextStep"
      >
        Next
      </v-btn>
    </div>
  </div>
</template>

<script>
import { mapActions, mapState } from "vuex";
import TooltipIconButton from "@/components/buttons/TooltipIconButton";
import DisplayUnits from "@/components/dialogs/swap-handling/DisplayUnits";

export default {
  name: "ChooseHardware",
  components: {
    DisplayUnits,
    TooltipIconButton
  },
  props: {
    customer: {
      type: Object,
      required: true
    },
    render: {type: Boolean}
  },
  data() {
    return {
      selectedSerialNumber: null,
      validSwap: true
    };
  },
  methods: {
    ...mapActions({
      setSwapChoices: 'SwapHandlingWizardModule/setSwapChoices',
      setSwapChoice: 'SwapHandlingWizardModule/setSwapChoice'
    }),
    setSwapChoiceForSpecificUnit(hardware) {
      if (!hardware.qualified)
        return;

      var swapChoice = {serialNumber: this.selectedSerialNumber, unitQualification: hardware};
      this.setSwapChoice(swapChoice);
      this.$nextTick(() => {
        var list = document.getElementsByClassName("selectedUnitType");
        if(list.length > 0) list[0].classList.remove("selectedUnitType");
        document.getElementById(hardware.unitType).classList.add("selectedUnitType");
      });
    },
    nextStep() {
      this.$emit("nextStep");
    },
    previousStep() {
      this.$emit("previousStep");
    },
    itemQualificationText(unit){
      if(!unit.qualified) return "Not qualified";
      if(unit.currentStock < 1) return "Not in stock";
      if(unit.qualified) return "Available";

      return "";
    },
    setInitialSwapChoices(){
      if(this.swapChoices != null && this.swapChoices.length != 0) return;
      var choiceList = [];
      const qualifiedUnits = this.allQualifiedUnits;

      for (let i = 0; i < this.validSwaps.length; i++) {
        const validSwapUnit = this.validSwaps[i];
        for (let k = 0; k < qualifiedUnits.length; k++) {
          const unitQualification = qualifiedUnits[k];
          if(unitQualification.serialNumber == validSwapUnit.serialNumber && unitQualification.qualification[0].qualified){
            choiceList.push({serialNumber: validSwapUnit.serialNumber, unitQualification: unitQualification.qualification[0]})
          }
        }
      }
      this.setSwapChoices(choiceList);
    },
    setSelectedUnit(unit){
      this.selectedSerialNumber = unit;
      this.$nextTick(() => {
        var list = document.getElementsByClassName("selectedUnitType");
        if(list.length > 0) list[0].classList.remove("selectedUnitType");
        let swapChoice = this.getCurrentUnitSwapChoice;
        if(swapChoice) document.getElementById(swapChoice).classList.add("selectedUnitType");
      });
    }
  },
  computed: {
    ...mapState('SwapHandlingWizardModule', ['swapData', 'troubleShootingData', 'issueValidationData', 'contractValidationData', 'validSwapUnits', 'swapChoices', 'unitQualifications']),
    swapType() {
      return this.swapData.type;
    },
    swapReason() {
      return this.swapData.reason.reason;
    },
    troubleShootingPerUnit() {
      return this.troubleShootingData.troubleShootingPerUnit;
    },
    getValidUnitCount() {
      let unitCount = 0;

      if (this.swapType === "issue" && this.swapReason === "technical") {
        unitCount = this.troubleShootingPerUnit
          ?.filter(unit => unit.validSwap)
          ?.map(unit => unit.serialNumber)?.length ?? 0;
      }
      else if (this.swapType === "issue") {
        unitCount = this.issueValidationData
          ?.filter(unit => unit.validSwap)
          ?.map(unit => unit.serialNumber)?.length ?? 0;
      }
      else if (this.swapType === "contract") {
        unitCount = this.contractValidationData
          ?.filter(unit => unit.validSwap)
          ?.map(unit => unit.serialNumber)?.length ?? 0;
      }

      return unitCount;
    },
    validSwaps(){
      return this.validSwapUnits?.data ?? [];
    },
    allQualifiedUnits(){
      return this.unitQualifications;
    },
    qualifiedUnitsForSelectedUnit() {
      const unitQualifications = this.unitQualifications ?? [];
      for (let i = 0; i < unitQualifications.length; i++) {
        const unitQualification = unitQualifications[i];
        var serialNumber = this.selectedSerialNumber;
        if(unitQualification.serialNumber == serialNumber) return unitQualification.qualification;
      }
      return null;
    },
    getCurrentUnitUnitType(){
      for (let i = 0; i < this.validSwaps.length; i++) {
        const validSwapUnit = this.validSwaps[i];
        if(validSwapUnit.serialNumber == this.selectedSerialNumber) return validSwapUnit.unitTypeId;
      }
      return null;
    },
    getCurrentUnitSwapChoice(){
      for (let i = 0; i < this.swapChoices.length; i++) {
        const swapChoice = this.swapChoices[i];
        if(swapChoice.serialNumber == this.selectedSerialNumber) return swapChoice.unitQualification.unitType;
      }
      return null;
    },
    getSelectedUnitsShoppingCart(){
      let shoppingCart = [];
      for (let i = 0; i < this.swapChoices.length; i++) {
        const swapChoice = this.swapChoices[i];
        let hasIncremented = false;
        for (let k = 0; k < shoppingCart.length; k++) {
          const cartItem = shoppingCart[k];
          if(cartItem.unitType == swapChoice.unitQualification.unitType){
            cartItem.selectedQuantity += 1;
            hasIncremented = true;
          }
        }
        if(!hasIncremented){
          shoppingCart.push({unitType: swapChoice.unitQualification.unitType, currentStock: swapChoice.unitQualification.currentStock, selectedQuantity: 1});
        }
      }
      return shoppingCart;
    }
  },
  watch: {
    render(newValue, oldValue) {
      if (oldValue === false && newValue === true) {
        this.selectedSerialNumber = this.validSwaps[0].serialNumber;
        this.setInitialSwapChoices();

        this.$nextTick(function() {
          var selectedUnitElement = document.getElementById(this.getCurrentUnitSwapChoice);
          selectedUnitElement != null ? selectedUnitElement.classList.add("selectedUnitType") :
          document.getElementsByClassName('unitTypesList')[0].classList.add("selectedUnitType");
        });
      }
    },
    // getSelectedUnitsShoppingCart(newValue, oldValue){
    //   if(newValue !== oldValue){
    //     let setValue = false;
    //     for (let i = 0; i < newValue.length; i++) {
    //       const cartItem = newValue[i];
    //       if(cartItem.currentStock - cartItem.selectedQuantity < 0) {
    //         this.validSwap = false;
    //         setValue = true;
    //       }
    //     }
    //     if(!setValue && !this.validSwap) this.validSwap = true;
    //   }
    // }
  }
};
</script>

<style scoped>
.card-height {
  height: 100%
}
.selectedUnitType{
  background-color: rgba(155, 155, 155, 0.75);
  border-radius: 5px;
}
</style>
