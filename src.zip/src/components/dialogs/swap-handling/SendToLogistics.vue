﻿<template>
  <div>
    <v-card
      class="mb-12"
      height="600px"

    >
      <v-card-title class="justify-center py-0">
        <span class="headline secondary--text font-weight-medium">Summary</span>
      </v-card-title>

      <v-card-text class="d-flex justify-center">
        <div class="form">

          <div class="d-flex justify-space-between">
            <v-text-field
              v-if="swapReasonText"
              :value="swapReasonText"
              label="Swap reason"
              append-icon="mdi-help"
              readonly
              style="padding-right: 40px;"
            ></v-text-field>

            <v-text-field
              v-else
              :value="swapType"
              label="Swap type"
              append-icon="mdi-help"
              readonly
              style="padding-right: 40px;"
            ></v-text-field>

            <v-text-field
              :value="ticketId"
              label="Ticket ID"
              append-icon="mdi-identifier"
              readonly
            ></v-text-field>
          </div>


          <div class="d-flex justify-space-between">
            <v-text-field
              :value="getConsignmentTypeText(consignmentType)"
              label="Consignment type"
              append-icon="mdi-truck"
              readonly
              style="padding-right: 40px;"
            ></v-text-field>

            <v-text-field
              :value="confirmedAddress"
              label="Confirmed address"
              append-icon="mdi-map-marker"
              readonly
            ></v-text-field>
          </div>

          <div class="d-flex justify-space-around">
            <v-checkbox
              :value="hasTroubleshooted"
              label="Troubleshooting done"
              on-icon="mdi-check"
              off-icon="mdi-close"
              color="green"
              :ripple="false"
              readonly
            ></v-checkbox>
            <v-checkbox
              :value="invoiceCustomer"
              label="Invoice customer"
              on-icon="mdi-check"
              off-icon="mdi-close"
              color="green"
              :ripple="false"
              readonly
            ></v-checkbox>
            <v-checkbox
              :value="includeReturnLabel"
              label="Include return label"
              on-icon="mdi-check"
              off-icon="mdi-close"
              color="green"
              :ripple="false"
              readonly
            ></v-checkbox>
          </div>

          <v-card class="rounded-lg mt-0" elevation="2">
            <v-card-title class="caption">Contact Person</v-card-title>
            <div class="d-flex justify-space-between">
              <v-text-field
                :value="contactPerson.name"
                label="Name"
                append-icon="mdi-account-edit"
                readonly
                style="padding-right: 20px; padding-left: 16px;"
              ></v-text-field>

              <v-text-field
                :value="contactPerson.phone"
                label="Phone"
                append-icon="mdi-account-edit"
                readonly
                style="padding-right: 20px;"
              ></v-text-field>

              <v-text-field
                :value="contactPerson.email"
                label="Email"
                append-icon="mdi-account-edit"
                readonly
                style="padding-right: 16px;"
              ></v-text-field>
            </div>
          </v-card>

          <div class="d-flex justify-space-between flex-grow-0 flex-shrink-0">
            <v-card
              class="rounded-lg"
              height="160"
              width="calc(50% - 20px)"
              style="margin-top: 24px;"
            >
              <v-list class="overflow-y-auto" height="140">
                <v-list-item
                  v-for="(swapChoice, index) in swapChoices"
                  :key="`choice-${index}-${swapChoice.serialNumber}`"
                >
                  <template v-slot:default="{ active }">
                    <v-list-item-avatar>
                      <v-icon>mdi-cable-data</v-icon>
                    </v-list-item-avatar>

                    <v-list-item-content>
                      <v-list-item-title>
                        <div class="d-flex align-center">
                          <span class="pr-10">{{ swapChoice.serialNumber }}</span>
                          <span>{{ getUnitHardwareType(swapChoice.serialNumber) ? getUnitHardwareType(swapChoice.serialNumber) : '?' }}</span>
                          <v-icon class="mr-1 ml-1">mdi-arrow-right</v-icon>
                          <span>{{ swapChoice.unitQualification.unitType.replaceAll('_', ' ') }}</span>
                        </div>
                      </v-list-item-title>
                    </v-list-item-content>
                  </template>
                </v-list-item>
              </v-list>
            </v-card>

            <div style="width: calc(50% - 20px);">
              <v-textarea
                :value="otherInformation"
                label="Other information"
                append-icon="mdi-information-variant"
                height="160"
                readonly
                outlined
                no-resize
                class="pt-6 pb-0 mb-0"
              >
              </v-textarea>
            </div>
          </div>
        </div>
      </v-card-text>
    </v-card>

    <div class="d-flex justify-end mr-2">
      <v-btn
        tex
        @click="previousStep"
      >
        Previous
      </v-btn>
      <v-btn
        color="secondary"
        class="mb-1 ml-2"
        @click="submit"
        :loading="swapping"
      >
        Send to logistics
      </v-btn>
    </div>
  </div>
</template>

<script>
import axios from "@/axios-client";
import { mapActions, mapState } from "vuex";

export default {
  name: "SendToLogistics",
  data() {
    return {
      swapping: false,
      consignmentTypes: [
        {
          text: "Pick up point",
          value: "PuP"
        },
        {
          text: "Business to business",
          value: "B2B"
        }
      ],
    };
  },
  methods: {
    async submit() {
      const swapModels = this.constructModels();

      this.swapping = true;

      try {
        const { data } = await axios.post("/api/swap/mass/swap", swapModels);

        for (let i = 0; i < swapModels.length; i++) {
          const swapModel = swapModels[i];
          await this.$store.dispatch("audit", {
            source: "datasource",
            entityId: swapModel.serialNumber,
            message: "Swap initiated",
            oldValue: "",
            newValue: `Unit was swapped because of something ${swapModel.type} related. The reason was ${swapModel.reason}. The hardware chosen to swap this unit with is a ${swapModel.hardware.unitType}`
          });
        }
        this.$emit("displayFinishScreen");
      } catch (exception) {
        console.log("exception:", exception?.response?.data.includes("One or more ticket ids sent in the request does not exist in superoffice"));
        if(exception?.response?.data){
          var error = exception.response.data;
          if(error.includes("One or more ticket ids sent in the request does not exist in superoffice"))
            this.$eventBus.$emit("alert", { text: "Failed to initiate swap on units because the super office ticket id does not exist", type: "error", duration: 5 });
          else this.$eventBus.$emit("alert", { text: "Failed to initiate swap on units", type: "error" });
        }
        else this.$eventBus.$emit("alert", { text: "Failed to initiate swap on units", type: "error" });
      } finally {
        this.swapping = false;
      }
    },
    constructModels() {
      let models = [];

      for (const swapChoice of this.swapChoices) {
        models.push({
          serialNumber: swapChoice.serialNumber,
          troubleShootingInfo: this.troubleShootingInfo,
          additionalInformation: {
            confirmedAddress: this.confirmedAddress,
            otherInformation: this.otherInformation,
            ticketId: Number(this.ticketId),
            consignment: this.consignmentType
          },
          contactPerson: this.contactPerson,
          includeReturnLabel: this.includeReturnLabel,
          reason: this.swapType === 'issue' ? this.mapReasonToEnum(this.swapReason) : null,
          type: this.swapType,
          hardware: swapChoice.unitQualification
        });
      }

      return models;
    },
    mapReasonToEnum(reason) {
      switch (reason) {
        case "technical":
        case "carrier":
          return this.$utils.capitalizeFirstLetter(reason);
        case "customer-blunder":
          return "CustomerBlunder";
        case "abax-blunder":
          return "AbaxBlunder";
      }
    },
    previousStep() {
      this.$emit("previousStep");
    },
    getUnitHardwareType(serialNumber) {
      for (let i = 0; i < this.unitHardwareTypes.length; i++) {
        const hardwareType = this.unitHardwareTypes[i];
        if (hardwareType.serialNumber == serialNumber) return hardwareType.unitType;
      }
      return null;
    },
    getConsignmentTypeText(type) {
      for (let i = 0; i < this.consignmentTypes.length; i++) {
        const consignment = this.consignmentTypes[i];
        if (consignment.value == type) return consignment.text;
      }
    }
  },
  computed: {
    ...mapState('SwapHandlingWizardModule', ['swapData', 'validSwapUnits', 'troubleShootingData', 'issueValidationData', 'swappedUnits', 'contractValidationData', 'swapChoices', 'unitHardwareTypes']),
    swapType() {
      return this.swapData.type;
    },
    troubleShootingPerUnit() {
      return this.troubleShootingData.troubleShootingPerUnit;
    },
    ticketId() {
      return this.swapData.additionalInformation.ticketId;
    },
    otherInformation() {
      return this.swapData.additionalInformation.otherInformation;
    },
    consignmentType() {
      return this.swapData.additionalInformation.consignmentType;
    },
    invoiceCustomer() {
      return this.swapData.additionalInformation.invoiceCustomer;
    },
    confirmedAddress() {
      return this.swapData.additionalInformation.confirmedAddress;
    },
    contactPerson() {
      let contactPerson = this.swapData.additionalInformation.contactPerson;
      return {
        name: contactPerson?.name ?? '',
        phone: contactPerson?.phone ?? '',
        email: contactPerson?.email ?? ''
      };
    },
    includeReturnLabel() {
      return this.swapData.additionalInformation.includeReturnLabel;
    },
    troubleShootingInfo() {
      return this.swapData.troubleShootingInfo.troubleshootingInfo;
    },
    hasTroubleshooted() {
      return this.swapData.troubleShootingInfo.hasTroubleshooted;
    },
    swapReason() {
      return this.swapData.reason.reason;
    },
    swapReasonText() {
      return this.swapData.reason.text;
    }
  }
};
</script>

<style scoped>
.form {
  width: 100%;
}

.v-card > :last-child:not(.v-btn):not(.v-chip) {
  border-bottom-left-radius: inherit;
  border-bottom-right-radius: inherit;
  overflow-y: auto;
  max-height: 530px;
}

.v-input--selection-controls {
  padding: 0;
  margin: 0;
}
</style>
