﻿<template>
  <v-dialog
    :value="true"
    width="700"
    persistent
  >
    <v-card>
      <v-card-title>How did we do?</v-card-title>
      <v-card-subtitle>How accurate do you feel the churn prediction score was for this customer, after talking to him/her.</v-card-subtitle>

      <v-card-text>
        <v-radio-group v-model="option">
          <v-radio label="Not accurate"></v-radio>
          <v-radio label="Somewhat accurate"></v-radio>
          <v-radio label="I don't know"></v-radio>
          <v-radio label="Pretty accurate"></v-radio>
          <v-radio label="Very accurate"></v-radio>
        </v-radio-group>
      </v-card-text>

      <v-divider class="ml-6 mr-6"></v-divider>

      <v-card-text>
        <v-textarea
          label="Additional information (if applicable)"
          v-model="additionalInformation"
          no-resize
        ></v-textarea>
      </v-card-text>

      <v-card-actions>
        <v-spacer></v-spacer>

        <v-btn
          :disabled="option === null"
          class="secondary ma-2"
        >
          <v-icon left>mdi-share</v-icon>
          Submit
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
export default {
  name: "ChurnPredictionFeedbackDialog",
  data() {
    return {
      option: null,
      additionalInformation: ""
    }
  },
}
</script>

<style scoped>

</style>
