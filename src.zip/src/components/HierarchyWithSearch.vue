<template>
  <v-sheet height="400">
    <v-text-field
      append-icon="mdi-magnify"
      label="Search"
      class="pl-3 pr-3"
      clear-icon="mdi-close-circle-outline"
      clearable
      v-model="search"
      single-line
      hide-details
    ></v-text-field>

    <v-treeview
      style="height: 340px;"
      dense
      activatable
      hoverable
      :items="items"
      :active="getInitialCustomer"
      :search="search"
      :filter="filter"
      :open="open"
      @update:active="itemClicked"
      item-disabled="isNonSelectable"
    >
      <template v-slot:prepend="{ item }">
        <v-icon  v-if="item.children && item.isUser">mdi-account</v-icon>
        <v-icon v-else-if="item.children && item.isVehicle">mdi-car</v-icon>
        <v-icon v-else>mdi-office-building</v-icon>
      </template>
      <template v-slot:label="{ item }">
        <span v-if="item.isUser">
          {{ item.name }} : {{ item.id }}
          <span class="grey--text" v-if="item.assignedToVehicle">- Assigned Vehicle: {{ item.vehicleAssignedAlias ? item.vehicleAssignedAlias : item.vehicleAssignedVehicleId }}</span>
        </span>
        <span v-else-if="item.isVehicle">
          {{ item.name }} : {{ item.id }}
          <span class="grey--text" v-if="item.currentDriverName">- Assigned Driver: {{ item.currentDriverName }}</span>
          <br/><small class="grey--text" v-if="item.vehicle.licensePlate">Reg-no: {{ item.vehicle.licensePlate }}</small>
        </span>
        <span :ref="item.id" v-else>{{ item.name }}</span>
      </template>
    </v-treeview>
  </v-sheet>
</template>

<script>
export default {
  props: {
    items: {
      type: Array,
      required: true,
    },
    subItems: {
      type: Array,
      required: false,
    },
    nonSelectableSubItems: {
      type: Array,
      required: false,
    },
    subItemType: {
      type: String,
      required: false
    },
    initialCustomerId: {
      type: Number,
      required: false
    }
  },
  data: () => ({
    open: [],
    search: "",
    caseSensitive: false,
    selectedItem: {}
  }),
  mounted() {
    if (this.subItems) {
      this.populateHierarchyWithSubItems(this.items[0], this.subItems);
    }
    if (this.items) {
      this.open = [this.items[0].id];
    }
  },
  methods: {
    scrollToDepartment(){
      this.$nextTick(() => {
        if(!this.selectedItem.id || !this.$refs[this.selectedItem.id]) return
        this.$refs[this.selectedItem.id].scrollIntoView({block: 'center'})
      });
    },
    filter(item, search, textKey) {
      return item?.name?.toLowerCase()?.includes(search?.toLowerCase())
        || item?.id?.toString() === search
        || item?.vehicle?.licensePlate?.toLowerCase()?.includes(search?.toLowerCase())
    },
    cancel() {
      this.$emit("cancel");
    },
    itemClicked(id) {
      this.$emit("itemClicked", id);
      this.findDepartmentInHierarchy(this.items[0], id);
    },
    findDepartmentInHierarchy(item, id) {
      if(item.id == id && !item.isDepartment){
        this.$emit("subItemClicked", item)
      }
      if (item.id === id) {
        this.selectedItem = item
        this.selectedItem.departmentPath.forEach(x => {
          this.open.push(x.id);
        });
      } else {
        item.children.forEach(child => {
          this.findDepartmentInHierarchy(child, id);
        });
      }
    },
    populateHierarchyWithSubItems(department, subItems) {
      //Add Users to department
      if (department.name == null) {
        department.name = "";
      }
      if (this.subItemType == "users") {
        var users = subItems;
        users.forEach(user => {
          if (user.departmentId == department.id && user.accountActive && !user.isAdminUser) {
            if (user.name == null) {
              user.name = "";
            }
            department.children.push({
              id: user.userId,
              name: user.name,
              isUser: true,
              children: [],
              isNonSelectable: this.nonSelectableSubItems.filter(i => i === user.userId).length > 0,
              assignedToVehicle: user.assignedToVehicle,
              vehicleAssignedAlias: user.vehicleAssignedAlias,
              vehicleAssignedVehicleId: user.vehicleAssignedVehicleId
            });
          }
        });
      } else if (this.subItemType == "vehicles") {
        var vehicles = subItems;
        vehicles.forEach(vehicle => {
          if (vehicle.departmentId == department.id) {
            if (vehicle.alias == null) {
              vehicle.alias = "";
            }
            department.children.push({
              id: vehicle.vehicleId,
              simcardId: vehicle.id,
              currentDriverName: vehicle.currentDriverName,
              name: vehicle.alias,
              isVehicle: true,
              vehicle: {
                licensePlate: vehicle.licensePlate
              },
              children: [],
              isNonSelectable: this.nonSelectableSubItems.filter(i => i === vehicle.id).length > 0
            });
          }
        });
      }

      //recursivly go to subdepartment if any
      department.children.forEach(child => {
        if (child.isDepartment) {
          this.populateHierarchyWithSubItems(child, subItems);
        }
      });
    }
  },
  computed: {
    getInitialCustomer() {
      if(!this.initialCustomerId) return this.items[0].id
      this.findDepartmentInHierarchy(this.items[0], this.initialCustomerId)
      return [this.selectedItem.id]
    },
  },
  watch: {
    selectedItem: function(){
      this.scrollToDepartment()
    }
  }
};
</script>

<style lang="scss" scoped>
.v-treeview {
  overflow: auto;
}

.v-treeview-node__content,
.v-treeview-node__label {
  flex-shrink: 1;
}

.v-treeview-node__root {
  height: auto;
}
</style>
