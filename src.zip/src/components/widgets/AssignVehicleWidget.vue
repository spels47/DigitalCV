<template>
  <v-card>
    <v-container>
      <v-row>
        <v-col>
          <v-card-title>Select vehicle to assign driver to</v-card-title>
          <v-progress-linear indeterminate color="black" v-if="isLoading"></v-progress-linear>
          <HierarchyWithSearch
            v-if="customerHierarchy && customerHierarchy.length"
            @cancel="closeDialog()"
            @subItemClicked="vehicleClickedInDialog"
            @itemClicked="vehicleClickedForAssigning = null"
            :items="customerHierarchy"
            :subItems="customerVehicles"
            :subItemType="'vehicles'"
            :nonSelectableSubItems="[]"
          ></HierarchyWithSearch>
        </v-col>
      </v-row>
      <v-row>
        <v-col class="text-right">
          <v-spacer></v-spacer>
          <v-btn color="primary" text @click="closeDialog">Cancel</v-btn>
          <v-btn :disabled="vehicleClickedForAssigning == null" color="secondary" @click="vehicleSelected">
            <v-icon left>
              mdi-account-check
            </v-icon>
            Assign
          </v-btn>
        </v-col>
      </v-row>
    </v-container>
  </v-card>
</template>

<script>
import axios from "~/axios-client";
import HierarchyWithSearch from "../HierarchyWithSearch";
export default {
  props: ["customerId"],
  components: {
    HierarchyWithSearch
  },
  data() {
    return {
      vehicleClickedForAssigning: null,
      customerVehicles: null,
      customerHierarchy: [],
      isLoading: true
    };
  },
  mounted() {
    this.getCustomerHierarchyAndVehicles();
  },
  methods: {
    getCustomerHierarchyAndVehicles() {
      this.customerHierarchy = [];
      this.customerVehicles = [];
      axios.get(`/api/customer/CustomerTreeWithVehicles/${this.customerId}`).then(res => {
        this.customerVehicles = res.data.vehicles;
        this.customerHierarchy.push(res.data.departmentHiarchy);
        this.isLoading = false;
      });
    },
    vehicleClickedInDialog(vehicle) {
      this.vehicleClickedForAssigning = vehicle;
    },
    closeDialog() {
      this.$emit("closeMergeDialog");
    },
    vehicleSelected() {
      if (this.vehicleClickedForAssigning) {
        this.$emit("vehicleSelected", this.vehicleClickedForAssigning);
        this.$emit("closeMergeDialog");
      }
    }
  }
};
</script>

<style></style>
