<template>
  <v-card>
    <v-card-title>
      <v-icon class="mr-2">mdi-medal</v-icon>Favorite Customer Statistics
      <v-spacer />
      <v-dialog v-model="dialog" max-width="500px">
        <template v-slot:activator="{ on }">
          <v-btn color="secondary" dark class="mb-2" data-cy="customer-statistics-favorites-add-customer" v-on="on">Add Customer</v-btn>
        </template>
        <v-card>
          <v-card-title>
            <span class="headline">Search to add Customer</span>
          </v-card-title>
          <v-card-text>
            <CustomerSearchbar
              ref="search"
              v-on:CUSTOMER_SELECTED="addFavorite"
            />
          </v-card-text>
          <v-card-actions>
            <v-spacer />
            <v-btn color="blue darken-1" data-cy="customer-statistics-favorites-add-customer-dialog-cancel" text @click="close">Cancel</v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </v-card-title>
    <v-spacer></v-spacer>
    <v-data-table
      v-bind:loading="loading"
      v-on:click:row="navigateToCustomer"
      loading-text="Loading... Please wait"
      :headers="headers"
      :items="customers"
      :search="search"
      :sort-by="['customer']"
      :sort-asc="['true', 'false']"
    >
      <template v-slot:item.customer="{ item }">
        <strong style="cursor: pointer">{{item.customer}}</strong>
      </template>
      <template v-slot:item.installed="{ item }">
        <v-chip
          v-bind:class="getScoreColor(item.installed)"
          v-if="item.installed != null"
          outlined
        >{{ item.installed }}%</v-chip>
        <v-chip color="highlight" v-else outlined>No Data</v-chip>
      </template>
      <template v-slot:item.onboarding="{ item }">
        <v-chip
          v-bind:class="getScoreColor(item.onboarding)"
          v-if="item.onboarding != null"
          outlined
        >{{ item.onboarding }}%</v-chip>
        <v-chip color="highlight" v-else outlined>No Data</v-chip>
      </template>
      <template v-slot:item.usage="{ item }">
        <v-chip
          v-bind:class="getScoreColor(item.usage)"
          v-if="item.usage != null"
          outlined
        >{{ item.usage }}%</v-chip>
        <v-chip color="highlight" v-else outlined>No Data</v-chip>
      </template>
      <template v-slot:item.reports="{ item }">
        <v-chip
          v-bind:class="getScoreColor(item.reports)"
          v-if="item.reports != null"
          outlined
        >{{ item.reports }}%</v-chip>
        <v-chip color="highlight" v-else outlined>No Data</v-chip>
      </template>
      <template v-slot:item.features="{ item }">
        <v-chip
          v-bind:class="getScoreColor(item.features)"
          v-if="item.features != null"
          outlined
        >{{ item.features }}%</v-chip>
        <v-chip color="highlight" v-else outlined>No Data</v-chip>
      </template>
      <template v-slot:item.vehicles="{ item }">
        <v-chip
          v-bind:class="getScoreColor(item.vehicles)"
          v-if="item.vehicles != null"
          outlined
        >{{ item.vehicles }}%</v-chip>
        <v-chip color="highlight" v-else outlined>No Data</v-chip>
      </template>
      <template v-slot:item.drivers="{ item }">
        <v-chip
          v-bind:class="getScoreColor(item.drivers)"
          v-if="item.drivers != null"
          outlined
        >{{ item.drivers }}%</v-chip>
        <v-chip color="highlight" v-else outlined>No Data</v-chip>
      </template>
      <template v-slot:item.action="{ item }">
        <v-tooltip bottom>
          <template v-slot:activator="{ on }">
            <v-icon
              v-on="on"
              @click.stop="stopPropagation"
              color="error"
              @click="removeFavorite(item.id)"
            >mdi-delete</v-icon>
          </template>
          <span>Remove from favorites</span>
        </v-tooltip>
      </template>

    </v-data-table>
  </v-card>
</template>

<script>
import CustomerSearchbar from "../CustomerSearchbar";
export default {
  data() {
    return {
      loading: false,
      scoreBrackets: {
        ok: 60,
        error: 30
      },
      dialog: false,
      search: "",
      customerIds: [],
      customers: [],
      headers: [
        {
          text: "Customer",
          value: "customer"
        },
        {
          text: "Installed",
          value: "installed"
        },
        {
          text: "Onboarding",
          value: "onboarding"
        },
        {
          text: "Usage",
          value: "usage"
        },
        {
          text: "Reports",
          value: "reports"
        },
        {
          text: "Features",
          value: "features"
        },
        {
          text: "Vehicles",
          value: "vehicles"
        },
        {
          text: "Drivers",
          value: "drivers"
        },
        {
          text: "",
          value: "action",
          sortable: false
        }
      ],
    };
  },
  async mounted() {
    this.loading = true
    await this.$store.dispatch("CustomerStatisticsModule/getCustomerStatisticsFavorites");
    this.update()
    this.loading = false
  },
  watch: {
    dialog(val) {
      if (!val) return;
      requestAnimationFrame(() => {
        this.$refs.search.$refs.focus.focus();
      });
    }
  },
  computed: {
    defaultTable() {
      return this.$store.state.userSettings.defaultTable;
    },

  },
  methods: {
    getScoreColor(val) {
      if (val <= this.scoreBrackets.error) return "error error--text";
      else if (val >= this.scoreBrackets.ok) return "success success--text";
      else return "warning warning--text";
    },
    close() {
      this.dialog = false;
    },
    async addFavorite(customer) {
      await this.$store.dispatch('CustomerStatisticsModule/addCustomerStatisticsFavorite', customer)
      if(this.$store.getters['CustomerStatisticsModule/customerStatisticsFavoritesIds'].some(x => x === customer.id)){
        this.$eventBus.$emit('alert', {text: `Customer statistics favorite added`, icon: 'mdi-alert-circle', type: 'success'});
      } else {
        this.$eventBus.$emit('alert', {text: `Could not find any data for customer with id: ${customer.id}`, icon: 'mdi-alert-circle', type: 'warning'});
      }
      this.close();
      this.update()
    },
    async removeFavorite(id) {
      await this.$store.commit('CustomerStatisticsModule/removeCustomerStatisticsFavorite', id)
      this.update()
    },
    navigateToCustomer(customer) {
      this.$router.push({
        name: "customer",
        params: { id: customer.id },
        query: {activeTab: this.$utils.getDefaultTab(this.defaultTable)}});
    },
    stopPropagation(event) {
      event.stopPropagation();
    },
    update(){
      this.customers = this.$store.getters['CustomerStatisticsModule/customerStatisticsFavorites'];
      this.customerIds = this.$store.getters['CustomerStatisticsModule/customerStatisticsFavoritesIds'];
    }
  },
  components: {
    CustomerSearchbar
  }
};
</script>

<style lang="scss" scoped>
</style>
