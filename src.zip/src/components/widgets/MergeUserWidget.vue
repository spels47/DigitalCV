<template>
  <v-card>
    <v-container>
      <v-row>
        <v-col>
          <v-card-title>Select an user to merge with</v-card-title>
          <v-progress-linear indeterminate color="black" v-if="isLoading"></v-progress-linear>
          <HierarchyWithSearch
            v-if="customerHierarchy && customerHierarchy.length"
            @cancel="mergeUserDialog = false"
            @subItemClicked="userClickedInMergeDialog"
            @itemClicked="userClickedForMerging = null"
            :items="customerHierarchy"
            :subItems="customerUsers"
            :subItemType="'users'"
            :nonSelectableSubItems="[sourceUser.userId]"
          ></HierarchyWithSearch>
        </v-col>
      </v-row>
      <v-divider></v-divider>
      <v-row>
        <v-col>
          <v-card-subtitle
            >Result of merge will move data from <span class="font-weight-black">{{ sourceUser.name }}</span> to
            <span class="font-weight-black" v-if="userClickedForMerging">{{ userClickedForMerging.name }}</span>
            <span class="font-weight-black" v-if="!userClickedForMerging">(SELECT A USER TO MERGE WITH)</span>:
          </v-card-subtitle>
          <v-card dark>
            <v-card-subtitle class="text-center">
              <span class="font-weight-black">{{ sourceUser.name }}: {{ sourceUser.userId }}</span>
              <v-icon class="ml-2 mr-2">mdi-arrow-right-bold</v-icon>
              <span class="font-weight-black" v-if="userClickedForMerging">{{ userClickedForMerging.name }}: {{ userClickedForMerging.id }}</span>
              <span class="font-weight-black" v-if="!userClickedForMerging">(SELECT A USER TO MERGE WITH)</span>
            </v-card-subtitle>
          </v-card>
        </v-col>
      </v-row>
      <v-row>
        <v-col class="text-right">
          <v-spacer></v-spacer>
          <v-btn color="primary" text @click="closeDialog">Cancel</v-btn>
          <v-btn :disabled="userClickedForMerging == null" color="secondary" @click="accountMerge">
            <v-icon left>
              mdi-set-left-center
            </v-icon>
            Merge
          </v-btn>
        </v-col>
      </v-row>
    </v-container>
  </v-card>
</template>

<script>
import axios from "~/axios-client";
import HierarchyWithSearch from "@/components/HierarchyWithSearch";
export default {
  name: "MergeUserWidget",
  props: ["customerId", "sourceUser"],
  components: { HierarchyWithSearch },
  data() {
    return {
      userClickedForMerging: null,
      customerUsers: null,
      customerHierarchy: [],
      isLoading: true
    };
  },
  mounted() {
    this.getCustomerHierarchyAndUsers();
  },
  methods: {
    closeDialog(successful) {
      this.$emit("closeMergeDialog", successful);
    },
    userClickedInMergeDialog(user) {
      this.userClickedForMerging = user;
    },
    async accountMerge() {
      if (this.userClickedForMerging && this.userClickedForMerging.id) {
        const mergeDrivers = {
          SourceUserId: this.sourceUser.userId,
          TargetUserId: this.userClickedForMerging.id
        };

        let accountsMerged = false;

        try{
          await axios.put("/api/user/mergeDrivers", mergeDrivers)
          await this.$store.dispatch("audit", { source: "account", entityId: this.sourceUser.userId, message: "Users have been merged", oldValue: `Source user: ${this.sourceUser.userId}`, newValue: `Target user: ${this.userClickedForMerging.id}` });
          await this.$store.dispatch("audit", { source: "account", entityId: this.userClickedForMerging.id, message: "Users have been merged", oldValue: `Source user: ${this.sourceUser.userId}`, newValue: `Target user: ${this.userClickedForMerging.id}` });

          this.$eventBus.$emit("alert", { text: "Accounts merged", icon: "mdi-emoticon", type: "success" });
          accountsMerged = true
        } catch(ex){
          this.$eventBus.$emit("alert", { text: "Failed to merge accounts", icon: "mdi-alert-circle", type: "error" });
        } finally {
          this.closeDialog(accountsMerged)
        }
      }
    },
    getCustomerHierarchyAndUsers() {
      this.customerHierarchy = [];
      axios.get(`/api/customer/CustomerTreeWithUsers/${this.customerId}`).then(res => {
        this.customerUsers = res.data.users;
        this.customerHierarchy.push(res.data.departmentHiarchy);
        this.isLoading = false;
      });
    }
  }
};
</script>

<style></style>
