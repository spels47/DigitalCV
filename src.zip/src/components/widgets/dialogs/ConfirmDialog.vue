<template>
  <v-dialog v-model="dialog" :max-width="options.width" @keydown.esc="cancel">
    <v-card>
      <v-card-title>{{ title }}</v-card-title>
      <v-card-text>
        <div v-if="options.preformatted">
          <div class="width-fix preformat" v-html="text"></div>
        </div>
        <span v-if="!options.preformatted">
          {{ text }}
        </span>
      </v-card-text>
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn color="grey" text @click="cancel">
          {{ options.cancelLabel }}
        </v-btn>
        <v-btn color="secondary" text @click="agree">
          {{ options.confirmLabel }}
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>

// Vuetify Confirm Dialog component
//
// Insert component where you want to use it:
//   <confirm ref="confirm"></confirm>
//
// Call it:
//   this.$refs.confirm.open('Delete', 'Are you sure?', { width: 700, preformatted: true }).then((confirm) => { doSomething() })
// Or use await:
//   let result = await this.$refs.confirm.open('Delete', 'Are you sure?', { width: 700, preformatted: true }))
// if ( result ) doSomething();
// else doNothing()

export default {
  name: "ConfirmDialog",
  data: () => ({
    dialog: false,
    resolve: null,
    reject: null,
    text: null,
    title: null,
    options: {
      width: 300,
      preformatted: false,
      cancelLabel: 'Cancel',
      confirmLabel: 'Ok'
    }
  }),
  methods: {
    open(title, text, options) {
      this.dialog = true
      this.title = title
      this.text = text
      this.options = Object.assign(this.options, options)
      return new Promise((resolve, reject) => {
        this.resolve = resolve
        this.reject = reject
      })
    },
    agree() {
      this.resolve(true)
      this.dialog = false
    },
    cancel() {
      this.resolve(false)
      this.dialog = false
    }
  }
}
</script>

<style lang="scss">
.width-fix{
  max-width: 100%;
}
.preformat{
  white-space: pre-wrap;
}
</style>
