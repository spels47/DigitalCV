﻿<template>
  <v-dialog
    v-model="show"
    max-width="1500px"
  >
    <v-card>
      <v-col>
        <v-list>
          <v-list-item>
            <v-list-item-content>
              <v-list-item-subtitle>
                Jira issue / <a class="secondary--text hover text-decoration-none" :href="getJiraIssueLink" target="_blank">{{getJiraIssueKey}}</a> / Linked GitLab issue /
                <a class="secondary--text hover text-decoration-none" :href="getGitlabIssueLink" target="_blank">{{issue.issueId}}</a>
                <v-btn absolute right class="ml-1" @click="close" icon>
                  <v-icon large>mdi-close</v-icon>
                </v-btn>
              </v-list-item-subtitle>
              <v-list-item-title class="headline">
                Edit GitLab issue
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-col>
      <v-col>
        <v-text-field
          label="Title*"
          v-model="issueTitle"
          prepend-icon="mdi-text-short"
          single-line
          :rules="[rules.summaryLength(165), rules.required]"
          hint="Describe the issue with a short and concise summary"
          rows="1"
          spellcheck="false"
          clearable>

        </v-text-field>
        <v-textarea spellcheck="false" :key="autoGrowHack"
                    auto-grow
                    v-model="issueDescription"
                    clearable
                    counter
                    prepend-icon="mdi-text"
                    label="Issue description"
                    hint="Give a throughout description of the issue"
        ></v-textarea>
      </v-col>
      <v-col>
        <v-select
          :items="availableMilestones"
          v-model="issueMilestone"
          prepend-icon="mdi-flag-triangle"
          class="elevation-0"
          clearable
          return-object
          :loading="fetchingMilestones"
          item-text="title"
          no-data-text="No milestones available"
          label="Milestone"
        >
          <template slot="selection" slot-scope="data">
            <span v-if="data.item.expired">{{data.item.title}} (expired)</span>
            <span v-else>{{data.item.title}}</span>
          </template>
          <template slot="item" slot-scope="data">
            <span v-if="data.item.expired">{{data.item.title}} (expired)</span>
            <span v-else>{{data.item.title}}</span>
          </template>
        </v-select>
      </v-col>
      <v-col>
        <v-menu
          v-model="showCalendarDialog"
          :close-on-content-click="true"
          :nudge-right="40"
          transition="scale-transition"
          offset-y
          min-width="auto"
        >
          <template v-slot:activator="{ on, attrs }">
            <v-text-field
              label="Due date"
              v-model="issueDueDate"
              prepend-icon="mdi-calendar-alert"
              readonly
              clearable
              v-bind="attrs"
              v-on="on"
            ></v-text-field>
          </template>
          <v-date-picker
            show-current
            scrollable
            color="blue"
            v-model="issueDueDate"
            @input="showCalendarDialog = false"
          ></v-date-picker>
        </v-menu>
        <v-select prepend-icon="mdi-help-circle-outline" :items="issueTypes" v-model="issueType" label="Issue type*"></v-select>
        <v-autocomplete
          :items="availableLabels"
          :loading="fetchingLabels"
          v-model="issueLabels"
          multiple
          chips
          clearable
          prepend-icon="mdi-label-multiple"
          item-text="name"
          class="elevation-0"
          label="Labels"
        >
          <template slot="selection" slot-scope="data">
            <v-chip :color="data.item.color" :text-color="data.item.textColor">{{ data.item.name }}</v-chip>
          </template>
          <template slot="item" slot-scope="data">
            <v-chip :color="data.item.color" :text-color="data.item.textColor">{{ data.item.name }}</v-chip>
          </template>
        </v-autocomplete>
      </v-col>
      <v-col>
        <v-checkbox style="width: 15%"
                    prepend-icon="mdi-eye-off"
                    v-model="issueIsConfidential"
                    label="Confidential"
        ></v-checkbox>
        <v-checkbox style="width: 16%"
                    prepend-icon="mdi-lock"
                    v-model="issueDiscussionLocked"
                    label="Discussion locked"
        ></v-checkbox>
      </v-col>
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn
          text
          v-if="isValidConfig"
          :loading="isSaving"
          @click="saveChanges"
        >
          Save changes
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import axios from "@/axios-client";
import util from "@/helpers/util";

export default {
  props: ["title", "showDialog", "issue"],
  data: function() {
    return {
      rules: {
        summaryLength: len => v => (v || '').length <= len  || `Max summary length is ${len}`,
        required: v => !!v || 'This field is required',
      },
      issueTypes: [ "Issue", "Incident" ],
      autoGrowHack: false,
      showCalendarDialog: false,
      isSaving: false,
      fetchingMilestones: false,
      fetchingLabels: false,
      availableMilestones: [],
      availableLabels: [],
      issueTitle: "",
      issueDueDate: null,
      issueDescription: "",
      issueType: "",
      issueMilestone: {},
      issueIsConfidential: false,
      issueDiscussionLocked: false,
      issueLabels: [],
    }
  },
  watch: {
    showDialog: async function(newVal) {
      if (newVal) {
        this.forceReRender();

        // set values
        this.issueTitle = this.issue.title;
        this.issueDescription = this.issue.description;
        this.issueType = (this.issue.type.charAt(0)) + this.issue.type.slice(1).toLowerCase();
        this.issueLabels = this.issue.labels ?? [];
        this.issueIsConfidential = this.issue.confidential;
        this.issueDiscussionLocked = this.issue.discussionLocked !== null && this.issue.discussionLocked === true;

        try {
          if (this.issue.dueDate !== null) {
            this.issueDueDate = util.addDaysToDate(new Date(this.issue.dueDate), 1).toISOString().substr(0,10);
          }
        } catch {
          // we don't care if this fails really
        }

        await Promise.all([this.fetchAvailableLabels(), this.fetchAvailableMilestones()]);
      }
    },
    issueTitle: function(newVal) {
      this.$store.state.GitlabModule.newIssueTitle = newVal;
    },
    issueDescription: function(newVal) {
      this.$store.state.GitlabModule.newIssueDescription = newVal;
    },
    issueType: function(newVal) {
      this.$store.state.GitlabModule.newIssueType = newVal;
    },
    issueLabels: function(newVal) {
      this.$store.state.GitlabModule.newIssueLabels = newVal;
    },
    issueMilestone: function(newVal) {
      this.$store.state.GitlabModule.newIssueMilestone = newVal;
    },
    issueDueDate: function(newVal) {
      this.$store.state.GitlabModule.newIssueDueDate = newVal;
    },
    issueIsConfidential: function(newVal) {
      this.$store.state.GitlabModule.newIssueIsConfidential = newVal;
    },
    issueDiscussionLocked: function(newVal) {
      this.$store.state.GitlabModule.newIssueDiscussionLocked = newVal;
    },
  },
  methods: {
    async saveChanges() {
      this.isSaving = true;
      try {
        const { data } = await this.$store.dispatch("editGitlabIssue", { projectId: this.issue.projectId, issueId: this.issue.issueId });
        if (data) {
          this.$eventBus.$emit("alert", { text: "Issue edited 😃", type: "success"})
          this.close();
          this.$emit("editSuccessful");
        } else {
          this.$eventBus.$emit("alert", { text: "There was a problem editing the issue 😓", type: "error"});
        }
      } finally {
        this.isSaving = false;
      }
    },
    async fetchAvailableLabels() {
      this.fetchingLabels = true;
      try {
        const { data } = await axios.get(`/api/gitlab/projects/${this.issue.projectId}/labels`);
        this.availableLabels = data;
        this.issue.labels.forEach(label => {
          if (!this.availableLabels.some(x => x.name === label)) {
            this.availableLabels.unshift({ name: label });
          }
        })
      } finally {
        this.fetchingLabels = false;
      }
    },
    async fetchAvailableMilestones() {
      this.fetchingMilestones = true;
      try {
        const { data } = await axios.get(`/api/gitlab/projects/${this.issue.projectId}/milestones`);
        this.availableMilestones = data;
      } finally {
        this.fetchingMilestones = false;
      }
    },
    close() {
      this.$emit("closeDialog");
    },
    forceReRender() {
      this.autoGrowHack = !this.autoGrowHack;
    },
  },
  computed: {
    isValidConfig() {
      return this.issueSummary !== "";
    },
    getGitlabIssueLink() {
      return this.issue.source;
    },
    getJiraIssueKey() {
      return this.$store.state.JiraModule.currentJiraIssue.key;
    },
    getJiraIssueLink() {
      return `https://jira.planetabax.com/browse/${this.$store.state.JiraModule.currentJiraIssue.key}`;
    },
    show: {
      get() {
        return this.showDialog;
      },
      set(value) {
        if (!value) {
          this.$emit("closeDialog");
        }
      }
    }
  }
};
</script>

<style scoped>
</style>
