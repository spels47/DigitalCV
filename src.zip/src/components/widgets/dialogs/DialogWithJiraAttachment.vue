﻿<template>
  <v-dialog :width="width || 950" v-model="show">
    <v-card>
      <v-container>
        <v-row>
          <v-col>
            <v-btn class="float-right mr-1 mt-2" @click="show = false" icon>
              <v-icon size="30">mdi-close</v-icon>
            </v-btn>
            <v-btn class="float-right mr-1 mt-2" @click="openLink" icon>
              <v-icon size="30">mdi-open-in-new</v-icon>
            </v-btn>
            <div>
              <figure>
                <figcaption v-if="title !== undefined" style="margin: 1rem; font-size: 20px;">{{ title }}</figcaption>
                <div>
                  <figcaption v-if="created !== undefined" style="margin: 1rem; margin-top: -1rem; font-size: 13px; width: 50%">Added: {{ created }}</figcaption>
                  <br/>
                  <figcaption v-if="size !== undefined" style="margin: 1rem; font-size: 13px; margin-top: -2.2rem">Size: {{ size }}</figcaption>
                </div>
              </figure>
            </div>
            <v-divider ></v-divider>
            <v-img class="mt-3" contain  max-height="1000" :src="imageUrl"></v-img>
          </v-col>
        </v-row>
      </v-container>
    </v-card>
  </v-dialog>
</template>

<script>
export default {
  props: ["title", "created", "size", "showDialog", "imageUrl", "width"],
  methods: {
    openLink() {
      window.open(this.imageUrl);
    }
  },
  computed: {
    show: {
      get() {
        return this.showDialog;
      },
      set(value) {
        if (!value) {
          this.$emit("closeDialog");
        }
      }
    }
  }
};
</script>

<style scoped>
</style>
