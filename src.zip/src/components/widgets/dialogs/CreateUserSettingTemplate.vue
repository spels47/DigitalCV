<template>
  <v-dialog persistent width="700" value="true">
    <v-card>
      <v-container>
        <v-row>
          <v-col>
            <v-card-title>Create New User Template</v-card-title>
            <v-card-subtitle>
                <v-text-field v-model="templateName" counter="25" label="Template Name"></v-text-field>
            </v-card-subtitle>
          </v-col>
        </v-row>
        <v-row class="pr-3">
          <v-col class="text-right">
            <v-spacer></v-spacer>
            <v-btn color="primary" text @click="closeDialog">Cancel</v-btn>
            <v-btn :disabled="templateName.length < 3" color="secondary" @click="confirm">
              <v-icon left>
                mdi-check-bold
              </v-icon>
              Confirm
            </v-btn>
          </v-col>
        </v-row>
      </v-container>
    </v-card>
  </v-dialog>
</template>

<script>
import axios from "~/axios-client";
export default {
  data() {
    return {
      templateName: ""
    };
  },
  methods: {
    confirm() {
      this.$emit("confirm", this.templateName);
    },
    closeDialog() {
      this.$emit("closeDialog");
    }
  }
};
</script>

<style></style>
