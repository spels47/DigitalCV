<template>
  <v-dialog :value="true" persistent :max-width="preformattedWidth ? preformattedWidth : 300">
    <v-card>
      <v-card-title class="headline">{{ title }}</v-card-title>
      <v-card-text>
        <div v-if="preformatted">
          <pre class="widthfix">{{ text }}</pre>
        </div>
        <span v-if="!preformatted">
          {{ text }}
        </span>
      </v-card-text>
      <v-card-actions>
        <v-spacer></v-spacer>
        <v-btn color="grey" text @click="cancel">
          {{ cancelLabel }}
        </v-btn>
        <v-btn color="secondary" text @click="confirm">
          {{ confirmLabel }}
        </v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
export default {
  props: ["title", "text", "confirmLabel", "cancelLabel", "preformatted", "preformattedWidth"],
  methods: {
    cancel() {
      this.$emit("cancel");
    },
    confirm() {
      this.$emit("confirm");
    }
  }
};
</script>

<style lang="scss">
.widthfix{
  max-width: 100%;
}
pre { white-space: pre-wrap }
</style>
