﻿<template>
  <v-dialog :width="dialogWidth" v-model="show">
   <v-card>
     <v-progress-linear
       absolute
       :active="isPushing"
       indeterminate
       dark
     ></v-progress-linear>
     <div>
       <v-btn  style="float: right; margin-right: 0.5rem" class="mt-3" @click="show = false" icon>
         <v-icon large>mdi-close</v-icon>
       </v-btn>
       <v-btn style="float: right; margin-right: 0.5rem" class="mt-3" @click="dialogWidth === 1500 ? dialogWidth = 1000 : dialogWidth = 1500" icon>
         <v-icon v-if="dialogWidth !== 1500" large>mdi-arrow-expand-horizontal</v-icon>
         <v-icon v-else large>mdi-arrow-collapse-right</v-icon>
       </v-btn>
       <v-card-title class="mb-1">Push issue to GitLab for further investigation</v-card-title>
       <v-card-subtitle>Create a GitLab issue equilvant to this issue and link them together</v-card-subtitle>
     </div>

     <v-container>
       <v-row>
         <v-col cols="12">
           <v-textarea spellcheck="false"
                       auto-grow
                       clearable
                       prepend-icon="mdi-text-short"
                       v-model="issueTitle"
                       counter
                       label="Title*"
                       :rules="[rules.titleLength(165), rules.required]"
                       hint="Describe the issue with a short and concise title"
                       rows="1"
           ></v-textarea>
           <p v-if="notSameTitle" class="ml-8" style="cursor: pointer; font-size: 15px" @click="setSameTitle">Use same title as JIRA issue</p>
           <v-textarea spellcheck="false"
                       auto-grow
                       clearable
                       prepend-icon="mdi-text"
                       :key="autoGrowHack"
                       v-model="issueDescription"
                       counter
                       label="Description"
                       hint="Give a throughout description of the issue"
                       rows="1"
           ></v-textarea>
         </v-col>
         <v-col cols="12">
           <v-select prepend-icon="mdi-help-circle-outline" :items="issueTypes" v-model="issueType" label="Type"></v-select>
           <v-menu
             v-model="showCalendarDialog"
             :close-on-content-click="true"
             :nudge-right="40"
             transition="scale-transition"
             offset-y
             min-width="auto"
           >
             <template v-slot:activator="{ on, attrs }">
               <v-text-field
                 label="Due date"
                 v-model="issueDueDate"
                 prepend-icon="mdi-calendar"
                 readonly
                 v-bind="attrs"
                 v-on="on"
               ></v-text-field>
             </template>
             <v-date-picker
               show-current
               scrollable
               color="blue darken-1"
               v-model="issueDueDate"
               @input="showCalendarDialog = false"
             ></v-date-picker>
           </v-menu>
         </v-col>
         <v-col cols="12">
           <v-autocomplete
             :loading="fetchingProjects"
             :items="availableProjects"
             class="elevation-0"
             return-object
             clearable
             prepend-icon="mdi-folder-open-outline"
             :rules="[ rules.required ]"
             item-text="path_with_namespace"
             item-value="path_with_namespace"
             v-model="issueProject"
             label="Project*"
           >
             <template slot="selection" slot-scope="data">
               <v-avatar v-if="data.item.avatar_url || data.item.namespace.avatar_url" size="25px">
                 <img :src="data.item.avatar_url || getAvatarUrl(data.item)"/>
               </v-avatar>
               <span :class="data.item.avatar_url || data.item.namespace.avatar_url ? 'ml-2' : ''">{{ data.item.name }}</span>
             </template>
             <template slot="item" slot-scope="data">
               <v-list-item-avatar v-if="data.item.avatar_url || data.item.namespace.avatar_url"  size="22">
                 <img width="25" height="25" :src="getAvatarUrl(data.item)"/>
               </v-list-item-avatar>
               <v-list-item-content :class="data.item.avatar_url || data.item.namespace.avatar_url ? 'ml-2' : ''">
                 <v-list-item-title>{{ data.item.name }}</v-list-item-title>
                 <v-list-item-subtitle>{{data.item.path_with_namespace}}</v-list-item-subtitle>
               </v-list-item-content>
             </template>
           </v-autocomplete>
           <v-checkbox
             v-model="isConfidential"
             label="This issue is confidential and should only be visible to team members with at least Reporter access."
           ></v-checkbox>
         </v-col>
       </v-row>
     </v-container>
     <v-card-actions>
       <v-spacer></v-spacer>
       <v-btn
         v-if="isValidConfig && !isPushing"
         text
         :loading="isPushing"
         @click="push"
       >
         <v-icon left>
           mdi-gitlab
         </v-icon>
         Create GitLab issue
       </v-btn>
     </v-card-actions>
   </v-card>
  </v-dialog>
</template>

<script>
import axios from "@/axios-client";
import util from "@/helpers/util";

export default {
  props: ["issue", "showDialog"],
  data: function() {
    return {
      dialogWidth: 1000,
      rules: {
        titleLength: len => v => (v || '').length <= len  || `Max title length is ${len}`,
        required: v => !!v || 'This field is required',
      },
      issueTypes: [ "Issue", "Incident" ],
      title: null,
      description: "",
      dueDate: null,
      issueType: "Issue",
      issueProject: null,
      autoGrowHack: false,
      isConfidential: false,
      showCalendarDialog: false,
      isPushing: false,
      fetchingProjects: false,
      availableProjects: []
    }
  },
  watch: {
    showDialog: async function(newVal) {
      if (newVal) {
        this.forceReRender();
        await this.fetchProjects();
      }
    },
    issueProject: function(newVal) {
      if (newVal === undefined) {
        this.issueProject = null;
      }
    }
  },
  methods: {
    forceReRender() {
      this.autoGrowHack = !this.autoGrowHack;
    },
    async fetchProjects() {
      this.availableProjects = [];
      this.fetchingProjects = true;
      await axios.get("/api/gitlab/projects").then((res) => {
        res.data.forEach((project) => {
          this.availableProjects.push(project);
        });
      }).finally(() => {
        this.availableProjects.sort((a, b) => a.name.localeCompare(b.name))
        this.fetchingProjects = false;
      });
    },
    async push() {
      this.isPushing = true;
      try {
        if (this.description !== "") {
          this.description += `\n\n${this.getJiraIssueUrl}`;
        } else {
          this.description += this.getJiraIssueUrl;
        }
        const { data } = await axios.post(`/api/gitlab/issue/create`, {
          "title": this.title ?? this.issue.fields.summary,
          "project_id": this.issueProject.id,
          "description": this.description,
          "issue_type": this.issueType.toLowerCase(),
          "confidential": this.isConfidential,
          "due_date": this.issueDueDate
        });
        if (data.id === 0) {
          this.$eventBus.$emit("alert", { text: "There was a problem creating the issue 😓", type: "error"});
          return;
        }
        const jiraData  = (await axios.put(`/api/jira/issue/${this.getJiraIssue.key}/gitlablink`, {
          "fields": {
            "customfield_12900": data.web_url
          }
        })).data;
        if (jiraData === false) {
          this.show = false;
          window.open(jiraData.web_url);
          this.$eventBus.$emit("alert", { text: "Created GitLab issue, but not able to update JIRA SD ticket", type: "warning"});
          return;
        }

        await this.$store.dispatch("postCommentOnJiraIssue", { key: this.issue.key, comment: "Awaiting reply in the GitLab ticket.", mentionAssignee: false });

        this.$eventBus.$emit("alert", { text: "GitLab issue created and JIRA SD ticket updated", type: "success"})
        this.show = false;
        this.$emit("success");
      } finally {
        this.isPushing = false;
      }
    },
    setSameTitle() {
      this.title = this.issue.fields.summary;
    },
    getAvatarUrl(item) {
      if (item.avatar_url) return item.avatar_url;
      if (item.namespace.avatar_url.startsWith("/uploads")) {
        return `https://gitlab.planetabax.com/${item.namespace.avatar_url}`;
      } else {
        return item.avatar_url ?? item.namespace.avatar_url;
      }
    }
  },
  computed: {
    getJiraIssueUrl() {
      return `https://jira.planetabax.com/browse/${this.getJiraIssue.key}`;
    },
    getJiraIssue() {
      return this.$store.state.JiraModule.currentJiraIssue;
    },
    isValidConfig() {
      return this.issueTitle !== "" && this.issueProject !== null;
    },
    notSameTitle() {
      if (this.title === null) return false;
      return this.title !== this.issue?.fields?.summary;
    },
    issueTitle: {
      get() {
        return this.title ?? this.issue?.fields?.summary;
      },
      set(value) {
        this.title = value;
      }
    },
    issueDescription: {
      get() {
        return this.description ?? this.issue?.fields?.description?.trim();
      },
      set(value) {
        this.description = value;
      }
    },
    issueDueDate: {
      get() {
        try {
          if (this.dueDate) {
            return this.dueDate;
          } else if (this.issue?.fields?.dueDate !== null) {
            return util.addDays(new Date(this.issue?.fields?.dueDate), 1).toISOString().substr(0, 10);
          } else {
            return (new Date(Date.now() - (new Date()).getTimezoneOffset() * 60000)).toISOString().substr(0, 10);
          }
        } catch { return new Date(); } //eslint-disable-line
      },
      set(value) {
        this.dueDate = value;
      }
    },
    show: {
      get() {
        return this.showDialog;
      },
      set(value) {
        if (!value) {
          this.$emit("closeDevDialog");
          this.issueDueDate = util.addDays(new Date(this.issue?.fields?.dueDate), 1).toISOString().substr(0, 10) ??
            new Date().toISOString().substr(0, 10);
          this.dueDate = null;
          this.title = null;
          this.description = null;
          this.issueProject = null;
          this.issueType = "Issue";
        }
      }
    }
  }
};
</script>

<style scoped>
</style>
