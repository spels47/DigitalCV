<template>
  <v-dialog persistent width="700" value="true">
    <v-card>
      <v-container>
        <v-row>
          <v-col>
            <v-card-title>{{ title }}</v-card-title>
            <v-progress-linear indeterminate color="black" v-if="isLoading || loading"></v-progress-linear>
            <HierarchyWithSearch v-if="customerHierarchy.length" @cancel="closeDialog()" @itemClicked="departmentClicked" :items="customerHierarchy" :initialCustomerId="initialCustomerId"></HierarchyWithSearch>
            <v-checkbox v-if="checkboxLabel && checkboxLabel.length > 0" :label="checkboxLabel" v-model="moveConnected"></v-checkbox>
          </v-col>
        </v-row>
        <v-row>
          <v-col class="text-right">
            <v-spacer></v-spacer>
            <v-btn color="primary" class="mr-2" text @click="closeDialog" :disabled="loading">Cancel</v-btn>
            <v-btn :disabled="selectedDepartments.length <= 0 || loading" :color="invalidMove ? 'error' : 'secondary'" @click="confirm">
              <v-icon left>
                {{ invalidMove ? 'mdi-alert-circle' : 'mdi-check-bold' }}
              </v-icon>
              {{ invalidMove ? "Can't move to same department" : "Confirm" }}
            </v-btn>
          </v-col>
        </v-row>
      </v-container>
    </v-card>
  </v-dialog>
</template>

<script>
import axios from "~/axios-client";
import HierarchyWithSearch from "../../HierarchyWithSearch";
export default {
  props: {
    mainOfficeId: {
      type: Number,
      required: true
    },
    initialCustomerId: {
      type: Number,
      required: false,
    },
    multipleDepartmentSourcesIds: {
      type: Array,
      required: false
    },
    title: {
      type: String,
      required: true,
    },
    checkboxLabel: {
      type: String,
      required: false,
    },
    loading: {
      type: Boolean,
      required: false
    }
  },
  components: {
    HierarchyWithSearch
  },
  data() {
    return {
      customerHierarchy: [],
      isLoading: true,
      selectedDepartments: [],
      moveConnected: true,
      invalidMove: false,
    };
  },
  async mounted() {
    await this.getCustomerHierarchyAndUsers();
  },
  methods: {
    async getCustomerHierarchyAndUsers() {
      this.customerHierarchy = [];
      await axios.get(`/api/customer/hierarchy/${this.mainOfficeId}`).then(res => {
        this.customerHierarchy = [res.data];
        this.isLoading = false;
      });
    },
    departmentClicked(id) {
      if (this.multipleDepartmentSourcesIds)
        this.invalidMove = this.multipleDepartmentSourcesIds.some(x => x === id[0]);
      else
        this.invalidMove = id[0] === this.initialCustomerId;

      this.selectedDepartments = id;
    },
    confirm() {
      if (this.invalidMove)
        return;

      this.$emit("confirm", this.moveConnected, this.selectedDepartments[0]);
    },
    closeDialog() {
      this.$emit("closeDialog");
    }
  },
};
</script>

<style></style>
