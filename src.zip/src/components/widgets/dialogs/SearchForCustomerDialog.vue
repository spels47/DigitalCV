<template>
  <v-dialog :value="true" persistent max-width="500px">
    <v-card>
      <v-card-title>
        <span class="headline">{{ title }}</span>
      </v-card-title>
      <v-card-text>
        <CustomerSearchbar ref="search" v-on:CUSTOMER_SELECTED="confirm" />
      </v-card-text>
      <v-card-actions>
        <v-spacer />
        <v-btn color="blue darken-1" text @click="cancel">cancel</v-btn>
      </v-card-actions>
    </v-card>
  </v-dialog>
</template>

<script>
import CustomerSearchbar from "../../CustomerSearchbar";
export default {
  props: ["title"],
  components: { CustomerSearchbar },
  data() {
    return {};
  },
  methods: {
    cancel() {
      this.$emit("cancel");
    },
    confirm(customer) {
      this.$emit("confirm", customer);
    }
  }
};
</script>

<style></style>
