﻿<template>
  <v-card class="fill" elevation="1" :loading="loadingStats">
    <v-card-title>
      {{title}}
    </v-card-title>
    <v-card-subtitle>
      <b>Issues in the last 150 days</b>
      <br/>
      <b class="red-color">{{totalCreated}}</b> issues created
      <br>
      <b class="green-color">{{totalResolved}}</b> issues resolved
    </v-card-subtitle>
    <v-card-text>
      <VueApexCharts ref="chart" :options="chartOptions" :series="series"></VueApexCharts>
      <VueApexCharts height="50%" ref="unresolvedTrendChart" :options="unresolvedTrendChartOptions" :series="unresolvedTrendChartSeries"></VueApexCharts>
    </v-card-text>
  </v-card>
</template>
<script>
import VueApexCharts from "vue-apexcharts"
import axios from "~/axios-client";
import moment from "moment";

export default {
  components: {VueApexCharts},
  data() {
    return {
      loadingStats: false,
      statistics: null,
      chartOptions: {
        chart: {
          type: "line",
          toolbar: {
            show: true
          },
          animations: {
            enabled: true,
            easing: 'easeinout',
            speed: 600,
            animateGradually: {
              enabled: true,
              delay: 100
            },
            dynamicAnimation: {
              enabled: true,
              speed: 600
            }
          },
        },
        dataLabels: {
          enabled: false
        },
        colors: ["#d04437", "#8eb021"],
        stroke: {
          curve: "smooth",
          width: [4, 4]
        },
        yaxis: [
          {
            axisTicks: {
              show: true
            },
          },
        ],
        tooltip: {
          shared: true,
          intersect: false,
          x: {
            show: true
          },
        },
        markers: {
          size: 6,
        },
      },
      unresolvedTrendChartOptions: {
        chart: {
          type: "line",
          toolbar: {
            show: true
          },
          animations: {
            enabled: true,
            easing: 'easeinout',
            speed: 600,
            animateGradually: {
              enabled: true,
              delay: 100
            },
            dynamicAnimation: {
              enabled: true,
              speed: 600
            }
          },
        },
        stroke: {
          curve: "smooth",
          width: 3
        },
        colors: ["#3572b0"],
        dataLabels: {
          enabled: false
        },
        yaxis: [
          {
            axisTicks: {
              show: true
            },
          },
        ],
        markers: {
          size: 6,
        },
      },
    }
  },
  async mounted() {
    try {
      this.loadingStats = true;
      const { data } = await axios.get("api/jira/statistics/issuesCreated");
      this.statistics = data;
      this.$refs.chart.updateOptions({
        xaxis: {
          categories: this.axis
        }
      });
      this.$refs.unresolvedTrendChart.updateOptions({
        xaxis: {
          categories: this.axis
        }
      });
    } catch {
      this.$eventBus.$emit("alert", {text: "Couldn't fetch ASAPSD Customer statistics", type: "error"});
    } finally {
      this.loadingStats = false;
    }
  },
  computed: {
    totalCreated() {
      return this.statistics?.totals?.created ?? 0;
    },
    totalResolved() {
      return this.statistics?.totals?.resolved ?? 0;
    },
    title() {
      return this.statistics?.filterTitle ?? "";
    },
    series() {
      return [
      {
        name: `Created issues`,
        data: this.created
      },
      {
        name: `Resolved issues`,
        data: this.resolved
      }];
    },
    unresolvedTrendChartSeries() {
      return [
        {
          name: "Unresolved trend",
          data: this.unresolvedTrend
        }
      ]
    },
    unresolvedTrend() {
      if (!this.statistics) return [{ data: [] }];
      return this.statistics.data.map(i => {
        return i.statistics.unresolvedTrend.count;
      })
    },
    created() {
      if (!this.statistics) return [{ data: [] }];
      return this.statistics.data.map(i => {
        return i.statistics.created.count;
      })
    },
    resolved() {
      if (!this.statistics) return [{ data: [] }];
      return this.statistics.data.map(i => {
        return i.statistics.resolved.count;
      })
    },
    axis() {
      if (!this.statistics) return [];

      return this.statistics.data.map(i => {
        return moment(i.start).format("ll")
      });//.filter((v,i) => i % 2);
    },
  }
}
</script>
<style scoped>
.red-color {
  color: #d04437
}

.green-color {
  color: #8eb021
}

.fill {
  width: 100%;
  height: 100%;
}
</style>
