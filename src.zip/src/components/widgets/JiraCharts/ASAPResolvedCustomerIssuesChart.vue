﻿<template>
  <v-card elevation="1" :loading="loadingStats">
    <v-card-title>
      {{title}}
    </v-card-title>
    <v-card-subtitle>
      <span>10 most frequent assignees</span>
      <br/>
      <b>Total issues: {{issueCount}} (all included)</b>
    </v-card-subtitle>
    <v-card-text>
      <VueApexCharts ref="chart" :options="chartOptions" :series="series"></VueApexCharts>
    </v-card-text>
  </v-card>
</template>
<script>
import VueApexCharts from "vue-apexcharts"
import axios from "~/axios-client";

export default {
  components: {VueApexCharts},
  data() {
    return {
      loadingStats: false,
      statistics: null,
      chartOptions: {
        chart: {
          type: "donut",
        },
        plotOptions: {
          pie: {
            donut: {
              labels: {
                show: true,
                name: {
                },
                value: {
                }
              }
            }
          }
        },

        dataLabels: {
          enabled: true,
          formatter: function (val) {
            return Math.floor(val) + "%"
          },
        }
      },
    }
  },
  async mounted() {
    try {
      this.loadingStats = true;
      const { data } = await axios.get("api/jira/statistics/asapResolvedCustomerIssues");
      this.statistics = data;
      this.$refs.chart.updateOptions({
        labels: this.chartLabels
      });

    } catch {
      this.$eventBus.$emit("alert", {text: "Couldn't fetch ASAPSD Customer statistics", type: "error"});
    } finally {
      this.loadingStats = false;
    }
  },
  computed: {
    issueCount() {
      return this.statistics?.issueCount ?? 0;
    },
    title() {
      return this.statistics?.filterTitle ?? "";
    },
    chartLabels() {
      if (!this.statistics) return [{ data: [] }];
      return this.statistics.data.slice(0,10).map(i => { // first 10 elements
        return i.key
      });
    },
    series() {
      if (!this.statistics) return [{ data: [] }];
      return this.statistics.data.slice(0,10).map(i => { // first 10 elements
        return i.value
      });
    },
  }
}
</script>
<style scoped>
.fill {
  width: 100%;
  height: 400px;
}
</style>
