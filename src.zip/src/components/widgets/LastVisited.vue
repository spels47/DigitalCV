<template>
  <v-card>
    <v-card-subtitle>
      <div class="d-flex align-center">
        <span>{{ numberOfItemsShown }} last visited {{ type === "units" ? "assets" : type }}</span>

        <v-menu nudge-bottom="40">
          <template #activator="{ on, attrs }">
            <v-btn
              class="ml-2"
              icon
              @click="chevronUp = !chevronUp"
              v-bind="attrs"
              v-on="on"
            >
              <v-icon>{{ chevronUp ? 'mdi-chevron-up' : 'mdi-chevron-down' }}</v-icon>
            </v-btn>
          </template>

          <v-list dense>
            <v-list-item
              class="list-item"
              dense
              @click="setLastVisitedAmount(5)"
            >
              Last 5
            </v-list-item>
            <v-list-item
              v-if="itemCount >= 10"
              class="list-item"
              dense
              @click="setLastVisitedAmount(10)"
            >
              Last 10
            </v-list-item>
          </v-list>
        </v-menu>
      </div>
    </v-card-subtitle>

    <v-list dense class="list-max-height">
      <template v-if="items.length < 1">
        <v-divider></v-divider>
        <v-list-item>
          <v-list-item-icon>
            <v-icon>mdi-emoticon-happy-outline</v-icon>
          </v-list-item-icon>
          <v-list-item-content>
            <v-list-item-title>No data yet, but don't worry</v-list-item-title>
            <v-list-item-subtitle>
              The list will fill when you navigate to {{type}}
            </v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>
      </template>

      <template v-for="(item, index) in items" >
        <v-divider :key="index" v-if="index > 0"></v-divider>
        <search-result-list-item :data-cy="type + 'last-visited' + index" :item="item" @click="goTo(item)" :key="item.type+item.id"></search-result-list-item>
      </template>
    </v-list>
  </v-card>
</template>

<script>
  import SearchResultListItem from "../SearchResultListItem"
  export default {
    name: "LastVisited",
    components: {SearchResultListItem},
    props: {
      type: String
    },
    data: function () {
      return {
        types: [
          {
            type: 'customers',
            filter: ['MainOfficeCustomer', 'Customer'],
            action: item => this.$router.push({
              name: "customer",
              params: { id: item.id },
              query: { activeTab: this.$utils.getDefaultTab(this.defaultTable) }})
          },
          {
            type: 'units',
            filter: ['Vehicle', 'EQ', 'Mini', 'Simcard', "SimcardStorageUnit", 'Oem'],
            action: item => {
              if (item.type === "SimcardStorageUnit") {
                this.$router.push({
                  name: "customer-placeholder",
                  query: { dataSourceId: item.id }
                });
              } else {
                this.$router.push({
                  name: "customer",
                  params: { id: item.departmentPath[item.departmentPath.length - 1].id },
                  query: { activeTab: this.getSelectedTab(item.type), type: item.type.toLowerCase(), id: item.id }
                });
              }
            },
          },
          {
            type: 'accounts',
            filter: ['AdminAccount', 'Account'],
            action: item => this.$router.push({
              name: "customer",
              params: { id: item.departmentPath[item.departmentPath.length -1].id },
              query: { activeTab: this.getSelectedTab(item.type), type: 'account', id: item.id }
            })
          },
        ],
        chevronUp: false,
        numberOfItemsShown: 5
      };
    },
    async mounted() {
      await this.$store.dispatch('userSettings_Fetch');
      let storedItemsToShow = window.localStorage.getItem(`numberOfItemsShown-${this.type === "units" ? "assets" : this.type}`);
      this.numberOfItemsShown = storedItemsToShow ? storedItemsToShow : 5;
    },
    methods: {
      goTo(event) {
        this.types.filter(x => x.filter.includes(event.type))[0].action(event)
      },
      getSelectedTab(type) {
        switch(type.toLowerCase())
        {
          case "overview":
            return 0;
          case "account":
            return 1;
          case "adminaccount":
            return 1;
          case "vehicle":
            return 2;
          case "eq":
            return 3;
          case "subscription":
            return 4;
          case "simcard":
            return 5;
          case "oem":
            return 5;
          case "mini":
            return 5;
          case "rfid":
            return 5;
          case "datasource":
            return 5;
          case "customerlog":
            return 6;
          case "financial":
            return 7;
          default:
            return 0;
        }
      },
      setLastVisitedAmount(amount){
        this.numberOfItemsShown = amount;
        window.localStorage.setItem(`numberOfItemsShown-${this.type === "units" ? "assets" : this.type}`, amount);
        this.chevronUp = !this.chevronUp;
      }
    },
    computed: {
      items(){
        let filterArray = this.types.find(filter => filter.type === this.type)?.filter

        if(filterArray == null) return [{title:'invalid type setting'}]
        return this.$store.state.userSettings?.lastVisited?.filter(x => filterArray.includes(x.type)).slice(0, this.numberOfItemsShown) ?? []
      },
      itemCount(){
        let filterArray = this.types.find(filter => filter.type === this.type)?.filter

        if(filterArray == null) return [{title:'invalid type setting'}]
        return this.$store.state.userSettings?.lastVisited?.filter(x => filterArray.includes(x.type))?.length ?? 0
      },
      defaultTable() {
        return this.$store.state.userSettings.defaultTable;
      }
    }
  };
</script>

<style lang="css" scoped>
.list-item {
  font-size: 0.95rem;
}

.list-max-height{
  max-height: 330px;
  overflow-y: auto;
}
</style>
