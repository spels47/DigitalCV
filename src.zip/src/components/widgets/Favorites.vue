<template>
  <v-card>
    <v-tabs fixed-tabs background-color="black" dark v-model="activeTab">
      <v-tab v-for="tab in types" :key="tab.type">{{ tab.displayText }}</v-tab>
    </v-tabs>

    <v-card>
      <v-card-title>
        <v-text-field v-model="search" append-icon="mdi-magnify" label="Search in favorites" single-line hide-details></v-text-field>
      </v-card-title>
      <v-list two-line>
        <template v-if="items.length < 1">
          <v-list-item>
            <v-list-item-icon>
              <v-icon>mdi-heart-plus</v-icon>
            </v-list-item-icon>
            <v-list-item-content>
              <v-list-item-title>No favorites yet</v-list-item-title>
              <v-list-item-subtitle>
                Get started by clicking the button
              </v-list-item-subtitle>
            </v-list-item-content>
          </v-list-item>
        </template>

        <template v-for="(item, index) in itemsFilteredBySearch">
          <v-divider :key="index" v-if="index > 0"></v-divider>
          <search-result-list-item :item="item" @click="goTo(item)" :key="item.id">
            <template v-slot:action>
              <v-icon v-tooltippy="'Remove from favorites'" @click.stop="removeFavorite(item)" right class="float-right" color="error">mdi-delete</v-icon>
              <v-icon v-tooltippy="'Impersonate'" v-if="activeTab === 2" @click.stop="userImpersonate(item.id)" right class="float-right" color="secondary">mdi-login-variant</v-icon>
            </template>
          </search-result-list-item>
        </template>
      </v-list>

      <v-dialog v-model="dialog" max-width="460px" scrollable>
        <template v-slot:activator="{ on, attrs }">
          <v-col class="text-center" cols="12">
            <div>
              <v-btn color="secondary" v-on="on" v-bind="attrs"> <v-icon left>mdi-plus-circle</v-icon>Add favorite </v-btn>
            </div>
          </v-col>
        </template>
        <v-card>
          <v-card-title>
            <span>Let's try finding what you're looking for</span>
          </v-card-title>
          <v-card-subtitle>Use the search bar below to find and add a favorite.</v-card-subtitle>
          <v-card-text>
            <MultiSearchBar v-if="dialog" @click="addFavorite" emit-item-on-click menu-max-height="450px" />
          </v-card-text>
          <v-card-actions>
            <v-spacer />
            <v-btn text @click="close">Cancel</v-btn>
          </v-card-actions>
        </v-card>
      </v-dialog>
    </v-card>
  </v-card>
</template>

<script>
import SearchResultListItem from "../SearchResultListItem";
import MultiSearchBar from "../MultiSearchBar";
import axios from "~/axios-client";

export default {
  name: "Favorites",
  components: { MultiSearchBar, SearchResultListItem },
  data: function() {
    return {
      search: "",
      activeTab: 0,
      dialog: false,
      types: [
        {
          type: "customers",
          displayText: "Customers",
          tabNumber: 0,
          filter: ["MainOfficeCustomer", "Customer"],
          action: item => this.$router.push({
            name: "customer",
            params: { id: item.id },
            query: {activeTab: this.$utils.getDefaultTab(this.defaultTable)}
          }).catch(err => {})
        },
        {
          type: "units",
          displayText: "Assets",
          tabNumber: 1,
          filter: ["Vehicle", "EQ", "Mini", "Simcard", "SimcardStorageUnit", "Oem"],
          action: item => {
            if (item.type === "SimcardStorageUnit") {
              this.$router.push({
                name: "customer-placeholder",
                query: { dataSourceId: item.id }
              });
            } else {
              this.$router.push({
                name: "customer",
                params: { id: item.departmentPath[item.departmentPath.length - 1].id },
                query: { activeTab: this.getSelectedTab(item.type), type: item.type.toLowerCase(), id: item.id }
              });
            }
          },
        },
        {
          type: "accounts",
          displayText: "Accounts",
          tabNumber: 2,
          filter: ["AdminAccount", "Account"],
          action: item => this.$router.push({
            name: "customer",
            params: { id: item.departmentPath[0].id },
            query: { type: "account", id: item.id, activeTab: this.getSelectedTab(item.type) }
          }).catch(err => {})
        },
        {
          type: "subscriptions",
          displayText: "Subscriptions",
          tabNumber: 3,
          filter: ["Subscription"],
          action: item => this.$router.push({
            name: "subscription",
            params: { id: item.departmentPath[0].id },
            query: { type: "account", id: item.id, activeTab: this.getSelectedTab(item.type) }
          }).catch(err => {})
        }
      ]
    };
  },
  async mounted() {
    await this.$store.dispatch("userSettings_Fetch");
    try {
      this.activeTab = parseInt(window.localStorage.getItem("widgets:favorites:activeTab") ?? "0");
    } catch (ex) {
      console.error(ex);
    }
  },
  computed: {
    defaultTable() {
      return this.$store.state.userSettings.defaultTable;
    },
    items() {
      let filterArray = this.types.find(filter => filter.tabNumber === this.activeTab)?.filter;
      if (filterArray == null) return [{ title: "invalid type setting" }];
      return this.$store.state.userSettings?.favorites?.filter(x => filterArray.includes(x.type)) ?? [];
    },
    itemsFilteredBySearch() {
      return this.search ? this.items.filter(x => x.name.toLowerCase().includes(this.search.toLowerCase())) : this.items;
    }
  },
  methods: {
    getSelectedTab(type) {
      switch(type.toLowerCase()) {
        case "overview":
          return 0;
        case "account":
          return 1;
        case "vehicle":
          return 2;
        case "eq":
          return 3;
        case "subscription":
          return 4;
        case "simcard":
          return 5;
        case "customerlog":
          return 6;
        case "financial":
          return 7;
        default:
          return 0;
      }
    },
    goTo(event) {
      this.types.find(x => x.filter.includes(event.type)).action(event);
    },
    async addFavorite(favorite) {
      this.dialog = false;
      this.activeTab = this.types.find(x => x.filter.includes(favorite.type)).tabNumber;
      await this.$store.dispatch("toggleFavorite", favorite);
    },
    async removeFavorite(favorite) {
      await this.$store.dispatch("toggleFavorite", favorite);
    },
    close() {
      this.dialog = false;
    },
    async userImpersonate(id) {
      try {
        let res = await axios.get(`/api/user/${id}`);
        if(!res.data.accountActive) {
          this.$eventBus.$emit('alert', { text: "Unable to impersonate, this user is not active", type: "error" });
          return
        }
        if(res.data.isAdminUser) window.open(`/start-impersonation-central?userId=${res.data.userId}&username=${res.data.username}`, "_blank");
        else window.open(`/start-impersonation-triplog?userId=${res.data.userId}&username=${res.data.username}`, "_blank");
      } catch (ex){
        this.$eventBus.$emit('alert', { text: "Unable to fetch user information required to impersonate", type: "error" });
      }
    }
  },
  watch: {
    activeTab: function() {
      window.localStorage.setItem("widgets:favorites:activeTab", this.activeTab);
    },
    dialog: function() {
      // if(this.dialog) this.$refs.
    }
  }
};
</script>

<style scoped></style>
