﻿<template>
  <v-menu right background-color="black" offset-y :close-on-content-click="true">
    <template v-slot:activator="{ on }">
      <v-icon class="pr-2 pl-2" v-on="on" :color="getFilterColor">
        mdi-filter-variant
      </v-icon>
    </template>

    <v-list
      shaped
      style="width: 250px"
    >
      <v-subheader class="font-weight-medium">Choose team</v-subheader>
      <v-divider></v-divider>
      <v-list-item-group color="primary">
        <v-list-item
          v-for="(item, i) in allTeams"
          :key="i"
          @click="changeTeam(item)"
          color="primary"
        >
          <v-list-item-content>
            <v-list-item-title v-text="item.teamName"></v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list-item-group>
    </v-list>
  </v-menu>
</template>

<script>
export default {
  name: "PortfolioTeamSelector",
  props: ["includeCountry"],
  data() {
    return {
    }
  },
  async mounted() {
    await this.$store.dispatch("PortfolioTeamModule/retrieveAllTeams");
  },
  methods: {
    changeTeam(item) {
      this.$store.dispatch("PortfolioTeamModule/selectTeam",item._id)
    },
  },
  computed: {
    allTeams() {
      let teams = this.$store.state.PortfolioTeamModule.allTeams;
      if(this.includeCountry){
        teams = teams.concat(this.$store.state.PortfolioTeamModule.countries)
      }
      return teams;
    },
    currentTeam() {
      if(!this.$store.state.PortfolioTeamModule.currentTeam) return {teamName: "All", _id: null}
      return this.$store.state.PortfolioTeamModule.currentTeam;
    },
    getFilterColor() {
      if(!this.currentTeam.teamName || this.currentTeam.teamName === "All") return "white";
      return "secondary";
    }
  }
}
</script>

<style scoped>

</style>
