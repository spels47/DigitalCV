<template>
  <v-container>
    <v-data-table
      :items="parcels"
      :headers="headers"
      :footer-props="{ 'items-per-page-options': [5] }"
      :single-expand="singleExpand"
      :expanded.sync="expanded"
      :items-per-page="5"
      :loading="loading"
      sort-by="latestStatusChangeDateTime"
      sort-desc
      loading-text="Fetching parcels for this customer..."
      show-expand
    >
      <template v-slot:item.trackingNumber="{ item }">
        <div
          v-if="determineTrackingNumber(item)"
          class="d-flex"
        >
          <WrappedTextWithTooltip
            :text="item.trackingNumber"
            :max-length="10"
            clickable
            :apply-clickable-styling="false"
            @clicked="openTrackingPage(item)"
          ></WrappedTextWithTooltip>
          <v-icon
            class="ml-1"
            small
            @click="copyToClipboard(item.trackingUrl)"
          >
            mdi-content-copy
          </v-icon>
        </div>
        <span v-else>Not available for tracking yet.</span>
      </template>
      <template v-slot:item.latestStatus="{ item }">
        <WrappedTextWithTooltip
          :text="item.latestStatus"
          :max-length="38"
        ></WrappedTextWithTooltip>
      </template>
      <template v-slot:item.latestStatusChangeDateTime="{item}">
        <WrappedTextWithTooltip
          v-if="item.latestStatusChangeDateTime"
          :text="item.latestStatusChangeDateTime | ntzDatetime"
          :max-length="10"
        ></WrappedTextWithTooltip>
      </template>
      <template v-slot:item.data-table-expand="{ item, isExpanded, expand }">
        <v-icon v-if="!isExpanded && item.orderedItems != null && item.orderedItems !== [] && item.orderedItems.length > 0" @click="expand(true)"> mdi-chevron-down</v-icon>
        <v-icon v-if="isExpanded && item.orderedItems != null && item.orderedItems !== [] && item.orderedItems.length > 0" @click="expand(false)"> mdi-chevron-up</v-icon>
      </template>
      <template v-slot:expanded-item="{ headers, item }">
        <td :colspan="headers.length" v-if="item.orderedItems != null && item.orderedItems !== [] && item.orderedItems.length > 0">
          <table v-for="(orderedItem, index) in item.orderedItems" :key="index">
            <tr>
              <td>{{ orderedItem.quantity > 0 ? orderedItem.quantity + 'x' : '' }} {{ orderedItem.displayName }}</td>
            </tr>
          </table>
        </td>
      </template>
    </v-data-table>
  </v-container>
</template>

<script>
import axios from "@/axios-client";
import WrappedTextWithTooltip from "@/components/text/WrappedTextWithTooltip";
import { mapGetters } from "vuex";

export default {
  name: "Consignments",
  components: { WrappedTextWithTooltip },
  data() {
    return {
      parcels: [],
      headers: [
        { text: 'Tracking number', value: 'trackingNumber' },
        { text: 'Status', value: 'latestStatus' },
        { text: 'Last update', value: 'latestStatusChangeDateTime' },
        { text: '', value: 'data-table-expand' },
      ],
      expanded: [],
      loading: false,
      singleExpand: false
    }
  },
  watch: {
    customer: {
      handler: async function(newValue) {
        if (!newValue.id)
          return;

        await this.getParcelDeliveries();
      },
      deep: true,
      immediate: true
    }
  },
  methods: {
    determineTrackingNumber(item) {
      if (this.customer.country === "GB") {
        return (item.latestStatus === "Packed" || item.trackingUrl === "https://track.dpd.co.uk/parcels/")
          ? null
          : item.latestStatus;
      }

      return true;
    },
    async getParcelDeliveries() {
      this.loading = true;

      try {
        const { data: parcels } = await axios.get(`/api/parcel/${this.customer.id}/customer-shipments`);
        this.parcels = parcels;
      } finally {
        this.loading = false;
      }
    },
    openTrackingPage(item) {
      window.open(item.trackingUrl);
    },
    copyToClipboard(url) {
      navigator.clipboard.writeText(url);
    }
  },
  computed: {
    ...mapGetters('customerStore', ['customer']),
  }
}
</script>

<style scoped>

</style>
