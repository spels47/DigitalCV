﻿<template>
  <v-container>
    <v-row>
      <v-col cols="lg-12">
        <v-list dense>
          <v-list-item class="pl-0">
            <v-col cols="lg-9">
              <span class="font-weight-bold">Products</span>
            </v-col>
            <v-col cols="lg-3">
              <span class="font-weight-bold">Amount</span>
            </v-col>
          </v-list-item>
        </v-list>
        <v-list dense>
          <template v-for="item in groupedSubscriptions">
          <v-list-item class="pl-0" :key="item.key">
            <v-col cols="lg-9">
              <span>{{ item[0].description }}</span>
            </v-col>
            <v-col cols="lg-3">
              <span>{{ item.totalQuantity }}</span>
            </v-col>
          </v-list-item>
            <v-divider :key="item.key"></v-divider>
          </template>
        </v-list>
      </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {
  name: "ContractInfo",
  props: {
    currentContract: Object,
  },
  data() {
    return {
      filteredSubscriptionList: [],
      groupedSubscriptions: [],
      accessCustomer: false,
    }
  },
  watch: {
    currentContract: {
      deep: true,
      handler() {
        this.filteredSubscriptionList = [];
        this.groupedSubscriptions = [];
        if (this.currentContract?.subscriptions !== undefined) {
          this.currentContract.subscriptions.forEach(x => {
            if (x.pricePerMonth > 0 && x.quantity > 0 && !x.status.toLowerCase().includes("terminated")) {
              this.filteredSubscriptionList.push(x);
            }
            if(x.itemNumber === "5140"){
              this.accessCustomer = true;
            }
          });
          this.groupedSubscriptions = this.filteredSubscriptionList.reduce((r, a) => {
            r[a.itemNumber] = [...r[a.itemNumber] || [], a];
            return r;
          }, {});
          for (let prop in this.groupedSubscriptions) {
            let sumTotal = 0;
            this.groupedSubscriptions[prop].forEach(x => {
              sumTotal = sumTotal + x.quantity;
            })
            // if (sumTotal === 0) sumTotal = 1;
            this.groupedSubscriptions[prop].totalQuantity = sumTotal;
          }
        }
      }
    }
  },
}
</script>

<style scoped>

</style>
