﻿<template>
  <v-container>
    <v-data-table
      :items="customerLedger.filter(x => allowedDocumentTypes.includes(x.documentType))"
      :headers="headers"
      :item-class="itemRowBackground"
      :footer-props="{ 'items-per-page-options': [5] }"
      :items-per-page="5"
    >
      <template v-slot:item.documentNo="{ item }">
        <span v-if="Date.parse(item.postingDate) >= Date.parse(startingDate)"><a :href="getSharePointLink(item.documentNo)" target="_blank">{{ item.documentNo }}</a></span>
        <span v-if="Date.parse(item.postingDate) < Date.parse(startingDate)">{{ item.documentNo }}</span>
      </template>
      <template v-slot:item.open="{item}">
        <span>{{ item.open === true ? "Open" : "Closed" }}</span>
      </template>
      <template v-slot:item.postingDate="{item}">
        <span>{{ item.postingDate | ntzDate }}</span>
      </template>
      <template v-slot:item.dueDate="{item}">
        <span>{{ item.dueDate | ntzDate }}</span>
      </template>
      <template v-slot:item.originalAmount="{item}">
        <span>{{ currencyFormatter(item.originalAmount) }}</span>
      </template>
    </v-data-table>
  </v-container>
</template>

<script>
export default {
  name: "Invoice",
  props: ["customerLedger", "customer"],
  data() {
    return {
      allowedDocumentTypes: ['Invoice'],
      startingDate: '02.01.2021',
      country: "NO",
      folderName: "",
      headers: [
        { text: 'Invoice ID', value: 'documentNo' },
        { text: 'Payment Status', value: 'open' },
        { text: 'Amount', value: 'originalAmount' },
        { text: 'Creation Date', value: 'postingDate' },
        { text: 'Due Date', value: 'dueDate' },
      ],
      today: new Date()
    }
  },
  methods: {
    itemRowBackground(item) {
      return item.open && Date.parse(item.dueDate) < this.today
        ? "error--text font-weight-bold" :
        "";
    },
    currencyFormatter(item) {
      return this.$utils.getFormattedPriceForCountry(this.customer.country, item);
    },
    getSharePointLink(id) {
      let fileName = "";
      let folderName = ""
      let levelTwoId = this.customer.cPath.split(".")[1];
      switch (levelTwoId) {
        case "22880":
          folderName = "ABAX as";
          fileName = "ABAX as";
          break;
        case "67066":
          folderName = "ABAX Danmark AS";
          fileName = "ABAX Danmark AS";
          break;
        case "51672":
          folderName = "ABAX Sweden AB";
          fileName = "ABAX Sweden AB";
          break;
        case "22944":
          folderName = "ABAX Finland Oy";
          fileName = "ABAX Finland Oy";
          break;
        case "67067":
          folderName = "ABAX UK Ltd";
          fileName = "ABAX UK Ltd.";
          break;
        case "200672":
        case "590078":
          folderName = "ABAX Nederland BV";
          fileName = "ABAX Nederland BV";
          break;
        case "310896":
          folderName = "ABAX Poland Sp z o o";
          fileName = "ABAX Poland Sp. z o. o.";
          break;
        case "601817":
          folderName = "RAM Mobile Data BV";
          fileName = "RAM Mobile Data (Belgium) NV";
          break;
        case "601528":
          folderName = "RAM Track %26 Trace BV";
          fileName = "RAM Track %26 Trace NL";
          break;
        case "385237":
          folderName = "Fleetfinder ApS";
          fileName = "Abax FleetFinder";
      }
      return `https://abaxas.sharepoint.com/sites/ABAXInvoices/Documents/Forms/allItems.aspx?id=%2Fsites%2FABAXInvoices%2FDocuments%2F${folderName}%2F${fileName}-${id}%2Epdf&parent=%2Fsites%2FABAXInvoices%2FDocuments%2F${folderName}`
    },
  }
}
</script>

<style scoped>

</style>
