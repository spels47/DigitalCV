﻿<template>
  <v-container>
    <v-card>
      <v-list color="background" elevation="2">
        <v-list-item>
          <v-list-item-content>
            <v-list-item-title class="headline">
              <span>{{ header }}</span>
            </v-list-item-title>
            <v-list-item-subtitle v-if="subHeader">
              <span class="font-weight-bold" :style="`color: ${subHeader.color}`">{{ subHeader.text }}</span>
            </v-list-item-subtitle>
          </v-list-item-content>
        </v-list-item>
        <v-progress-linear indeterminate dark v-if="this.loading"></v-progress-linear>
      </v-list>
      <slot name="mainContent"></slot>
      <slot name="extraFeature"></slot>
    </v-card>
  </v-container>
</template>

<script>
export default {
  name: "Box",
  props: {
    header: String,
    subHeader: Object,
    items: [],
    loading: Boolean,
  },
  data() {
    return {

    }
  },
}
</script>

<style scoped>

</style>
