﻿<template>
  <v-container>
    <div>
      <v-card elevation="5" color="black" class="text-center pb-8 mb-2 rounded-lg" style="max-height:200px; min-height:200px">
        <v-card-title class="justify-center white--text">{{ header }}</v-card-title>
        <div>
          <span class="justify-center white--text">{{ subText }}</span>
        </div>
        <div>
          <span class="justify-center white--text">{{ subText2 }}</span>
        </div>
        <slot name="mainContent">
        </slot>
      </v-card>
      <div class="text-center" v-if="buttonVisible">
        <v-btn class="elevation-1" :prepend-icon="buttonIcon" color="black">
          <v-icon color="#25BACA">{{ buttonIcon }}</v-icon>
          <span class="white--text">{{ buttonText }}</span>
        </v-btn>
      </div>
    </div>
  </v-container>
</template>

<script>
export default {
  name: "WidgetBox",
  props: ["header", "subText", "subText2", "showButton", "buttonText", "buttonIcon"],
  data() {
    return {}
  },
  computed: {
    buttonVisible: function () {
      return !!this.showButton;

    }
  }
}
</script>

<style scoped>

</style>
