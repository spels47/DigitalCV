﻿<template>

</template>

<script>
export default {
  name: "TicketInfo",
  props: {
    customerTickets: Array,
  },
  data() {
    return {}
  }
}
</script>

<style scoped>

</style>
