﻿<template>
  <v-container>
    <v-row>
      <v-col>
        <v-data-table
        :items="pricesList"
        :headers="headers"
        >
          <template v-slot:item.pricePerMonth="{ item }">
            <span>{{ getSumPrice(item.pricePerMonth)}}</span>
          </template>
        </v-data-table>
        </v-col>
    </v-row>
  </v-container>
</template>

<script>
export default {
  name: "PricesInfo",
  props: {
    customerInformation: Array,
    customer: Object
  },
  data() {
    return {
      filteredSubscriptionList: [],
      groupedSubscriptions: [],
      pricesList: [],
      headers: [
        {text: "Products", value: "description"},
        {text: "Amount", value: "quantity"},
        {text: "Price", value: "pricePerMonth"}
      ]
    }
  },
  methods: {
    getSumPrice(price) {
      return this.$utils.getFormattedPriceForCountry(this.customer.country, price)
    },
  },
  watch: {
    customerInformation() {
      let allSubs = []
      this.customerInformation.forEach(x => {
        x.subscriptions.forEach(z => {
          if (z.pricePerMonth > 0 && !z.status.toLowerCase().includes("terminated") && z.quantity > 0)  {
            // if (z.quantity < 1) z.quantity = 1;
            let findIndex = allSubs.findIndex(t => t.itemNumber === z.itemNumber && t.pricePerMonth === z.pricePerMonth);
            if (findIndex === -1) {
              allSubs.push(Object.assign({}, z));
            } else {
              allSubs[findIndex].quantity += z.quantity;
            }
          }
        })
      })
      let deliveryIndex = allSubs.findIndex(x => x.itemNumber === "F150" || x.description.toLowerCase().includes("frakt"))
      if (deliveryIndex !== -1) {
        let deliveryCopy = Object.assign({}, allSubs[deliveryIndex])
        allSubs.splice(deliveryIndex, 1)
        allSubs.push(deliveryCopy);
      }
      this.pricesList = allSubs;
    }
  }
}
</script>

<style scoped>

</style>
