﻿<template>
<v-card>
  <v-data-table>

  </v-data-table>
</v-card>
</template>

<script>
export default {
  name: "TableBasic",
  props: {
    items: [],
  },
  data() {
    return {

    }
  },
}
</script>

<style scoped>

</style>
