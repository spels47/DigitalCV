﻿<template>
  <v-card class="rounded-lg">
    <v-tabs background-color="black" v-model="tabModel" dark>
      <v-tab
        v-for="tab in tabs"
        :key="tab.id"
        :href="`#${tab.name}`"
        @click="currentTab = tab.id">
        {{ tab.name }}
      </v-tab>
      <v-spacer></v-spacer>
    </v-tabs>

    <v-card-subtitle class="d-flex flex-row justify-space-between">
      <v-card class="d-flex flex-row justify-space-between">
        <v-card-title class="caption">Quick filters:</v-card-title>
        <v-card-actions>
          <v-btn v-for="filter in quickFilters" width="150px" class="mb-1 ml-2" :outlined="filter.color == 'primary'" :key="filter.id" :color="filter.color" @click="toggleQuickFilter(filter.id)">
            {{filter.id}}
          </v-btn>
        </v-card-actions>
      </v-card>
      <div class="d-flex flex-row justify-center align-self" style="width: 500px;">
        <v-menu offset-y :close-on-content-click="false" bottom>
          <template v-slot:activator="{ on }">
            <v-icon class="filter-icon" style="height: 24px; padding-top: 8px;" :color="anyFilterChecked ? 'marked' : ''" v-on="on">
              mdi-filter
            </v-icon>
          </template>
          <v-list>
            <v-list-item>
              <v-list-item-title>
                <v-checkbox v-for="filter in quickFilters" :key="filter.id" dense :label="'Show ' + filter.id"  @click="toggleFilter()" v-model="filter.state" ></v-checkbox>
              </v-list-item-title>
            </v-list-item>
          </v-list>
        </v-menu>
        <v-text-field class="mt-0 pt-0 pl-1" v-model="search" append-icon="mdi-magnify" label="Search" single-line hide-details width="200px"/>
      </div>
    </v-card-subtitle>
    <v-data-table
      :headers="tableHeaders"
      :items="filteredData"
      :loading="loading"
      :search="search"
      :sort-by.sync="sortBy"
      :sort-desc.sync="sortDesc"
      :footer-props="{ 'items-per-page-options': [10, 20, 100] }">
      <template v-slot:item.itemNumber="{ item }">
        <v-layout>
          <v-flex >
            <span class="font-weight-medium mrr-text">{{ item.itemNumber }}</span>
          </v-flex>
        </v-layout>
      </template>
      <template v-slot:item.itemName="{ item }">
        <v-layout>
          <v-flex >
            <span class="font-weight-medium mrr-text">{{ item.itemName }}</span>
          </v-flex>
        </v-layout>
      </template>
      <template v-slot:item.quantity="{ item }">
        <v-layout class="text-right">
          <v-flex>
            <span class="font-weight-medium mrr-text">{{ item.quantity }}</span>
          </v-flex>
        </v-layout>
      </template>
      <template v-slot:item.pendingPicks="{ item }">
        <v-layout class="text-right">
          <v-flex>
            <span class="font-weight-medium mrr-text">{{ item.pendingPicks }}</span>
          </v-flex>
        </v-layout>
      </template>
      <template v-slot:item.available="{ item }">
        <v-layout class="text-right">
          <v-flex>
            <span class="font-weight-medium mrr-text">{{ item.available }}</span>
          </v-flex>
        </v-layout>
      </template>

    </v-data-table>
  </v-card>

</template>

<script>
import axios from "@/axios-client";

export default {
  name: "StockListComponent",
  data() {
    return {
      data: [],
      loading: false,
      sortBy: 'available',
      sortDesc: true,
      search: "",
      selectedTab: 0,
      tabModel: "",
      tableHeaders: [
        {text: "Item No.", value: "itemNumber"},
        {text: "Product type", value: "itemName"},
        {text: "Amount in stock", value: "quantity", align:"right"},
        {text: "Pending picks", value: "pendingPicks", align:"right"},
        {text: "Available", value:"available", align:"right"}
      ],
      tabs: [
        {id: 0, name: "NO", clientId: [22880]},
        {id: 1, name: "UK", clientId: [67067]},
        {id: 2, name: "NL", clientId: [200672]},
      ],
      inventoryData: [],
      quickFilters: [
        {id: "Triplog", state: true, color: 'secondary'},
        {id: "Equipment", state: true, color: 'secondary'},
        {id: "RFID", state: true, color: 'secondary'},
        {id: "Mini", state: true, color: 'secondary'},
        {id: "Other", state: true, color: 'secondary'}
      ],
      buttonGroupList: []
    }
  },
  async mounted() {
    await this.getStockData();
    this.currentTab = this.getDefaultStockTab;
    this.tabModel = this.tabs[this.currentTab].name
  },
  methods: {
    async getStockData() {
      this.loading = true;
      let inventory = await axios.get("api/bcs/Inventory/Items");
      this.inventoryData = inventory.data;
      this.loading = false;
    },
    toggleFilter(){
      for (let i = 0; i < this.quickFilters.length; i++) {
        const quickFilter = this.quickFilters[i];
        quickFilter.color = 'secondary';
      }
      this.buttonGroupList = [];
    },
    toggleQuickFilter(id){
      var currentFilterIndex = this.quickFilters.indexOf(this.quickFilters.find(filter => filter.id == id));
      this.quickFilters = [
          {id: "Triplog", state: false, color: 'secondary'},
          {id: "Equipment", state: false, color: 'secondary'},
          {id: "RFID", state: false, color: 'secondary'},
          {id: "Mini", state: false, color: 'secondary'},
          {id: "Other", state: false, color: 'secondary'}
        ];
      this.quickFilters[currentFilterIndex].state = true;
      this.quickFilters[currentFilterIndex].color = 'primary';
    },
    existsInFilter(subscriptions){
      for (let i = 0; i < subscriptions.length; i++) {
        const sub = subscriptions[i];
        if(this.getActiveFilters.includes(sub)) return true;
      }
      return false;
    }
  },
  watch: {
    defaultCountry: {
      deep: true,
      async handler() {
        this.currentTab = this.getDefaultStockTab;
        this.tabModel = this.tabs[this.currentTab].name
      }
    }
  },
  computed: {
    filteredData() {
      if(this.selectedTab <= 1) return this.currentData.filter(x => this.tabs[this.selectedTab].clientId.includes(x.clientId) && (this.existsInFilter(x.supportedSubscriptions) || !this.anyFilterChecked));
      return this.currentData.filter(x => !this.tabs[0].clientId.includes(x.clientId) && !this.tabs[1].clientId.includes(x.clientId) && (this.existsInFilter(x.supportedSubscriptions) || !this.anyFilterChecked))

    },
    currentData: {
      get: function() {
        return this.inventoryData
      },
      set: function(value) {
        this.inventoryData = value;
      }
    },
    currentTab: {
      get: function() {
        return this.selectedTab
      },
      set: function(value) {
        this.selectedTab = value;
      }
    },
    defaultCountry() {
      return this.$store.state.userSettings.defaultCountry === "ALL" ? "NO" : this.$store.state.userSettings.defaultCountry;
    },
    getDefaultStockTab() {
      switch(this.defaultCountry?.toLowerCase()){
        case "no":
        case "se":
        case "dk":
        case "fi":
        case "pl":
            return 0;
        case "gb":
          return 1;
        case "nl":
        case "be":
        case "fr":
          return 2;
        default:
          return 0;

      }
    },
    getActiveFilters() {
      return this.quickFilters.filter(filter => filter.state).map(filter => filter.id);
    },
    anyFilterChecked() {
      return this.quickFilters.filter(filter => filter.state).length > 0;
    },
  }
}
</script>

<style scoped>
.filter-icon:focus::after {
  opacity: 0;
}
</style>
