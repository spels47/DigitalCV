﻿<template>
  <v-card>
    <v-tabs fixed-tabs background-color="black" dark v-model="activeTab" @change="goToTab">
      <v-tab v-for="tab in getTabs()" :key="tab.id">{{ tab.text }}</v-tab>
        <v-menu right background-color="black" offset-y :close-on-content-click="true">
          <template v-slot:activator="{ on }">
            <v-btn
              icon
              class="ma-1"
              v-on="on"
            >
              <v-icon>mdi-dots-vertical</v-icon>
            </v-btn>
          </template>
          <v-list
            shaped
            style="width: 250px"
          >
            <v-subheader class="font-weight-medium">Choose default table</v-subheader>
            <v-divider></v-divider>
            <v-list-item-group color="primary">
              <v-list-item
                v-for="(item, i) in defaultItems"
                :key="i"
                @click="changeDefaultTable(item)"
                color="primary"
              >
                <v-list-item-icon>
                  <v-icon v-text="item.icon"></v-icon>
                </v-list-item-icon>
                <v-list-item-content>
                  <v-list-item-title v-text="item.text" :class="defaultTable === item.value ? 'secondary--text' : ''"></v-list-item-title>
                </v-list-item-content>
              </v-list-item>
            </v-list-item-group>
          </v-list>
        </v-menu>
    </v-tabs>
  </v-card>
</template>


<script>
import axios from "@/axios-client";

export default {
  name: "CustomerTabs",
  data() {
    return {
      defaultItems: [
        { text: "Overview", value:"overview", icon: "mdi-domain" },
        { text: "Account", value:"account", icon: "mdi-account" },
        { text: "Vehicle", value:"vehicle", icon: "mdi-car-hatchback" },
        { text: "Equipment", value:"eq", icon: "mdi-bulldozer" },
        { text: "Subscription", value:"subscription", icon: "mdi-clipboard-list" },
        { text: "Data Source", value:"datasource", icon: "mdi-cable-data" },
        { text: "Financial", value:"financial", icon: "mdi-finance" }
      ],
      tabs: [
        {id: 0, type: "overview", text: "Overview", data: ["overview"], userright: ""},
        {id: 1, type: "account", text: "Accounts", data: ["account"], userright: ""},
        {id: 2, type: "vehicle", text: "Vehicles", data: ["vehicle"], userright: ""},
        {id: 3, type: "equipment", text: "Equipment", data: ["equipment"], userright: ""},
        {id: 4, type: "subscription", text: "Subscriptions", data: ["subscription"], userright: ""},
        {id: 5, type: "datasources", text: "Data sources", data: ["mini", "simcard"], userright: ""},
        {id: 7, type: "financial", text: "Financial", data: ["financial"], userright: ""},
        {id: 8, type: "tickets", text: "Tickets", data: ["tickets"], userright: "DEVELOPER_ASAP"}
      ],
      activeTab: 0,
    };
  },
  created() {
    let tab = parseInt(this.$route.query?.activeTab ?? 0);
    this.goToTab(tab);
  },
  methods: {
    changeDefaultTable(item) {
      axios.post(`/api/UserSettings/setDefaultTable/${item.value}`);
      switch (item.value) {
        case 'account':
          this.$store.commit("userSettings_AddDefaultTable", 'Account')
          break;
        case 'vehicle':
          this.$store.commit("userSettings_AddDefaultTable", 'Vehicle')
          break;
        case 'equipment':
          this.$store.commit("userSettings_AddDefaultTable", 'Eq')
          break;
        case 'datasource':
          this.$store.commit("userSettings_AddDefaultTable", 'DataSource')
          break;
        case 'subscription':
          this.$store.commit("userSettings_AddDefaultTable", 'Subscription')
          break;
        case 'overview':
          this.$store.commit("userSettings_AddDefaultTable", 'Overview');
          break;
        default:
          this.$store.commit("userSettings_AddDefaultTable", 'Overview')
          break;
      }
    },
    getTabs() {
      let allowedTabs = [];
      this.tabs.forEach(x => {
        if (x.userright === "" || this.roles[x.userright]) {
          allowedTabs.push(x);
        }
      });
      return allowedTabs;
    },
    async goToTab(tab) {
      await this.$store.dispatch("setUrlParameter", {name: "activeTab", value: tab});
      this.activeTab = tab;
      this.$emit("tabChanged", tab);
    }
  },
  computed: {
    roles() {
      return this.$store.state.currentUserRoles;
    },
    defaultTable() {
      return this.$store.state.userSettings.defaultTable?.toLowerCase()
    },
    userSettings() {
      return this.$store.state.userSettings
    },
  }
};
</script>

<style scoped></style>
