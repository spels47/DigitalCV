﻿<template>
  <v-card class="mx-auto">
    <v-toolbar flat>
      <div class="d-flex flex-column">
        <v-toolbar-title>{{ title }}</v-toolbar-title>
        <span
          v-if="subTitle"
          class="subtitle-2"
        >
          {{ subTitle }}
        </span>
      </div>
    </v-toolbar>

    <v-divider></v-divider>

    <v-card-text class="pl-0 card-text">
      <v-fade-transition v-if="Object.keys(statisticsValue).length > 0">
        <div
          v-if="!loading"
          style="height: 100%"
          class="d-flex justify-left align-center"
        >
          <vue-apex-charts
            :options="options"
            :series="statisticsValue"
            width="480"
          >
          </vue-apex-charts>
        </div>
      </v-fade-transition>
      <template v-else>
        <div
          v-if="loading"
          style="height: 100%"
          class="d-flex justify-center align-center"
        >
          <v-fade-transition hide-on-leave>
            <v-progress-circular
              indeterminate
              size="40"
            ></v-progress-circular>
          </v-fade-transition>
        </div>

        <v-list v-else>
          <v-list-item>
            <v-list-item-icon>
              <v-icon>mdi-emoticon-sad-outline</v-icon>
            </v-list-item-icon>
            <v-list-item-title class="subtitle-1">No data to show</v-list-item-title>
          </v-list-item>
        </v-list>
      </template>
    </v-card-text>
  </v-card>
</template>

<script>
import VueApexCharts from "vue-apexcharts"

export default {
  name: "ApexDonutChart",
  components: { VueApexCharts },
  props: ["statistics", "loading", "subTitle", "height", "title", "monoChrome"],
  computed: {
    statisticsValue() {
      return this.statistics ? Object.values(this.statistics) : [];
    },
    getHeight() {
      return this.height ? this.height : 200;
    },
    getTitle() {
      return this.title ? this.title : "";
    },
    darkMode() {
      return this.$store.getters.darkMode;
    },
    isMonochrome() {
      return this.monoChrome ?? false;
    },
    labels() {
      return this.statistics ? Object.keys(this.statistics) : [""];
    },
    options() {
      return {
        chart: {
          foreColor: this.darkMode ? '#FFFFFF' : '#000000',
          type: 'donut',
          toolbar: {
            show: false
          }
        },
        colors: ["#25BACA", "#4CAA71", "#FF9A00", "#00b7bd", "#009688", "#4CAA71"],
        plotOptions: {
          pie: {
            donut: {
              labels: {
                show: true,
                total: {
                  show: true,
                  style: {
                    fontSize: "11px",
                    fontFamily: "Roboto",
                  },
                },
                name: {
                  show: true,
                  fontFamily: "Roboto",
                  formatter: function (val) {
                    if (val === "Total") return val;
                    return val.substring(0, val.indexOf("@"));
                  }
                },
                value: {
                  show: true,
                  fontFamily: "Roboto",
                }
              }
            }
          }
        },
        tooltip: {
          enabled: false
        },
        dataLabels: {
          enabled: true,
          style: {
            fontSize: "11px",
            fontFamily: "Roboto",
          },
          formatter: function (val) {
            return Math.round(val) + "%"
          },
        },
        theme: {
          monochrome: {
            enabled: this.isMonochrome
          }
        },
        labels: this.labels
      }
    }
  }
}
</script>

<style scoped>
.card-text {
  height: 270px;
}
</style>
