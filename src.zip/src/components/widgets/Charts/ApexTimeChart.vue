﻿<template>
  <v-card>
    <v-card-title>
      <span>{{ name }}</span>
      <v-spacer></v-spacer>
    </v-card-title>
    <v-card-subtitle v-if="subTitle">
      {{ subTitle }}
    </v-card-subtitle>
    <v-divider></v-divider>

    <v-card-text class="pa-0 card-text">
      <v-fade-transition v-if="shouldShowChart && !loading">
        <vue-apex-charts
          :options="options"
          :series="series"
          :height="setHeight"
        >
        </vue-apex-charts>
      </v-fade-transition>
      <template v-else>
        <div
          v-if="loading"
          style="height: 100%"
          class="d-flex justify-center align-center"
        >
          <v-fade-transition hide-on-leave>
            <v-progress-circular
              indeterminate
              size="40"
            ></v-progress-circular>
          </v-fade-transition>
        </div>

        <v-list v-else>
          <v-list-item>
            <v-list-item-icon>
              <v-icon>mdi-emoticon-sad-outline</v-icon>
            </v-list-item-icon>
            <v-list-item-title class="subtitle-1">No data to show</v-list-item-title>
          </v-list-item>
        </v-list>
      </template>
    </v-card-text>
  </v-card>
</template>

<script>
import VueApexCharts from "vue-apexcharts";
import moment from "moment";
import CardWithHeader from "@/components/cards/CardWithHeader.vue";

export default {
  components: { VueApexCharts },
  name: "ApexTimeChart",
  props: {
    // the set of statistics that will be displayed
    statistic: {
      type: [Object, Array],
      required: true,
    },
    useDateRangeFilter: {
      type: Boolean,
    },
    dateRange: {
      type: Array,
      default: () => []
    },
    // the title of the chart
    name: {
      type: String,
      required: true
    },
    // height of the chart, ex. 100px or 100%
    height: {
      type: [String, Number]
    },
    // width of the chart, ex. 100px or 100%
    width: {
      type: String
    },
    // optional subtitle of the chart
    subTitle: {
      type: String,
    },
    // optional custom y-axis title
    yAxisTitle: {
      type: String,
    },
    // specify if the y-axis is represented in %
    percent: {
      type: Boolean
    },
    // loading state for v-card
    loading: {
      type: Boolean
    },
    // specify custom label and formatter for x-axis
    // ex. { label: 'Week', format: 'w' }
    xAxis: {
      type: Object
    },
    formatAsCurrency: {
      type: Object,
    }
  },
  computed: {
    darkMode() {
      return this.$store.getters.darkMode;
    },
    getYAxisTitle() {
      return this.yAxisTitle ? this.yAxisTitle : "";
    },
    isPercent() {
      return this.percent ?? false;
    },
    showXAxis() {
      return this.xAxis?.format ?? false;
    },
    timeFrameFormat() {
      if (this.xAxis.label) {
        return `[${this.xAxis.label}] ${this.xAxis.format}`
      } else if (this.xAxis.format) {
        return this.xAxis.format;
      }
      return "MMMM YYYY";
    },
    series() {
      return [
        {
          name: this.name,
          data: this.statisticValues
        }
      ]
    },
    options() {
      return {
        stroke: {
          curve: "smooth",
        },
        colors: [this.darkMode ? "#00bcd4" : "#25BACA"],
        chart: {
          id: this.name,
          type: "line",
          foreColor: this.darkMode ? '#FFFFFF' : '#000000',
          zoom: {
            enabled: false
          },
          toolbar: {
            show: false
          },
          animations: {
            enabled: true,
            easing: 'easeinout',
            speed: 400,
            animateGradually: {
              enabled: true,
              delay: 400
            },
            dynamicAnimation: {
              enabled: true,
              speed: 250
            }
          }
        },
        yaxis: {
          title: {
            text: this.getYAxisTitle
          },
          tickAmount: 3,
          labels: {
            offsetX: -5,
            formatter: (value) => {
              if (this.formatAsCurrency?.value) {
                const price = parseInt(value);
                return this.$utils.getFormattedPriceForCountry(this.formatAsCurrency.country, price);
              }
              value = Math.round(value);
              return this.isPercent ? parseInt(value) + "%" : value;
            }
          }
        },
        xaxis: {
          categories: this.timeFrame,
          tickAmount: 4,
          axisBorder: {
            show: false
          },
          axisTicks: {
            show: false
          },
          tooltip: {
            enabled: false
          },
          tickPlacement: 'on',
          labels: {
            rotate: 0,
            show: this.showXAxis,
            formatter: (value) => {
              return this.showXAxis ? moment(value).format(this.timeFrameFormat) : value;
            },
            style: {
              fontSize: "10px",
              fontFamily: "Roboto",
            }
          },
        },
        tooltip: {
          theme: this.darkMode ? 'dark' : 'light'
        }
      }
    },
    timeFrame() {
      const timeFrame = Object.keys(this.statistic).map(key => new Date(key).toISOString_ntz().substring(0, 10));
      if (!this.useDateRangeFilter || this.dateRange.length === 1)
        return timeFrame;

      let timeFrameWithinDateRange = [];
      const dates = this.dateRange.map(date => moment(date));

      for (let i = 0; i < timeFrame.length; i++) {
        const asDate = moment(timeFrame[i]);
        const isBefore = asDate.isBefore(dates[0]);
        const isAfter = asDate.isAfter(dates[1]);
        if (!isBefore && !isAfter) {
          timeFrameWithinDateRange.push(timeFrame[i]);
        }
      }

      return timeFrameWithinDateRange;
    },
    statisticValues() {
      let result = {};

      const statisticsWithModifiedDate = Object.fromEntries(
        Object.entries(this.statistic).map(([key, val]) => [new Date(key).toISOString_ntz().substring(0, 10), val])
      );

      this.timeFrame.forEach(x => {
        result[x] = statisticsWithModifiedDate[x];
      })

      this.$emit("update:values", this.$utils.sumIntegerArray(Object.values(result)));

      return Object.values(result);
    },
    shouldShowChart() {
      return this.statistic === undefined ? false : Object.keys(this.statistic)?.length > 0;
    },
    cardHeight() {
      return this.height ?? 325;
    },
    setHeight() {
      return this.height ?? 210;
    }
  }
}
</script>

<style scoped>
.card-text {
  height: 270px;
}
</style>
