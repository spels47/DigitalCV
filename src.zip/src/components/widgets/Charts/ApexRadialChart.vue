﻿<template>

  <v-card class="mx-auto">
    <v-toolbar flat>
      <div class="d-flex flex-column">
        <v-toolbar-title>{{ title }}</v-toolbar-title>
        <span
          v-if="subTitle"
          class="subtitle-2"
        >
          {{ subTitle }}
        </span>
      </div>
    </v-toolbar>

    <v-divider></v-divider>

    <v-card-text class="pl-0 card-text">
      <v-fade-transition v-if="Object.keys(statisticsValue).length > 0 && !loading">
        <vue-apex-charts
          :options="options"
          :series="statisticsValue"
          :height="getHeight"
        >
        </vue-apex-charts>
      </v-fade-transition>
      <template v-else>
        <div
          v-if="loading"
          style="height: 100%"
          class="d-flex justify-center align-center"
        >
          <v-fade-transition hide-on-leave>
            <v-progress-circular
              indeterminate
              size="40"
            ></v-progress-circular>
          </v-fade-transition>
        </div>

        <v-list v-else>
          <v-list-item>
            <v-list-item-icon>
              <v-icon>mdi-emoticon-sad-outline</v-icon>
            </v-list-item-icon>
            <v-list-item-title class="subtitle-1">No data to show</v-list-item-title>
          </v-list-item>
        </v-list>
      </template>
    </v-card-text>
  </v-card>

  <!--
  <div>
    <v-card
      :loading="loading"
      height="275"
    >
      <v-card-title class="align-start">
        <span>{{ title }}</span>
      </v-card-title>
      <v-card-subtitle v-if="subTitle" class="font-weight-medium">{{ subTitle }}</v-card-subtitle>

      <v-card-text>
        <vue-apex-charts
          v-if="Object.keys(statisticsValue).length > 0"
          :options="options"
          :series="statisticsValue"
          :height="getHeight"
        >
        </vue-apex-charts>
        <v-list v-else>
          <v-list-item>
            <v-list-item-icon>
              <v-icon>mdi-chart-line-variant</v-icon>
            </v-list-item-icon>
            <v-list-item-title class="subtitle-1">No data to show</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-card-text>
    </v-card>
  </div>
  -->
</template>

<script>
import VueApexCharts from "vue-apexcharts"

export default {
  name: "ApexRadialChart",
  components: { VueApexCharts },
  props: ["statistics", "loading", "height", "title", "subTitle"],
  computed: {
    statisticsValue() {
      if (this.statistics[0] === null)
        return []

      return this.statistics ? this.statistics : [];
    },
    getHeight() {
      return this.height ? this.height : 210;
    },
    getWidth() {
      return this.width ? this.width : 200;
    },
    getTitle() {
      return this.title ? this.title : "";
    },
    darkMode() {
      return this.$store.getters.darkMode;
    },
    options() {
      return {
        chart: {
          type: 'radialBar',
          toolbar: {
            show: false
          }
        },
        plotOptions: {
          radialBar: {
            hollow: {
              margin: 0,
              size: '75%',
              background: '#fff',
              image: undefined,
              imageOffsetX: 0,
              imageOffsetY: 0,
              position: 'front',
              dropShadow: {
                enabled: true,
                top: 3,
                left: 0,
                blur: 4,
                opacity: 0.2
              }
            },
          },
        },
        labels: ["Average"]
      }
    }
  }
}
</script>

<style scoped>
.card-text {
  height: 225px;
}
</style>
