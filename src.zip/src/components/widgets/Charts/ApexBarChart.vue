﻿<template>
  <v-card class="fill-height">
    <v-card-title>
      {{ title }}
    </v-card-title>
    <v-card-subtitle v-if="subtitle">
      {{ subtitle }}
    </v-card-subtitle>
    <v-divider></v-divider>

    <v-card-text class="pa-0 card-text">
      <v-fade-transition v-if="hasData && !loading">
        <VueApexCharts
          v-if="hasData && !loading"
          :series="getValues"
          :options="chartOptions"
          height="249"
        ></VueApexCharts>
      </v-fade-transition>
      <template v-else>
        <div
          v-if="loading"
          style="height: 100%"
          class="d-flex justify-center align-center"
        >
          <v-fade-transition hide-on-leave>
            <v-progress-circular
              indeterminate
              size="40"
            ></v-progress-circular>
          </v-fade-transition>
        </div>

        <v-list v-else>
          <v-list-item>
            <v-list-item-icon>
              <v-icon>mdi-emoticon-sad-outline</v-icon>
            </v-list-item-icon>
            <v-list-item-title class="subtitle-1">No data to show</v-list-item-title>
          </v-list-item>
        </v-list>
      </template>
    </v-card-text>
  </v-card>
</template>

<script>
import VueApexCharts from "vue-apexcharts"
import moment from "moment/moment";

export default {
  name: "ApexBarChart",
  components: {
    VueApexCharts
  },
  props: {
    itemDescription: {
      type: String,
      required: true
    },
    title: {
      type: String,
      required: true
    },
    statistics: {
      type: [Object, Array],
      required: true
    },
    subtitle: {
      type: String,
    },
    loading: {
      type: Boolean,
    },
    useDateRangeFilter: {
      type: Boolean,
    },
    dateRange: {
      type: Array,
      default: () => []
    },
  },
  computed: {
    chartOptions() {
      return {
        chart: {
          type: 'bar',
          toolbar: {
            show: false
          }
        },
        plotOptions: {
          bar: {
            columnWidth: '25%',
            distributed: true,
          }
        },
        dataLabels: {
          enabled: false
        },
        legend: {
          show: false
        },
        colors: [this.isDarkMode ? "#00bcd4" : "#25BACA"],
        yaxis: {
          tickAmount: 5,
          labels: {
            formatter: (value) => {
              return value
            },
            style: {
              fontSize: "11px",
              fontFamily: "Roboto",
              colors: this.isDarkMode ? "white" : "black"
            },
          }
        },
        tooltip: {
          theme: this.isDarkMode ? "dark" : "light",
          x: {
            formatter: (value) => {
              return value[0];
            }
          },
          style: {
            fontFamily: "Roboto",
          }
        },
        xaxis: {
          categories: this.modifiedCategories,
          labels: {
            rotate: 0,
            style: {
              fontSize: "11px",
              fontFamily: "Roboto",
              colors: this.isDarkMode ? "white" : "black"
            },
          }
        }
      }
    },
    isDarkMode() {
      return this.$store.getters.darkMode;
    },
    hasData() {
      return this.statistics
    },
    categories() {
      let categories = [];
      if (!this.hasData)
        return categories;

      if (this.useDateRangeFilter) {
        const dates = this.dateRange.map(date => moment(date));

        for (const placeholder in this.statistics) {
          const actualItem = this.statistics[placeholder];
          if (!actualItem.Dates || actualItem.Dates.length === 0) continue;
          const timeFrame = actualItem.Dates.map(key => new Date(key).toISOString_ntz().substring(0, 10));
          for (let i = 0; i < timeFrame.length; i++) {
            const asDate = moment(timeFrame[i]);
            const isBefore = asDate.isBefore(dates[0]);
            const isAfter = asDate.isAfter(dates[1]);

            if (!isBefore && !isAfter) {
              if (categories.some(x => x.Username === actualItem.Username)) {
                const existingCategory = categories.find(x => x.Username === actualItem.Username);
                existingCategory.Total = existingCategory.Total += 1;
              } else {
                categories.push({
                  Username: actualItem.Username,
                  Total: 1
                })
              }
            }
          }
        }
      }
      else{
        for(let item in this.statistics){
          categories.push({Description: item, Total: this.statistics[item]})
        }
      }
      return categories;
    },
    modifiedCategories() {
      let fixedCategories = []
      for (let i = 0; i < this.categories.length; i++) {
        let item = this.categories[i];
        if(!item.Username){
          fixedCategories.push([item.Description, item.Total])
        }
        else if (item.Username.includes('@')) {
          let trimmedName = this.$utils.trimUsername(item.Username);
          fixedCategories.push([trimmedName, item.Total]);
        } else {
          fixedCategories.push([item.Username, item.Total]);
        }
      }
      fixedCategories.sort(function (a, b) {
        return b[1] - a[1];
      });
      return fixedCategories;
    },
    getValues() {
      if (!this.hasData) {
        return [{
          data: []
        }]
      }

      const values = this.categories.map(x => x.Total)?.sort((a, b) => b - a).slice(0, 5);
      return [
        {
          name: this.itemDescription,
          data: values
        }
      ];
    },
  }
}
</script>

<style scoped>
.card-text {
  height: 249px
}
</style>
