﻿<template>
  <div>
    <v-card height="360">
      <v-card-title class="align-start">
        <span>Customer satisfaction</span>
        <v-spacer></v-spacer>

        <div>
          <v-icon
            small
            color="error"
          >
            mdi-square-rounded-outline
          </v-icon>
          <span
            class="subtitle-2 ml-2 mr-4"
          >
            Danger of churning
          </span>

          <template v-if="hasSuperOfficeAppointments">
            <v-icon
              x-small
              color="success"
            >
              mdi-checkbox-blank-circle
            </v-icon>
            <span
              class="subtitle-2 ml-2"
            >
            SuperOffice appointments
          </span>
          </template>
        </div>
      </v-card-title>
      <v-card-subtitle>Get an insight into how satisfied this customer seems to be.</v-card-subtitle>
      <v-card-text class="pl-0">
        <vue-apex-charts
          v-if="churnValueSet"
          :options="chartOptions"
          :series="series"
          :height="265"
        >
        </vue-apex-charts>
        <v-list v-else>
          <v-list-item>
            <v-list-item-icon>
              <v-icon>mdi-emoticon-sad-outline</v-icon>
            </v-list-item-icon>
            <v-list-item-title class="subtitle-1">No data to show</v-list-item-title>
          </v-list-item>
        </v-list>
      </v-card-text>
    </v-card>
  </div>
</template>

<script>
import VueApexCharts from "vue-apexcharts";
import moment from "moment";

export default {
  props: {
    churnPrediction: {
      type: Object,
      required: true
    }
  },
  components: { VueApexCharts },
  name: "ChurnPredictionChart",
  data() {
    return {
      churnValueSet: null,
      superOfficeAppointments: null
    };
  },
  watch: {
    churnPrediction: {
      handler: function (value) {
        this.churnValueSet = value.churnPrediction;
        this.superOfficeAppointments = value.superOfficeAppointments;
      },
      deep: true,
      immediate: true
    }
  },
  computed: {
    chartOptions() {
      return {
        stroke: {
          curve: "smooth"
        },
        colors: ["#00bcd4"],
        chart: {
          type: "line",
          foreColor: this.darkMode ? '#FFFFFF' : '#000000',
          zoom: {
            enabled: false
          },
          toolbar: {
            show: false
          },
          animations: {
            enabled: true,
            easing: 'easeinout',
            speed: 400,
            animateGradually: {
              enabled: true,
              delay: 250
            },
            dynamicAnimation: {
              enabled: true,
              speed: 250
            }
          }
        },
        annotations: {
          yaxis: [
            {
              y: 0,
              y2: 20,
              borderColor: this.darkMode ? '#FF6666' : '#E5043A'
            }
          ],
          points: this.pointsOfInterest
        },
        yaxis: {
          min: 0,
          max: 100,
          tickAmount: 5,
          labels: {
            offsetX: -5,
            formatter: (value) => {
              return `${value}%`;
            }
          }
        },
        xaxis: {
          categories: this.timeFrame,
          axisBorder: {
            show: false
          },
          axisTicks: {
            show: false
          },
          tooltip: {
            enabled: false
          },
          tickPlacement: 'on',
          labels: {
            offsetX: 0,
            style: {
              fontSize: "10px",
              fontFamily: "Roboto"
            }
          }
        },
        tooltip: {
          theme: this.darkMode ? 'dark' : 'light'
        }
      };
    },
    pointsOfInterest() {
      if (!this.superOfficeAppointments)
        return {};

      let points = [];
      this.superOfficeAppointments.forEach(appointment => {
        points.push({
          x: moment(new Date(appointment.date)).format("YYYY-MM-DD"),
          marker: {
            offsetX: -5
          },
          label: {
            offsetY: 0,
            style: {
              color: "#fff",
              background: this.darkMode ? "#004e00" : "#4CAA71",
              fontFamily: "Roboto",
              fontSize: "12px"
            },
            text: `${appointment.type}`
          }
        });
      });

      return points.sort(point => point.x);
    },
    timeFrame() {
      if (!this.churnValueSet)
        return [];

      return Object.keys(this.churnValueSet).map(key => moment(new Date(key)).format("YYYY-MM-DD")).sort();
    },
    series() {
      //let data =
      return [
        {
          name: "Customer satisfaction",
          data: Object.entries(this.churnValueSet).sort((a, b) => (new Date(a[0])) - (new Date(b[0]))).map(y => y[1])
        }
      ];
    },
    darkMode() {
      return this.$store.getters.darkMode;
    },
    hasSuperOfficeAppointments() {
      return this.superOfficeAppointments.length > 0;
    }
  }
};
</script>

<style scoped>

</style>
