﻿<template>
      <VueApexCharts ref="chart" :options="options" :series="statisticsValue" :height="getHeight" :width="getWidth"></VueApexCharts>
</template>

<script>
import VueApexCharts from "vue-apexcharts"

export default {
  name: "ApexPieChart",
  components: { VueApexCharts },
  props: ["statistics", "loading", "height", "width", "title", "monoChrome"],
  data: () => ({

  }),
  computed: {
    statisticsValue() {
      return this.statistics ? Object.values(this.statistics) : [];
    },
    getHeight() {
      return this.height ? this.height : 300;
    },
    getWidth() {
      return this.width ? this.width : 300;
    },
    getTitle() {
      return this.title ? this.title : "";
    },
    darkMode() {
      return this.$store.getters.darkMode;
    },
    isMonochrome() {
      return this.monoChrome ?? false;
    },
    labels() {
      return this.statistics ? Object.keys(this.statistics) : [""];
    },
    options() {
      return {
        chart: {
          foreColor: this.darkMode ? '#FFFFFF' : '#000000',
          type: 'pie',
          toolbar: {
            show: false
          }
        },
        title: {
          offsetY: 5,
          text: this.getTitle,
            style: {
            fontFamily: 'Roboto',
              fontSize: '16px',
              color: this.darkMode ? '#FFFFFF' : '#000000',
          },
        },
        theme: {
          monochrome: {
            enabled: this.isMonochrome
          }
        },
        labels: this.labels
      }
    }
  }
}
</script>

<style scoped>

</style>
