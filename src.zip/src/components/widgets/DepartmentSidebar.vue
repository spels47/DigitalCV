<template>
  <div class="container">
    <v-card height="500px" :elevation="10">
      <v-row>
        <v-treeview
          v-if="expanded"
          :active="active"
          :items="mainOfficeHierarchyArray"
          @update:active="gotoCustomer"
          activatable
          class="department-path-selector-treeview"
          active-class="selected-node"
          dense
          expand-icon="mdi-chevron-down"
          :open="openItems"
          style="max-height:500px;"
          hoverable
        >
          <template v-slot:prepend="{ item, open }">
            <v-icon :color="item.isMainOffice ? 'secondary' : 'primary'">
              {{ item.isMainOffice ? "mdi-office-building" : "mdi-domain" }}
            </v-icon>
          </template>
          <template slot="label" slot-scope="{ item }">
            <a :ref="item.id">{{ item.name }}</a>
          </template>
        </v-treeview>
        <div class="placeholder" @click="expand">
          <v-icon class="align-vertical-center ml-1 mr-1" color="white">mdi-file-tree</v-icon>
        </div>
      </v-row>
    </v-card>
  </div>
</template>

<script>
  export default {
    name: "DepartmentSidebar",
    props: {
      department: Object,
      mainOfficeHierarchy: Object
    },
    data: function(){
      return {
        expanded: false
      }
    },
    computed: {
      active() {
        return this.department.id ? [this.department.id] : []
      },
      openItems() {
        if(!this.department.id || !this.department.cPath) return [];
        return this.department.cPath.split(".").slice(2)
      },
      mainOfficeHierarchyArray() {
        return [this.mainOfficeHierarchy]
      }
    },
    methods:{
      gotoCustomer(row) {
        if (row.length === 0)
          return;

        this.$router.push({ name: "customer", params: { id: row[0] } });
      },
      scrollToDepartment(){
        this.$nextTick(() => {
          if(!this.department.id || !this.$refs[this.department.id]) return
          this.$refs[this.department.id].scrollIntoView({block: 'center'})
        });
      },
      expand() {
        this.expanded = !this.expanded
        if(!this.expanded)
          return

        this.scrollToDepartment()
      }
    },
    watch: {
      department: function(){
        this.scrollToDepartment()
      }
    }
  }
</script>

<style scoped>
.container {
  position: fixed;
  left: 0;
  top: 108px;
  z-index: 1000;
  width: auto;
  height: 500px;
}

.department-path-selector-treeview {
  background-color: white;
  color: black;
  overflow: auto;
  width: 400px;
}
.department-path-selector-treeview.theme--dark {
  background-color: inherit;
}

.placeholder {
  height: 500px;
  background-color: black;
  cursor: pointer;
  position: relative;
  border-radius: 0 6px 6px 0;
  transition: ease-in-out, 0.1s;
}
.placeholder:hover {
  background-color: rgba(0, 0, 0, 0.9);
  transform: scaleX(1.05);
}
.align-vertical-center {
  position: relative;
  top: 242px;
}
</style>
<style>
/*Overriding vuetify styles requires global it seems*/
.department-path-selector-treeview .selected-node {
  background-color: black !important;
  color: white !important;
}
.department-path-selector-treeview .selected-node i {
  color: white;
}
.department-path-selector-treeview .selected-node a {
  color: white;
}
</style>
