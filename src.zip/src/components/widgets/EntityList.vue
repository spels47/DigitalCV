﻿<template>
  <v-card min-height="50" v-if="customerId">
    <CustomerTabs @tabChanged="tabChanged"></CustomerTabs>
    <v-tabs-items v-model="tabNumber">
      <v-tab-item>
        <CustomerOverview :customerId="customerId.toString()"></CustomerOverview>
      </v-tab-item>
      <v-tab-item>
        <AccountList :customerId="customerId" :customer="customer" @rowClicked="openSidebar" @assignedAssetClicked="assignedAssetClicked"></AccountList>
      </v-tab-item>
      <v-tab-item>
        <VehicleList :customerId="customerId" :customer="customer" @rowClicked="openSidebar" @currentDriverClicked="currentDriverClicked" @currentDataSourceClicked="currentDataSourceClicked"></VehicleList>
      </v-tab-item>
      <v-tab-item>
        <EquipmentList :customerId="customerId" :customer="customer" @rowClicked="openSidebar" @currentDataSourceClicked="currentDataSourceClicked"></EquipmentList>
      </v-tab-item>
      <v-tab-item>
        <SubscriptionList :customerId="customerId" :customer="customer" @rowClicked="openSidebar"></SubscriptionList>
      </v-tab-item>
      <v-tab-item>
        <DataSourceList :customerId="customerId" :customer="customer" @rowClicked="openSidebar" @connectedAssetClicked="connectedAssetClicked"></DataSourceList>
      </v-tab-item>
      <v-tab-item>
        <CustomerFinancial :customer="customer"></CustomerFinancial>
      </v-tab-item>
      <v-tab-item>
        <CustomerTickets
          :customer="customer"
          @rowClicked="openTicketSidebar"
        ></CustomerTickets>
      </v-tab-item>
    </v-tabs-items>
  </v-card>
</template>

<script>
import CustomerTabs from "@/components/widgets/CustomerTabs";
import CustomerOverview from "@/views/customer/details/CustomerOverview";
import AccountList from "@/components/entityLists/AccountList";
import VehicleList from "@/components/entityLists/VehicleList";
import EquipmentList from "@/components/entityLists/EquipmentList";
import SubscriptionList from "@/components/entityLists/SubscriptionList";
import DataSourceList from "@/components/entityLists/DataSourceList";
import CustomerFinancial from "@/views/customer/details/CustomerFinancial";
import CustomerTickets from "@/views/customer/details/CustomerTickets";

export default {
  name: "EntityList",
  components: {
    CustomerTickets,
    CustomerFinancial,
    CustomerTabs,
    AccountList,
    VehicleList,
    EquipmentList,
    SubscriptionList,
    DataSourceList,
    CustomerOverview
  },
  props: ["customerId", "customer"],
  data() {
    return {
      tabNumber: 0
    };
  },
  methods: {
    async openSidebar(row) {
      this.$emit("openSidebar", { type: row.type, id: row.id, data: row });
    },
    openTicketSidebar(ticket) {
      this.$emit("openSidebar", { type: "ticket", id: ticket.contactId, data: ticket });
    },
    assignedAssetClicked(item) {
      this.$emit("openSidebar", { type: "vehicle", id: item.assignedAsset.vehicleAssignedVehicleId });
    },
    currentDriverClicked(item) {
      this.$emit("openSidebar", { type: "account", id: item.currentDriverId.toString() });
    },
    connectedAssetClicked(item) {
      let type = item.features.includes("3000") ? "eq" : "vehicle"
      let id = item.features.includes("3000") ? item.simcardId : item.connectedAssetId
      if (!id) return
      this.$emit("openSidebar", { type: type, id: id });
    },
    currentDataSourceClicked(item) {
      if (item.unitTypeId === 'Oem') {
        this.$emit("openSidebar", { type: "oem", id: item.simcardId });
      } else {
        this.$emit("openSidebar", { type: "simcard", id: item.primaryDataSourceId });
      }
    },
    async tabChanged(tabNumber) {
      this.tabNumber = tabNumber;
    }
  }
};
</script>

<style scoped></style>
