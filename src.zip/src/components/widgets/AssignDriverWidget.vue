<template>
  <v-card>
    <v-container>
      <v-row>
        <v-col>
          <v-card-title>Select driver to assign vehicle to</v-card-title>
          <v-progress-linear indeterminate color="black" v-if="isLoading"></v-progress-linear>
          <HierarchyWithSearch
            v-if="customerHierarchy && customerHierarchy.length"
            @cancel="closeDialog()"
            @itemClicked="userClickedForAssigning = null"
            @subItemClicked="userClickedInDialog"
            :items="customerHierarchy"
            :subItems="customerUsers"
            :subItemType="'users'"
            :nonSelectableSubItems="[]"
          ></HierarchyWithSearch>
        </v-col>
      </v-row>
      <v-row>
        <v-col class="text-right">
          <v-spacer></v-spacer>
          <v-btn color="primary" text @click="closeDialog">Cancel</v-btn>
          <v-btn :disabled="userClickedForAssigning == null" color="secondary" @click="userSelected">
            <v-icon left>
              mdi-account-check
            </v-icon>
            Assign
          </v-btn>
        </v-col>
      </v-row>
    </v-container>
  </v-card>
</template>

<script>
import axios from "~/axios-client";
import HierarchyWithSearch from "../HierarchyWithSearch";
export default {
  props: ["customerId"],
  components: {
    HierarchyWithSearch
  },
  data() {
    return {
      userClickedForAssigning: null,
      customerUsers: null,
      customerHierarchy: [],
      isLoading: true
    };
  },
  async mounted() {
    await this.getCustomerHierarchyAndUsers();
  },
  methods: {
    async getCustomerHierarchyAndUsers() {
      this.customerHierarchy = [];
      await axios.get(`/api/customer/CustomerTreeWithUsers/${this.customerId}`).then(res => {
        this.customerUsers = res.data.users;
        this.customerHierarchy.push(res.data.departmentHiarchy);
        this.isLoading = false;
      });
    },
    userClickedInDialog(user) {
      this.userClickedForAssigning = user;
      if (user.vehicleAssignedVehicleId !== 0)
        this.$eventBus.$emit("alert", { text: "Be careful, this driver is already assigned to a vehicle.", type: "warning"});
    },
    closeDialog() {
      this.$emit("closeMergeDialog");
    },
    userSelected() {
      if (this.userClickedForAssigning.id) {
        this.$emit("userSelected", this.userClickedForAssigning);
        this.$emit("closeMergeDialog");
      }
    }
  }
};
</script>

<style></style>
