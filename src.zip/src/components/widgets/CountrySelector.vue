﻿<template>
  <v-menu
    :close-on-content-click="true"
    right
    offset-y
    background-color="black">
    <template v-slot:activator="{ on }">
      <v-btn
        icon
        class="mt-1 mr-1"
        v-on="on">
        <v-icon size="25" :color="defaultCountry === 'ALL' ? 'white' : 'secondary'">mdi-flag-variant</v-icon>
      </v-btn>
    </template>

    <v-list
      shaped
      style="width: 250px">
      <v-subheader class="font-weight-medium">Choose country</v-subheader>
      <v-divider></v-divider>
      <v-list-item-group color="primary">
        <v-list-item
          v-for="(item, i) in countrySelector"
          :key="i"
          :data-cy="i.data-cy"
          @click="changeDefaultCountry(item)"
          color="primary">
          <v-list-item-content>
            <v-list-item-title v-text="item.text" :class="defaultCountry === item.value ? 'secondary--text' : ''"></v-list-item-title>
          </v-list-item-content>
        </v-list-item>
      </v-list-item-group>
    </v-list>
  </v-menu>
</template>

<script>
export default {
  name: "CountrySelector",
  data() {
    return {
      countrySelector: [
        { text: "All", value: "ALL" },
        { text: "Norway", value: "NO" },
        { text: "Sweden", value: "SE" },
        { text: "Finland", value: "FI" },
        { text: "Denmark", value: "DK" },
        { text: "UK", value: "GB" },
        { text: "France", value: "FR" },
        { text: "Belgium", value: "BE" },
        { text: "Netherlands", value: "NL" },
        { text: "Poland", value: "PL" }
      ],
    }
  },
  methods: {
    changeDefaultCountry(item) {
      this.$store.dispatch("setDefaultCountry", item.value);
    },
  },
  computed: {
    defaultCountry() {
      return this.$store.state.userSettings.defaultCountry;
    },
  }
}
</script>

<style scoped>

</style>
