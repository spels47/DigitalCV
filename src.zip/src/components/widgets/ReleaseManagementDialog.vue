<template>
  <v-card
    class="pa-2"
    :loading="loading"
  >
    <v-dialog
      width="500px"
      persistent
      v-model="completeReleaseMessageDialog"
    >
      <v-card class="overflow-hidden">
        <v-card-title>Complete Release</v-card-title>
        <v-card-subtitle>Write an optional message to let others know how the release went.</v-card-subtitle>
        <v-divider></v-divider>

        <v-card-text>
          <v-textarea v-model="completeReleaseMessage"></v-textarea>
        </v-card-text>

        <v-card-actions>
          <v-row>
            <v-col>
              <v-btn block color="primary" dark class="mb-2" @click="completeReleaseMessageDialog = false">Close</v-btn>

            </v-col>
            <v-col>
              <v-btn block color="secondary" dark class="mb-2" @click="completeRelease">Send</v-btn>
            </v-col>
          </v-row>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-dialog
      width="500px"
      persistent
      v-model="abortReleaseMessageDialog"
    >
      <v-card class="overflow-hidden">
        <v-card-title>Abort Release</v-card-title>
        <v-card-subtitle>Write an optional message to let others why this release got aborted.</v-card-subtitle>
        <v-divider></v-divider>

        <v-card-text>
          <v-textarea v-model="abortReleaseMessage"></v-textarea>
        </v-card-text>

        <v-card-actions>
          <v-row>
            <v-col>
              <v-btn color="primary" dark class="mb-2" block @click="abortReleaseMessageDialog = false">Close</v-btn>
            </v-col>
            <v-col>
              <v-btn color="secondary" dark class="mb-2" block @click="abortRelease">Send</v-btn>
            </v-col>
          </v-row>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-card-title>
      <span v-if="release"><v-icon class="mr-2">mdi-calendar-edit</v-icon>Edit release</span>
      <span v-else><v-icon class="mr-2">mdi-calendar</v-icon>Schedule a new release</span>
      <v-spacer></v-spacer>
      <TooltipIconButton
        v-if="release && new Date(ReleaseStart) > new Date(new Date().setMinutes(new Date().getMinutes() + 15)) && release.manager === this.$store.getters.currentUsername"
        @clicked="deleteRelease"
        tooltip="Delete release"
        icon="mdi-delete"
        color="error"
      ></TooltipIconButton>
      <TooltipIconButton
        v-if="release && release.state !== 'Completed' && new Date(ReleaseStart) < new Date(new Date().setMinutes(new Date().getMinutes() + 15)) && release.manager === this.$store.getters.currentUsername"
        @clicked="completeReleaseMessageDialog = true"
        tooltip="Complete"
        icon="mdi-check-circle"
        color="success"
      ></TooltipIconButton>
      <TooltipIconButton
        v-if="release && release.state !== 'Aborted' && new Date(ReleaseStart) < new Date(new Date().setMinutes(new Date().getMinutes() + 15)) && release.manager === this.$store.getters.currentUsername"
        @clicked="abortReleaseMessageDialog = true"
        tooltip="Abort"
        icon="mdi-exit-run"
        color="warning"
      ></TooltipIconButton>
    </v-card-title>

    <v-card-subtitle class="pt-2">
      <span v-if="!release">Please fill out some more details about the release.</span>
      <span v-else>Make changes to the release details.</span>
    </v-card-subtitle>

    <v-divider></v-divider>

    <v-container fluid>
      <v-select v-model="ReleaseName" prepend-icon="mdi-shape" :items="availableReleaseTypes" chips label="Release type"></v-select>
      <v-row>
        <v-col>
          <v-datetime-picker
            :textFieldProps="textFieldProps"
            :datePickerProps="{ min: new Date().toISOString(), max: new Date(ReleaseFinish).toISOString() }"
            :timePickerProps="{ format: '24hr', min: new Date().toTimeString(), max: new Date(ReleaseFinish).toTimeString() }"
            label="From"
            v-model="ReleaseStart"
          >
            <template v-slot:dateIcon>
              <v-icon>mdi-calendar</v-icon>
            </template>
            <template v-slot:timeIcon>
              <v-icon>mdi-clock</v-icon>
            </template>
          </v-datetime-picker>
        </v-col>
        <v-col>
          <v-datetime-picker
            :textFieldProps="textFieldProps"
            :datePickerProps="{ min: new Date(ReleaseStart).toISOString() }"
            :timePickerProps="{ format: '24hr', min: new Date(ReleaseStart).toTimeString() }"
            label="To"
            v-model="ReleaseFinish"
          >
            <template v-slot:dateIcon>
              <v-icon>mdi-calendar</v-icon>
            </template>
            <template v-slot:timeIcon>
              <v-icon>mdi-clock</v-icon>
            </template>
          </v-datetime-picker>
        </v-col>
      </v-row>

      <v-combobox
        v-model="JiraIssues"
        prepend-icon="mdi-jira"
        label="Add issue URL's"
        @change="JiraSearch = ''"
        :search-input.sync="JiraSearch"
        multiple
      >
        <template v-slot:no-data>
          <v-list-item>
            <v-list-item-content>
              <v-list-item-title>
                Press
                <kbd color="primary">enter</kbd> to add " <strong>{{ JiraSearch }}</strong
              >".
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </template>
        <template v-slot:selection="{ index, item }">
          <v-chip close @click="openLink(item)" @click:close="deleteChip(item)">
            {{ item }}
          </v-chip>
        </template>
      </v-combobox>

      <v-combobox
        v-model="gitlabMergeRequests"
        prepend-icon="mdi-gitlab"
        label="Add related MR's"
        @change="mergeRequestSearch = ''"
        :search-input.sync="mergeRequestSearch"
        multiple
      >
        <template v-slot:no-data>
          <v-list-item>
            <v-list-item-content>
              <v-list-item-title>
                Press
                <kbd color="primary">enter</kbd> to add " <strong>{{ mergeRequestSearch }}</strong
              >".
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </template>
        <template v-slot:selection="{ index, item }">
          <v-chip close @click="openLink(item)" @click:close="deleteMrChip(item)">
            {{ item }}
          </v-chip>
        </template>
      </v-combobox>

      <v-combobox
        v-model="gitlabProjectsAffected"
        :items="gitlabProjects"
        prepend-icon="mdi-alert"
        label="Affected Gitlab project(s)"
        @change="availableProductsSearch = ''"
        :search-input.sync="availableProductsSearch"
        multiple
        chips
        deletable-chips
      >
        <template v-slot:no-data>
          <v-list-item>
            <v-list-item-content>
              <v-list-item-title>
                Press
                <kbd color="primary">enter</kbd> to add " <strong>{{ DEVSearch }}</strong
              >".
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </template>

        <template v-slot:selection="{ index, item }">
          <v-chip
            close
            @click="gotoGitlabProject(item)"
            @click:close="removeProject(item)"
          >
            {{ item }}
          </v-chip>
        </template>
      </v-combobox>

      <v-combobox
        :items="Developers"
        :prepend-icon="isCowboyRelease ? 'mdi-account-cowboy-hat' : 'mdi-account-multiple'"
        :search-input.sync="DEVSearch"
        v-model="Developers"
        label="Assigned developers"
        multiple
        chips deletable-chips
        @change="DEVSearch = ''"
      >
        <template v-slot:no-data>
          <v-list-item>
            <v-list-item-content>
              <v-list-item-title>
                Press
                <kbd color="primary">enter</kbd> to add " <strong>{{ DEVSearch }}</strong
              >".
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </template>
      </v-combobox>

      <v-combobox v-model="QA" :items="availableQATesters" prepend-icon="mdi-account-heart" label="QA - Tester" @change="QASearch = ''" :search-input.sync="QASearch" multiple chips deletable-chips>
        <template v-slot:no-data>
          <v-list-item>
            <v-list-item-content>
              <v-list-item-title>
                Press
                <kbd color="primary">enter</kbd> to add " <strong>{{ QASearch }}</strong
              >".
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </template>
      </v-combobox>

      <v-textarea prepend-icon="mdi-comment" label="Release details" v-model="ReleaseDescription"/>

      <v-combobox
        v-model="EmailRecipients"
        :items="availableEmailRecipients"
        prepend-icon="mdi-email"
        label="Additional email recipients"
        @change="EmailRecipientSearch = ''"
        :search-input.sync="EmailRecipientSearch"
        multiple
        chips
        deletable-chips
      >
        <template v-slot:no-data>
          <v-list-item>
            <v-list-item-content>
              <v-list-item-title>
                Press
                <kbd color="primary">enter</kbd> to add " <strong>{{ EmailRecipientSearch }}</strong
              >".
              </v-list-item-title>
            </v-list-item-content>
          </v-list-item>
        </template>
      </v-combobox>
    </v-container>
    <v-card-actions>
      <v-row>
        <v-col>
          <v-btn color="primary" dark class="mb-2" block v-on:click="closeModal">Close</v-btn>
        </v-col>
        <v-col>
          <v-btn color="secondary" dark class="mb-2" block v-on:click="scheduleRelease" v-if="!release">Submit</v-btn>
          <v-btn color="secondary" dark class="mb-2" block v-on:click="saveRelease" v-if="release">Save</v-btn>
        </v-col>
      </v-row>
    </v-card-actions>
  </v-card>
</template>

<script>
import axios from "~/axios-client";
import moment from "moment";
import TooltipIconButton from "@/components/buttons/TooltipIconButton";

export default {
  components: { TooltipIconButton },
  props: ["from", "to", "release"],
  data() {
    return {
      fromTimePickerVisible: false,
      toTimePickerVisible: false,
      valid: false,
      availableProducts: ["Triplog", "EQ", "Mini", "Backstage"],
      QASearch: null,
      DEVSearch: null,
      JiraSearch: null,
      mergeRequestSearch: null,
      gitlabMergeRequests: [],
      EmailRecipientSearch: "ams@abax.no",
      PRMDocumentSearch: null,
      availableProductsSearch: null,
      availableReleaseTypes: ["Bugfix Release", "Feature Release", "Maintenance Release", "Bulk Release", "Hotfix Release"],
      availableQATesters: ["Piotr Zlendak", "John O Keefe", "David Gould", "Jonas Skaalen", "Anne Magnhild Sundet", "Mathias Stolpestad", "Anna Slupska"],
      availableEmailRecipients: ["ams@abax.no"],
      newJiraIssue: "",
      ReleaseName: "Bugfix Release",
      ReleaseStart: null,
      ReleaseFinish: null,
      JiraIssues: [],
      QA: [],
      Developers: [],
      EmailRecipients: ["ams@abax.no"],
      gitlabProjectsAffected: [],
      ReleaseDescription: "",
      PRMDocument: [],
      releaseHistory: [],
      textFieldProps: {
        prependIcon: "mdi-calendar"
      },
      completeReleaseMessageDialog: false,
      abortReleaseMessageDialog: false,
      abortReleaseMessage: "",
      completeReleaseMessage: "",
      loading: false
    };
  },
  mounted() {
    this.availableQATesters = this.availableQATesters.sort((a, b) => a.localeCompare(b));
    this.Developers.push(this.name);

    if (this.release && this.release.id) {
      this.ReleaseStart = this.release.start;
      this.ReleaseFinish = this.release.end;
      this.ReleaseName = this.release.releaseName;
      this.JiraIssues = this.release.jiraIssues;
      this.gitlabMergeRequests = this.release.mergeRequests;
      this.QA = this.release.qa;
      this.Developers = this.release.dev;
      this.EmailRecipients = this.release.emailRecipients;
      this.gitlabProjectsAffected = this.release.gitlabProjectsAffected;
      this.ReleaseDescription = this.release.description;
      this.PRMDocument = this.release.prmDocument;
      this.Manager = this.release.manager;
    } else {
      this.ReleaseStart = new Date(this.from);
      this.ReleaseFinish = new Date(this.to);
      this.gitlabProjectsAffected = ["triplog/triplog"];
    }
  },
  computed: {
    name() {
      return this.$store.getters.currentUser?.name;
    },
    gitlabProjects() {
      return [{ header: "Can't find what you're looking for? Projects are listed with path and namespace." }, ...this.$store.state.ReleaseManagementModule.gitlabProjects];
    },
    roles() {
      return this.$store.state.currentUserRoles;
    },
    isCowboyRelease() {
      // if developer and qa is the same person and no one else is on the release
      if (this.Developers?.length !== 1 || this.QA?.length !== 1) return false;
      return this.QA[0] === this.Developers[0];
    }
  },
  methods: {
    removeProject(item) {
      const index = this.gitlabProjectsAffected.indexOf(item);
      if (index >= 0)
        this.gitlabProjectsAffected.splice(index, 1);
    },
    gotoGitlabProject(item) {
      window.open(`https://gitlab.planetabax.com/${item}`);
    },
    openLink(item) {
      window.open(item);
    },
    deleteChip(item) {
      const index = this.JiraIssues.indexOf(item);
      if (index >= 0) this.JiraIssues.splice(index, 1);
    },
    deleteMrChip(item) {
      const index = this.gitlabMergeRequests.indexOf(item);
      if (index >= 0)
        this.gitlabMergeRequests.splice(index, 1);
    },
    closeModal() {
      this.clearForm();
      this.$emit("cancel");
    },
    async scheduleRelease() {
      let formattedRelease = {
        ReleaseName: this.ReleaseName,
        ReleaseStart: moment(this.ReleaseStart),
        ReleaseFinish: moment(this.ReleaseFinish),
        JiraIssues: this.JiraIssues,
        MergeRequests: this.gitlabMergeRequests,
        QA: this.QA,
        Dev: this.Developers,
        gitlabProjectsAffected: this.gitlabProjectsAffected,
        Manager: this.$store.getters.currentUsername,
        EmailRecipients: this.EmailRecipients,
        ReleaseDescription: this.ReleaseDescription,
        PRMDocument: this.PRMDocument
      };

      await this.$store.dispatch("createRelease", formattedRelease);
      this.$emit("releaseCreated");
    },
    async saveRelease() {
      let formattedRelease = {
        ReleaseName: this.ReleaseName,
        ReleaseStart: moment(this.ReleaseStart),
        ReleaseFinish: moment(this.ReleaseFinish),
        JiraIssues: this.JiraIssues,
        MergeRequests: this.gitlabMergeRequests,
        QA: this.QA,
        Dev: this.Developers,
        gitlabProjectsAffected: this.gitlabProjectsAffected,
        Manager: this.release.manager,
        EmailRecipients: this.EmailRecipients,
        ReleaseDescription: this.ReleaseDescription,
        PRMDocument: this.PRMDocument,
        id: this.release.id,
        State: this.release.state
      };

      this.loading = true;
      await this.$store.dispatch("updateRelease", formattedRelease);
      this.$emit("clearReleases");
      this.$emit("releaseUpdated");
      this.loading = false;
    },
    async abortRelease() {
      this.loading = true;
      await axios.post("/api/ReleaseManagement/Aborted/" + this.release.id, { Message: this.abortReleaseMessage });
      this.abortReleaseMessageDialog = false;
      await this.$store.dispatch("clearReleases");
      await this.$store.dispatch("getReleases");
      this.$emit("releaseUpdated");
      this.loading = false;
    },
    async completeRelease() {
      this.loading = true;
      await axios.post("/api/ReleaseManagement/Completed/" + this.release.id, { Message: this.completeReleaseMessage });
      this.completeReleaseMessageDialog = false;
      await this.$store.dispatch("clearReleases");
      await this.$store.dispatch("getReleases");
      this.$emit("releaseUpdated");
      this.loading = false;
    },
    async deleteRelease() {
      this.loading = true;
      await this.$store.dispatch("deleteRelease", this.release.id);
      await this.$store.dispatch("getReleases");
      this.$emit("releaseDeleted");
      this.loading = false;
    },
    clearForm() {
      this.ReleaseName = "Bugfix Release";
      this.ReleaseStart = null;
      this.ReleaseFinish = null;
      this.JiraIssues = [];
      this.QA = [];
      this.Developers = [];
      this.gitlabProjectsAffected = ["triplog"];
      this.ReleaseDescription = "";
      this.EmailRecipients = [];
      this.PRMDocument = [];
    }
  }
};
</script>

<style></style>
