﻿<template>
  <v-card>
    <div class="card-header">
      <v-card-title class="white--text pt-3">All activities</v-card-title>
    </div>
    <v-data-table
      :items="activities"
      :headers="headers"
      :loading="loading"
      sort-by="date"
      :sort-desc="true"
      :footer-props="{ 'items-per-page-options': [4, 8, 12] }"
      loading-text="Fetching SuperOffice activities"
    >
      <template v-slot:item.date="{ item }">
        <span>{{ item.date | ntzDate }}</span>
      </template>
      <template v-slot:item.type="{ item }">
        <b>{{ item.type === "" ? "AutoMail" : item.type }}</b>
      </template>
      <template v-slot:item.completed="{ item }">
        <v-icon color="success" v-if="item.completed">mdi-check-circle-outline</v-icon>
        <v-icon color="primary" v-else>mdi-checkbox-blank-circle-outline</v-icon>
      </template>
    </v-data-table>
  </v-card>
</template>

<script>
export default {
  name: "AllActivities",
  props: {
    activities: Array,
    loading: Boolean
  },
  data: function() {
    return {
      headers: [
        { text: "Date", value: "date" },
        { text: "Type", value: "type" },
        { text: "Completed", value: "completed", align: "center" },
      ],
    }
  },
}
</script>

<style scoped>
.card-header {
  background-color: black;
  height: 55px;
}
</style>
