﻿<template>
  <v-card>
    <div class="card-header">
      <v-card-title class="white--text pt-3">Datasources without contact</v-card-title>
    </div>
    <v-progress-linear indeterminate :active="loading" />
    <v-data-table
      :headers="headers"
      :items="dataSources"
      :loading="loading"
      :items-per-page="7"
      sort-by="serialNumber"
      :sort-desc="true"
      :footer-props="{ 'items-per-page-options': (items_per_page = [7, 14, 21]) }"
    >
      <template v-slot:item.connectedAssetId="{ item }">
        <span>{{ item.connectedAssetAlias !== "" ? item.connectedAssetAlias : item.connectedAssetId }}</span>
      </template>

    </v-data-table>
  </v-card>
</template>

<script>
import axios from "@/axios-client";

export default {
  name: "DataSourcesWithoutLastContact",
  props: {
    customer: Object,
  },
  data: function() {
    return {
      headers: [
        { text: "Serial number", value: "serialNumber" },
        { text: "Type", value: "unitTypeId" },
        { text: "Connected asset", value: "connectedAssetId" },
      ],
      loading: false,
      dataSources: []
    }
  },
  watch: {
    customer: {
      deep: true,
      async handler() {
        await this.getDataSources();
      }
    }
  },
  methods: {
    async getDataSources() {
      try {
        this.loading = true;
        const { data } = await axios.get(`api/customer/details?customerId=${this.customer.id}&type=simcard`);
        this.dataSources = data.data.filter(source => !source.serialNumber.includes("FAKE") && source.lastContact === "--");
      } finally {
        this.loading = false;
      }
    },
  }
}
</script>

<style scoped>
.card-header {
  background-color: black;
  height: 55px;
}
</style>
