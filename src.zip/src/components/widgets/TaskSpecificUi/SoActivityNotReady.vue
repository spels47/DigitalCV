﻿<template>
  <v-card height="640">
    <div class="card-header">
      <v-card-title class="white--text pt-3">SuperOffice activity</v-card-title>
    </div>
    <v-card-text class="d-flex justify-center align-center fill-height">
      <v-progress-circular
        indeterminate
        size="70"
      ></v-progress-circular>
    </v-card-text>
  </v-card>
</template>

<script>

export default {
  name: "SoActivityNotReady",
  props: ["aktorId", "workItem"],
  data: function() {
    return {
    }
  },

  methods: {
  }
}
</script>

<style scoped>
.fill-height {
  height: 100%
}

.card-header {
  background-color: black;
  height: 55px;
}
</style>
