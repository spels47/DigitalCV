﻿<template>
  <v-card>
    <div class="card-header">
      <v-card-title class="white--text pt-3">Prices (ex. VAT)</v-card-title>
    </div>
    <v-progress-linear indeterminate :active="loading" />
    <v-data-table
      :headers="headers"
      :items="pricesList"
      :loading="loading"
      :items-per-page="7"
      sort-by="pricePerMonth"
      :sort-desc="true"
      :footer-props="{ 'items-per-page-options': (items_per_page = [7, 14, 21]) }"
    >
      <template v-slot:item.quantity="{ item }">
        <v-chip outlined>{{ item.quantity }}</v-chip>
      </template>
      <template v-slot:item.pricePerMonth="{ item }">
        <span>{{ formatPrice(item.pricePerMonth) }}</span>
      </template>
    </v-data-table>
  </v-card>
</template>

<script>
import axios from "@/axios-client";
import util from "@/helpers/util";

export default {
  name: "Prices",
  props: {
    customer: Object,
  },
  data: function() {
    return {
      headers: [
        { text: "Product", value: "description" },
        { text: "Amount", value: "quantity" },
        { text: "Price", value: "pricePerMonth" },
      ],
      loading: false,
      pricesList: []
    }
  },
  watch: {
    customer: {
      deep: true,
      async handler() {
        await this.getCustomerInformation();
      }
    }
  },
  methods: {
    formatPrice(price) {
      return this.$utils.getFormattedPriceForCountry(this.customer.country, price);
    },
    async getCustomerInformation() {
      try {
        this.loading = true;
        const { data } = await axios.get(`/api/bcs/CustomerInformation?customerId=${this.customer.erpCustomerId}&clientId=${this.customer.erpClientId}`);

        let customerInformation = data.sort((a, b) => a.endDate === b.endDate ? 0 : a.endDate < b.endDate ? -1 : 1);
        this.pricesList = customerInformation.length === 0 ? [] : customerInformation[0].subscriptions;
      } finally {
        this.loading = false;
      }
    }
  },
}
</script>

<style scoped>
.card-header {
  background-color: black;
  height: 55px;
}
</style>
