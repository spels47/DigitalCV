﻿<template>
  <v-card>
    <div class="card-header">
      <v-card-title class="white--text pt-3">Task information</v-card-title>
    </div>
    <v-list>
      <v-list-item>
        <v-text-field prepend-icon="mdi-shape" readonly label="Category" :value="`${ workListType } - ${ customer.name }`" />
      </v-list-item>
      <v-list-item>
        <v-text-field prepend-icon="mdi-calendar" readonly label="Created" :value="dateAdded | ntzDatetime" />
      </v-list-item>
      <v-list-item>
         <v-text-field prepend-icon="mdi-account-heart" readonly label="Assignee" v-model="assignedUser" />
      </v-list-item>
    </v-list>
  </v-card>
</template>

<script>
export default {
  name: "TaskInformation",
  props: {
    customer: Object,
    workItem: Object
  },
  computed: {
    workListType() {
      return this.workItem?.worklistType ?? "";
    },
    dateAdded() {
      return this.workItem?.dateAdded ?? "";
    },
    assignedUser() {
      return this.workItem?.assignedUser ?? "";
    }
  }
}
</script>

<style scoped>
.card-header {
  background-color: black;
  height: 55px;
}
</style>
