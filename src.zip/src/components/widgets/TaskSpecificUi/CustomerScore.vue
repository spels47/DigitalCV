﻿<template>
  <v-card>
    <div class="card-header">
      <v-card-title class="white--text pt-3">Overview</v-card-title>
    </div>
    <v-progress-linear indeterminate :active="loading" />
    <v-container fluid>
      <v-row>
        <v-col>
          <ScoreCard
            :title="deviceInstallStatusCard.header"
            :description="deviceInstallStatusCard.desc"
            :list-items="deviceInstallStatusCard.details"
            :totalScore="deviceInstallStatusCard.result"
          />
        </v-col>
        <v-col>
          <ScoreCard
            :title="greenCustomerCard.header"
            :description="greenCustomerCard.desc"
            :list-items="greenCustomerCard.details"
            :totalScore="greenCustomerCard.result"
            :iconInsteadOfTotal="'mdi-account-tie'"
          />
        </v-col>
        <v-col>
          <ScoreCard
            :title="devicesCard.header"
            :description="devicesCard.desc"
            :list-items="devicesCard.details"
            :totalScore="devicesCard.result"
            :showValuesAsPercentage="false"
          />
        </v-col>
      </v-row>
    </v-container>
  </v-card>
</template>

<script>
import axios from "@/axios-client";
import ScoreCard from "@/components/ScoreCard";

export default {
  name: "CustomerOverview",
  components: { ScoreCard },
  props: {
    customer: Object
  },
  data: function() {
    return {
      loading: false,
      customerStatistics: {},
    }
  },
  watch: {
    customer: {
      deep: true,
      async handler() {
        await this.getCustomerStatistics();
      }
    }
  },
  methods: {
    async getCustomerStatistics() {
      try {
        this.loading = true;
        const { data } = await axios.get("/api/customerStatistics/backstage?customerId=" + this.customer.id);
        this.customerStatistics = data;
      } catch{
        this.$eventBus.$emit("alert", {template: "api-error"});
      } finally {
        this.loading = false;
      }
    },
  },
  computed: {
    deviceInstallStatusCard() {
      if(this.customerStatistics.data === undefined){
        return {
          header: "",
          desc: "",
          details: null,
          result: 0
        }
      }
        return this.customerStatistics.data.cards.find(card => card.header === "Installed");

    },
    greenCustomerCard() {
      if(this.customerStatistics.data === undefined){
        return {
          header: "",
          desc: "",
          details: null,
          result: 0
        }
      }
      return this.customerStatistics.data?.cards.find(card => card.header === "Green");
    },
    devicesCard() {
      if(this.customerStatistics.data === undefined){
        return {
          header: "",
          desc: "",
          details: null,
          result: 0
        }
      }
      return this.customerStatistics.data?.cards.find(card => card.header === "Devices");
    },
  }
}
</script>

<style scoped>
.card-header {
  background-color: black;
  height: 55px;
}
</style>
