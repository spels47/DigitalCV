﻿<template>
  <v-card>
    <v-tabs background-color="black" dark>
      <v-tab @click="tab = 0">Datasources without contact</v-tab>
      <v-tab @click="tab = 1">Prices</v-tab>
    </v-tabs>
    <v-tabs-items v-model="tab">
      <v-tab-item :eager="true">
        <v-data-table
          :headers="dataSourceHeaders"
          :items="dataSources"
          :loading="loading"
          :items-per-page="7"
          sort-by="serialNumber"
          :sort-desc="true"
          :footer-props="{ 'items-per-page-options': (items_per_page = [7, 14, 21]) }"
        >
          <template v-slot:item.connectedAssetId="{ item }">
            <span>{{ item.connectedAssetAlias !== "" ? item.connectedAssetAlias : item.connectedAssetId }}</span>
          </template>

        </v-data-table>
      </v-tab-item>
      <v-tab-item>
        <v-data-table
          :headers="pricesHeaders"
          :items="pricesFiltered"
          :loading="loading"
          :items-per-page="7"
          :sort-desc="true"
          :footer-props="{ 'items-per-page-options': (items_per_page = [7, 14, 21]) }"
        >
          <template v-slot:item.quantity="{ item }">
            <v-chip outlined>{{ item.quantity }}</v-chip>
          </template>

          <template v-slot:item.pricePerMonth="{ item }">
            <span>{{ formatPrice(item.pricePerMonth) }},-</span>
          </template>
        </v-data-table>
      </v-tab-item>
    </v-tabs-items>
  </v-card>
</template>

<script>
import axios from "@/axios-client";

export default {
  name: "DataSourcesWithoutContactAndPrices",
  props: {
    customer: Object,
    workItem: Object
  },
  data: function () {
    return {
      tab: 0,
      dataSourceHeaders: [
        { text: "Serial number", value: "serialNumber" },
        { text: "Type", value: "unitTypeId" },
        { text: "Connected asset", value: "connectedAssetId" },
      ],
      pricesHeaders: [
        { text: "Product", value: "description" },
        { text: "Amount", value: "quantity" },
        { text: "Price", value: "pricePerMonth" }
      ],
      loading: false,
      prices: [],
      dataSources: [],
      now: new Date()
    };
  },
  watch: {
    customer: {
      deep: true,
      async handler() {
        this.loading = true;
        await Promise.all([this.getPrices(), this.getDataSources()]).then(() => this.loading = false);
      }
    }
  },
  methods: {
    formatPrice(price) {
      return this.$utils.getFormattedPriceForCountry(this.customer.country, Math.round(price));
    },
    async getDataSources() {
      const { data } = await axios.get(`api/customer/details?customerId=${this.customer.id}&type=simcard`);
      this.dataSources = data.data.filter(source => !source.serialNumber.includes("FAKE") && source.lastContact === "--");
    },
    async getPrices() {
      const { data } = await axios.get(`/api/bcs/CustomerInformation?customerId=${this.customer.erpCustomerId}&clientId=${this.customer.erpClientId}`);
      let temp = data;

      let allSubs = [];
      temp.forEach(x => {
        x.subscriptions.forEach(z => {
          if (z.pricePerMonth > 0 && !z.status.toLowerCase().includes("terminated")) {
            let findIndex = allSubs.findIndex(t => t.itemNumber === z.itemNumber && t.pricePerMonth === z.pricePerMonth);
            if (findIndex === -1) {
              allSubs.push(Object.assign({}, z));
            } else {
              allSubs[findIndex].quantity += z.quantity;
            }
          }
        });
      });
      let deliveryIndex = allSubs.findIndex(x => x.itemNumber === "F150" || x.description.toLowerCase().includes("frakt"));
      if (deliveryIndex !== -1) {
        let deliveryCopy = Object.assign({}, allSubs[deliveryIndex]);
        allSubs.splice(deliveryIndex, 1);
        allSubs.push(deliveryCopy);
      }
      this.prices = allSubs;
    }
  },
  computed: {
    pricesFiltered() {
      return this.prices.filter(price => price.quantity !== 0);
    }
  }
};
</script>

<style scoped>
</style>
