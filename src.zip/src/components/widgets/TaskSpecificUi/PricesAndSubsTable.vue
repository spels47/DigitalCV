﻿<template>
  <v-card>
    <v-tabs background-color="black" dark>
      <v-tab @click="tab = 0">Prices</v-tab>
      <v-tab @click="tab = 1">Subscriptions</v-tab>

      <v-spacer></v-spacer>

      <v-menu
        v-if="tab === 1"
        transition="slide-y-transition"
        min-width="200"
        offset-y
      >
        <template v-slot:activator="{ on, attrs }">
          <v-btn
            class="ma-1"
            v-on="on"
            v-bind="attrs"
            icon
          >
            <v-icon
              :color="isFilterApplied ? 'secondary' : ''"
            >
              mdi-filter
            </v-icon>
          </v-btn>
        </template>

        <v-list width="200">
          <v-subheader class="font-weight-bold subtitle-1">Filters</v-subheader>
          <v-divider></v-divider>

          <v-list-item>
            <v-list-item-content>
              <v-checkbox
                label="Show MINI's"
                class="ml-2"
                v-model="filter_minis"
              ></v-checkbox>
            </v-list-item-content>
          </v-list-item>
        </v-list>
      </v-menu>
    </v-tabs>
    <v-tabs-items v-model="tab">
      <v-tab-item :eager="true">
        <v-data-table
          :headers="pricesHeaders"
          :items="pricesFiltered"
          :loading="loading"
          :items-per-page="7"
          :sort-desc="true"
          :footer-props="{ 'items-per-page-options': (items_per_page = [7, 14, 21]) }"
          loading-text="Fetching prices for this customer..."
          no-data-text="No prices available for this customer."
        >
          <template v-slot:item.quantity="{ item }">
            <v-chip outlined>{{ item.quantity }}</v-chip>
          </template>

          <template v-slot:item.pricePerMonth="{ item }">
            <span>{{ formatPrice(item.pricePerMonth) }},-</span>
          </template>
        </v-data-table>
      </v-tab-item>
      <v-tab-item>
        <v-data-table
          :headers="subscriptionsHeaders"
          :items="filteredSubscriptions"
          :loading="loading"
          :items-per-page="7"
          :footer-props="{ 'items-per-page-options': (items_per_page = [7, 14, 21]) }"
          :item-class="getCustomItemClass"
          no-data-text="This customer does not have any subscriptions."
        >
        </v-data-table>
      </v-tab-item>
    </v-tabs-items>
  </v-card>
</template>

<script>
import axios from "@/axios-client";

export default {
  name: "PricesAndSubsTable",
  props: {
    customer: Object,
    workItem: Object
  },
  data: function () {
    return {
      tab: 0,
      pricesHeaders: [
        { text: "Product", value: "description" },
        { text: "Amount", value: "quantity" },
        { text: "Price", value: "pricePerMonth" }
      ],
      subscriptionsHeaders: [
        { text: "Subscription number", value: "contractNumber" },
        { text: "Main item", value: "serialNumber" },
        { text: "Renewal date", value: "renewalDate" },
        { text: "Termination date", value: "terminationDate" }
      ],
      loading: false,
      filter_minis: false,
      prices: [],
      subscriptions: [],
      now: new Date()
    };
  },
  watch: {
    customer: {
      deep: true,
      async handler() {
        this.loading = true;
        await Promise.all([this.getPrices(), this.getSubscriptions()]).then(() => this.loading = false);
      }
    }
  },
  methods: {
    getCustomItemClass(item) {
      if (item.terminationDate !== "") {
        const terminationDate = new Date(item.terminationDate);
        if (terminationDate > this.now) {
          return this.darkMode ? "yellow darken-3" : "yellow lighten-4";
        }
      }

      if (item.hasExpired || item.id.startsWith("DLG")) return "tablered";
    },
    formatPrice(price) {
      return this.$utils.getFormattedPriceForCountry(this.customer.country, Math.round(price));
    },
    async getSubscriptions() {
      const { data } = await axios.get(`/api/customer/details?customerId=${this.customer.id}&type=subscription`);
      if (this.workItem.workListType === "yellowFlaggedCall") {
        this.subscriptions = data.data.filter(x => x.terminationDate > new Date());
      } else {
        this.subscriptions = data.data;
      }
    },
    async getPrices() {
      const { data } = await axios.get(`/api/bcs/CustomerInformation?customerId=${this.customer.erpCustomerId}&clientId=${this.customer.erpClientId}`);
      let temp = data;

      let allSubs = [];
      temp.forEach(x => {
        x.subscriptions.forEach(z => {
          if (z.pricePerMonth > 0 && !z.status.toLowerCase().includes("terminated")) {
            let findIndex = allSubs.findIndex(t => t.itemNumber === z.itemNumber && t.pricePerMonth === z.pricePerMonth);
            if (findIndex === -1) {
              allSubs.push(Object.assign({}, z));
            } else {
              allSubs[findIndex].quantity += z.quantity;
            }
          }
        });
      });
      let deliveryIndex = allSubs.findIndex(x => x.itemNumber === "F150" || x.description.toLowerCase().includes("frakt"));
      if (deliveryIndex !== -1) {
        let deliveryCopy = Object.assign({}, allSubs[deliveryIndex]);
        allSubs.splice(deliveryIndex, 1);
        allSubs.push(deliveryCopy);
      }
      this.prices = allSubs;
    }
  },
  computed: {
    filteredSubscriptions() {
      if (this.filter_minis)
        return this.subscriptions;

      return this.subscriptions
        .filter(x => x.serialNumber?.startsWith("MUM") === false)
        .filter(x => x.serialNumber?.startsWith("AM") === false);
    },
    isFilterApplied() {
      return this.filter_minis;
    },
    darkMode() {
      return this.$store.getters.darkMode;
    },
    pricesFiltered() {
      return this.prices.filter(price => price.quantity !== 0);
    }
  }
};
</script>

<style scoped>
</style>
