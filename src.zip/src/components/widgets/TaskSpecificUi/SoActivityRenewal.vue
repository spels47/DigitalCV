﻿<template>
  <v-card>
    <div class="card-header">
      <v-card-title class="white--text pt-3">SuperOffice activity</v-card-title>
    </div>
    <v-progress-linear indeterminate :active="loading" />
    <v-list>
      <v-list-item>
        <v-text-field prepend-icon="mdi-shape" readonly label="Activity type" :value="soActivity.type" />
      </v-list-item>
      <v-list-item>
        <v-text-field prepend-icon="mdi-calendar" readonly label="Created" :value="soActivity.date | ntzDatetime" />
      </v-list-item>
      <v-list-item>
        <v-radio-group :disabled="soActivity.completed" v-model="contractRenewed" row prepend-icon="mdi-autorenew">
          <v-radio
            label="Not renewed"
            value="notRenewed"
          ></v-radio>
          <v-radio
            label="Renewed"
            value="renewed"
          ></v-radio>
          <br/>
        </v-radio-group>
      </v-list-item>
      <v-list-item>
        <v-select
          v-model="soOwner"
          :items="usersWithRenewalCallAccess"
          item-text="username"
          item-value="username"
          return-object
          :readonly="!editing"
          label="SO Owner"
          prepend-icon="mdi-account-tie"
        />
      </v-list-item>
      <v-list-item>
        <v-textarea height="215" full-width prepend-icon="mdi-form-textbox" :readonly="!editing" label="Text" v-model="soActivity.text" />
      </v-list-item>
    </v-list>
    <v-card-actions>
      <v-bottom-navigation grow class="elevation-0">
        <v-btn @click="determineEdit()">
          <span class="mt-2">{{ editing ? "Cancel edit" : "Edit" }}</span>
          <v-icon :color="!editing ? 'secondary' : 'red'">{{ !editing ? "mdi-pencil" : "mdi-pencil-off" }}</v-icon>
        </v-btn>

        <div>
          <v-btn
            v-if="!editing"
            :disabled="contractRenewed === null && !soActivity.completed"
            @click="saveChanges"
          >
            <span class="mt-2">{{ soActivity.completed ? "Uncomplete renewal call" : "Complete renewal call" }}</span>
            <v-icon :color="soActivity.completed ? 'error' : 'success'">{{ soActivity.completed ? "mdi-undo" : "mdi-check-circle" }}</v-icon>
          </v-btn>

          <v-btn v-else @click="saveChanges()">
            <span class="mt-2">Save</span>
            <v-icon color="success">mdi-content-save-edit</v-icon>
          </v-btn>
        </div>
      </v-bottom-navigation>
    </v-card-actions>
  </v-card>
</template>

<script>
import axios from "@/axios-client";

export default {
  name: "SoActivityRenewal",
  props: ["customer", "workItem", "soActivity", "soOwner"],
  data: function() {
    return {
      loading: false,
      editing: false,
      contractRenewed: null,
      usersWithRenewalCallAccess: [],
    }
  },
  async mounted() {
    await this.fetchUsersWithRenewalCallAccess();
  },
  methods: {
    determineEdit() {
      this.editing = !this.editing;
      if (!this.editing) {
        this.$emit("refresh");
        this.$emit("fetchActivities");
      }
    },
    async saveChanges() {
      this.loading = true;

      try {
        if (this.editing) {
          const saveDescriptionCall = axios.post("/api/so/activity/description", { appointmentId: this.soActivity.appointmentId, description: this.soActivity.text });
          const saveSoOwner = axios.put(`/api/so/activity/setOwner/${this.soActivity.appointmentId}/${this.soOwner.superOfficePersonInfo.associateId}`);

          await Promise.all([ saveDescriptionCall, saveSoOwner ]);
        }
        else {
          if (this.soActivity.completed) {
            await axios.post("api/workList/cancel", {
              taskId: this.workItem._id,
              adUsername: this.username
            });
          } else {
            await axios.post("api/workList/completeItem", {
              taskId: this.workItem._id,
              adUsername: this.username,
              message: this.soActivity.text,
              toggle: this.contractRenewed === "renewed"
            });
          }
        }
        this.editing = false;
        this.$emit("refresh");
        this.$emit("fetchActivities");
        this.loading = false;
      } catch {
        this.loading = false;
        this.$eventBus.$emit("alert", { text: "Error when updating SO activity", type: "error" });
      }
    },
    async fetchUsersWithRenewalCallAccess() {
      const { data } = await axios.get("/api/RoleManagement/role/renewalCall")
      this.usersWithRenewalCallAccess = data.sort((a, b) => a.username.localeCompare(b.username));
    }
  },
  computed: {
    username() {
      return this.$store.getters.currentUser?.username;
    },
  }
}
</script>

<style scoped>
.theme--light.v-btn.v-btn--disabled:not(.v-btn--flat):not(.v-btn--text):not(.v-btn--outlined) {
  background-color: #FFFFFF !important;
}

.card-header {
  background-color: black;
  height: 55px;
}
</style>
