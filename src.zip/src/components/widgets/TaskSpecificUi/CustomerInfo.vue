﻿<template>
  <v-card>
    <div class="card-header">
      <v-card-title class="white--text pt-3">Customer details</v-card-title>
    </div>
    <v-list>
      <v-list-item>
        <v-text-field prepend-icon="mdi-office-building" readonly label="Name" v-model="customer.name" />
      </v-list-item>
      <v-list-item>
        <v-text-field prepend-icon="mdi-flag-variant" readonly label="Country" v-model="customer.country" />
      </v-list-item>
      <v-list-item>
        <v-text-field prepend-icon="mdi-map-marker" readonly label="Address" :value="constructFullAddress()" />
      </v-list-item>
      <v-list-item>
        <v-text-field prepend-icon="mdi-phone" readonly label="Telephone" v-model="customer.telephone" />
      </v-list-item>
      <v-list-item>
        <v-text-field prepend-icon="mdi-counter" readonly label="Organization number" v-model="customer.organizationNumber" />
      </v-list-item>
      <v-list-item>
        <v-text-field prepend-icon="mdi-email" readonly label="Email" v-model="customer.email" />
      </v-list-item>
    </v-list>
    <v-card-actions>
      <v-bottom-navigation grow class="elevation-0">
        <v-btn @click="gotoWorkhub()">
          <span class="mt-1">Go to workhub</span>
          <v-icon>mdi-puzzle</v-icon>
        </v-btn>
<!--        <v-btn>-->
<!--          <span class="mt-1">Go to SuperOffice</span>-->
<!--          <v-icon>mdi-open-in-new</v-icon>-->
<!--        </v-btn>-->
        <v-btn @click="gotoCustomer()">
          <span class="mt-1">Go to customer</span>
          <v-icon>mdi-office-building</v-icon>
        </v-btn>
      </v-bottom-navigation>
    </v-card-actions>
  </v-card>
</template>

<script>
export default {
  name: "CustomerInfo",
  props: {
    customer: Object,
    workItem: Object
  },
  methods: {
    constructFullAddress() {
      return `${this.customer.address}, ${this.customer.zip}, ${this.customer.city}`;
    },
    gotoWorkhub() {
      let tabIndex = 0;
      switch (this.workItem.worklistType.toLowerCase()) {
        case "welcomecall":
          tabIndex = 0;
          break;
        case "renewalcall":
          tabIndex = 1;
          break;
        case "yellowflaggedcall":
          tabIndex = 2;
          break;
        case "churnpreventioncall":
          tabIndex = 5
          break;
      }
      this.$router.push({ path: "/workhub?tab=" + tabIndex});
    },
    gotoCustomer() {
      this.$router.push({
        name: "customer",
        params: { id: this.customer.id },
        query: { activeTab: this.$utils.getDefaultTab(this.defaultTable) }});
    },
  },
  computed: {
    defaultTable() {
      return this.$store.state.userSettings.defaultTable;
    }
  }
}
</script>

<style scoped>
.card-header {
  background-color: black;
  height: 55px;
}
</style>
