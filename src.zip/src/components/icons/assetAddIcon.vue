<template>
  <svg class="assetAddIcon" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
    <path d="M11.1111 0V8.88889H20V0H11.1111ZM0 20H8.88889V11.1111H0V20ZM0 0V8.88889H8.88889V0H0ZM11.1111 14.4444H14.4444V11.1111H16.6667V14.4444H20V16.6667H16.6667V20H14.4444V16.6667H11.1111V14.4444Z" />
  </svg>
</template>

<script>
export default {
  name: "assetAddIcon"
};
</script>

<style lang="scss" scoped>
.assetAddIcon {
  fill: currentColor;
  height: 20px;
}
</style>
