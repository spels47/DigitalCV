<template>
  <svg viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
    <path d="M0 8.88889H8.88889V0H0V8.88889ZM0 20H8.88889V11.1111H0V20ZM11.1111 0V8.88889H20V0" />
    <path d="M11 12.8051L12.8051 11L15.5 13.7076L18.1949 11L20 12.8051L17.2924 15.5L20 18.1949L18.1949 20L15.5 17.2924L12.8051 20L11 18.1949L13.7076 15.5L11 12.8051Z" />
  </svg>
</template>

<script>
export default {
  name: "assetRemoveIcon"
};
</script>

<style lang="scss" scoped>
.assetAddIcon {
  fill: currentColor;
  height: 20px;
}
</style>
