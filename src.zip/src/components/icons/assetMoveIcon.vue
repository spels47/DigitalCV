<template>
  <svg class="customIcon" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
    <path d="M0 8.88889H8.88889V0H0V8.88889ZM0 20H8.88889V11.1111H0V20ZM11.1111 0V8.88889H20V0" />
    <path d="M16.1429 17V20L20 15.5L16.1429 11V14H11V17H16.1429Z" />
  </svg>
</template>

<script>
export default {
  name: "assetMoveIcon"
};
</script>

<style lang="scss" scoped>
.customIcon {
  fill: currentColor;
  height: 20px;
}
</style>
