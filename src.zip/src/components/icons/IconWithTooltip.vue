﻿<template>
  <v-tooltip bottom>
    <template #activator="{ on, attrs }">
      <v-icon
        :color="color"
        dark
        v-bind="attrs"
        v-on="on"
      >
        {{ icon }}
      </v-icon>
    </template>
    <span>{{ tooltip }}</span>
  </v-tooltip>
</template>

<script>
export default {
  name: "IconWithTooltip",
  props: {
    icon: {
      type: String,
      required: true
    },
    tooltip: {
      type: String,
      required: true
    },
    color: {
      type: String,
      default: "primary"
    }
  }
}
</script>

<style scoped>

</style>
