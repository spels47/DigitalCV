﻿<template>
  <v-card>
    <div class="card-header">
      <v-card-title class="white--text pt-3">{{ title }}</v-card-title>
    </div>
    <v-progress-linear
      indeterminate
      :active="loading"
    ></v-progress-linear>
    <v-card-text :class="{ 'pa-0': removePadding }">
      <slot name="content"></slot>
    </v-card-text>
  </v-card>
</template>

<script>
export default {
  name: "CardWithHeader",
  props: {
    title: {
      type: String,
      required: true
    },
    loading: {
      type: Boolean,
    },
    removePadding: {
      type: Boolean,
      default: false
    }
  }
}
</script>

<style scoped>
.card-header {
  background-color: black;
  height: 55px;
}
</style>
