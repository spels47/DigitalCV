﻿<template>
  <v-card
    :width="width"
    :loading="loading"
    rounded="lg"
  >
    <v-card-title>{{ title }}</v-card-title>
    <v-card-subtitle v-if="subtitle">
      {{ subtitle }}
    </v-card-subtitle>
    <v-divider></v-divider>

    <v-card-text>
      <slot name="content"></slot>
    </v-card-text>

    <v-card-actions>
      <slot name="actions"></slot>
    </v-card-actions>
  </v-card>
</template>

<script>
export default {
  name: "BackstageCard",
  props: {
    title: {
      type: String,
      required: true
    },
    subtitle: {
      type: String
    },
    width: {
      type: String,
      required: true
    },
    loading: {
      type: Boolean
    }
  }
}
</script>

<style scoped>

</style>
