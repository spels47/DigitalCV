﻿<template>
  <div @click="clicked()">
    <span
      v-if="computedText.length < maxLength"
      :class="{ 'secondary--text': applyClickableStyling && clickable, 'primary--text': !applyClickableStyling, 'clickable': clickable }"
    >
      {{ text }}
    </span>

    <v-tooltip
      v-else
      bottom
    >
      <template #activator="{ on }">
        <span
          class="text-no-wrap text-truncate"
          :class="{ 'secondary--text': applyClickableStyling && clickable, 'primary--text': !applyClickableStyling, 'clickable': clickable }"
          v-on="on"
        >
          {{ computedText.substring(0, maxLength) }}...
        </span>
      </template>
      <span>{{ computedText }}</span>
    </v-tooltip>
  </div>

</template>

<script>
export default {
  name: "WrappedTextWithTooltip",
  props: {
    text: {
      type: String,
      required: true
    },
    clickable: {
      type: Boolean,
      default: false
    },
    applyClickableStyling: {
      type: Boolean,
      default: true
    },
    maxLength: {
      type: Number,
      default: 30
    }
  },
  methods: {
    clicked() {
      if (this.clickable)
        this.$emit("clicked");
    }
  },
  computed: {
    computedText() {
      return this.text ?? "";
    }
  }
}
</script>

<style scoped>
.clickable {
  cursor: pointer;
}
</style>
