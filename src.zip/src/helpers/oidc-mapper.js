export const getOidcUser = (getters) => getters["oidcStore/oidcUser"];
export const getOidcUsername = (profile) => profile['http://schemas.abax.no/identity/claims/adusername']
export const getOidcDepartmentName = (profile) => profile['http://schemas.abax.no/identity/claims/addepartmentname'] || '';
export const getOidcDivisionName = (profile) => profile['http://schemas.abax.no/identity/claims/addivisionname'] || '';
export const getOidcImpersonationContext = (profile) => profile["http://schemas.abax.no/identity/claims/impersonatorcontext"];

export function mapOidcProfile (profile) {
  const mappedProfile = {
    id: profile.sub,
    name: profile.name,
    locale: profile.locale,
    email: profile.email,
    emailVerified: profile.email_verified,
    username: getOidcUsername(profile),
    departmentName: getOidcDepartmentName(profile),
    divisionName: getOidcDivisionName(profile),
    impersonationContext: getOidcImpersonationContext(profile)
  }
  return mappedProfile;
}

export default {
  mapOidcProfile,
}
