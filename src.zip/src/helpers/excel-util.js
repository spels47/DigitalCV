﻿import xlsx from "xlsx";

export function exportToExcelFile(fileName, sheetName, data) {
  const fitToColumn = data => {
    const columnWidths = [];
    for (const property in data[0]) {
      columnWidths.push({
        wch: Math.max(property ? property.toString().length + 7 : 0, ...data.map(obj => obj[property] ? obj[property].toString().length + 7 : 0))
      });
    }
    return columnWidths;
  };

  return new Promise((resolve, reject) => {
    try {
      const workSheet = xlsx.utils.json_to_sheet(data);
      workSheet["!cols"] = fitToColumn(data);

      const workBook = xlsx.utils.book_new();
      xlsx.utils.book_append_sheet(workBook, workSheet, sheetName);
      xlsx.writeFile(workBook, fileName, { bookType: "xlsx", type: "file" });
      resolve();
    } catch  {
      reject();
    }
  });
}
