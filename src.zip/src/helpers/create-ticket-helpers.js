﻿const subCategories = [
  {
    topLevelCategoryId: 1, items:
      [
        { categoryId: 840, text: "Misc. sales (batteries, cables, etc)" },
        { categoryId: 841, text: "New sales lead" },
        { categoryId: 839, text: "Sale to existing KA customer" },
        { categoryId: 842, text: "Sale to existing SME customer" },
        { categoryId: 844, text: "Upgrade to KA customer that requires hardware swap" },
        { categoryId: 843, text: "Upgrade to SME customer that requires hardware swap" }
      ]
  },
  {
    topLevelCategoryId: 2, items:
      [
        { categoryId: 899, text: "Delivery not as expected" },
        { categoryId: 900, text: "Is Missing delivery" },
        { categoryId: 959, text: "Missing feature or add-on" }
      ]
  },
  {
    topLevelCategoryId: 3, items:
      [
        { categoryId: 902, text: "Claims invoice, reminders or debt collection is wrong" },
        { categoryId: 906, text: "Customer has ended leasing on vehicle with unit" },
        { categoryId: 903, text: "Leasing claims invoice is wrong" },
        { categoryId: 904, text: "Needs help to understand invoice" },
        { categoryId: 905, text: "Needs invoice copy" },
        { categoryId: 907, text: "Wants aligned invoice" },
        { categoryId: 908, text: "Wants statement" },
        { categoryId: 909, text: "Wants to defer payment" }
      ]
  },
  {
    topLevelCategoryId: 4, items:
      [
        { categoryId: 911, text: "Claims contract is wrong" },
        { categoryId: 960, text: "Missing item in contract" },
        { categoryId: 912, text: "Needs information regarding contract details or copy of contract" }
      ]
  },
  {
    topLevelCategoryId: 5, items:
      [
        { categoryId: 914, text: "Needs to change company legal inf (orgnr, company structure etc," },
        { categoryId: 915, text: "Wants to change addresses or contact details" },
        { categoryId: 916, text: "Wants to change EHF or Direct billing" }
      ]
  },
  {
    topLevelCategoryId: 6, items:
      [
        { categoryId: 918, text: "Customer has purchased vehicle with unit" },
        { categoryId: 919, text: "Customer has sold vehicle with unit" },
        { categoryId: 920, text: "Customer needs to move unit between departments or companies" }
      ]
  },
  {
    topLevelCategoryId: 7, items:
      [
        { categoryId: 922, text: "Key Account Wishes to reduce subscription" },
        { categoryId: 923, text: "Key Account Wishes to terminate contract" },
        { categoryId: 924, text: "SME Wishes to reduce subscription" },
        { categoryId: 925, text: "SME Wishes to terminate contract" }
      ]
  },
  {
    topLevelCategoryId: 8, items:
      [
        { categoryId: 932, text: "API" },
        { categoryId: 928, text: "Automile" },
        { categoryId: 923, text: "Dealer Portal" },
        { categoryId: 927, text: "Driving behaviour" },
        { categoryId: 935, text: "FMS Systems" },
        { categoryId: 930, text: "Helpten Systems" },
        { categoryId: 931, text: "Interface" },
        { categoryId: 955, text: "Mobile app" },
        { categoryId: 933, text: "RAM Systems" },
        { categoryId: 934, text: "RCID" },
        { categoryId: 936, text: "TRA" }
      ]
  },
  {
    topLevelCategoryId: 9, items:
      [
        { categoryId: 938, text: "A4" },
        { categoryId: 939, text: "A5" },
        { categoryId: 941, text: "A6" },
        { categoryId: 956, text: "FMS Hardware" },
        { categoryId: 942, text: "FMT 100" },
        { categoryId: 943, text: "Helpten Hardware" },
        { categoryId: 945, text: "M-track" },
        { categoryId: 944, text: "Mini" },
        { categoryId: 947, text: "MUG" },
        { categoryId: 948, text: "RAM Hardware" },
        { categoryId: 949, text: "RFID" },
        { categoryId: 957, text: "TRA" }
      ]
  },
  {
    topLevelCategoryId: 10, items:
      [
        { categoryId: 852, text: "Need help with hardware installation" },
        { categoryId: 853, text: "Need help with login" },
        { categoryId: 850, text: "Need help with privacy settings" },
        { categoryId: 854, text: "Need information on how to use API" },
        { categoryId: 855, text: "Need startup training - customer requests onboarding" },
        { categoryId: 856, text: "Need system guidance" }
      ]
  },
  {
    topLevelCategoryId: 11, items:
      [
        { categoryId: 961, text: "Company Car to Commercial Vehicle" },
        { categoryId: 964, text: "Create Mobil id" },
        { categoryId: 962, text: "Moving unit within business group" },
        { categoryId: 851, text: "Need help backdating information" },
        { categoryId: 965, text: "Other" },
        { categoryId: 963, text: "Over 1600 lines" }
      ]
  },
  {
    topLevelCategoryId: 12, items:
      [
        { categoryId: 846, text: "Customer has GDPR issues or questions" },
        { categoryId: 847, text: "Need help with tax rules and compliance" }
      ]
  },
  {
    topLevelCategoryId: 13, items:
      [
        { categoryId: 858, text: "Abax server down" },
        { categoryId: 859, text: "New release issue" },
        { categoryId: 860, text: "Other" }
      ]
  },
  {
    topLevelCategoryId: 14, items:
      [
        { categoryId: 862, text: "Customer has complaint" },
        { categoryId: 863, text: "Customer has improvement suggestion" }
      ]
  },
  {
    topLevelCategoryId: 15, items:
      [
        { categoryId: 866, text: "ASAP escalation"},
        { categoryId: 871, text: "ASAP escalation/Acc Management"},
        { categoryId: 873, text: "ASAP escalation/API"},
        { categoryId: 874, text:"ASAP escalation/Backoffice"},
        { categoryId: 872, text: "ASAP escalation/Customer Service"},
        { categoryId: 882, text: "ASAP escalation/Customer Success"},
        { categoryId: 875, text: "ASAP escalation/Equipment Control"},
        { categoryId: 883, text: "ASAP escalation/Finance"},
        { categoryId: 876, text: "ASAP escalation/FMS"},
        { categoryId: 877, text: "ASAP escalation/Hardware"},
        { categoryId: 884, text: "ASAP escalation/Logistics"},
        { categoryId: 878, text: "ASAP escalation/Mobile app"},
        { categoryId: 885, text: "ASAP escalation/Order"},
        { categoryId: 879, text: "ASAP escalation/Privacy Breach"},
        { categoryId: 880, text: "ASAP escalation/Ram"},
        { categoryId: 881, text: "ASAP escalation/Triplog"},
        { categoryId: 954, text: "Customer Service"},
        { categoryId: 973, text: "Customer Service/Outgoing activity"},
        { categoryId: 951, text: "Customer Success"},
        { categoryId: 886, text: "Direct mailings"},
        { categoryId: 952, text: "Finance"},
        { categoryId: 967, text: "Finance/Bankrupt"},
        { categoryId: 968, text: "Finance/Closure - termination"},
        { categoryId: 969, text: "Finance/Debt collection"},
        { categoryId: 966, text: "Finance/Order handling"},
        { categoryId: 953, text: "Logistics"},
        { categoryId: 970, text: "Logistics/Planning"},
        { categoryId: 971, text: "Logistics/Return units"},
        { categoryId: 972, text: "Logistics/Swap"},
        { categoryId: 895, text: "Sales"},
        { categoryId: 897, text: "Sales/Access upgrade "}
      ]
  },
];

export function getApplicableSubCategoriesFromTopCategory(topCategoryId) {
  return subCategories.find(category => category.topLevelCategoryId === topCategoryId)?.items;
}

export function determineCategoryId(topLevelCategory, subCategory) {
  return subCategory?.categoryId ?? topLevelCategory.categoryId;
}
