// Usage example:
// <button v-tooltippy="'Navigate to home'" >Navigate</button>
// <button v-tooltippy="'Navigate to home<br/>Next line'" >Navigate</button>

export default {
  register: function(vue) {
    let mouseenterFunc = event => {
      let binding = event.currentTarget.tooltippyBinding;
      let el = event.currentTarget.tooltippyEl;
      if (!binding.value) return;

      let tooltip = document.createElement("div");
      tooltip.setAttribute("id", "tooltippy");

      // Supporting html or text
      if (binding.value.startsWith("<")) {
        tooltip.innerHTML = binding.value;
      } else {
        tooltip.innerHTML = `<div>${binding.value}</div>`;
      }

      // Create the tooltip
      tooltip.style.position = "absolute";
      tooltip.style.zIndex = "1000";
      tooltip.style.backgroundColor = "rgba(97, 97, 97, 0.9)";
      tooltip.style.color = "#ffffff";
      tooltip.style.padding = "8px";
      tooltip.style.borderRadius = "4px";
      tooltip.style.fontFamily = "Roboto";
      tooltip.style.opacity = "0.9";
      tooltip.style.fontSize = "14px";
      tooltip.style.transition = "all .3s ease-in-out";
      tooltip.style.transform = "scale(0)";
      document.body.appendChild(tooltip);

      // Get positions
      let bindingElementDimension = el.getBoundingClientRect();
      let createdElement = document.getElementById("tooltippy");
      if (!createdElement) return;
      let leftPosition = bindingElementDimension.left + (bindingElementDimension.width / 2 - createdElement.offsetWidth / 2);

      // Position element according to parent element unless at screen edges
      if (leftPosition + createdElement.offsetWidth > window.innerWidth) {
        createdElement.style.right = `20px`;
      } else if (leftPosition < 20) {
        leftPosition = 20;
        createdElement.style.left = `${leftPosition}px`;
      } else {
        createdElement.style.left = `${leftPosition}px`;
      }
      createdElement.style.top = `${bindingElementDimension.top + window.scrollY + 50}px`;

      // Animate tooltip in
      tooltip.style.transform = "scale(1)";
    };
    let mouseleaveFunc = () => {
      let elemToRemove = document.getElementById("tooltippy");
      if (!elemToRemove) return;
      elemToRemove.parentNode.removeChild(elemToRemove);
    };
    vue.directive("tooltippy", {
      update: (el, binding) => {
        el.removeEventListener("mouseenter", mouseenterFunc);
        el.removeEventListener("mouseleave", mouseleaveFunc);
        el.tooltippyBinding = binding;
        el.tooltippyEl = el;
        el.addEventListener("mouseenter", mouseenterFunc);
        el.addEventListener("mouseleave", mouseleaveFunc);
      },
      bind: (el, binding) => {
        el.removeEventListener("mouseenter", mouseenterFunc);
        el.removeEventListener("mouseleave", mouseleaveFunc);
        el.tooltippyBinding = binding;
        el.tooltippyEl = el;
        el.addEventListener("mouseenter", mouseenterFunc);
        el.addEventListener("mouseleave", mouseleaveFunc);
      }
    });
  }
};
