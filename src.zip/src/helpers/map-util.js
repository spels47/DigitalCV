export function getPositionPopupHtml(position) {
  return `
    <div style="color:black;">
    <div><b>TrackedObjectId:</b> ${position.trackedObjectId}</div>
    <div><b>Lat/Lng:</b> ${position.latitude.toFixed(6)} / ${position.longitude.toFixed(6)}</div>
    <div><b>Date:</b> ${position.timestamp}</div>
    <div><b>Speed:</b> ${(position.speed * 1.852).toFixed(0)} km/h</div>
    <div><b>Course:</b> ${position.course}</div>
    <div><b>IsManual:</b> ${position.isManual}</div>
    <div><b>IsFix:</b> ${position.isFix}</div>
    </div>
  `;
}