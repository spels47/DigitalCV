export function sortIssueList(list, filterAssignee, filterNeedsAttention, filterNotAssignedIssues, jiraUserToUse, selectedAssignee, minimumTtr) {
  if (filterAssignee) {
    if (!filterNeedsAttention && !filterNotAssignedIssues) {
      return list.filter(issue => issue.fields.assignee?.key === selectedAssignee.key)
    } else if (filterNotAssignedIssues) {
      return list.filter(issue => issue.fields.assignee === null);
    }
    else {
      return list
        .filter(issue => issue.fields.assignee?.key === selectedAssignee.key)
        .filter(issue => issue.fields.ttr.cycle.remaining.milliseconds !== null)
        .filter(issue => issue.fields.ttr.cycle.remaining.milliseconds <= minimumTtr);
    }
  } else if (filterNeedsAttention) {
    if (!filterAssignee) {
      return list
        .filter(issue => issue.fields.assignee?.key === jiraUserToUse.key)
        .filter(issue => issue.fields.ttr.cycle.remaining.milliseconds !== null)
        .filter(issue => issue.fields.ttr.cycle.remaining.milliseconds <= minimumTtr);
    } else {
      return list
        .filter(issue => issue.fields.assignee?.key === selectedAssignee.key)
        .filter(issue => issue.fields.ttr.cycle.remaining.milliseconds !== null)
        .filter(issue => issue.fields.ttr.cycle.remaining.milliseconds <= minimumTtr);
    }
  } else if (filterNotAssignedIssues) {
    return list
      .filter(issue => issue?.fields?.assignee === null);
  } else {
    return list.filter(issue => issue.fields.assignee?.key === jiraUserToUse?.key);
  }
}

