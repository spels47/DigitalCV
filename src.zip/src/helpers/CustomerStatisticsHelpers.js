﻿export default {
  cleanupStatisticHeaderName(statTitle) {
    switch (statTitle.toLowerCase()) {
      case "mrr":
        return "Avg. MRR per customer";
      case "averagepricetriplogeq":
        return "Avg. Price per main unit"
      case "averagepricepermainsub":
        return "Avg. Price per subscription";
      case "mainsubscriptions":
        return "Avg. Amount of main subscriptions";
      case "averageinstallationdegree":
        return "Average Installation Degree"
      case "averagecustomerscore":
        return "Average Customer Score";
      case "totalmrr":
        return "Total MRR";
      case "subscriptionsterminated":
        return "Subscriptions Terminated";
      case "totalcustomers":
        return "Total Customers";
      case "averagecustomersatisfaction":
        return "Average Satisfaction";
    }
  }
}
