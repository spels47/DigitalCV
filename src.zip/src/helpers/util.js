export default {
  // Color util
  stringToHslColor(str, s, l) {
    let hash = 0;
    for (let i = 0; i < str.length; i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }

    let h = hash % 360;
    return "hsl(" + h + ", " + s + "%, " + l + "%)";
  },
  projectToColor(name) {
    switch (name) {
      case "triplog/triplog":
        return "#25BACA";
      case "backoffice/backoffice4":
        return "#C800A1";
      default:
        return "#BBBBBB";
    }
  },
  hashCode(str) {
    // java String#hashCode
    var hash = 0;
    for (var i = 0; i < str.length; i++) {
      hash = str.charCodeAt(i) + ((hash << 5) - hash);
    }
    return hash;
  },
  intToRGB(i) {
    var c = (i & 0x00ffffff).toString(16).toUpperCase();
    return "#" + "00000".substring(0, 6 - c.length) + c;
  },
  getGuid() {
    return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function(c) {
      const r = (Math.random() * 16) | 0;
      const v = c == "x" ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  },

  addDaysToDate(currentDate, days) {
    const date = new Date(currentDate.valueOf());
    date.setDate(date.getDate() + days);
    return date;
  },

  // used to automatically format all links in a string to a <a></a>
  linkify(text) {
    const urlRegex = /(\b(https?|ftp|file):\/\/[-A-Z0-9+&@#\/%?=~_|!:,.;]*[-A-Z0-9+&@#\/%=~_|])/gi; //eslint-disable-line
    return text.replace(urlRegex, function (url) {
      if (url.includes("upload")) return url;
      return '<a target="_blank" href="' + url + '">' + url + "</a>";
    });
  },

  formatBytes(bytes, decimals = 2) {
    if (bytes === 0) return "0 Bytes";

    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = ["Bytes", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"];

    const i = Math.floor(Math.log(bytes) / Math.log(k));

    return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + " " + sizes[i];
  },

  parseIsoDatetime(dtstr) {
    if (dtstr === "" || dtstr == null) return;
    const dt = dtstr.split(/[: T-]/).map(parseFloat);
    return new Date(dt[0], dt[1] - 1, dt[2], dt[3] || 0, dt[4] || 0, dt[5] || 0, 0).toLocaleString("en-US", this.dateOptions);
  },

  // takes in a date and returns time since. Example -> 24 minutes, 5 hours & 3 days
  getTimeSince(date) {
    const seconds = Math.floor((new Date() - date) / 1000);
    let interval = seconds / 31536000;

    if (interval > 1) {
      return Math.floor(interval) + " year(s)";
    }
    interval = seconds / 2592000;
    if (interval > 1) {
      return Math.floor(interval) + " month(s)";
    }
    interval = seconds / 604800;
    if (interval > 1) {
      return Math.floor(interval) + " week(s)";
    }
    interval = seconds / 86400;
    if (interval > 1) {
      return Math.floor(interval) + " day(s)";
    }
    interval = seconds / 3600;
    if (interval > 1) {
      return Math.floor(interval) + " hours(s)";
    }
    interval = seconds / 60;
    if (interval > 1) {
      return Math.floor(interval) + " minute(s)";
    }
    return Math.floor(seconds) + " second(s)";
  },

  // Date util
  addDays(date, days) {
    let result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
  },
  getIsoDateString(date) {
    return date.toISOString().substring(0, 10);
  },
  getTimeString(date) {
    let dt = new Date(date);
    let hours = dt.getHours().toString();
    let minutes = dt.getMinutes().toString();
    let seconds = dt.getSeconds().toString();
    if (hours.length === 1) hours = "0" + hours;
    if (minutes.length === 1) minutes = "0" + minutes;
    if (seconds.length === 1) seconds = "0" + seconds;
    return hours + ":" + minutes + ":" + seconds
  },
  getStartOfYearDate() {
    return new Date(new Date().getFullYear(), 0, 1);
  },
  setupGlobalDateHelper() {
    // ntz = no time zone, for when the date is correct from the api if you disregard the timezone info
    Date.prototype.toISOString_ntz = function () {
      let tzo = -this.getTimezoneOffset(),
        dif = tzo >= 0 ? "+" : "-",
        pad = function (num) {
          let norm = Math.floor(Math.abs(num));
          return (norm < 10 ? "0" : "") + norm;
        };
      return this.getFullYear() + "-" + pad(this.getMonth() + 1) + "-" + pad(this.getDate()) + "T" + pad(this.getHours()) + ":" + pad(this.getMinutes()) + ":" + pad(this.getSeconds()) + dif + pad(tzo / 60) + ":" + pad(tzo % 60);
    };
  },
  getFormattedPriceForCountry(country, price) {
    const getLocaleAndCurrency = (locale) => {
      switch (locale.toLowerCase()) {
        case "no":
          return { locale: "nb-NO", currency: "NOK" };
        case "se":
          return { locale: "sv-SE", currency: "SEK" };
        case "dk":
          return { locale: "da-DK", currency: "DKK" };
        case "gb":
          return { locale: "en-GB", currency: "GBP" };
        case "fi":
          return { locale: "fi-FI", currency: "EUR" };
        case "fr":
          return { locale: "fr-FR", currency: "EUR" };
        case "nl":
          return { locale: "nl-NL", currency: "EUR" };
        case "be":
          return { locale: "nl-BE", currency: "EUR" };
        case "pl":
          return { locale: "pl-PL", currency: "PLN" };
        case "kr":
          return { locale: "ko-KR", currency: "EUR" };
        default:
          return { locale: "nb-NO", currency: "NOK" };
      }
    }

    const { locale, currency } = getLocaleAndCurrency(country);
    const formatter = new Intl.NumberFormat(locale, {
      style: 'currency',
      currency: currency,
    });
    return formatter.format(price);
  },
  getDateTimeByCountry(date, country, includeSeconds = true) {
    if (!country)
      return "";

    //date provided is UTC
    let dt = new Date(date);
    let correctedDate = new Date();
    let returnString = "";
    switch (country.toLowerCase()) {
      case "no":
        correctedDate = new Date(dt.toLocaleString("sv-SE", { timeZone: "Europe/Oslo", hour12: false }));
        break;
      case "gb":
        correctedDate = new Date(dt.toLocaleString("sv-SE", { timeZone: "Europe/London", hour12: false }));
        break;
      case "se":
        correctedDate = new Date(dt.toLocaleString("sv-SE", { timeZone: "Europe/Stockholm", hour12: false }));
        break;
      case "fi":
        correctedDate = new Date(dt.toLocaleString("sv-SE", { timeZone: "Europe/Helsinki", hour12: false }));
        break;
      case "nl":
        correctedDate = new Date(dt.toLocaleString("sv-SE", { timeZone: "Europe/Amsterdam", hour12: false }));
        break;
      case "pl":
        correctedDate = new Date(dt.toLocaleString("sv-SE", { timeZone: "Europe/Warsaw", hour12: false }));
        break;
      default:
        correctedDate = new Date(dt.toLocaleString("sv-SE", { timeZone: "Europe/Oslo", hour12: false }));
        break;
    }

    if (includeSeconds) {
      return (
        correctedDate.getFullYear() +
        "-" +
        this.addZ(correctedDate.getMonth() + 1) +
        "-" +
        this.addZ(correctedDate.getDate()) +
        " " +
        this.addZ(correctedDate.getHours()) +
        ":" +
        this.addZ(correctedDate.getMinutes()) +
        ":" +
        this.addZ(correctedDate.getSeconds())
      );
    } else {
      return (
        correctedDate.getFullYear() +
        "-" +
        this.addZ(correctedDate.getMonth() + 1) +
        "-" +
        this.addZ(correctedDate.getDate()) +
        " " +
        this.addZ(correctedDate.getHours()) +
        ":" +
        this.addZ(correctedDate.getMinutes())
      );
    }
  },
  addZ(n) {
    return n < 10 ? "0" + n : "" + n;
  },
  deepClone(obj) {
    const string = JSON.stringify(obj);
    return JSON.parse(string);
  },
  isEmpty(obj) {
    return Object.keys(obj).length === 0;
  },
  async sleep(milliseconds) {
    return new Promise(resolve => setTimeout(resolve, milliseconds));
  },
  getDefaultTab(itemType) {
    switch (itemType?.toLowerCase()) {
      case "overview":
        return 0;
      case "account":
        return 1;
      case "adminaccount":
        return 1;
      case "vehicle":
        return 2;
      case "eq":
        return 3;
      case "subscription":
        return 4;
      case "simcard":
        return 5;
      case "oem":
        return 5;
      case "mini":
        return 5;
      case "rfid":
        return 5;
      case "datasource":
        return 5;
      case "customerlog":
        return 6;
      case "financial":
        return 7;
      default:
        return 0;
    }
  },
  getCountryFromCode(code) {
    switch (code) {
      case "NO":
        return "Norway";
      case "SE":
        return "Sweden";
      case "FI":
        return "Finland";
      case "DK":
        return "Denmark";
      case "GB":
        return "UK";
      case "FR":
        return "France";
      case "BE":
        return "Belgium";
      case "NL":
        return "Netherlands";
      case "PL":
        return "Poland";
      default:
        return "all countries";
    }
  },
  capitalizeFirstLetter(string) {
    return string.charAt(0).toUpperCase() + string.slice(1);
  },
  customSort(items, index, isDesc) {
    items.sort((a, b) => {
      if (a[index] === b[index]) { // equal items sort equally
        return 0;
      } else if (a[index] === null) { // nulls sort after anything else
        return 1;
      } else if (b[index] === null) {
        return -1;
      } else if (!isDesc[0]) { // otherwise, if we're ascending, lowest sorts first
        return a[index] < b[index] ? -1 : 1;
      } else { // if descending, highest sorts first
        return a[index] < b[index] ? 1 : -1;
      }
    });
    return items;
  },
  flattenDict(dictToFlatten) {
    function flatten(dict, parent) {
      let keys = [];
      let values = [];

      for (let key in dict) {
        if (typeof dict[key] === 'object') {
          let result = flatten(dict[key], parent ? parent + '_' + key : key);
          keys = keys.concat(result.keys);
          values = values.concat(result.values);
        } else {
          keys.push(parent ? parent + '_' + key : key);
          values.push(dict[key]);
        }
      }
      return {
        keys: keys,
        values: values
      }
    }

    let result = flatten(dictToFlatten);
    let flatDict = {};
    for (let i = 0, end = result.keys.length; i < end; i++) {
      flatDict[result.keys[i]] = result.values[i];
    }
    return flatDict;
  },
  trimUsername(username) {
    return username?.substr(0, username.indexOf("@"));
  },
  stringContainsWord(string, word) {
    // eslint-disable-next-line no-useless-escape
    return string?.toLowerCase()?.replace(/[.,\/#!$%\^&\*;:{}=\-_`~()]/g,"")?.split(/\s+/)?.includes(word.toLowerCase());
  },
  sumIntegerArray(array) {
    return array.reduce(function (a, b) {
      return a + b;
    }, 0);
  }
};
