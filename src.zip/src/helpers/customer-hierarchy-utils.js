import utils from "~/helpers/util.js";

export function sortHierarchy(hierarchy){
  if(utils.isEmpty(hierarchy) || !hierarchy.children)
    return;

  hierarchy.children.sort((a, b) => a.name?.localeCompare(b.name))
  hierarchy.children.forEach(child => sortHierarchy(child))
}

export function findCustomerHierarchy(hierarchy, customerId){
  if(!hierarchy.id)
    return null

  if(hierarchy.id === customerId)
    return hierarchy;

  if(!hierarchy.children)
    return null

  var result = null;
  for(let i = 0; result === null && i < hierarchy.children.length; i++){
    result = findCustomerHierarchy(hierarchy.children[i], customerId);
  }
  return result;
}

export function findDepartmentPath(hierarchy, departmentId){
  const emptyPath = []

  if(!hierarchy.children)
    return emptyPath;

  let departmentPath = [];
  const pathFound = tryFindPath(hierarchy, departmentId, departmentPath);

  return pathFound ? departmentPath : emptyPath

  function tryFindPath(hierarchy, departmentId, departmentPath){
    departmentPath.push(hierarchy);

    if(hierarchy.id === departmentId){
      return true;
    }

    let found = false;
    for(let i = 0;!found && i < hierarchy.children.length; i++){
      found = tryFindPath(hierarchy.children[i], departmentId, departmentPath);
    }

    if(found) return true;

    departmentPath.pop(hierarchy);

    return false;
  }
}
