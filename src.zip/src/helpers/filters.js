import Vue from "vue"

Vue.filter("date", str => {
  if (!str || str.startsWith('0')) { return '--'; }
  let date = new Date(str);
  return date.toISOString().substring(0, 10)
})

Vue.filter("datetime", str => {
  if (!str || str.startsWith('0')) { return '--'; }
  let date = new Date(str);
  return `${date.toISOString().substring(0, 10)} ${date.toISOString().substring(11, 16)}`
})

Vue.filter("datetimeSeconds", str => {
  if (!str || str.startsWith('0')) { return '--'; }
  let date = new Date(str);
  return `${date.toISOString().substring(0, 10)} ${date.toISOString().substring(11, 19)}`
})

// ntz = no time zone, for when the date is correct from the api if you disregard the timezone info
Vue.filter("ntzDate", str => {
  if (!str || str.startsWith('0')) { return '--'; }
  let date = new Date(str);
  return date.toISOString_ntz().substring(0, 10)
})

Vue.filter("ntzDatetime", str => {
  if (!str || str.startsWith('0')) { return '--'; }
  let date = new Date(str);
  return `${date.toISOString_ntz().substring(0, 10)} ${date.toISOString_ntz().substring(11, 16)}`
})

Vue.filter("ntzDatetimeSeconds", str => {
  if (!str || str.startsWith('0')) { return '--'; }
  let date = new Date(str);
  return `${date.toISOString_ntz().substring(0, 10)} ${date.toISOString_ntz().substring(11, 19)}`
})
