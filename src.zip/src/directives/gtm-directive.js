import gtm from '~/gtm'

let register = function(app){
  app.directive('gtm', {
    bind: function (el, binding, vnode) {
      el.addEventListener('click', () => {
        gtm.trackEvent(binding.value, vnode.context.$route.path)
      })
    }
  })
}
export default register

