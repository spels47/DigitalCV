let oidcToken = null;

let register = function (app) {
  window.errorHandlerMessagesSent = 0
  window.errorHandlerMaxMessagesPrRefresh = 10

  let sendError = function (message) {
    if (oidcToken === null)
      return;

    if(window.errorHandlerMessagesSent >= window.errorHandlerMaxMessagesPrRefresh)
      return

    const xhr = new window.XMLHttpRequest()
    xhr.open('POST', '/api/log/error', true)
    xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8')
    xhr.setRequestHeader('Authorization', 'Bearer ' + oidcToken)
    xhr.send(JSON.stringify(message))
    window.errorHandlerMessagesSent++
  }

  window.onerror = function (errorMsg, url, lineNumber, column, errorObj) {
    console.error(errorMsg, url, lineNumber, column, errorObj)  /* eslint-disable-line */

    let message = {
      ErrorMessage: errorMsg,
      Url: window.location.href,
      LineNumber: lineNumber,
      Column: column,
      ErrorObject: JSON.stringify(errorObj)
    }
    sendError(message)
  }

  app.config.errorHandler = function (err, vm, info) {
    console.error(err, vm, info)  /* eslint-disable-line */

    let message = {
      ErrorMessage: err.message,
      Url: window.location.href,
      LineNumber: 0,
      Column: 0,
      ErrorObject: err.stack
    }
    sendError(message)
  }

  app.config.warnHandler = function (msg, vm, trace) {
    if (msg.includes(`Property or method "cy" is not defined on the instance but referenced during render.`))
      return;

    console.warn(msg, vm, trace)  /* eslint-disable-line */
  }

  window.addEventListener('unhandledrejection', function(event) {
    console.warn(event)  /* eslint-disable-line */
  })

  app.config.ignoredElements = [] // https://vuejs.org/v2/api/
}

export function setOidcToken(token)  {
  if (!token)
    return;

  oidcToken = token;
}


export default {
  register,
  setOidcToken
}
