let gtm = {
  setCurrentUser: function(username) {
    window.dataLayer.push({
      userId: username
    });
  },
  trackPageView: function(page) {
    window.dataLayer.push({
      event: "VirtualPageview",
      virtualPageURL: page,
      path: page
    });
  },
  trackEvent: function(action, path) {
    window.dataLayer.push({
      event: `customEvent`,
      path: path,
      action: action
    });
  }
};

export default gtm;
