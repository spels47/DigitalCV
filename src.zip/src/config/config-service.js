import axios from 'axios'

let identityServerConfig = null;
let triplogConfig = null;

let AxiosClient = axios.create({
  baseURL: window.location.origin + process.env.BASE_URL
})

export async function loadConfig () {
  await AxiosClient.get("/api/config/identity-server").then(response => {
    identityServerConfig = response.data
  });

  await AxiosClient.get("/api/config/triplog").then(response => {
    triplogConfig = response.data
  });
}

export default {
  loadConfig
};

export const getIdentityServerConfig = () => identityServerConfig
export const getTriplogConfig = () => triplogConfig
