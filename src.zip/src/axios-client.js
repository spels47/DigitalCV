import axios from 'axios'
import store from '~/store'

window.axiosClientFailedRequests = 0

function getCurrentToken () {
  return store.state.oidcStore.access_token
}

let abaxApiClient = axios.create({
  baseURL: window.location.origin + process.env.BASE_URL
})

abaxApiClient.interceptors.request.use(request => {
  let token = getCurrentToken();
  if (token != undefined && token != null)
    request.headers['Authorization'] = 'Bearer ' + token;

  if(request.error) window.axiosClientFailedRequests++

  return request
}, error => {
  if(error?.response?.status === 401){
    alert(`You're currently logged out. The page will refresh to try to log you back in using Identity server`)
    location.reload();
  }
  window.axiosClientFailedRequests++
  return Promise.reject(error);
});

abaxApiClient.interceptors.response.use(response => {
  return response
}, error => {
  window.axiosClientFailedRequests++
  return Promise.reject(error);
});

export default abaxApiClient

