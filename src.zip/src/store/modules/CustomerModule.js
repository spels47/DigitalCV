import axios from "~/axios-client";
import { sortHierarchy, findCustomerHierarchy, findDepartmentPath } from "~/helpers/customer-hierarchy-utils.js";

const state = {
  customer: {},
  mainOfficeHierarchy: {}
};

const getters = {
  customer: state => state.customer,
  mainOfficeHierarchy: state => {
    sortHierarchy(state.mainOfficeHierarchy);
    return state.mainOfficeHierarchy;
  },
  customerHierarchy: (_, getters) => {
    const customerHierarchy = findCustomerHierarchy(getters.mainOfficeHierarchy, getters.customer.id);
    return customerHierarchy === null ? {} : customerHierarchy;
  },
  getDepartmentPath: (_, getters) => departmentId => {
    const departmentPath = findDepartmentPath(getters.mainOfficeHierarchy, departmentId);

    return departmentPath.map(department => ({
      id: department.id,
      name: department.name
    }));
  }
};

const mutations = {
  setCustomer(state, customer) {
    state.customer = customer;
  },
  setMainOfficeHierarchy(state, mainOfficeHierarchy) {
    state.mainOfficeHierarchy = mainOfficeHierarchy;
  }
};

const actions = {
  async fetchCustomer({ commit, dispatch }, customerId) {
    try {
      let res = await axios.get(`/api/customer?customerId=${customerId}`);
      commit("setCustomer", res.data);
    } catch (ex) {
      this._vm.$eventBus.$emit("alert", { template: "api-error" });
    }

    await dispatch("fetchMainOfficeHierarchy", customerId);
  },
  async fetchMainOfficeHierarchy({ commit, state }) {
    try {
      let res = await axios.get(`/api/customer/hierarchy/${state.customer.mainOfficeId}`);
      commit("setMainOfficeHierarchy", res.data);
    } catch (ex) {
      this._vm.$eventBus.$emit("alert", { template: "api-error" });
    }
  }
};

export default {
  namespaced: true,
  state,
  getters,
  mutations,
  actions
};
