import axios from "~/axios-client";

const state = {
  timesFetched: 0,
  jiraIssueBeingRetrieved: false,
  retrievingPinnedIssues: false,
  jiraUserToUse: {},
  chosenAssignee: {},
  currentJiraIssue: {},
  jiraIssueComments: [],
  startOfIssueList: [],
  previousIssueList: [],
  pinnedIssues: [],
  issueList: {
    items: [],
    headers: []
  },
  newIssueSummary: "",
  newIssueDescription: "",
  newIssuePriority: "",
  newIssueType: "",
  newIssueResolution: "",
  newIssueEpicLink: null,
  newIssueGitlabLink: "",
  newIssueCsTicketLink: "",
  newIssueCategory: "",
  newIssueReleaseNotes: "",
  newIssueUrgency: "",
  newIssueLinkedCustomerTickets: [],
  newIssueCountriesAffected: [],
  newIssueLabels: [],
  newIssueAssignee: null,
  newIssueComponents: null,
  newIssueDueDate: null,
  issueIsADevelopmentIssue: false
};

const mutations = {
  updateIssueList(state, payload) {
    state.issueList.items = payload.items;
    state.issueList.headers = payload.headers;
  },
  updatePinnedIssues(state, payload) {
    state.pinnedIssues = payload;
  },
  updateJiraIssueBeingRetrieved(state, payload) {
    state.jiraIssueBeingRetrieved = payload;
  },
  updateRetrievingPinnedIssues(state, payload) {
    state.retrievingPinnedIssues = payload;
  },
  updateJiraUserToUse(state, payload) {
    state.jiraUserToUse = payload;
  },
  updateChosenAssignee(state, payload) {
    state.chosenAssignee = payload;
  },
  updateJiraIssue(state, payload) {
    state.currentJiraIssue = payload;
  },
  updateJiraIssueComments(state, payload) {
    state.jiraIssueComments = payload;
  }
};
const actions = {
  setJiraAssigneeToUse(context, parameters) {
   context.commit("updateJiraUserToUse", parameters);
  },
  async retrieveIssueList(context, parameters) {
    state.previousIssueList = state.issueList.items;

    if (!parameters.silentFetch) {
      context.commit("updateDataBeingRetrieved", true);
      context.commit("updateIssueList", {
        items: [],
        headers: []
      });
    }
    try {
      const { data } = await axios.get(`/api/jira/issues/${parameters.key}`);
      state.timesFetched += 1;
      context.commit("updateIssueList", {
        items: data.data,
        headers: data.headers
      });

      // we keep track of the first time we got the issue list
      // in order to check Goal below 30
      if (state.timesFetched === 1) {
        state.startOfIssueList = state.issueList.items;
      }
    } catch { /* ignored */ }
    finally {
      //eslint-disable-line
      context.commit("updateDataBeingRetrieved", false);
    }
  },
  async retrieveJiraIssue(context, parameters) {
    context.commit("updateJiraIssueBeingRetrieved", true);
    await axios
      .get(`api/jira/issue/${parameters.key}`)
      .then(res => {
        context.commit("updateJiraIssue", res.data);
      })
      .catch(() => this._vm.$eventBus.$emit("alert", { template: "api-error" }))
      .finally(() => context.commit("updateJiraIssueBeingRetrieved", false));
  },
  async fetchJiraIssueComments(context, parameters) {
    const { data } = await axios.get(`/api/jira/issue/${parameters.name}/comments`);
    context.commit("updateJiraIssueComments", data);
  },
  async postCommentOnJiraIssue(context, parameters) {
    if (Object.keys(state.jiraUserToUse).length !== 0 && (parameters.mentionAssignee ?? true)) {
      parameters.comment += `\n\n[~${state.jiraUserToUse?.key}]`;
    }

    const commentObject = {
      visibility: {
        type: "role",
        value: "Administrators"
      },
      body: parameters.comment
    };

    return await axios.post(`/api/jira/issue/${parameters.key}/comment`, commentObject);
  },
  async deleteComment(context, parameters) {
    return await axios.delete(`/api/jira/issue/${parameters.key}/comment`, { data: parameters.comment });
  },
  async deleteAttachment(context, parameters) {
    return await axios.delete(`/api/jira/attachment`, { data: parameters.attachment });
  },
  async watchIssue(context, parameters) {
    return await axios.post(`/api/jira/issue/${parameters.key}/watch`);
  },
  async removeWatch(context, parameters) {
    return await axios.delete(`/api/jira/issue/${parameters.key}/watch`);
  },
  async updateIssueWithJSON(context, parameters) {
    try {
      return await axios.put(`/api/jira/issue/${parameters.key}/update/${JSON.stringify(parameters.updateModel)}`)
    } catch {
      this._vm.$eventBus.$emit("alert", { template: "api-error" });
    }
  },
  async updateIssue(context, parameters) {
    const updateModel = {
      update: {
        summary: [
          {
            set: state.newIssueSummary
          }
        ],
        priority: [
          {
            set: {
              name: state.newIssuePriority
            }
          }
        ],
        components: [
          {
            set: state.newIssueComponents ?? []
          }
        ],
        labels: [
          {
            set: state.newIssueLabels
          }
        ],
        assignee: [
          {
            set: {
              name: state.newIssueAssignee === null ? "" : state.newIssueAssignee.name
            }
          }
        ],
        customfield_12123: [
          {
            set: state.newIssueCountriesAffected
          }
        ]
        /*
"customfield_12100": [
  {
    "set": {
      "value": state.newIssueCategory,
    }
  }
],
"customfield_12109": [
  {
    "set": {
      "value": state.newIssueUrgency,
    }
  }
]
 */
      },
      fields: {
        description: state.newIssueDescription ?? "",
        issuetype: {
          name: state.newIssueType
        },
        //"duedate": state.newIssueDueDate,
        //"customfield_12504": state.newIssueResolution,
        customfield_10004: state.newIssueEpicLink,
        customfield_11400: state.newIssueReleaseNotes,
        customfield_12900: state.newIssueGitlabLink,
        customfield_12120: state.newIssueCsTicketLink,
        customfield_12124: state.newIssueLinkedCustomerTickets,
        customfield_12130: state.issueIsADevelopmentIssue ? [{ value: "Development issue" }] : null
      }
    };

    try {
      if (state.issueIsADevelopmentIssue && parameters.currentJiraIssue.fields.isDevelopmentIssue[0].value !== "Development issue") {
        // this issue got turned into a development issue as well, therefore notify in comments
        await context.dispatch("postCommentOnJiraIssue", { key: parameters.key, comment: "Issue has been moved to development for further investigation.", mentionAssignee: false });
      }
    } catch {
      /* this exception gets ignored */
    }

    // we have a priority change, post a comment to notify Gitlab issue
    if (state.newIssuePriority !== parameters.currentJiraIssue.fields.priority.name && Object.keys(parameters.linkedGitlabIssue).length !== 0) {
      await context.dispatch("postCommentOnGitlabIssue", { body: `Jira SD ticket changed priority from '${parameters.currentJiraIssue.fields.priority.name}' to '${state.newIssuePriority}'` }, { root: true });
    }

    return await axios.put(`/api/jira/issue/${parameters.key}/update`, updateModel);
  },
  async getPinnedIssues(context, parameters) {
    if (!parameters.silent ?? false) {
      context.commit("updateRetrievingPinnedIssues", true);
    }
    try {
      const result = await axios.get(`/api/jira-user-data/pinnedIssues/${parameters.userKey}`);
      if (result.status === 200) {
        context.commit("updatePinnedIssues", result.data);
      }
    } catch {
      this._vm.$eventBus.$emit("alert", { template: "api-error" })
    } finally {
      context.commit("updateRetrievingPinnedIssues", false);
    }
  },
  async pinIssue(context, parameters) {
    await axios.put(`/api/jira-user-data/pinIssue/${parameters.user.key}/${parameters.issue.key}`);
  },
  async unpinIssue(context, parameters) {
    await axios.put(`/api/jira-user-data/unpinIssue/${parameters.user.key}/${parameters.issue.key}`);
  }
};

export default {
  state,
  actions,
  mutations
};
