import axios from "~/axios-client";
import moment from "moment";

const state = {
  releases: [],
  gitlabProjects: [],
  firstWeekDay: null
};
const actions = {
  async getReleases() {
    if (!state.firstWeekDay) return;
    let response = await axios.get("/api/ReleaseManagement", {
      params: {
        firstWeekDay: state.firstWeekDay
      }
    });
    this.commit("clearReleases");
    response.data.forEach(release => {
      this.commit("addRelease", {
        id: release.id,
        name: release.releaseName,
        releaseName: release.releaseName,
        start: moment(release.releaseStart).format("YYYY-MM-DD HH:mm"),
        end: moment(release.releaseFinish).format("YYYY-MM-DD HH:mm"),
        description: release.releaseDescription,
        jiraIssues: release.jiraIssues,
        mergeRequests: release.mergeRequests,
        manager: release.manager,
        qa: release.qa,
        dev: release.dev,
        gitlabProjectsAffected: release.gitlabProjectsAffected,
        prmDocument: release.prmDocument,
        emailRecipients: release.emailRecipients,
        timed: true,
        state: release.state
      });
    });
  },
  async createRelease(state, payload) {
    await axios.post("/api/ReleaseManagement", payload);
    await this.dispatch("getReleases");
  },
  async updateRelease(state, payload) {
    await axios.put("/api/ReleaseManagement", payload);
    await this.dispatch("getReleases");
  },
  async deleteRelease(state, payload) {
    await axios.delete("/api/ReleaseManagement", {
      params: {
        id: payload
      }
    });
    await this.dispatch("getReleases");
  },
  async getGitlabProjects() {
    this.commit("clearGitlabProjects");
    let response = await axios.get("/api/ReleaseManagement/projects");
    response.data.forEach(project => {
      this.commit("addGitlabProject", project);
    });
  }
};
const mutations = {
  async setFirstWeekDay(state, payload) {
    state.firstWeekDay = payload;
    await this.dispatch("getReleases");
  },
  clearReleases() {
    state.releases = [];
  },
  addRelease(state, payload) {
    state.releases.push(payload);
  },
  addGitlabProject(state, payload) {
    state.gitlabProjects.push(payload);
  },
  clearGitlabProjects() {
    state.gitlabProjects = [];
  }
};
const getters = {};

export default {
  state,
  actions,
  mutations,
  getters
};
