import axios from "~/axios-client";

const state = {
  mySwaps: [],
  myCompletedSwaps: [],
  loading: false
};
const getters = {};
const mutations = {
  setMySwaps(state, payload) {
    state.mySwaps = payload;
    state.loading = false;
  },
  setMyCompletedSwaps(state, payload) {
    state.myCompletedSwaps = payload;
    state.loading = false;
  },
  toggleLoading(state, value) {
    state.loading = value;
  },
  clearMySwaps(state){
    state.mySwaps = [];
  },
  clearMyCompletedSwaps(state){
    state.myCompletedSwaps = [];
  },
  async updateMySwap(state, payload) {
    let item = state.mySwaps.find(x => x.workItem?._id === payload._id);
    let index = state.mySwaps.indexOf(item);
    if (index !== -1) {
      item.workItem = payload;
    }
  },
  removeMySwap(state, payload) {
    let item = state.mySwaps.find(x => x._id === payload._id);
    let index = state.mySwaps.indexOf(item);
    if (index >= 0)
      state.mySwaps.splice(index, 1);
  }
};
const actions = {
  async removeMySwapItem({ commit }, payload) {
    commit("removeMySwap", payload);
  },
  async retrieveMySwaps(context, payload) {
    if(payload.state == "active") context.commit("clearMySwaps");
    else context.commit("clearMyCompletedSwaps");
    context.commit("toggleLoading", true);
    let result = await axios.get(`/api/worklist/myswaps/${payload.state}`);
    if(payload.state == "active") context.commit("setMySwaps", result.data);
    else context.commit("setMyCompletedSwaps", result.data);
    context.commit("toggleLoading", false);
  }
};

export default {
  namespaced: true,
  state,
  actions,
  mutations,
  getters
};
