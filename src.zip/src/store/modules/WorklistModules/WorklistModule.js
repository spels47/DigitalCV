﻿import axios from "~/axios-client";

const state = {
  workItems: [],
  loading: false,
  worklistType: "",
};
const getters = {};
const mutations = {
  setWorklistItems(state, payload) {
    state.workItems = payload;
    state.loading = false;
  },
  setWorklistType(state, payload) {
    state.worklistType = payload
  },
  toggleLoading(state, value) {
    state.loading = value;
  },
  clearWorkItems(state){
    state.workItems = [];
  },
  async updateWorkItem(state, payload) {
    let item = state.workItems.find(x => x.workItem?._id === payload._id);
    let index = state.workItems.indexOf(item);
    if (index !== -1) {
      item.workItem = payload;
    }
  },
  removeWorklistItem(state, payload) {
    let item = state.workItems.find(x => x.workItem._id === payload);
    let index = state.workItems.indexOf(item);
    if (index >= 0)
      state.workItems.splice(index, 1);
  },
  removeSwapItem(state, payload) {
    for (let i = 0; i < state.workItems.length; i++) {
      const itemList = state.workItems[i].workItems;
      let item = itemList.find(x => x._id === payload);
      if(item){
        let index = itemList.indexOf(item);
        if(index >= 0) itemList.splice(index, 1);
        return;
      }
    }
  }
};
const actions = {
  async updateWorkItemFromWebSocket(context, payload) {
    await context.commit("updateWorkItem", payload);
  },
  async removeWorkListItem({ commit }, payload) {
    commit("removeWorklistItem", payload);
  },
  async removeSwapItem({ commit }, payload) {
    commit("removeSwapItem", payload);
  },
  async retrieveWorkItems(context, payload) {
    context.commit("clearWorkItems");
    context.commit("toggleLoading", true);
    let result = payload.isDev && payload.worklistType == 'Swap' ? await axios.get(`/api/worklist/list/active/swap`) : await axios.get(`/api/worklist/list/${payload.worklistType}`);
    context.commit("setWorklistType", payload.worklistType)
    context.commit("toggleLoading", false);
    context.commit("setWorklistItems", result.data);
  },
  async retrieveCompletedWorkItems(context, payload) {
    context.commit("clearWorkItems");
    context.commit("toggleLoading", true);
    let result = await axios.get(`/api/worklist/list/${payload.worklistType}?states=active&states=completed`);
    context.commit("setWorklistType", payload.worklistType)
    context.commit("toggleLoading", false);
    context.commit("setWorklistItems", result.data);
  },
  async completeWorklistItem(context, payload) {
    context.commit("toggleLoading", true);
    let result = await axios.post("api/worklist/completeItem", {
      TaskId: payload.id
    });
    context.commit("toggleLoading", false);
    context.commit("updateWorkItem", result.data);
  },
  async cancelWorklistItem(context, payload) {
    context.commit("toggleLoading", true);
    let result = await axios.post("api/worklist/cancel", {
      TaskId: payload.id
    });
    context.commit("toggleLoading", false);
    context.commit("updateWorkItem", result.data);
  },
  async assignWorklistItem(context, payload) {
    let assignTask = {
      TaskId: payload.id
    };
    context.commit("toggleLoading", true);
    await axios.post(`/api/worklist/assign`, assignTask);
    context.commit("toggleLoading", false);
  },
  async unassignWorklistItem(context, payload) {
    let assignTask = {
      TaskId: payload.id,
      AdUsername: payload.username
    };
    context.commit("toggleLoading", true);
    await axios.post(`/api/worklist/unassign`, assignTask);
    context.commit("toggleLoading", false);
  },
  async ignoreWorkItem(context, payload) {
    context.commit("toggleLoading", true);
    await axios.post("/api/worklist/ignore", {
      TaskId: payload
    });
    context.commit("toggleLoading", false);
  },
  async hideWorkItemUntil(context, payload){
    await axios.post(`/api/worklist/hide-until/${payload.taskId}/${payload.hideUntil}`)
  }
};

export default {
  namespaced: true,
  state,
  actions,
  mutations,
  getters
};
