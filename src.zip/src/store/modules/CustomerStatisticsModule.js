import axios from "~/axios-client";

const state = {
  customerStatisticsFavoritesIds: [],
  customerStatisticsFavorites: []
};

const actions = {
  async getCustomerStatisticsFavorites(context) {
    let res = await axios.get("/api/customerStatistics/favorites");
    let customerIds = res.data?.customerIds || [];
    context.commit("setCustomerStatisticsFavoritesIds", customerIds || []);

    let customers = [];
    for (let id of customerIds) {
      if (isNaN(id)) continue;
      let response = await axios.get("/api/customerStatistics/backstage?customerId=" + id);
      let customer = response.data;

      if (!response.data) continue;

      customers.push({
        customer: customer.data.customer_name,
        id: customer._id,
        installed: customer.data.cards.find(c => {
          return c.header === "Installed";
        })?.result,
        onboarding: customer.data.cards.find(c => {
          return c.header === "Onboarding";
        })?.result,
        usage: customer.data.cards.find(c => {
          return c.header === "Usage";
        })?.result,
        reports: customer.data.cards.find(c => {
          return c.header === "Reports";
        })?.result,
        features: customer.data.cards.find(c => {
          return c.header === "Reports";
        })?.result,
        vehicles: customer.data.cards.find(c => {
          return c.header === "Vehicles";
        })?.result,
        drivers: customer.data.cards.find(c => {
          return c.header === "Drivers";
        })?.result
      });
    }

    context.commit("setCustomerStatisticsFavorites", customers || []);
  },
  async addCustomerStatisticsFavorite(context, customer) {
    if (!customer?.id || state.customerStatisticsFavoritesIds.includes(customer.id)) return;

    let response = await axios.get("/api/customerStatistics/backstage?customerId=" + customer.id);
    if (!response.data) return;

    await context.commit("addACustomer", response.data);
    await context.commit("saveCustomerStatisticsFavorites");
  }
};

const mutations = {
  addACustomer(state, customer) {
    let newCustomer = {
      customer: customer.data.customer_name,
      id: customer._id,
      installed: customer.data.cards.find(c => {
        return c.header === "Installed";
      })?.result,
      onboarding: customer.data.cards.find(c => {
        return c.header === "Onboarding";
      })?.result,
      usage: customer.data.cards.find(c => {
        return c.header === "Usage";
      })?.result,
      reports: customer.data.cards.find(c => {
        return c.header === "Reports";
      })?.result,
      features: customer.data.cards.find(c => {
        return c.header === "Reports";
      })?.result,
      vehicles: customer.data.cards.find(c => {
        return c.header === "Vehicles";
      })?.result,
      drivers: customer.data.cards.find(c => {
        return c.header === "Drivers";
      })?.result
    };
    state.customerStatisticsFavorites.push(newCustomer);
    state.customerStatisticsFavoritesIds.push(newCustomer.id);
  },
  setCustomerStatisticsFavoritesIds(state, list) {
    state.customerStatisticsFavoritesIds = list;
  },
  setCustomerStatisticsFavorites(state, list) {
    state.customerStatisticsFavorites = list;
  },
  async removeCustomerStatisticsFavorite(state, id) {
    state.customerStatisticsFavoritesIds.splice(state.customerStatisticsFavoritesIds.indexOf(id), 1);
    state.customerStatisticsFavorites = state.customerStatisticsFavorites.filter(x => x.id.toString() !== id.toString());
    await axios.put("/api/customerStatistics/favorites", state.customerStatisticsFavoritesIds);
  },
  async saveCustomerStatisticsFavorites(state) {
    await axios.put("/api/customerStatistics/favorites", state.customerStatisticsFavoritesIds);
  }
};

const getters = {
  customerStatisticsFavorites: state => {
    return state.customerStatisticsFavorites;
  },
  customerStatisticsFavoritesIds: state => {
    return state.customerStatisticsFavoritesIds;
  }
};

export default {
  namespaced: true,
  state,
  actions,
  mutations,
  getters
};
