﻿import axios from "~/axios-client";

const state = {
  swapData: {
    type: "",
    additionalInformation: {},
    reason: {},
    troubleShootingInfo: {},
  },
  unitQualifications: [],
  unitHardwareTypes: [],
  troubleShootingData: [],
  swapChoices: [],
  validSwapUnits: [],
  currentUnits: [],
  swappedUnits: [],
  contractValidationData: [],
  issueValidationData: null,
  mainOfficeAddress: {}
};

const mutations = {
  updateSwapChoices(state, payload){
    state.swapChoices = payload;
  },
  updateSwapChoice(state, payload){
    let setData = false;
    for (let i = 0; i < state.swapChoices.length; i++) {
      const choice = state.swapChoices[i];
      if(choice.serialNumber == payload.serialNumber) {
        this._vm.$set(state.swapChoices, i, payload);
        setData = true;
      }
    }
    if(!setData){
      state.swapChoices.push(payload);
      this._vm.$set(state.swapChoices, state.swapChoices.length -1, payload);
    } 
  },
  updateCurrentUnits(state, payload) {
    state.currentUnits = payload;
  },
  updateValidSwapUnits(state, payload) {
    state.validSwapUnits = payload;
  },
  updateSwapType(state, payload) {
    state.swapData.type = payload;
  },
  updateSwapReason(state, payload) {
    state.swapData.reason =  payload;
  },
  updateTroubleShootingInfo(state, payload) {
    state.swapData.troubleShootingInfo = payload;
  },
  updateAdditionalInformation(state, payload) {
    state.swapData.additionalInformation = payload;
  },
  updateUnitQualifications(state, payload) {
    state.unitQualifications = payload;
  },
  updateUnitHardwareTypes(state, payload) {
    state.unitHardwareTypes = payload;
  },
  updateTroubleShootingData(state, payload) {
    state.troubleShootingData = payload;
  },
  updateContractValidationData(state, payload) {
    state.contractValidationData = payload.response;
  },
  updateIssueValidationData(state, payload) {
    state.issueValidationData = payload.response;
  },
  resetState(state) {
    state.swapData.type = "";
    state.swapData.reason = {};
    state.swapData.troubleShootingInfo = {};
    state.swapData.additionalInformation = {};
    state.swapChoices = [];
    state.unitHardwareTypes = [];
    state.validSwapUnits = [];
    state.currentUnits = [];
    state.contractValidationData = [];
    state.issueValidationData = null;
    state.troubleShootingData = {};
    state.unitQualifications = [];
  },
  updateMainOfficeAddress(state, payload) {
    state.mainOfficeAddress = payload;
  },
};

const actions = {
  setCurrentUnits({ commit }, payload) {
    commit("updateCurrentUnits", payload);
  },
  setValidSwapUnits({ commit }, payload) {
    commit("updateValidSwapUnits", payload);
  },
  setContractValidationData({ commit }, payload) {
    commit("updateContractValidationData", payload);
  },
  setIssueValidationData({ commit }, payload) {
    commit("updateIssueValidationData", payload);
  },
  setSwapType({ commit }, payload) {
    commit("updateSwapType", payload);
  },
  setSwapReason({ commit }, payload) {
    commit("updateSwapReason", payload);
  },
  setTroubleShootingInfo({ commit }, payload) {
    commit("updateTroubleShootingInfo", payload);
  },
  setAdditionalInformation({ commit }, payload) {
    commit("updateAdditionalInformation", payload);
  },
  resetSwapState({ commit }) {
    commit("resetState");
  },
  setSwapChoices({ commit }, payload){
    commit("updateSwapChoices", payload);
  },
  setSwapChoice({ commit }, payload){
    commit("updateSwapChoice", payload);
  },
  async troubleShootUnits({ commit }, payload) {
    const { data } = await axios.post(`/api/swap/mass/troubleshooting`, payload);
    commit("updateTroubleShootingData", data);
  },
  async getUnitQualifications({ commit }, payload) {
    const { data } = await axios.post(`/api/swap/mass/qualifiedUnitTypes`, payload.serialNumbers);
    commit("updateUnitQualifications", data);
  },
  async getUnitHardwareTypes({ commit }, payload) {
    const { data } = await axios.post(`/api/swap/mass/getUnitHardwareTypes`, payload.units.map(unit => unit.serialNumber));
    for (let i = 0; i < payload.units.length; i++) {
      const originalUnit = payload.units[i];
      var valueSet = false;
      for (let k = 0; k < data.length; k++) {
        const backendUnit = data[k];
        if(originalUnit.serialNumber == backendUnit.serialNumber){
          if(!backendUnit.unitType) data[k].unitType = originalUnit.unitTypeId;
          valueSet = true;
          break;
        }
      }
      if(!valueSet) data.push({serialNumber: originalUnit.serialNumber, unitType: originalUnit.unitTypeId});
    }
    commit("updateUnitHardwareTypes", data);
  },
  async getMainOfficeAddress({ commit }, payload) {
    if(payload.isMainOffice) {
      commit("updateMainOfficeAddress", {
        address: null,
        zip: null,
        city: null
      });
      return;
    }
    const { data } = await axios.get(`/api/customer?customerId=${payload.mainOfficeId}`);
    commit("updateMainOfficeAddress", {
      address: data.address,
      zip: data.zip,
      city: data.city
    });
  }
};

export default {
  namespaced: true,
  state,
  actions,
  mutations,
};
