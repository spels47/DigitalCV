﻿import axios from "~/axios-client";

const state = {
  siteSettings: {},
  loading: false,
};
const getters = {
  infoBannerSettings() {
    return state.siteSettings.siteSettingsInfoBanner;
  },
}
const mutations = {
  updateSettings(state, payload) {
    state.siteSettings = payload;
  },
  updateBannerSettings(state, payload) {
    state.siteSettings.siteSettingsInfoBanner = payload;
  }
};
const actions = {
  async retrieveSiteSettings(context) {
    let result = await axios.get(`/api/siteSettings`);
    this.commit("updateSettings", result.data)
  },
  async changeInfoBannerSettings(context, payload) {
    let infoBannerSettings = {
      Show: payload.show,
      Text: payload.text,
      ColorCode: payload.colorCode,
      UserRoles: payload.userRoles
    }
    await axios.post(`/api/siteSettings/infoBanner`, infoBannerSettings).then(response => {
      this.commit('updateSettings', response.data)
    })
  },

  async changeInfoBannerSettingsFromWebSocket(state, payload) {
    let bannerSetting = {};
    bannerSetting.show = payload.show;
    bannerSetting.text = payload.text;
    bannerSetting.colorCode = payload.colorCode;
    bannerSetting.userRoles = payload.userRoles;
    await this.commit('updateBannerSettings', bannerSetting);
  },

};

export default {
  state,
  actions,
  mutations,
  getters
};
