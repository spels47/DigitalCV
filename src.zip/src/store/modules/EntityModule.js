import axios from "~/axios-client";

const state = {
  dataBeingRetrieved: false,
  accounts: {
    items: [],
    headers: []
  },
  vehicles: {
    items: [],
    headers: []
  },
  equipmentList: {
    items: [],
    headers: []
  },
  dataSources: {
    items: [],
    headers: []
  },
  subscriptionList: {
    items: [],
    headers: []
  },
  auditList: {
    items: [],
    headers: []
  },
};

const getters = {};

const mutations = {
  updateDataBeingRetrieved(state, payload) {
    state.dataBeingRetrieved = payload;
  },
  updateAccounts(state, payload) {
    state.accounts.items = payload.items;
    state.accounts.headers = payload.headers;
  },
  updateVehicles(state, payload) {
    state.vehicles.items = payload.items;
    state.vehicles.headers = payload.headers;
  },
  updateEquipmentList(state, payload) {
    state.equipmentList.items = payload.items;
    state.equipmentList.headers = payload.headers;
  },
  updateDataSources(state, payload) {
    state.dataSources.items = payload.items;
    state.dataSources.headers = payload.headers;
  },
  updateSubscriptionList(state, payload) {
    state.subscriptionList.items = payload.items;
    state.subscriptionList.headers = payload.headers;
  },
  updateAuditList(state, payload) {
    state.auditList.items = payload.items;
    state.auditList.headers = payload.headers;
  }
};
const actions = {
  async retrieveAccounts(context, parameters) {
    context.commit("updateDataBeingRetrieved", true);
    context.commit("updateAccounts", {
      items: [],
      headers: []
    });
    try {
      let response = await axios.get(`/api/customer/details?customerId=${parameters}&type=account`);
      context.commit("updateAccounts", {
        items: response.data.data,
        headers: response.data.headers
      });
    } catch (ex) {
      this._vm.$eventBus.$emit("alert", { text: "Unable to fetch accounts at the moment", icon: "mdi-alert-circle", type: "error" });
    }
    context.commit("updateDataBeingRetrieved", false);
  },
  async retrieveVehicles(context, parameters) {
    context.commit("updateDataBeingRetrieved", true);
    context.commit("updateVehicles", {
      items: [],
      headers: []
    });
    try {
      let response = await axios.get(`/api/customer/details?customerId=${parameters}&type=vehicle`);
      context.commit("updateVehicles", {
        items: response.data.data,
        headers: response.data.headers
      });
    } catch (ex) {
      this._vm.$eventBus.$emit("alert", { text: "Unable to fetch vehicles at the moment", icon: "mdi-alert-circle", type: "error" });
    }
    context.commit("updateDataBeingRetrieved", false);
  },
  async retrieveAuditLog(context, parameters) {
    context.commit("updateDataBeingRetrieved", true);
    context.commit("updateAuditList", {
      items: [],
      headers: []
    });
    try {
      let response = await axios.get(`/api/customer/details?customerId=${parameters}&type=auditLog`);
      context.commit("updateAuditList", {
        items: response.data.data,
        headers: response.data.headers
      });
    } catch (ex) {
      this._vm.$eventBus.$emit("alert", { text: "Unable to fetch audit log at the moment", icon: "mdi-alert-circle", type: "error" });
    }
    context.commit("updateDataBeingRetrieved", false);
  },
  async retrieveEquipmentList(context, parameters) {
    context.commit("updateDataBeingRetrieved", true);
    context.commit("updateEquipmentList", {
      items: [],
      headers: []
    });
    let equipment = [];
    let miniAsEquipment = [];
    let headers = [];
    try {
      let res = await axios.get(`/api/customer/details?customerId=${parameters}&type=equipment`);
      equipment = res.data.data;
      headers = res.data.headers;
    } catch (ex) {
      this._vm.$eventBus.$emit("alert", { text: "Unable to fetch simcards at the moment", icon: "mdi-alert-circle", type: "error" });
    }

    try {
      let res = await axios.get(`/api/customer/details?customerId=${parameters}&type=mini-as-equipment`);
      miniAsEquipment = res.data.data;
      headers = res.data.headers;
    } catch (ex) {
      this._vm.$eventBus.$emit("alert", { text: "Unable to fetch minis at the moment", icon: "mdi-alert-circle", type: "error" });
    }

    context.commit("updateEquipmentList", {
      items: equipment.concat(miniAsEquipment),
      headers: headers
    });
    context.commit("updateDataBeingRetrieved", false);
  },
  async retrieveDataSources(context, parameters) {
    context.commit("updateDataBeingRetrieved", true);
    context.commit("updateDataSources", {
      items: [],
      headers: []
    });

    let simcards = [];
    let minis = [];
    let headers = [];
    try {
      let res = await axios.get(`/api/customer/details?customerId=${parameters}&type=simcard`);
      simcards = res.data.data;
      headers = res.data.headers;
    } catch (ex) {
      this._vm.$eventBus.$emit("alert", { text: "Unable to fetch simcards at the moment", icon: "mdi-alert-circle", type: "error" });
    }

    try {
      let res = await axios.get(`/api/customer/details?customerId=${parameters}&type=mini`);
      minis = res.data.data;
      headers = res.data.headers;
    } catch (ex) {
      this._vm.$eventBus.$emit("alert", { text: "Unable to fetch minis at the moment", icon: "mdi-alert-circle", type: "error" });
    }

    context.commit("updateDataSources", {
      items: simcards.concat(minis),
      headers: headers
    });
    context.commit("updateDataBeingRetrieved", false);
  },
  async retrieveSubscriptionList(context, parameters) {
    context.commit("updateDataBeingRetrieved", true);
    context.commit("updateSubscriptionList", {
      items: [],
      headers: []
    });
    try {
      let response = await axios.get(`/api/customer/details?customerId=${parameters}&type=subscription`);
      context.commit("updateSubscriptionList", {
        items: response.data.data,
        headers: response.data.headers
      });
    } catch (ex) {
      this._vm.$eventBus.$emit("alert", { text: "Unable to fetch subscriptions at the moment", icon: "mdi-alert-circle", type: "error" });
    }
    context.commit("updateDataBeingRetrieved", false);
  },
  async refreshFetchedEntities({ dispatch, state }, customerId) {
    let fetchDataPromises = [];

    if (state.accounts.items.length > 0) fetchDataPromises.push(dispatch("retrieveAccounts", customerId));
    if (state.vehicles.items.length > 0) fetchDataPromises.push(dispatch("retrieveVehicles", customerId));
    if (state.equipmentList.items.length > 0) fetchDataPromises.push(dispatch("retrieveEquipmentList", customerId));
    if (state.dataSources.items.length > 0) fetchDataPromises.push(dispatch("retrieveDataSources", customerId));
    if (state.subscriptionList.items.length > 0) fetchDataPromises.push(dispatch("retrieveSubscriptionList", customerId));

    await Promise.all(fetchDataPromises);
  }
};

export default {
  state,
  actions,
  mutations,
  getters
};
