﻿import axios from "~/axios-client";

const state = {
  fetchingTickets: false,
  tickets: []
};

const mutations = {
  updateFetchingTickets(state, payload) {
    state.fetchingTickets = payload;
  },
  replaceCustomerTickets(state, payload) {
    state.tickets = payload;
  },
  updateCustomerTickets(state, payload) {
    state.tickets.push(payload);
  }
};

const actions = {
  addTicketToList({ commit }, parameters) {
    commit("updateCustomerTickets", parameters);
  },
  async retrieveCustomerTickets({ commit }, parameters) {
    commit("updateFetchingTickets", true);
    commit("replaceCustomerTickets", []);

    const { data: tickets } = await axios.get(`/api/ticket/customer/${parameters}`);

    commit("replaceCustomerTickets", tickets);
    commit("updateFetchingTickets", false);
  },
};

export default {
  namespaced: true,
  state,
  actions,
  mutations,
};
