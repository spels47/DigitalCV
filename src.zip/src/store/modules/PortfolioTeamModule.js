﻿import axios from "~/axios-client";

const state = {
  allTeams: [],
  currentTeam: {},
  currentCountry: {},
  countries: [],
  myTeam: {},
  loading: false,
};
const getters = {};
const mutations = {
  setAllTeams(state, payload) {
    state.allTeams = [];
    state.allTeams = state.allTeams.concat(payload);
    state.allTeams.forEach(x => {
      if(state.countries.filter(z => z.teamName === x.country + ' Portfolios').length === 0)
        state.countries.push({teamName: x.country + ' Portfolios', _id: x.country, country: x.country})
    })
    if(!state.currentTeam._id) state.currentTeam = state.allTeams[0];
    state.myTeam = this.state.userSettings.portfolioTeam
  },
  setCurrentTeam(state, payload) {
    if(state.allTeams.filter(x => x._id === payload).length === 0){
      state.currentCountry = state.countries.find(x => x._id === payload);
      state.currentTeam = null;
    }
    else{
      state.currentTeam = state.allTeams.find(x => x._id === payload)
      state.currentCountry = null;
    }
  },
  toggleLoading(state, value) {
    state.loading = value;
  }
};
const actions = {
  async retrieveAllTeams(context) {
    context.commit("toggleLoading", true);
    let result = await axios.get(`/api/portfolio/teams/allTeams`);
    context.commit("toggleLoading", false);
    context.commit("setAllTeams", result.data);
  },
  selectTeam(context, payload) {
    context.commit("setCurrentTeam", payload);
  },
};

export default {
  namespaced: true,
  state,
  actions,
  mutations,
  getters
};
