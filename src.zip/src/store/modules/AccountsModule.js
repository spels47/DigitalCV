﻿import axios from "~/axios-client";
import moment from "moment";

const state = {
  customerId: 0,
  accountsInDepartment: {},
};
const actions = {
  getAccountsForDepartment(state, payload) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        this.customerId = payload
        if (this.customerId === 0) return;
        axios
          .get(`/api/customer/details?customerId=${this.customerId}&type=account`)
          .then(response => {
            this.commit("addCurrentAccounts", response.data);
            resolve();
          }).catch(() => reject());
      }, 1000)
    })
  }
};
const mutations = {
  addCurrentAccounts(state, payload) {
    state.vehiclesInDepartment = payload;
  },
};
const getters = {

};

export default {
  state,
  actions,
  mutations,
  getters
};
