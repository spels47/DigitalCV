﻿import axios from "~/axios-client";

const state = {
  sidebarState: false,
  sidebar: "",
  selectedAccount: {},
  selectedVehicle: {},
  selectedEquipment: {},
  selectedDataSource: {},
  selectedSubscriptions: [],
};

const getters = {
  getSidebarState(state) {
    return state.sidebarState;
  }
};

const mutations = {
  openSidebar(state, payload) {
    state.sidebar = payload.sidebarType;
    state.sidebarState = true;
  },
  updateSidebarState: function(state, value) {
    if (!value) {
      state.sidebar = "";
    }
    state.sidebarState = value;
  },
  updateAccount(state, payload) {
    state.selectedAccount = payload;
  },
  updateVehicle(state, payload) {
    state.selectedVehicle = payload;
  },
  updateEquipment(state, payload) {
    state.selectedEquipment = payload;
  },
  updateDataSource(state, payload) {
    state.selectedDataSource = payload;
  },
  updateSubscriptions(state, payload) {
    state.selectedSubscriptions = payload;
  }
};
const actions = {
  async retrieveAccount(context, parameters) {
    context.commit("updateAccount", {});
    let res = await axios.get(`/api/user/${parameters.id}`);
    context.commit("updateAccount", res.data);
  },
  async retrieveVehicle(context, parameters) {
    context.commit("updateVehicle", {});
    let res = await axios.get(`/api/vehicle/${parameters.id}`);
    context.commit("updateVehicle", res.data);
  },
  async retrieveEquipment(context, parameters) {
    context.commit("updateEquipment", {});
    if (isNaN(parameters.id) && (parameters.id.startsWith("MUM") || parameters.id.startsWith("AM"))) {
      let res = await axios.get(`/api/equipment/mini/${parameters.id}`);
      context.commit("updateEquipment", res.data);
    } else {
      let res = await axios.get(`/api/equipment/${parameters.id}`);
      context.commit("updateEquipment", res.data);
    }
  },
  async retrieveDataSource(context, parameters) {
    context.commit("updateDataSource", {});
    await axios.get(`/api/datasource/${parameters.type}/${parameters.id}`).then(res => context.commit("updateDataSource", res.data));
  },
  async retrieveSubscriptionsAsync(context, parameters) {
    context.commit("updateSubscriptions", {});
    let res = await axios.get(`/api/subscription/subscriptions?clientId=${parameters.erpClientId}&customerId=${parameters.erpCustomerId}&contractNumber=${parameters.id}`);
    context.commit("updateSubscriptions", res.data);
  },
  async updateAssetIsMountedState(context, parameters) {
    await axios.put(`/api/asset/${parameters.id}/setIsMountedState/${parameters.isMounted}`);
    if (parameters.vehicleId) await context.dispatch("audit", { source: "vehicle", entityId: parameters.vehicleId, message: "Changed Active State", oldValue: !parameters.isMounted, newValue: parameters.isMounted });
    else await context.dispatch("audit", { source: "equipment", entityId: parameters.id, message: "Changed Active State", oldValue: !parameters.isMounted, newValue: parameters.isMounted });
  }
};

export default {
  state,
  actions,
  mutations,
  getters
};
