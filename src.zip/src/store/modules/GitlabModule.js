import axios from "~/axios-client";

const state = {
  linkedGitlabIssue: {},
  issueIsMoved: false,
  gitlabIssueBeingRetrieved: false,
  newIssueTitle: "",
  newIssueDescription: "",
  newIssueDueDate: null,
  newIssueType: "",
  newIssueMilestone: null,
  newIssueIsConfidential: false,
  newIssueDiscussionLocked: false,
  newIssueLabels: null,
};

const getters = {};

const mutations = {
  updateLinkedGitlabIssue(state, payload) {
    state.linkedGitlabIssue = payload;
  },
  updateIssueIsMoved(state, payload) {
    state.issueIsMoved = payload;
  },
  updateGitlabIssueBeingRetrieved(state, payload) {
    state.gitlabIssueBeingRetrieved = payload;
  }
};
const actions = {
  async fetchGitlabIssueFromUrl(context, parameters) {
    context.commit("updateGitlabIssueBeingRetrieved", true);
    return await axios
      .get(`/api/gitlab/projectIssue`, {
        params: {
          url: parameters.url
        }
      }).then(res => {
        context.commit("updateLinkedGitlabIssue", res.data);
        context.commit("updateIssueIsMoved", res.data.movedToId !== null);
      }).finally(() =>   context.commit("updateGitlabIssueBeingRetrieved", false));
  },
  async fetchSpecificIssueFromId(context, parameters) {
    context.commit("updateGitlabIssueBeingRetrieved", true);
    return await axios
      .get(`/api/gitlab/projectIssue/${parameters.projectId}/${parameters.issueId}`)
      .then(async res => {
        context.commit("updateLinkedGitlabIssue", res.data);
        context.commit("updateIssueIsMoved", res.data.movedToId !== null);
      })
      .finally(() => context.commit("updateGitlabIssueBeingRetrieved", false))
  },
  async postCommentOnGitlabIssue(context, parameters) {
    return await axios.post(`/api/gitlab/projectIssue/${state.linkedGitlabIssue.projectId}/${state.linkedGitlabIssue.issueId}/notes?body=${parameters.body}`);
  },
  async editGitlabIssue(context, parameters) {
    return await axios.put(`api/gitlab/projectIssue/${parameters.projectId}/${parameters.issueId}`, {
      title: state.newIssueTitle,
      description: state.newIssueDescription,
      milestone_id: state.newIssueMilestone?.id ?? 0,
      due_date: state.newIssueDueDate ?? "",
      issue_type: state.newIssueType.toLowerCase(),
      labels: state.newIssueLabels ?? [],
      confidential: state.newIssueIsConfidential,
      discussion_locked: state.newIssueDiscussionLocked
    });
  }
};

export default {
  state,
  actions,
  mutations,
  getters
};
