import Vue from "vue";
import Vuex from "vuex";
import gtm from "~/gtm";
import { vuexOidcCreateStoreModule } from "vuex-oidc";
import { WebStorageStateStore } from "oidc-client";
import { getIdentityServerConfig } from "~/config/config-service";
import ReleaseManagementModule from "~/store/modules/ReleaseManagementModule";
import VehicleModule from "@/store/modules/VehicleModule";
import SidebarModule from "@/store/modules/SidebarModule";
import EntityModule from "@/store/modules/EntityModule";
import JiraModule from "@/store/modules/JiraModule";
import GitlabModule from "@/store/modules/GitlabModule";
import CustomerStatisticsModule from "@/store/modules/CustomerStatisticsModule";
import SiteSettingsModule from "@/store/modules/SiteSettingsModule";
import CustomerModule from "@/store/modules/CustomerModule";
import WorklistModule from "@/store/modules/WorklistModules/WorklistModule";
import MySwapsModule from "@/store/modules/WorklistModules/MySwapsModule";
import PortfolioTeamModule from "@/store/modules/PortfolioTeamModule";
import SwapHandlingWizardModule from "@/store/modules/SwapHandlingWizardModule";
import CustomerTicketsModule from "@/store/modules/CustomerTicketsModule";
import axios from "~/axios-client";
import { mapOidcProfile, getOidcUser, getOidcUsername } from "~/helpers/oidc-mapper";

const configIdentityServer = getIdentityServerConfig();
let userSettingsDebounceHolder = null;

Vue.use(Vuex);

const store = new Vuex.Store({
  state: {
    currentUserRoles: {},
    rolesLoaded: false,
    vuetifyDarkMode: false,
    userSettings: {},
    customerStatistics: {}
  },
  mutations: {
    updateCurrentUserRoles(state, data) {
      let roleDict = {};
      let roles = data || [];
      roles.forEach(role => (roleDict[role] = true));
      state.currentUserRoles = roleDict;
    },
    updateRolesLoaded(state) {
      state.rolesLoaded = true;
    },
    updateVuetifyDarkMode(state, payload) {
      state.vuetifyDarkMode = payload;
    },
    userSettings_Update(state, data) {
      state.userSettings = data;
    },
    userSettings_AddDefaultTable(state, payload) {
      state.userSettings.defaultTable = payload;
    },
    userSettings_SetDefaultCountry(state, payload) {
      state.userSettings.defaultCountry = payload;
    },
    userSettings_AddFavorite(state, favorite) {
      state.userSettings.favorites.push(favorite);
    },
    userSettings_RemoveFavorite(state, favorite) {
      let indexToRemove = state.userSettings.favorites.findIndex(x => x.type === favorite.type && x.id === favorite.id);
      state.userSettings.favorites.splice(indexToRemove, 1);
    }
  },
  actions: {
    async waitForRolesLoaded(context) {
      return new Promise((resolve, reject) => {
        // Resolve immediately if roles already loaded
        if (context.state.rolesLoaded) {
          resolve();
          return;
        }

        // Poll every 10ms until roles loaded
        let rounds = 0;
        let intervalHolder = setInterval(() => {
          if (context.state.rolesLoaded) {
            clearInterval(intervalHolder);
            resolve();
            return;
          }
          rounds++;
          if (rounds > 3000) {
            // Give up after 30s
            clearInterval(intervalHolder);
            reject();
          }
        }, 10);
      });
    },
    async toggleFavorite({ commit, state }, payload) {
      if (state.userSettings.favorites.some(x => x.type === payload.type && x.id === payload.id)) {
        commit("userSettings_RemoveFavorite", payload);
      } else {
        commit("userSettings_AddFavorite", payload);
      }
      await axios.post("api/UserSettings/favorites", state.userSettings.favorites).catch(() => this._vm.$eventBus.$emit("alert", { template: "api-error" }));
    },
    addFavorite(context, payload) {
      context.commit("userSettings_AddFavorite", payload);
    },
    removeFavorite(context, payload) {
      context.commit("userSettings_RemoveFavorite", payload);
    },
    async audit(context, data) {
      const payload = {
        username: context.getters.currentUser.username,
        name: context.getters.currentUser.name,
        timestamp: new Date(),
        source: data.source,
        entityId: data.entityId != null ? data.entityId + "" : "",
        message: data.message,
        oldValue: data.oldValue != null ? data.oldValue + "" : "",
        newValue: data.newValue != null ? data.newValue + "" : ""
      };
      await axios.post(`/api/audit`, payload);
    },
    async setDefaultCountry(context, data) {
      axios.post(`/api/UserSettings/setDefaultCountry/${data}`).then(_ => {
        this.commit("userSettings_SetDefaultCountry", data);
      });
    },
    async setCurrentUserRoles(context) {
      let rolesRes = await axios.get(`/api/user-roles`);
      context.commit("updateCurrentUserRoles", rolesRes.data);
    },
    setUrlParameter(context, data) {
      // data should contain: {name: String, value: String})
      if (!data) return;

      let url = new URL(window.location);
      url.searchParams.delete(data.name);
      if (data.value != null) url.searchParams.append(data.name, data.value);
      history.pushState(null, null, url.href);
    },
    async userSettings_Fetch(context) {
      // debounced to avoid fetching multiple times when loading multiple components at once
      clearTimeout(userSettingsDebounceHolder);
      userSettingsDebounceHolder = setTimeout(async () => {
        const response = await axios.get("/api/UserSettings");
        context.commit("userSettings_Update", response.data);
      }, 50);
    }
  },
  modules: {
    oidcStore: vuexOidcCreateStoreModule(
      {
        authority: configIdentityServer.authority,
        client_id: configIdentityServer.clientId,
        redirect_uri: configIdentityServer.redirectUri,
        response_type: "code",
        scope: `openid ${configIdentityServer.profileScope} ${configIdentityServer.backendScope}`,
        post_logout_redirect_uri: configIdentityServer.postLogoutRedirectUri,
        silent_redirect_uri: configIdentityServer.silentRedirectUri,
        accessTokenExpiringNotificationTime: 10,
        automaticSilentRenew: true,
        filterProtocolClaims: true,
        loadUserInfo: true,
        monitorSession: false,
        userStore: new WebStorageStateStore({
          store: window.localStorage
        })
      },
      {
        namespaced: true,
        dispatchEventsOnWindow: true
      }
    ),
    ReleaseManagementModule: ReleaseManagementModule,
    VehicleModule: VehicleModule,
    SidebarModule: SidebarModule,
    CustomerStatisticsModule: CustomerStatisticsModule,
    EntityModule: EntityModule,
    JiraModule: JiraModule,
    GitlabModule: GitlabModule,
    SiteSettingsModule: SiteSettingsModule,
    CustomerTicketsModule: CustomerTicketsModule,
    WorklistModule: WorklistModule,
    MySwapsModule: MySwapsModule,
    PortfolioTeamModule: PortfolioTeamModule,
    customerStore: CustomerModule,
    SwapHandlingWizardModule: SwapHandlingWizardModule
  },
  getters: {
    currentUser: (state, getters) => {
      let user = getOidcUser(getters);
      return user ? mapOidcProfile(user) : null;
    },
    currentUsername: (state, getters) => getters.currentUser?.username,
    currentUserDepartmentName: (state, getters) => getters.currentUser?.departmentName,
    currentUserDivisionName: (state, getters) => getters.currentUser?.divisionName,
    impersonationContext: (state, getters) => getters.currentUser?.impersonationContext,
    isImpersonating: (state, getters) => !!getters["impersonationContext"],
    impersonationSubject: (state, getters) => (getters["isImpersonating"] ? getters["impersonationContext"].sub : 0),
    impersonationSubjectName: (state, getters) => (getters["isImpersonating"] ? getters["impersonationContext"].name : ""),
    darkMode: state => state.vuetifyDarkMode
  }
});

store.subscribe(async (mutation, state) => {
  switch (mutation.type) {
    case "oidcStore/setOidcAuth": {
      if (state.rolesLoaded) return;

      await store.dispatch("setCurrentUserRoles");
      gtm.setCurrentUser(state?.oidcStore?.user?.email);
      store.commit("updateRolesLoaded");
    }
  }
});

export default store;
