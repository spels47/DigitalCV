<template>
  <div class="no-result-container">
    <img v-if="type == 'data'" class="large-bottom-margin" src="../assets/no-result.svg" alt="No Result">
    <img v-if="type == 'search'" class="large-bottom-margin" src="../assets/no-search-result.svg" alt="No Result">
    <h2 class="abt-text-header2 small-bottom-margin">{{title}}</h2>
    <span class="large-bottom-margin text">{{description}}</span>
    <abt-button v-if="showButton == true" type="primary" @click="resetSearch()">{{$t('noResult.clearSearch')}}</abt-button>
  </div>
</template>

<script>
export default {
  name: 'NoResult',
  emits: [
      "clearSearch"
  ],
  props: {
    title: "",
    description: "",
    showButton: null,
    type: ""
  },
  data () {
      return {
          showUnassignedOnly: false
      }
  },
  methods: {
      resetSearch(){
        this.$emit("clearSearch", null);
      }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.no-result-container{
  display:flex;
  flex-direction: column;
  align-items: center;
  justify-content: space-between;
  width: 481px;
  padding-top: 2.5rem;
}
.large-bottom-margin{
  padding-bottom: 1.5rem;
}
.small-bottom-margin{
  padding-bottom: 1rem;
}
.text{
  text-align: center;
}
</style>