<template>
  <FilterDialog :title="$t('filter.dialogLabel')" :locale="locale" :canApply="canApply" :canClear="canClear" @apply="onApply" @clear="onClear">
    <template #filter="{ openFilterTrigger }">
      <OpenFilterButton :locale="locale" :appliedFilterCounter="appliedFilterCounter" :isLoadingData="isLoadingDriverData" @click="openFilterTrigger"></OpenFilterButton>
    </template>
    <template #custom>
        <CustomFilter :customFilterData="customFilterData" :startingValues="customFilter" @Apply="customFilter = $event" :clearCounter="clearCounter"></CustomFilter>
    </template>
  </FilterDialog>
</template>

<script lang="ts">
import { computed, defineComponent, PropType, ref, toRefs } from 'vue';
import { FilterDialog, OpenFilterButton, DepartmentFilter, useDepartmentFilter, Department } from '@abax/tuxedo';
import { AppliedFiltersDialog } from '../assets/abax-tuxedo';
import useCustomFilterState from '../assets/abax-tuxedo';
import '@abax/tuxedo/dist/style.css';
import CustomFilter from './CustomFilter.vue';

export default defineComponent({
    name: 'FilterDialog2',
    components: {
      FilterDialog,
      DepartmentFilter,
      OpenFilterButton,
      CustomFilter
    },
    props: {
      appliedFilters: {
        type: Object as PropType<AppliedFiltersDialog>,
        required: true,
      },
      isLoadingData: {
        type: Boolean,
        default: false,
      },
      title: {
        type: String,
        required: true,
      },
      locale: {
        type: String,
        required: true,
      },
      customFilterData: {
        type: Object,
        required: true,
      }
    },
    emits: ['update'],
    setup(props, { emit }) {
      const {
        appliedFilters,
        isLoadingData: isLoadingDriverData,
        title,
        locale,
      } = toRefs(props);
      const initialCustomFilterValues = {
        userTags: appliedFilters.value?.customFilter?.userTags ?? [],
        installationTags: appliedFilters.value?.customFilter?.installationTags ?? [],
        types: appliedFilters.value?.customFilter?.types ?? []
      };

      const appliedFilterCounter = computed(() => {
        var installation = appliedFilters.value?.customFilter?.installationTags?.length ?? 0;
        var user = appliedFilters.value?.customFilter?.userTags?.length ?? 0;
        var types = appliedFilters.value?.customFilter?.types?.length ?? 0
        const customFilterCounter = user + installation + types;
        return customFilterCounter;
      });

      const {
        customFilter,
        isDefault: isCustomFilterInDefaultState,
        isDirty: isCustomFilterDirty,
        commit: commitCustomFilter,
        reset: resetCustomFilter,
      } = useCustomFilterState(
        initialCustomFilterValues
      );

      const createNewFilter = () => {
        const newActiveFilter: AppliedFiltersDialog = {
          customFilter: customFilter.value
        };
        emit('update', newActiveFilter);
      };

      var clearCounter = ref(0);
      return {
        customFilter,
        filterLocale: locale,
        filterTitle: title,
        appliedFilterCounter,
        isLoadingDriverData,
        clearCounter,
        canClear: computed(
          () => !isCustomFilterInDefaultState.value,
        ),
        canApply: computed(
          () => isCustomFilterDirty.value,
        ),
        onClear() {
          resetCustomFilter();
          clearCounter.value = clearCounter.value + 1;
        },
        onApply() {
          createNewFilter();
          commitCustomFilter();
        },
      };
    },
  });
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
  .filter-dialog {
    position: relative;
  }
</style>