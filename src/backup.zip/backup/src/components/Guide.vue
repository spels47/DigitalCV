<template>
  <abt-menu class="guide-container">
    <div class="top-bar hideMobile">
      <h3 class="abt-text-header3 title"><span v-html="findTextMatch(title)"></span></h3>
      <div>
        <abt-tag class="tag-margin" type="primary" pill v-for="(tag, index) in tags" :key="index"><span v-html="findTextMatch(tag.name)"></span></abt-tag>
        <abt-tag class="tag-margin" type="dark" filled pill v-if="type == 'Installation guide'"><span v-html="findTextMatch(type)"></span></abt-tag>
        <abt-tag class="tag-margin" type="accent" filled pill v-if="type == 'User guide'"><span v-html="findTextMatch(type)"></span></abt-tag>
      </div>
    </div>
    <div class="showMobile">
      <h5 class="abt-text-header5 title"><span v-html="findTextMatch(title)"></span></h5>
      <div class="mobile-left-padding">
        <abt-tag size="small" class="tag-margin" type="primary" pill v-for="(tag, index) in tags" :key="index"><span v-html="findTextMatch(tag.name)"></span></abt-tag>
        <abt-tag size="small" class="tag-margin" type="dark" filled pill v-if="type == 'Installation guide'"><span v-html="findTextMatch(type)"></span></abt-tag>
        <abt-tag size="small" class="tag-margin" type="accent" filled pill v-if="type == 'User guide'"><span v-html="findTextMatch(type)"></span></abt-tag>
      </div>
    </div>
    <div class="description" >
      <span v-html="findTextMatch(description)"></span>
    </div>
    <div class="footer">
      <abt-button size="small" :href="link" target="_blank" type="primary-ghost"><u>{{$t("openGuide")}}</u><abt-icon slot="suffix" name="far-external-link-alt"></abt-icon></abt-button>
    </div>
  </abt-menu>
</template>

<script>
export default {
  name: 'Guide',
  props: {
    title: "",
    description: "",
    link: null,
    tags: null,
    type: null,
    highlightText: ""
  },
  methods: {
    findTextMatch(text){
      if(text?.length < 3 && this.highlightText?.length == 0) return text;
      if(text.toLowerCase().includes(this.highlightText?.toLowerCase())){
        var startIndex = text.toLowerCase().indexOf(this.highlightText.toLowerCase());
        var keyword = text.substring(startIndex, this.highlightText.length + startIndex);
        return text.replaceAll(keyword, `<b>${keyword}</b>`);
      }
      else return text;
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.guide-container{
  display: flex;
  flex-direction: column;
  width: 100%;
  min-height: 200px;
  height: 200px;
  background-color: var(--abt-panel-background-color);
  border: solid 1px var(--abt-panel-border-color);
  border-radius: var(--abt-border-radius-medium);
  padding-top: 1rem;
  padding-right: 1rem;
  padding-bottom: 1rem;
  overflow: hidden;
}
.guide-container:hover{
  border: solid 2px var(--abt-color-primary-brighter);
}
.guide-container + .guide-container{
  margin-top: 1rem;
}
.top-bar{
  display: flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  padding-left: 1rem;
  flex-wrap: nowrap;
  overflow: hidden;
}
.title{
  max-width: 50%;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.description{
  margin-top: 1rem;
  padding-left: 1rem;
  height: 60px;
  width: 100%;
  overflow: hidden;
}
.footer{
  margin-top: 1rem;
}
.tag-margin{
  margin-left: 5px;
}
@media only screen and (max-width: 768px) { 
  .guide-container{
    min-height: 200px;
    height: 200px;
  }
  .top-bar{
    display: flex;
    flex-direction: row;
    justify-content: space-between;
    align-items: center;
    padding-left: 1rem;
    flex-wrap: wrap;
    overflow: hidden;
  }
  .title{
    max-width: 100%;
    padding-left: 1rem;
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
  .description{
    margin-top: 1rem;
    padding-left: 1rem;
    height: 60px;
    width: 100%;
    overflow: hidden;
  }
  .footer{
    margin-top: 1rem;
  }
  .tag-margin{
    margin-left: 0;
  }
  .tag-margin + .tag-margin{
    margin-left: 5px;
  }
  .hideMobile{
    display: none;
  }
  .mobile-left-padding{
    padding-left: 1rem;
  }
} 
@media only screen and (max-width: 360px) { 
  .search{
    margin-left: 0;
  }
}
@media only screen and (min-width: 769px) {   
  .showMobile{   
    display: none;
  }   
}
</style>