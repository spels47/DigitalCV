<template>
  <div @dragover.prevent @drop.prevent>
    <div id="uploader-container" class="uploader-container" @dragover="toggleDragoverStyle(true)" @dragleave="toggleDragoverStyle(false)" @drop="chooseFile($event); toggleDragoverStyle(false)">
      <span>
        <abt-icon class="icon-padding" name="far-upload"></abt-icon>
        {{$t('file.drag')}} <span class='uploader-button' @click='onPickFile()'>{{$t('file.browse')}}</span>
      </span>
      <input id="fileuploader" type="file" style="display: none" accept="image/*,.doc,.xls,.xlsx,.csv,.pdf,.txt,.docx,.xml" @change="onFilePicked($event)"/>
    </div>
    <span class="abt-text-label">{{$t("file.supportedFiles")}}: {{getFileExtensionsForPresentation()}}</span>
    <File v-for="file in Files" :key="file.name" :Filename="file.name" @remove="removeFile($event)"></File>
  </div>
</template>

<script>
import File from './File.vue';

export default {
  name: 'FileUploader',
  components: {
      File
  },
  props: {
    Type: "",
    Text: "",
    SubTypes: null
  },
  emits: [
      "select",
      "error"
  ],
  data () {
      return {
        imageUrl: null,
        Files: [],
        Base64Files: [],
        ValidFileExtensions: [
          "jpg",
          "png",
          "webp",
          "gif",
          "doc",
          "docx",
          "xls",
          "xlsx",
          "csv",
          "pdf",
          "txt",
          "xml"
        ]
      }
  },
  methods: {
    emitFiles(files){
      this.$emit("select", files);
    },
    async chooseFile(event) {
      const files = event.dataTransfer.files;
      await this.putFileInArray(files);
    },
    onPickFile(){
      document.getElementById("fileuploader").click();
    },
    async onFilePicked(event){
      const files = event.target.files;
      await this.putFileInArray(files);
    },
    async putFileInArray(files){
      const fileReader = new FileReader();
      
      fileReader.addEventListener('load', () => {
        this.imageUrl = fileReader.result
      })
      if(!this.validateFileExtension(files[0])){
        let nameArray = files[0].name.split('.');
        let error = {
          type: "extension",
          data: nameArray[nameArray.length -1]
        }
        this.$emit("error", error)
      }
      else if(!this.validateFileSize(files[0])){
        let error = {
          type: "size",
          data: files[0].size
        }
        this.$emit("error", error);
      }
      else if(this.duplicateFile(files[0])) {
        let error = {
          type: "duplicate",
          data: files[0].name
        }
        this.$emit("error", error);
      }
      else {
        let baseFile = {FileName: files[0].name, Data: await this.getBase64(files[0])};
        this.Base64Files.push(baseFile);
        this.Files.push(files[0]);
        if(!this.validateFileSizeForAllFiles()){
          let error = {
            type: "all-size",
            data: this.sumFileSize()
          }
          this.$emit("error", error);
          this.Files.pop();
          this.Base64Files.pop();
        }
        else this.emitFiles(this.Base64Files);
      }
    },
    async getBase64(file) {
      return new Promise(function(resolve, reject) {
        var reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = function () {
          resolve(reader.result);
        };
        reader.onerror = function (error) {
          console.error('Error: ', error);
          reject();
        };
      });
    },
    toggleDragoverStyle(toggle){
      if(toggle) document.getElementById("uploader-container").classList.add("uploader-container-dragover");
      else document.getElementById("uploader-container").classList.remove("uploader-container-dragover");
    },
    duplicateFile(file){
      for (let i = 0; i < this.Files.length; i++) {
        const currentFile = this.Files[i];
        if(currentFile.name == file.name) return true;
      }
      return false;
    },
    validateFileExtension(file){
      var filenameArray = file.name.split('.');
      var fileExtension = filenameArray[filenameArray.length -1].toLowerCase();
      if(this.ValidFileExtensions.includes(fileExtension)) return true;
      else return false;
    },
    validateFileSize(file){
      if(file.size > 10000000) return false;
      else return true;
    },
    sumFileSize(){
      let totalSize = 0;
      for (let i = 0; i < this.Files.length; i++) {
        const file = this.Files[i];
        totalSize += file.size;
      }
      return totalSize;
    },
    validateFileSizeForAllFiles(){
      let totalSize = this.sumFileSize();
      if(totalSize > 25000000) return false;
      else return true;
    },
    removeFile(file){
      for (let i = 0; i < this.Files.length; i++) {
        const currentFile = this.Files[i];
        if(currentFile.name == file) this.Files.splice(i, 1);
      }
    },
    getFileExtensionsForPresentation(){
      var result = "";
      for (let i = 0; i < this.ValidFileExtensions.length; i++) {
        const extension = this.ValidFileExtensions[i];
        result += `.${extension}, `;
      }
      return result.slice(0, -2);
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .uploader-container{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    width: 100%;
    min-height: 56px;
    height: 56px;
    background-color: var(--abt-panel-background-color);
    border: dashed 1px var(--abt-panel-border-color);
    border-radius: var(--abt-border-radius-medium);
    padding: 1rem;
    overflow: hidden;
  }
  .uploader-container-dragover{
    border: dashed 2px var(--abt-color-primary);
  }
  .uploader-button{
    text-decoration-line: underline;
    text-decoration-color: var(--abt-color-primary);
    color: var(--abt-color-primary);
  }
  .uploader-button:hover{
    cursor: pointer;
  }
  .icon-padding{
    padding-right: 8px;
  }
</style>