<template>
  <div class="label-user-select">
    <abt-input type="text" filled :label="fieldIsObligatory == true ? label + '*' : label" :placeholder="placeholder" :status="showError ? 'error' : ''" :status-message="nameErrorMessage" :value="nameInput" @blur="checkShowError" @input="nameInput = $event.target.value; validateName();" :disabled="loadingStart == null || loadingStart == true"></abt-input>
  </div>
</template>

<script>
export default {
  name: 'NameInputField',
  props: {
    label: "",
    placeholder: "",
    startingValue: "",
    ASCIIOnly: null,
    fieldIsObligatory: null,
    loadingStart: null
  },
  emits: [
      "nameInput",
      "nameIsValid"
  ],
  data () {
      return {
          nameInput: '',
          nameIsValid: false,
          showError: false,
          nameErrorMessage: this.$t('nameInputFieldComponent.nameErrorMessage'),
          setStartupValue: false
      }
  },
  methods: {
      validateName() {
        var nameRegex = /^.{2,50}$/;
        var ASCIIRegex = /^[\x00-\x7F]*$/;
        if(((this.nameInput == null || this.nameInput == "" || this.nameInput?.trim()?.length == 0) && !this.fieldIsObligatory) || this.nameInput?.trim().match(nameRegex) && (!this.ASCIIOnly || this.nameInput?.trim().match(ASCIIRegex))) {
          this.nameIsValid = true;
          this.showError = false;
        }
        else this.nameIsValid = false;
        this.$emit("nameInput", this.nameInput?.trim());
        this.$emit("nameIsValid", this.nameIsValid);
      },
      checkShowError(){
        if(!this.nameIsValid) this.showError = true;
      }
  },
  mounted: function () {
    this.nameInput = this.startingValue?.trim() ?? '';
    this.validateName();
  },
  watch: {
    startingValue: function (newValue, oldValue){
      if(newValue != oldValue) {
        this.nameInput = this.startingValue?.trim();
        this.validateName();
      }
    },
    fieldIsObligatory: function (newValue, oldValue){
      if(newValue != oldValue) this.validateName();
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.label-user-select{
    user-select:none;
}
</style>
