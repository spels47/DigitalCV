<template>
  <div class="label-user-select">
    <abt-input type="text" filled :label="fieldIsObligatory == true ? label + '*' : label" :placeholder="placeholder" :status="showError ? 'error' : ''" :status-message="invoiceNumberErrorMessage" :value="invoiceNumberInput" @blur="checkShowError()" @input="invoiceNumberInput = $event.target.value; validateInvoiceNumber();" :disabled="loadingStart == null || loadingStart == true"></abt-input>
  </div>
</template>

<script>
export default {
  name: 'InvoiceNumberInputField',
  props: {
    label: "",
    startingValue: "",
    fieldIsObligatory: null,
    loadingStart: null,
    placeholder: null
  },
  emits: [
      "invoiceNumberInput",
      "invoiceNumberIsValid"
  ],
  data () {
      return {
          invoiceNumberInput: '',
          invoiceNumberIsValid: false,
          showError: false,
          invoiceNumberErrorMessage: this.$t('invoiceNumberInputFieldComponent.errorMessage'),
          setStartupValue: false
      }
  },
  methods: {
      validateInvoiceNumber() {
        var InvoiceFormat = /^.{4,50}$/;
        if(((this.invoiceNumberInput == null || this.invoiceNumberInput == "" || this.invoiceNumberInput?.trim()?.length == 0) && !this.fieldIsObligatory) || this.invoiceNumberInput?.trim().match(InvoiceFormat)) {
          this.invoiceNumberIsValid = true;
          this.showError = false;
        }
        else this.invoiceNumberIsValid = false;
        this.$emit("invoiceNumberInput", this.invoiceNumberInput?.trim());
        this.$emit("invoiceNumberIsValid", this.invoiceNumberIsValid);
      },
      checkShowError(){
        if(!this.invoiceNumberIsValid) this.showError = true;
      }
  },
  mounted: function () {
    this.invoiceNumberInput = this.startingValue?.trim() ?? '';
    this.validateInvoiceNumber();
  },
  watch: {
    startingValue: function (newValue, oldValue){
      if(newValue != oldValue) {
        this.invoiceNumberInput = this.startingValue?.trim();
        this.validateInvoiceNumber();
      }
    },
    fieldIsObligatory: function (newValue, oldValue){
      if(newValue != oldValue) this.validateInvoiceNumber();
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.label-user-select{
    user-select:none;
}
</style>
