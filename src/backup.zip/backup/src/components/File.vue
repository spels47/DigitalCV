<template>
  <div id="file-container" class="file-container">
    <div class="same-line">
      <div class="ellipsis-text">
        <abt-icon class="icon-padding" name="far-file-pdf"></abt-icon>
        <span class="ellipsis-text">{{Filename}}</span>
      </div>
      <abt-icon class="icon-button" name="fas-times" @click="emitRemove()"></abt-icon>
    </div>
  </div>
</template>

<script>
export default {
  name: 'File',
  props: {
    Filename: ""
  },
  emits: [
      "remove"
  ],
  data () {
      return {
        imageUrl: null
      }
  },
  methods: {
    emitRemove(){
      this.$emit("remove", this.Filename);
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
  .file-container{
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-content: space-between;
    width: 100%;
    min-height: 38px;
    height: 38px;
    background-color: var(--abt-panel-background-color);
    border: dashed 1px var(--abt-panel-border-color);
    border-radius: var(--abt-border-radius-medium);
    margin-top: 1rem;
    padding-left: 1rem;
    padding-right: 1rem;
    overflow: hidden;
  }
  .file-container-dragover{
    border: dashed 2px var(--abt-color-primary);
  }
  .file-container + .file-container{
    margin-top: 4px;
  }
  .uploader-button{
    text-decoration-line: underline;
    text-decoration-color: var(--abt-color-primary);
    color: var(--abt-color-primary);
  }
  .uploader-button:hover{
    cursor: pointer;
  }
  .icon-padding{
    padding-right: 8px;
  }
  .icon-button{
    color: var(--abt-color-danger);
  }
  .icon-button:hover{
    cursor: pointer;
  }
  .same-line{
    display:flex;
    flex-direction: row;
    flex-wrap: nowrap;
    width: 100%;
    justify-content: space-between;
  }
  .ellipsis-text{
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
  }
</style>