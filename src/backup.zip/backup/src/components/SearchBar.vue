<template>
  <abt-input :disabled="loading" :value="searchInput" @keydown="checkIfsearchIsEmpty($event); hitEnter($event);" @input="searchInput = $event.target.value; Search()" autocomplete="off" class="search" :placeholder="searchPlaceHolder" size="small" pill>
    <abt-icon name="far-search" slot="prefix"></abt-icon>
    <abt-icon v-show="searchInput.length > 0" @click="resetSearch()" name="far-times-circle" slot="suffix"></abt-icon>
  </abt-input>
</template>

<script>
export default {
  title: 'SearchBar',
  props: {
    searchPlaceHolder: "",
    guides: null,
    loading: false,
    clearSearchCounter: null,
    overrideSearchValue: null
  },
  emits: [
      "SearchResult",
      "searchText",
      "searchActive",
      "ResetSearch"
  ],
  data () {
      return {
          searchInput: '',
          descriptionSearchResult: [],
          titleSearchResult: [],
          tagSearchResult: [],
          typeSearchResult: [],
          SearchResult: []
      }
  },
  methods: {
      Search(){
        if(this.searchInput.length < 3) {
          this.$emit("SearchResult", []);
          this.$emit("searchText", "");
          this.$emit("searchActive", false);
          return;
        }
        this.TitleSearch();
        this.DescriptionSearch();
        this.TypeSearch();
        this.TagSearch();
        this.CollectResults();
      },
      TitleSearch() {
        this.titleSearchResult = []
        for (let index = 0; index < this.guides.length; index++) {
          const guide = this.guides[index];
          if(guide?.title?.toLowerCase()?.includes(this.searchInput.toLowerCase())) this.titleSearchResult.push(guide);
        }
        this.titleSearchResult = this.uniq(this.titleSearchResult);
      },
      DescriptionSearch(){
        this.descriptionSearchResult = [];
        for (let index = 0; index < this.guides.length; index++) {
          const guide = this.guides[index];
          if(guide?.description?.toLowerCase()?.includes(this.searchInput.toLowerCase())) this.descriptionSearchResult.push(guide);
        }
        this.descriptionSearchResult = this.uniq(this.descriptionSearchResult);
      },
      TypeSearch(){
        this.typeSearchResult = [];
        for (let index = 0; index < this.guides.length; index++) {
          const guide = this.guides[index];
          if(guide?.type?.toLowerCase()?.includes(this.searchInput.toLowerCase())) this.typeSearchResult.push(guide);
        }
        this.typeSearchResult = this.uniq(this.typeSearchResult);
      },
      TagSearch(){
        this.tagSearchResult = [];
        for (let index = 0; index < this.guides.length; index++) {
          const guide = this.guides[index];
          for (let i = 0; i < guide?.tags?.length; i++) {
            if(guide?.tags[i]?.name?.toLowerCase()?.includes(this.searchInput.toLowerCase())) this.tagSearchResult.push(guide);
          }
        }
        this.tagSearchResult = this.uniq(this.tagSearchResult);
      },
      CollectResults(){
        this.SearchResult = this.uniq(this.typeSearchResult.concat(this.tagSearchResult.concat(this.titleSearchResult.concat(this.descriptionSearchResult))));
        this.$emit("SearchResult", this.SearchResult);
        this.$emit("searchText", this.searchInput);
        this.$emit("searchActive", true);
      },
      uniq(a) {
        var prims = {"boolean":{}, "number":{}, "string":{}}, objs = [];

        return a.filter(function(item) {
            var type = typeof item;
            if(type in prims) return prims[type].hasOwnProperty(item) ? false : (prims[type][item] = true);
            else return objs.indexOf(item) >= 0 ? false : objs.push(item);
        });
      },
      checkIfsearchIsEmpty(event){
        var key = event.keyCode || event.charCode;
        if(( key == 8 || key == 46 ) && this.searchInput.length == 1) this.$emit("ResetSearch", null);
      },
      hitEnter(event){
        var key = event.keyCode || event.charCode;
        if(key == 13) document.activeElement.blur();
      },
      resetSearch(){
        this.searchInput = "";
        this.$emit("ResetSearch", null);
      }
  },
  watch: {
    guides: function (newValue, oldValue){
      if(newValue != oldValue) {
        this.Search();
      }
    },
    clearSearchCounter: function(newValue, oldValue){
      if(newValue != oldValue) this.resetSearch();
    },
    overrideSearchValue: function (newValue, oldValue){
      if(newValue != oldValue && newValue?.trim().length > 2 && !this.loading) {
        this.searchInput = newValue;
        this.Search();
      }
    },
    loading: function (newValue){
      if(this.overrideSearchValue?.trim().length > 2 && this.searchInput != this.overrideSearchValue && !newValue && (this.searchInput == null || this.searchInput == '')){
        this.searchInput = this.overrideSearchValue;
        this.Search();
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.label-user-select{
    user-select:none;
}
.search{
  margin-left: 1rem;
  margin-right: 1rem;
  width: 25rem;
}
@media only screen and (max-width: 768px) { 
  .search{
    margin-left: 0;
  }
} 
@media only screen and (max-width: 360px) { 
  .search{
    margin-left: 0;
  }
}
</style>