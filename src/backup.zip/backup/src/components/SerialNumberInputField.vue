<template>
  <div class="label-user-select">
    <abt-input type="text" filled :label="fieldIsObligatory == true ? label + '*' : label" :placeholder="placeholder" :status="showError ? 'error' : ''" :status-message="serialNumberErrorMessage" :value="serialNumberInput" @blur="checkShowError()" @input="serialNumberInput = $event.target.value; validateSerialNumber();" :disabled="loadingStart == null || loadingStart == true"></abt-input>
  </div>
</template>

<script>
export default {
  name: 'SerialNumberInputField',
  props: {
    label: "",
    startingValue: "",
    fieldIsObligatory: null,
    loadingStart: null,
    placeholder: null
  },
  emits: [
      "serialNumberInput",
      "serialNumberIsValid"
  ],
  data () {
      return {
          serialNumberInput: '',
          serialNumberIsValid: false,
          showError: false,
          serialNumberErrorMessage: this.$t('serialNumberInputFieldComponent.errorMessage'),
          setStartupValue: false
      }
  },
  methods: {
      validateSerialNumber() {
        var serialnumberformat = /^.{4,50}$/;
        if(((this.serialNumberInput == null || this.serialNumberInput == "" || this.serialNumberInput?.trim()?.length == 0) && !this.fieldIsObligatory) || this.serialNumberInput?.trim().match(serialnumberformat)) {
          this.serialNumberIsValid = true;
          this.showError = false;
        }
        else this.serialNumberIsValid = false;
        this.$emit("serialNumberInput", this.serialNumberInput?.trim());
        this.$emit("serialNumberIsValid", this.serialNumberIsValid);
      },
      checkShowError(){
        if(!this.serialNumberIsValid) this.showError = true;
      }
  },
  mounted: function () {
    this.serialNumberInput = this.startingValue?.trim() ?? '';
    this.validateSerialNumber();
  },
  watch: {
    startingValue: function (newValue, oldValue){
      if(newValue != oldValue) {
        this.serialNumberInput = this.startingValue?.trim();
        this.validateSerialNumber();
      }
    },
    fieldIsObligatory: function (newValue, oldValue){
      if(newValue != oldValue) this.validateSerialNumber();
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.label-user-select{
    user-select:none;
}
</style>
