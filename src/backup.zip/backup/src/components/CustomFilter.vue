<template>
  <span class="custom-filter-header">{{$t('filter.guideTypeFilter')}}</span>
  <abt-menu-divider class="divider-margin"></abt-menu-divider>
  <div class="checkbox-container">
    <abt-checkbox id="UserTypeAssign" class="filter-checkbox" :checked="isTypeFiltered('User guide')" @click="addOrRemoveTypeFilter('User guide'); emitApply();">
      <span class="custom-filter-checkbox">{{$t('filter.userGuides')}}</span>
    </abt-checkbox>
    <abt-checkbox id="InstallationTypeAssign" class="filter-checkbox" :checked="isTypeFiltered('Installation guide')" @click="addOrRemoveTypeFilter('Installation guide'); emitApply();">
      <span class="custom-filter-checkbox">{{$t('filter.installationGuides')}}</span>
    </abt-checkbox>
  </div>
  <span class="custom-filter-header">{{$t('filter.topicFilter')}}</span>
  <abt-menu-divider class="divider-margin"></abt-menu-divider>
  <div class="checkbox-container">
    <abt-checkbox class="filter-checkbox" v-for="userTag in userTags" :key="userTag" :checked="isUserTagFiltered(userTag)" :disabled="isTypeFiltered('Installation guide') && !isTypeFiltered('User guide')" @click="addOrRemoveUserTag(userTag); emitApply();">
      <span class="custom-filter-checkbox">{{userTag}}</span>
    </abt-checkbox>
  </div>
  <span class="custom-filter-header">{{$t('filter.assetsFilter')}}</span>
  <abt-menu-divider class="divider-margin"></abt-menu-divider>
  <div class="checkbox-container">
    <abt-checkbox class="filter-checkbox" v-for="installationTag in installationTags" :key="installationTag" :checked="isInstallationTagFiltered(installationTag)" :disabled="isTypeFiltered('User guide') && !isTypeFiltered('Installation guide')" @click="addOrRemoveInstallationTag(installationTag); emitApply();">
      <span class="custom-filter-checkbox">{{installationTag}}</span>
    </abt-checkbox>
  </div>
</template>

<script>
export default {
  name: 'CustomFilter',
  emits: [
      "Apply",
      "FilterActive"
  ],
  props: {
    clearCounter: null,
    customFilterData: null,
    startingValues: null
  },
  data () {
      return {
          installationTags: [],
          userTags: [],
          filteredUserTags: [],
          filteredInstallationTags: [],
          filteredTypes: []
      }
  },
  methods: {
      emitApply() {
        var filters = {
          userTags: this.filteredUserTags,
          installationTags: this.filteredInstallationTags,
          types: this.filteredTypes
        };
        this.$emit("Apply", filters);
        this.$emit("FilterActive", false)
      },
      resetFilter(){
        this.filteredTypes = [];
        this.filteredUserTags = [];
        this.filteredInstallationTags = [];
      },
      addOrRemoveTypeFilter(type){
        if(this.filteredTypes.includes(type)) this.filteredTypes.splice(this.filteredTypes.indexOf(type), 1);
        else {
          this.filteredTypes.push(type);
          if(type == 'Installation guide') {
            this.filteredUserTags = [];
            if(this.filteredTypes.includes("User guide")) this.filteredTypes.splice(this.filteredTypes.indexOf("User guide"), 1);
          }
          else if(type == 'User guide') {
            this.filteredInstallationTags = [];
            if(this.filteredTypes.includes("Installation guide")) this.filteredTypes.splice(this.filteredTypes.indexOf("Installation guide"), 1);
          }
        }
      },
      addOrRemoveUserTag(userTag){
        if(this.filteredUserTags.includes(userTag)) this.filteredUserTags.splice(this.filteredUserTags.indexOf(userTag), 1);
        else this.filteredUserTags.push(userTag);
      },
      addOrRemoveInstallationTag(installationTag){
        if(this.filteredInstallationTags.includes(installationTag)) this.filteredInstallationTags.splice(this.filteredInstallationTags.indexOf(installationTag), 1);
        else this.filteredInstallationTags.push(installationTag);
      },
      isTypeFiltered(type){
        return this.filteredTypes.includes(type);
      },
      isUserTagFiltered(userTag){
        return this.filteredUserTags.includes(userTag);
      },
      isInstallationTagFiltered(installationTag){
        return this.filteredInstallationTags.includes(installationTag);
      }
  },
  mounted: function () {
    var localFilterData = [].concat(this.customFilterData);
    for (let i = 0; i < localFilterData.length; i++) {
      const guide = localFilterData[i];
      for (let k = 0; k < guide?.tags?.length; k++) {
        const tag = guide?.tags[k];
        if(this.installationTags.includes(tag?.name?.trim()) && tag?.types?.includes("Installation guide") || this.userTags.includes(tag?.name?.trim()) && tag?.types?.includes("User guide")) continue;
        if(tag?.types?.includes("User guide")) this.userTags.push(tag?.name?.trim());
        if(tag?.types?.includes("Installation guide")) this.installationTags.push(tag?.name?.trim());
      }
    }

    if(this.startingValues?.types?.length > 0) this.filteredTypes = [].concat(this.startingValues?.types);
    if(this.startingValues?.userTags?.length > 0) this.filteredUserTags = [].concat(this.startingValues?.userTags);
    if(this.startingValues?.installationTags?.length > 0) this.filteredInstallationTags = [].concat(this.startingValues?.installationTags);
  },
  watch: {
    clearCounter: function(){
      this.resetFilter();
      this.emitApply();
    },
    customFilterData: function(newValue, oldValue){
      if(newValue != oldValue && newValue?.length > 0){
        for (let i = 0; i < newValue.length; i++) {
          const guide = newValue[i];
          for (let k = 0; k < guide?.tags?.length; k++) {
            const tag = guide?.tags[k];
            if(this.installationTags.includes(tag?.name?.trim()) || this.userTags.includes(tag?.name?.trim())) continue;
            if(tag?.types?.includes("User guide")) this.userTags.push(tag?.name?.trim());
            if(tag?.types?.includes("Installation guide")) this.installationTags.push(tag?.name?.trim());
          }
        }
      }
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.label-user-select{
    user-select:none;
}
.no-bullets{
  list-style-type: none; /* Remove bullets */
  padding: 0; /* Remove padding */
  margin: 0; /* Remove margins */
}
.single-line{
  white-space: nowrap;
  float:right;
}
.custom-filter-header{
  font-size: .6878rem;
  font-style: var(--abt-letter-spacing-normal);
  font-family: var(--abt-text-title-font-family);
  color: var(--abt-text-label-color);
  line-height: var(--abt-spacing-medium);
  text-transform: uppercase;
  margin: 4px 0;
}
.custom-filter-checkbox{
  font-family: var(--abt-font-sans);
  font-style: normal;
  font-size: 14px;
}
.custom-filter-checkbox:hover{
  cursor:pointer;
}
.custom-filter-text{
  font-family: Roboto;
  font-style: normal;
  font-weight: normal;
  font-size: 14px;
  line-height: 18px;
  color: #303030;
  height: 100%;
}
.checkbox-container{
  display:flex;
  flex-direction: row;
  justify-content: space-between;
  align-items: center;
  flex-wrap: wrap;
  margin-bottom: 1rem;
}
.filter-checkbox{
  width: 50%;
}
.divider-margin{
  margin-bottom: 1rem;
}
</style>