<template>
  <div class="label-user-select">
    <abt-input type="text" filled :label="fieldIsObligatory == true ? label + '*' : label" :placeholder="placeholder" :status="showError ? 'error' : ''" :status-message="registrationNumberErrorMessage" :value="registrationNumberInput" @blur="checkShowError()" @input="registrationNumberInput = $event.target.value; validateRegistrationNumber();" :disabled="loadingStart == null || loadingStart == true"></abt-input>
  </div>
</template>

<script>
export default {
  name: 'RegistrationNumberInputField',
  props: {
    label: "",
    startingValue: "",
    fieldIsObligatory: null,
    loadingStart: null,
    placeholder: null
  },
  emits: [
      "registrationNumberInput",
      "registrationNumberIsValid"
  ],
  data () {
      return {
          registrationNumberInput: '',
          registrationNumberIsValid: false,
          showError: false,
          registrationNumberErrorMessage: this.$t('registrationNumberInputFieldComponent.errorMessage'),
          setStartupValue: false
      }
  },
  methods: {
      validateRegistrationNumber() {
        var RegNoFormat = /^.{4,50}$/;
        if(((this.registrationNumberInput == null || this.registrationNumberInput == "" || this.registrationNumberInput?.trim?.length == 0) && !this.fieldIsObligatory) || this.registrationNumberInput?.trim().match(RegNoFormat)) {
          this.registrationNumberIsValid = true;
          this.showError = false;
        }
        else this.registrationNumberIsValid = false;
        this.$emit("registrationNumberInput", this.registrationNumberInput?.trim());
        this.$emit("registrationNumberIsValid", this.registrationNumberIsValid);
      },
      checkShowError(){
        if(!this.registrationNumberIsValid) this.showError = true;
      }
  },
  mounted: function () {
    this.registrationNumberInput = this.startingValue?.trim() ?? '';
    this.validateRegistrationNumber();
  },
  watch: {
    startingValue: function (newValue, oldValue){
      if(newValue != oldValue) {
        this.registrationNumberInput = this.startingValue?.trim();
        this.validateRegistrationNumber();
      }
    },
    fieldIsObligatory: function (newValue, oldValue){
      if(newValue != oldValue) this.validateRegistrationNumber();
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.label-user-select{
    user-select:none;
}
</style>
