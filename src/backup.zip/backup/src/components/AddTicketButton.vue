<template>
  <div>
      <abt-button class="mobile" v-on:click="create" v-show="showCreateButton" size="small"><abt-icon slot="prefix" name="far-inbox-out"></abt-icon>{{$t('addTicketButton')}}</abt-button>
      <abt-button class="mobile" disabled v-show="showInvalidButton" size="small"><abt-icon slot="prefix" name="far-inbox-out"></abt-icon>{{$t('addTicketButton')}}</abt-button>
      <abt-button class="mobile" disabled v-show="showLoadingButton" size="small"><abt-spinner></abt-spinner></abt-button>
  </div>
</template>

<script>
export default {
  name: 'AddTicketButton',
  props: {
    buttonState: ""
  },
  emits: [
      "create"
  ],
  data () {
      return {
        showInvalidButton: false,
        showLoadingButton: false,
        showCreateButton: false
      }
  },
  methods: {
      updateButtonState(){
      this.showInvalidButton = false;
      this.showLoadingButton = false;
      this.showCreateButton = false;

      if(this.buttonState == "loading") this.showLoadingButton = true;
      else if(this.buttonState == "invalid") this.showInvalidButton = true;
      else if(this.buttonState == "enabled") this.showCreateButton = true;
    },
    create(){
      this.$emit("create", null);
    }
  },
  mounted: function () {
      this.updateButtonState();
  },
  watch: {
    buttonState: function () {
      this.updateButtonState();
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
@media only screen and (max-width: 768px) { 
  .mobile{ 
    width: calc(100vw - 32px); 
    padding-right: 0; 
  } 
} 
@media only screen and (max-width: 360px) {
  .mobile{ 
    width: calc(100vw - 16px); 
    padding-right: 0; 
  } 
}
</style>