<template>
  <div class="label-user-select">
    <abt-input type="text" filled :label="fieldIsObligatory == true ? label + '*' : label" placeholder="@" :status="showError ? 'error' : ''" :status-message="emailErrorMessage" :value="emailInput" @blur="checkShowError()" @input="emailInput = $event.target.value; validateEmail();" :disabled="loadingStart == null || loadingStart == true"></abt-input>
  </div>
</template>

<script>
export default {
  name: 'EmailInputField',
  props: {
    label: "",
    startingValue: "",
    fieldIsObligatory: null,
    loadingStart: null
  },
  emits: [
      "emailInput",
      "emailIsValid"
  ],
  data () {
      return {
          emailInput: '',
          emailIsValid: false,
          showError: false,
          emailErrorMessage: this.$t('emailInputFieldComponent.emailErrorMessage'),
          setStartupValue: false
      }
  },
  methods: {
      validateEmail() {
        var mailformat = /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        var ASCIIRegex = /^[\x00-\x7F]*$/;
        if(((this.emailInput == null || this.emailInput == "" || this.emailInput?.trim()?.length == 0) && !this.fieldIsObligatory) || this.emailInput?.trim().match(mailformat) && this.emailInput?.trim().match(ASCIIRegex) && this.emailInput?.trim()?.length <= 254) {
          this.emailIsValid = true;
          this.showError = false;
        }
        else this.emailIsValid = false;
        this.$emit("emailInput", this.emailInput?.trim());
        this.$emit("emailIsValid", this.emailIsValid);
      },
      checkShowError(){
        if(!this.emailIsValid) this.showError = true;
      }
  },
  mounted: function () {
    this.emailInput = this.startingValue?.trim() ?? '';
    this.validateEmail();
  },
  watch: {
    startingValue: function (newValue, oldValue){
      if(newValue != oldValue) {
        this.emailInput = this.startingValue?.trim();
        this.validateEmail();
      }
    },
    fieldIsObligatory: function (newValue, oldValue){
      if(newValue != oldValue) this.validateEmail();
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.label-user-select{
    user-select:none;
}
</style>
