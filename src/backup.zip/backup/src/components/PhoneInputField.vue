<template>
  <div class="label-user-select">
    <abt-input id="phoneInput" filled type="tel" :label="fieldIsObligatory == true ? label + '*' : label" :placeholder="getPhoneCountryCode(country)" :status="showError ? 'error' : ''" :status-message="phoneErrorMessage" :value="phoneInput?.trim()" @blur="checkShowError" @input="phoneInput = $event.target.value; validatePhone();" :disabled="loadingStart == null || loadingStart == true"></abt-input>
  </div>
</template>

<script>
export default {
  name: 'PhoneInputField',
  props: {
    label: "",
    countrycode: "",
    startingValue: "",
    fieldIsObligatory: null,
    loadingStart: null
  },
  emits: [
      "phoneInput",
      "phoneIsValid"
  ],
  data () {
      return {
          phoneInput: '',
          phoneIsValid: false,
          showError: false,
          phoneErrorMessage: this.$t('phoneInputFieldComponent.phoneErrorMessage'),
          setStartupValue: false,
          country: ""
      }
  },
  methods: {
      validatePhone() {
        var phoneformat = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
        let inputWithCountryCode = this.getPhoneCountryCode(this.country) + this.phoneInput;

        if(((this.phoneInput == null || this.phoneInput == "" || this.phoneInput?.trim()?.length == 0) && !this.fieldIsObligatory) || inputWithCountryCode?.trim().match(phoneformat) || this.phoneInput?.trim().match(phoneformat)) {
          this.phoneIsValid = true;
          this.showError = false;
        }
        else this.phoneIsValid = false;
        this.$emit("phoneInput", this.formatPhoneNumber(this.phoneInput?.trim()));
        this.$emit("phoneIsValid", this.phoneIsValid);
      },
      checkShowError(){
        if(!this.phoneIsValid) this.showError = true;
      },
      formatPhoneNumber(number){
          if(!number) return;
          let result = number;
          let countryCode = this.getPhoneCountryCode(this.country);
          if(result.substring(3, 4) == ' ') result = '+' + result;
          if(result.substring(3, 4) == '-') result = '+' + result;
          if(result.substring(3, 4) == '.') result = '+' + result;
          result = result.replaceAll('(', '+');
          result = result.replaceAll(')', '');
          result = result.replaceAll(' ', '');
          result = result.replaceAll('-', '');
          result = result.replaceAll('.', '');
          if(result.substring(0,1) != '+' && countryCode != '') result = countryCode + result;
          else if(result.substring(0,1) != '+') result = '+' + result;
          return result;
      },
      getPhoneCountryCode(countryCode){
          if(countryCode == null || countryCode == "") return '';
          switch(countryCode.toUpperCase()){
            case 'NO': return '+47';
            case '+47': return '+47';
            case 'SE': return '+46';
            case '+46': return '+46';
            case 'DK': return '+45';
            case '+45': return '+45';
            case 'BE': return '+32';
            case '+32': return '+32';
            case 'DE': return '+49';
            case '+49': return '+49';
            case 'FI': return '+358';
            case '+358': return '+358';
            case 'FR': return '+33';
            case '+33': return '+33';
            case 'UK': return '+44';
            case '+44': return '+44';
            case 'NL': return '+31';
            case '+31': return '+31';
            case 'PL': return '+48';
            case '+48': return '+48';
            case 'IT': return '+39';
            case '+39': return '+39';
            default: return countryCode;
          }
      }
  },
  mounted: function () {
    this.phoneInput = this.startingValue?.trim() ?? '';
    this.validatePhone();
  },
  watch: {
    startingValue: function (newValue, oldValue){
      if(newValue != oldValue && newValue != this.phoneInput && newValue != this.formatPhoneNumber(this.phoneInput?.trim())) {
        this.phoneInput = this.startingValue?.trim();
        this.validatePhone();
      }
    },
    fieldIsObligatory: function (newValue, oldValue){
      if(newValue != oldValue) this.validatePhone();
    },
    countrycode: function (newValue, oldValue){
      if(newValue != oldValue) {
        this.country = this.countrycode;
        document.getElementById("phoneInput").setAttribute("placeholder", this.getPhoneCountryCode(this.country));
      } 
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.label-user-select{
    user-select:none;
}
</style>
