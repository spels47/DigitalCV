<template>
  <div class="container">
    <div class="cross">
      <abt-icon-button name="fas-times" v-on:click="closeEditor"></abt-icon-button>
    </div>
    <div class="step-container" v-show="showStep1">
      <div class="step-counter">{{$t("createTicketPanel.step")}} 1 {{$t("createTicketPanel.of")}} 2</div>
      <div class="margin-top">
        <h1 class="abt-text-header1 has-ruler header-bottom-margin">{{$t("createTicketPanel.firstStepHeader")}}</h1>
        <abt-select :disabled="loadingStart" class="input-small-margin" id="enquirySelect" :placeholder="$t('createTicketPanel.enquiryPlaceholder')" :label="$t('createTicketPanel.enquiryField')+'*'" @change="EnquiryType = $event.target.value; validateShellRouting();">
          <abt-menu-item v-for="enquiry in EnquiryTypes" :key="enquiry?.Type" :value="enquiry?.Type">{{enquiry?.Text}}</abt-menu-item>
        </abt-select>
        <abt-select v-if="typeOrSubtypeOf('Product Support')" class="input-small-margin" :placeholder="$t('createTicketPanel.enquiryPlaceholder')" :label="$t('createTicketPanel.enquirySubField')+'*'" @change="SubEnquiryType = $event.target.value; validateShellRouting();" :value="SubEnquiryType">
          <abt-menu-item v-for="subEnquiry in EnquiryTypes[0].SubTypes" :key="subEnquiry?.Type" :value="subEnquiry?.Type">{{subEnquiry?.Text}}</abt-menu-item>
        </abt-select>
        <abt-select v-if="typeOrSubtypeOf('Invoice')" class="input-small-margin" :placeholder="$t('createTicketPanel.enquiryPlaceholder')" :label="$t('createTicketPanel.enquirySubField')+'*'" @change="SubEnquiryType = $event.target.value; validateShellRouting();" :value="SubEnquiryType">
          <abt-menu-item v-for="subEnquiry in EnquiryTypes[2].SubTypes" :key="subEnquiry?.Type" :value="subEnquiry?.Type">{{subEnquiry?.Text}}</abt-menu-item>
        </abt-select>
        <abt-select v-if="typeOrSubtypeOf('Customer relationship')" class="input-small-margin" :placeholder="$t('createTicketPanel.enquiryPlaceholder')" :label="$t('createTicketPanel.enquirySubField')+'*'" @change="SubEnquiryType = $event.target.value; validateShellRouting();" :value="SubEnquiryType">
          <abt-menu-item v-for="subEnquiry in EnquiryTypes[3].SubTypes" :key="subEnquiry?.Type" :value="subEnquiry?.Type">{{subEnquiry?.Text}}</abt-menu-item>
        </abt-select>
        <SerialNumberInputField class="input-small-margin" v-if="SubEnquiryType == 'Hardware' && EnquiryType == 'Product Support'" :label="$t('serialNumberInputFieldComponent.label')" :fieldIsObligatory="true" :loadingStart="loadingStart" :startingValue="serialNumberValue ?? ''" @serialNumberInput="serialNumberValue = $event; validateShellRouting();" @serialNumberIsValid="serialNumberIsValid = $event"></SerialNumberInputField>
        <RegistrationNumberInputField class="input-small-margin" v-if="SubEnquiryType == 'Backdate information' && EnquiryType == 'Product Support'" :label="$t('registrationNumberInputFieldComponent.label')" :fieldIsObligatory="true" :loadingStart="loadingStart" :startingValue="registrationNumberValue ?? ''" @registrationNumberInput="registrationNumberValue = $event; validateShellRouting();" @registrationNumberIsValid="registrationNumberIsValid = $event"></RegistrationNumberInputField>
        <InvoiceNumberInputField class="input-small-margin" v-if="(SubEnquiryType == 'Questions to invoice' || SubEnquiryType == 'Invoice copy') && EnquiryType == 'Invoice'" :label="$t('invoiceNumberInputFieldComponent.label')" :fieldIsObligatory="true" :loadingStart="loadingStart" :startingValue="invoiceNumberValue ?? ''" @invoiceNumberInput="invoiceNumberValue = $event; validateShellRouting();" @invoiceNumberIsValid="invoiceNumberIsValid = $event"></InvoiceNumberInputField>
        <abt-textarea filled class="input-large-margin" :label="$t('createTicketPanel.messageLabel')+'*'" :placeholder="$t('createTicketPanel.messagePlaceholder')" resize="none" :value="Message?.trim()" @input="Message = $event.target.value; validateShellRouting();"></abt-textarea>
        <FileUploader class="input-medium-margin" @error="handleError($event)"  @select="Files = $event; validateShellRouting();"></FileUploader>
        <abt-menu-divider class="input-large-margin"></abt-menu-divider>
        <abt-checkbox class="input-small-margin" @click="userConsent = !userConsent; validateShellRouting();">{{$t('createTicketPanel.consentCheckBox')}}</abt-checkbox>
        <abt-alert type="primary" open class="input-large-margin">
          <abt-icon slot="icon" name="far-info-circle"></abt-icon>
          <span>{{$t('createTicketPanel.understandInfo')}}</span> <a class="privacy-link" target="_blank" :href="`https://www.abax.com/${countryCode?.toLowerCase()}/personvern`">{{$t('createTicketPanel.understandLinkText')}}</a>
        </abt-alert>
        <div class="bottom-button-group-alt">
          <abt-button size="small" class="button-margin" type="primary-ghost" v-on:click="closeEditor">{{$t("createTicketPanel.cancelButton")}}</abt-button>
          <abt-button size="small" v-if="!loading && FirstStepValid" :disabled="false" v-on:click="setStep(2)">{{$t("createTicketPanel.nextButton")}}</abt-button>
          <abt-button size="small" v-if="!loading && !FirstStepValid" :disabled="true" v-on:click="setStep(2)">{{$t("createTicketPanel.nextButton")}}</abt-button>
          <abt-button size="small" v-if="loading" loading>{{$t("createTicketPanel.nextButton")}}</abt-button>
        </div>
      </div>
    </div>
    <div class="step-container" v-show="showStep2">
      <div class="step-counter">{{$t("createTicketPanel.step")}} 2 {{$t("createTicketPanel.of")}} 2</div>
      <div class="margin-top">
        <h1 class="abt-text-header1 has-ruler header-bottom-margin">{{$t("createTicketPanel.secondStepHeader")}}</h1>
        <NameInputField class="input-small-margin" :label="$t('nameInputFieldComponent.companyNameLabel')" :placeholder="$t('nameInputFieldComponent.enterCompanyNamePlaceholder')" @nameInput="Aktor = $event; validateShellRouting();" @nameIsValid="companyNameIsValid = $event" :ASCIIOnly="false" :fieldIsObligatory="true" :loadingStart="loadingStart" :startingValue="Aktor?.trim()?.length > 0 ? Aktor : CompanyName ?? ''"></NameInputField>
        <NameInputField class="input-small-margin" :label="$t('nameInputFieldComponent.firstNameLabel')" :placeholder="$t('nameInputFieldComponent.enterFirstNamePlaceholder')" @nameInput="FirstName = $event; validateShellRouting();" @nameIsValid="firstNameIsValid = $event" :ASCIIOnly="false" :fieldIsObligatory="true" :loadingStart="loadingStart" :startingValue="FirstName?.trim()?.length > 0 ? FirstName : FirstNameData ?? ''"></NameInputField>
        <NameInputField class="input-small-margin" :label="$t('nameInputFieldComponent.lastNameLabel')" :placeholder="$t('nameInputFieldComponent.enterLastNamePlaceholder')" @nameInput="LastName = $event; validateShellRouting();" @nameIsValid="lastNameIsValid = $event" :ASCIIOnly="false" :fieldIsObligatory="false" :loadingStart="loadingStart" :startingValue="LastName?.trim()?.length > 0 ? LastName : LastNameData ?? ''"></NameInputField>
        <PhoneInputField class="input-small-margin" @phoneInput="Phone = $event; validateShellRouting();" @phoneIsValid="phoneIsValid = $event" :fieldIsObligatory="true" :countrycode="countryCode" :label="$t('phoneInputFieldComponent.phoneNumberLabel')" :loadingStart="loadingStart" :startingValue="Phone?.trim()?.length > 0 ? Phone : PhoneData ?? ''"></PhoneInputField>
        <EmailInputField class="input-small-margin" @emailInput="Email = $event; validateShellRouting();" @emailIsValid="emailIsValid = $event" :fieldIsObligatory="true" :label="$t('emailInputFieldComponent.label')" :loadingStart="loadingStart" :startingValue="Email?.trim()?.length > 0 ? Email : EmailData ?? ''"></EmailInputField>
        <div class="bottom-button-group">
          <abt-button size="small" class="button-margin" type="primary-ghost" v-on:click="setStep(1)">{{$t("createTicketPanel.backButton")}}</abt-button>
          <div>
            <abt-button size="small" type="primary-ghost" v-on:click="closeEditor">{{$t("createTicketPanel.cancelButton")}}</abt-button>
            <abt-button size="small" v-if="!loading && TicketValid" :disabled="false" v-on:click="createTicket()">{{$t("createTicketPanel.createTicketButton")}}</abt-button>
            <abt-button size="small" v-if="!loading && !TicketValid" :disabled="true" v-on:click="createTicket()">{{$t("createTicketPanel.createTicketButton")}}</abt-button>
            <abt-button size="small" v-if="loading" loading>{{$t("createTicketPanel.createTicketButton")}}</abt-button>
          </div>
        </div>
      </div>
    </div>
    <div id="backendErrorDialog" class="alert">
      <abt-alert id="error-alert" v-on:abt-after-hide="showBackendErrorDialog = false;" v-on:abt-hide="showBackendErrorDialog = false;" :open="showBackendErrorDialog" duration="5000" type="danger">
        <abt-icon slot="icon" name="far-exclamation-circle"></abt-icon>
        {{backendErrorMessage}}
      </abt-alert>
    </div>
  </div>
</template>

<script>
import axios from 'axios';
import api from 'shell/api';
import PhoneInputField from './PhoneInputField.vue';
import EmailInputField from './EmailInputField.vue';
import NameInputField from './NameInputField.vue';
import FileUploader from './FileUploader.vue';
import SerialNumberInputField from './SerialNumberInputField.vue';
import RegistrationNumberInputField from './RegistrationNumberInputField.vue';
import InvoiceNumberInputField from './InvoiceNumberInputField.vue';

export default {
  name: 'CreateTicketForm',
  components: {
      EmailInputField,
      PhoneInputField,
      NameInputField,
      FileUploader,
      SerialNumberInputField,
      RegistrationNumberInputField,
      InvoiceNumberInputField
  },
  emits: [
      "create",
      "close",
      "error"
  ],
  props: {
    AktorId: "",
    CompanyName: "",
    FirstNameData: "",
    LastNameData: "",
    EmailData: "",
    PhoneData: "",
    countryCodeProp: "",
    loadingStart: null
  },
  data () {
      return {
        token: "",
        Aktor: "",
        FirstName: "",
        LastName: "",
        Email: "",
        Phone: "",
        Message: "",
        EnquiryType: "",
        SubEnquiryType: "",
        EnquiryTypes: [
          {
            Type: "Product Support",
            Text: this.$t("enquiryType.productSupport"),
            SubTypes: [
              {
                Type: "Hardware",
                Text: this.$t("enquiryType.hardware"),
                SubTypes: []
              },
              {
                Type: "Create Admin account",
                Text: this.$t("enquiryType.createAdminAccount"),
                SubTypes: []
              },
              {
                Type: "Backdate information",
                Text: this.$t("enquiryType.backdateInformation"),
                SubTypes: []
              },
              {
                Type: "System guidance",
                Text: this.$t("enquiryType.systemGuidance"),
                SubTypes: []
              },
              {
                Type: "Other",
                Text: this.$t("enquiryType.other"),
                SubTypes: []
              }
            ]
          },
          {
            Type: "Username/Password",
            Text: this.$t("enquiryType.usernamePassword"),
            SubTypes: []
          },
          {
            Type: "Invoice",
            Text: this.$t("enquiryType.invoice"),
            SubTypes: [
              {
                Type: "Move subscriptions",
                Text: this.$t("enquiryType.moveSubscriptions"),
                SubTypes: []
              },
              {
                Type: "Bank statement",
                Text: this.$t("enquiryType.bankStatement"),
                SubTypes: []
              },
              {
                Type: "Questions to invoice",
                Text: this.$t("enquiryType.questionsToInvoice"),
                SubTypes: []
              },
              {
                Type: "Change invoice address/email",
                Text: this.$t("enquiryType.changeInvoiceAddressEmail"),
                SubTypes: []
              },
              {
                Type: "Invoice copy",
                Text: this.$t("enquiryType.invoiceCopy"),
                SubTypes: []
              },
              {
                Type: "Other",
                Text: this.$t("enquiryType.other"),
                SubTypes: []
              }
            ]
          },
          {
            Type: "Customer relationship",
            Text: this.$t("enquiryType.customerRelationship"),
            SubTypes: [
              {
                Type: "Update customer data",
                Text: this.$t("enquiryType.updateCustomerData"),
                SubTypes: []
              },
              {
                Type: "Termination of subscriptions",
                Text: this.$t("enquiryType.terminationOfSubscriptions"),
                SubTypes: []
              },
              {
                Type: "Subscription reduction",
                Text: this.$t("enquiryType.subscriptionReduction"),
                SubTypes: []
              },
              {
                Type: "Contract information",
                Text: this.$t("enquiryType.contractInformation"),
                SubTypes: []
              },
              {
                Type: "Other",
                Text: this.$t("enquiryType.other"),
                SubTypes: []
              }
            ]
          },
          {
            Type: "Buy products",
            Text: this.$t("enquiryType.buyProducts"),
            SubTypes: []
          },
          {
            Type: "Package tracing",
            Text: this.$t("enquiryType.packageTracking"),
            SubTypes: []
          },
          {
            Type: "Tax, Privacy and GDPR",
            Text: this.$t("enquiryType.taxPrivacyAndGdpr"),
            SubTypes: []
          }
        ],
        userConsent: false,
        Files: [],
        phoneIsValid: false,
        emailIsValid: false,
        companyNameIsValid: false,
        firstNameIsValid: false,
        lastNameIsValid: false,
        loading: false,
        countryCode: "",
        showStep1: true,
        showStep2: false,
        showStep3: false,
        FirstStepValid: false,
        TicketValid: false,
        serialNumberIsValid: false,
        serialNumberValue: "",
        registrationNumberIsValid: false,
        registrationNumberValue: null,
        invoiceNumberIsValid: false,
        invoiceNumberValue: null,
        showBackendErrorDialog: false,
        backendErrorMessage: this.$t("backendErrorMessageDefault"),
      }
  },
  methods: {
      async getToken(){
        try{
          this.token = await api.auth.getAccessToken();
        }
        catch(error){
          console.error(error.response);
        }
      },
      async getBasePath(){
        let url = await api.app.getApiBasePath("triplogwebapi");
        return url + "/api";
      },
      closeEditor(){
        api.app.markAsPristine();
        this.$emit("close", null);
      },
      enquiryTypeHasSubTypes(type){
        for (let i = 0; i < this.EnquiryTypes.length; i++) {
          const enquiry = this.EnquiryTypes[i];
          if(enquiry.Type == type && enquiry.SubTypes.length > 0) return true;
        }
        return false;
      },
      createTicket(){
        let shouldAddSerialNumber = this.EnquiryType == 'Product Support' && this.SubEnquiryType == 'Hardware' && this.serialNumberValue != '' && this.serialNumberValue != null;
        let shouldAddRegistrationNumber = this.EnquiryType == 'Product Support' && this.SubEnquiryType == 'Backdate information' && this.registrationNumberValue != '' && this.registrationNumberValue != null;
        let shouldAddInvoiceNumber = this.EnquiryType == 'Invoice' && (this.SubEnquiryType == 'Questions to invoice' || this.SubEnquiryType == 'Invoice copy') && this.invoiceNumberValue != '' && this.invoiceNumberValue != null;

        let ticketToCreate = {
          CompanyName: this.Aktor,
          FirstName: this.FirstName,
          LastName: this.LastName,
          Email: this.Email,
          Phone: this.Phone,
          EnquiryType: this.EnquiryType,
          SubEnquiryType: this.enquiryTypeHasSubTypes(this.EnquiryType) ? this.SubEnquiryType : null,
          SerialNumber: shouldAddSerialNumber ? this.serialNumberValue : null,
          RegistrationNumber: shouldAddRegistrationNumber ? this.registrationNumberValue : null,
          InvoiceNumber: shouldAddInvoiceNumber ? this.invoiceNumberValue : null,
          Message: this.Message?.trim(),
          Files: this.Files
        }

        console.log("ticket to be created:", ticketToCreate);
        let self = this;
        if(this.TicketValid) {
          this.loading = true;
          axios.post("/HelpCentre/Ticket", ticketToCreate)
          .then(function (response) {
            self.loading = false;
            api.app.markAsPristine();
            self.$emit("create", null);
          })
          .catch(function (error) {
            console.error(error?.response);
            self.loading = false;
            self.$emit("error", null);
          });
        }
      },
      setStep(step){
        this.showStep1 = false;
        this.showStep2 = false;
        this.showStep3 = false;
        if(step == 1) this.showStep1 = true;
        if(step == 2) this.showStep2 = true;
        if(step == 3) this.showStep3 = true;
      },
      validateFirstStep(){
        // console.log("enquiry type:", this.EnquiryType, "enquiry type not empty condition:", (this.EnquiryType != null && this.EnquiryType != ""), "enquiry sub type:", this.SubEnquiryType, "sub enquiry type condition:", (this.enquiryTypeHasSubTypes(this.EnquiryType) == false || this.SubEnquiryType != null && this.SubEnquiryType != ''), "message:", this.Message, "message condition:", this.Message?.trim().length > 0, "user consent:", this.userConsent, "user consent conditon:", this.userConsent == true, "serial number is valid:", this.serialNumberIsValid, "serial number condition:", (this.SubEnquiryType != 'Hardware' || this.serialNumberIsValid), "registration number is valid:", this.registrationNumberIsValid, "registration number condition:", (this.EnquiryType != 'Invoice' && this.SubEnquiryType != 'Backdate information' || this.registrationNumberIsValid), "invoice number is valid:", this.invoiceNumberIsValid, "invoice number condition:", (this.SubEnquiryType != 'Questions to invoice' && this.SubEnquiryType != 'Invoice copy' || this.invoiceNumberIsValid));
        if((this.EnquiryType != null && this.EnquiryType != "") &&
          (this.enquiryTypeHasSubTypes(this.EnquiryType) == false || this.SubEnquiryType != null && this.SubEnquiryType != '') &&
          this.Message?.trim().length > 0 &&
          this.userConsent == true &&
          (this.EnquiryType != 'Product Support' || this.EnquiryType == 'Product Support' && this.SubEnquiryType != 'Hardware' || this.serialNumberIsValid) &&
          (this.EnquiryType != 'Product Support' || this.EnquiryType == 'Product Support' && this.SubEnquiryType != 'Backdate information' || this.registrationNumberIsValid) &&
          (this.EnquiryType != 'Invoice' || this.EnquiryType == 'Invoice' && this.SubEnquiryType != 'Questions to invoice' && this.SubEnquiryType != 'Invoice copy' || this.invoiceNumberIsValid)) this.FirstStepValid = true;
          else this.FirstStepValid = false;
      },
      validateTicket(){
        if(this.companyNameIsValid &&
          this.firstNameIsValid &&
          this.lastNameIsValid &&
          this.phoneIsValid &&
          this.emailIsValid &&
          (this.EnquiryType != null && this.EnquiryType != "") &&
          (this.enquiryTypeHasSubTypes(this.EnquiryType) == false || this.SubEnquiryType != null && this.SubEnquiryType != '') &&
          this.Message?.trim().length > 0 &&
          this.userConsent == true &&
          (this.EnquiryType != 'Product Support' || this.EnquiryType == 'Product Support' && this.SubEnquiryType != 'Hardware' || this.serialNumberIsValid) &&
          (this.EnquiryType != 'Product Support' || this.EnquiryType == 'Product Support' && this.SubEnquiryType != 'Backdate information' || this.registrationNumberIsValid) &&
          (this.EnquiryType != 'Invoice' || this.EnquiryType == 'Invoice' && this.SubEnquiryType != 'Questions to invoice' && this.SubEnquiryType != 'Invoice copy' || this.invoiceNumberIsValid)) this.TicketValid = true;
          else this.TicketValid = false;
      },
      typeOrSubtypeOf(type){
        for (let index = 0; index < this.EnquiryTypes.length; index++) {
          const enquiry = this.EnquiryTypes[index];
          if(enquiry.Type == type && enquiry.Type == this.EnquiryType) return true;

          else if(enquiry.Type == type && enquiry.SubTypes.length > 0){
            for (let i = 0; i < enquiry.SubTypes.length; i++) {
              const subType = enquiry.SubTypes[i];
              if(subType.Type == this.EnquiryType) return true;
            }
            return false;
          }
        }
        return false;
      },
      resetSpecialCaseInputs(){
        this.serialNumberValue = "";
        this.registrationNumberValue = null;
        this.invoiceNumberValue = null;
        this.serialNumberIsValid = false;
        this.registrationNumberIsValid = false;
        this.invoiceNumberIsValid = false;
      },
      handleError(event){
        if(event.type == "extension") this.fileExtensionErrorToast(event.data);
        else if(event.type == "size") this.fileSizeErrorToast(event.data);
        else if(event.type == "duplicate") this.duplicateFileErrorToast(event.data);
        else if(event.type == "all-size") allFilesSizeErrorToast(event.data);
      },
      allFilesSizeErrorToast(data){
        this.backendErrorMessage = this.$t("tooLargeFilesError");
        document.getElementById('backendErrorDialog').innerHTML = `
          <abt-alert id="error-alert" v-on:abt-after-hide="showBackendErrorDialog = false;" v-on:abt-hide="showBackendErrorDialog = false;" :open="showBackendErrorDialog" duration="5000" type="danger">
            <abt-icon slot="icon" name="far-exclamation-circle"></abt-icon>
            ${this.backendErrorMessage} ${(data / 1000000).toFixed(2)}MB
          </abt-alert>`;
        this.showBackendErrorDialog = true;
        document.getElementById('error-alert').toast({position: 'top-center'});
      },
      fileExtensionErrorToast(data){
        this.backendErrorMessage = this.$t("invalidFileExtensionError");
        document.getElementById('backendErrorDialog').innerHTML = `
          <abt-alert id="error-alert" v-on:abt-after-hide="showBackendErrorDialog = false;" v-on:abt-hide="showBackendErrorDialog = false;" :open="showBackendErrorDialog" duration="5000" type="danger">
            <abt-icon slot="icon" name="far-exclamation-circle"></abt-icon>
            ${this.backendErrorMessage} .${data}
          </abt-alert>`;
        this.showBackendErrorDialog = true;
        document.getElementById('error-alert').toast({position: 'top-center'});
      },
      fileSizeErrorToast(data){
        this.backendErrorMessage = this.$t("tooLargeFileError");
        document.getElementById('backendErrorDialog').innerHTML = `
          <abt-alert id="error-alert" v-on:abt-after-hide="showBackendErrorDialog = false;" v-on:abt-hide="showBackendErrorDialog = false;" :open="showBackendErrorDialog" duration="5000" type="danger">
            <abt-icon slot="icon" name="far-exclamation-circle"></abt-icon>
            ${this.backendErrorMessage} ${(data / 1000000).toFixed(2)}MB
          </abt-alert>`;
        this.showBackendErrorDialog = true;
        document.getElementById('error-alert').toast({position: 'top-center'});
      },
      duplicateFileErrorToast(data){
        this.backendErrorMessage = this.$t("duplicateFileError");
        document.getElementById('backendErrorDialog').innerHTML = `
          <abt-alert id="error-alert" v-on:abt-after-hide="showBackendErrorDialog = false;" v-on:abt-hide="showBackendErrorDialog = false;" :open="showBackendErrorDialog" duration="5000" type="danger">
            <abt-icon slot="icon" name="far-exclamation-circle"></abt-icon>
            ${this.backendErrorMessage} ${data}
          </abt-alert>`;
        this.showBackendErrorDialog = true;
        document.getElementById('error-alert').toast({position: 'top-center'});
      },
      validateShellRouting(){
        if(this.Aktor == this.CompanyName &&
           this.FirstName == this.FirstNameData &&
           this.LastName == this.LastNameData &&
           this.Email == this.EmailData &&
           this.Phone == this.PhoneData &&
           this.Message.length == 0 &&
           this.EnquiryType == this.EnquiryTypes[0].Type &&
           this.SubEnquiryType == this.EnquiryTypes[0].SubTypes[0].Type &&
           this.userConsent == false &&
           this.Files?.length == 0 &&
           (this.serialNumberValue == "" || this.serialNumberValue == null) &&
           (this.registrationNumberValue == null || this.registrationNumberValue == "") &&
           (this.invoiceNumberValue == null || this.invoiceNumberValue == "")) api.app.markAsPristine();
        else api.app.markAsDirty();
      }
  },
  mounted: async function () {
      await this.getToken();
      axios.defaults.baseURL = await this.getBasePath();
      axios.defaults.headers.common["Authorization"] = `Bearer ${await api.auth.getAccessToken()}`;
      axios.defaults.headers.common["Access-Control-Allow-Origin"] = "*";
      axios.defaults.headers.common["Accept"] = "application/json";
      this.$nextTick(function () {
        if(this.EnquiryTypes != null && this.EnquiryTypes.length > 0) {
          this.EnquiryType = this.EnquiryTypes[0].Type;
          this.SubEnquiryType = this.EnquiryTypes[0].SubTypes[0].Type;
          document.getElementById("enquirySelect").value = this.EnquiryTypes[0].Type;
        }
        this.countryCode = this.countryCodeProp;
      })
  },
  watch: {
    loadingStart: function (newValue) {
      if(newValue == false){
        this.countryCode = this.countryCodeProp;
      }
    },
    companyNameIsValid: function (){
      this.validateTicket();
    },
    firstNameIsValid: function(){
      this.validateTicket();
    },
    lastNameIsValid: function(){
      this.validateTicket();
    },
    phoneIsValid: function(){
      this.validateTicket();
    },
    emailIsValid: function(){
      this.validateTicket();
    },
    EnquiryType: function(newValue, oldValue){
      if(newValue != oldValue){
        if(newValue == 'Product Support') this.SubEnquiryType = this.EnquiryTypes[0].SubTypes[0].Type;
        else if(newValue == 'Invoice') this.SubEnquiryType = this.EnquiryTypes[2].SubTypes[0].Type;
        else if(newValue == 'Customer relationship') this.SubEnquiryType = this.EnquiryTypes[3].SubTypes[0].Type;
        else this.SubEnquiryType = "";
      }
      this.resetSpecialCaseInputs();
      this.validateTicket();
      this.validateFirstStep();
    },
    SubEnquiryType: function(){
      this.resetSpecialCaseInputs();
      this.validateTicket();
      this.validateFirstStep();
    },
    Message: function(){
      this.validateTicket();
      this.validateFirstStep();
    },
    userConsent: function(){
      this.validateTicket();
      this.validateFirstStep();
    },
    serialNumberIsValid: function(){
      this.validateTicket();
      this.validateFirstStep();
    },
    invoiceNumberIsValid: function(){
      this.validateTicket();
      this.validateFirstStep();
    },
    registrationNumberIsValid: function(){
      this.validateTicket();
      this.validateFirstStep();
    }
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
.container{
  position: absolute;
  align-self: stretch;
  display:flex;
  flex-direction: column;
  align-items: center;
  height: 100%;
  width: 100%;
}
.margin{
  width: 27rem;
  margin-top: 4.5rem;
}
.margin-top{
  margin-top: 5rem;
}
.step-container{
  width: 27rem;
}
.step-counter{
  margin-top: 2.5rem;
  float:right;
}
.button-width{
  margin-bottom: 1rem;
  width: 100%;
}
.cross{
  position:absolute;
  top: 2rem;
  right: 2.5rem;
}
.password-type-box{
  display:flex;
  flex-direction: row;
  align-items: center;
  justify-content: space-between;
}
.button-margin{
  margin-right: 1rem;
}
.bottom-button-group{
  display: flex; 
  flex-direction: row; 
  justify-content: space-between; 
}
.bottom-button-group-alt{
  display: flex; 
  flex-direction: row; 
  justify-content: right; 
}
.header-bottom-margin{
  margin-bottom: 2.5rem;
}
.input-small-margin{
  margin-bottom: 1rem;
}
.input-medium-margin{
  margin-bottom: 2rem;
}
.input-large-margin{
  margin-bottom: 2.5rem;
}
.privacy-link{
  text-decoration-line: underline;
  text-decoration-color: var(--abt-color-primary);
  color: var(--abt-color-primary);
  font-weight: var(--abt-text-title-font-weight);
  font-family: var(--abt-text-title-font-family);
}
@media only screen and (max-width: 768px) { 
  .step-container{ 
    width: calc(100% - 32px); 
  } 
  .cross{ 
    position:absolute; 
    top: 1rem; 
    right: 0.5rem; 
  } 
} 
@media only screen and (max-width: 360px) { 
  .step-container{ 
    width: calc(100% - 16px); 
  } 
  .cross{ 
    position:absolute; 
    top: 1rem; 
    right: 0; 
  } 
}
</style>
