import { createApp } from 'vue';
import { applyPolyfills, defineCustomElements } from '@abax/bow-tie/loader';
import router from '../router';
import MockedShell from './mocked-shell.vue';
import '@abax/bow-tie/dist/abax-bow-tie/abax-bow-tie.css';
import { i18nPlugin } from '../i18n';
import '@/app-startup';

// we're setting up bowtie here so that it's only included when serving locally, since when running in the
// shell it will have set them up before we're loaded

applyPolyfills().then(async () => {
  await defineCustomElements();
  createApp(MockedShell, {}).use(router).use(i18nPlugin).mount('#app');
});
