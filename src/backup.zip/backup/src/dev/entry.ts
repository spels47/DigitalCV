import '@abax/dev-shell/dist/css/lib.css';
import { startDevShell } from '@abax/dev-shell';

startDevShell({
  // should match your webpack config, but note that the abax-dev-shell oauth2 client
  // may need to be updated to accept other hosts and ports than 8080
  devServerPublicPath: 'http://localhost:8080/',
  // optional: '/mfe-app/' by default
  appBasePath: '/help-centre/', // will be used as router base path
  // optional: #app by default
  mountOptions: {
    rootContainer: '#app', // id of the app element inside index.html
  },
  authOptions: {
    authority: 'https://identity-server.api-gw-stg.gcp.abax.services',
    clientId: 'abax-dev-shell',
    apiScopes: 'triplog_api', // add additional api scopes here
  },
  // optional: sidebar is enabled by default
  layoutOptions: {
    sidebarEnabled: true, // set to false if your app is a top level application (eg. map)
  },
  // optional: use if your project should be internationalized
  i18nOptions: {
    currentLocale: 'en',
    async onLocaleChanged(newLocale: string) {
      console.log('Locale changed -->', newLocale);

      // async loading of i18n since it uses the shell-api
      (await import('../i18n')).setLocale(newLocale);
    },
  },
  // optional: use when your project contains a sidecar
  sidecarOptions: {
    // default, set to true here if you want to start it manually in dev shell (under options)
    manuallyStartSidecar: false,
    async onStartSidecar() {
      // use dynamic import here
      (await import('../sidecars/url-saver')).start();
    },
    async onStopSidecar() {
      // use dynamic import here
      (await import('../sidecars/url-saver')).stop();
    },
  },
}).then((loadApps) => {
  // ^-- you can remove the "then" continuation part if your project doesn't
  // contain any mfe app, but rather a sidecar (sidecar only project).

  // important to load apps dynamically (dev-shell need to be started first)
  // apps need to be in the format of an single-spa app (web framework agnostic)
  loadApps({
    microFrontendApp: import('@/mfe-app'), // required
    // devMenuApp: import('./dev-menu-app'), // optional
  });
});