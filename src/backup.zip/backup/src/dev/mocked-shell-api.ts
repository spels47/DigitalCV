/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
let accessToken = '';
let profile: any = {};

// for now we hardcode en since it the only language that is
// translated in this project.
let currentLocale = 'en';

const apiV1: ApiV1 = {
  user: {
    getProfile(): ApiV1UserProfile {
      return {
        id: profile.sub,
        name: profile.name,
        username: profile['http://schemas.abax.no/identity/claims/username'],
        countryCode: profile['http://schemas.abax.no/identity/claims/countrycode'],
      };
    },
  },
  auth: {
    async getAccessToken() {
      return accessToken;
    },
  },
  i18n: {
    getLocale() {
      return currentLocale;
    },
    setLocale(locale) {
      currentLocale = locale;
    },
  },
  app: {
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    getRouterBasePath(remoteAppId: string) {
      return '/help-centre/';
    },
    getApiBasePath(api): string {
      return `./${api}`;
    },
  },
};

async function initialize(): Promise<void> {
  const tokenEndpoint = 'https://identity-server.api-gw-stg.gcp.abax.services/connect/token';
  const userInfoEndpoint = 'https://identity-server.api-gw-stg.gcp.abax.services/connect/userinfo';

  const tokenResponse: any = await fetch(tokenEndpoint, {
    method: 'POST',
    cache: 'no-cache',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      grant_type: 'password',
      client_id: 'mocked-abax-shell',
      client_secret: 'Unti1She11IsAvai1ab1e',
      username: 'abax-adm',
      password: 'Unit1234',
    }),
  }).then((res) => res.json());

  accessToken = tokenResponse.access_token;

  profile = await fetch(userInfoEndpoint, {
    method: 'GET',
    cache: 'no-cache',
    headers: new Headers({
      Authorization: `Bearer ${accessToken}`,
      'Content-Type': 'application/json',
    }),
  }).then((res) => res.json());

  currentLocale = profile.locale;
}

(window as { [key: string]: any })['shell/v1/api'] = apiV1;

export default initialize;