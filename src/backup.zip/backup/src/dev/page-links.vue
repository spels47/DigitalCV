<template>
  <nav class="page-links">
    <h1>Mocked Shell Links</h1>
    <ul>
      <!-- <li>
        <router-link :to="{ name: 'some-new-page' }"> link name goes here </router-link>
      </li> -->
    </ul>
  </nav>
</template>

<style lang="scss" scoped>
  .page-links {
    font-family: var(--abt-font-sans-alt);

    h1 {
      font-size: 0.75rem;
      font-weight: var(--abt-font-weight-semibold);
      margin: 0;
      padding: 0.5rem 0;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      line-height: 1rem;
      color: var(--abt-color-gray-500);
    }

    ul {
      list-style-type: none;
      margin: 0;
      padding: 0;

      > li > a {
        display: inline-block;
        text-decoration: none;
        font-size: var(--abt-font-size-small);
        font-weight: var(--abt-font-weight-semibold);
        color: var(--abt-color-gray-600);
        padding: 0.5rem 0;

        &:hover,
        &.router-link-active {
          letter-spacing: -0.3px;
          font-weight: var(--abt-font-weight-bold);
          color: var(--abt-color-black);
        }
      }
    }
  }
</style>
