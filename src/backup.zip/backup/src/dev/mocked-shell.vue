<template>
  <div class="mocked-shell">
    <header class="top-navbar">
      <nav>
        <div class="brand-icon">
          <img src="@/assets/abax-logo.svg" />
        </div>
      </nav>
    </header>
    <aside class="left-sidebar">
      <PageLinks />
    </aside>
    <div class="main-area-wrapper">
      <main class="main-area">
        <App />
      </main>
    </div>
  </div>
</template>

<script lang="ts">
  import 'modern-normalize';
  import App from '@/app.vue';
  import { defineComponent } from 'vue';
  import PageLinks from '@/dev/page-links.vue';

  export default defineComponent({
    components: {
      App,
      PageLinks,
    },
    setup() {
      return {};
    },
  });
</script>

<style lang="scss" scoped>
  .mocked-shell {
    --shell-body-bg: #f5f5f5;
    --shell-top-navbar-height: 5rem;
    --shell-left-sidebar-width: 17.5rem;

    // shell exposed design tokens
    --shell-main-area-viewport-top: var(--shell-top-navbar-height);
    --shell-main-area-viewport-right: 0;
    --shell-main-area-viewport-bottom: 0;
    --shell-main-area-viewport-left: var(--shell-left-sidebar-width);

    height: 100vh;
    background: var(--shell-body-bg);

    .top-navbar {
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      height: var(--shell-top-navbar-height);
      background: #ffffff;
      z-index: 1000;
      box-shadow: 0 1px 13px 0 rgba(0, 0, 0, 0.06);

      nav {
        height: 100%;

        .brand-icon {
          margin-right: 44px;
          margin-left: 44px;
          height: 100%;

          img {
            height: 100%;
          }
        }
      }
    }

    .left-sidebar {
      position: fixed;
      top: var(--shell-main-area-viewport-top);
      left: 0;
      bottom: 0;
      width: var(--shell-left-sidebar-width);
      z-index: 999;
      height: calc(100vh - var(--shell-main-area-viewport-top));
      background: #ffffff;
      padding: 2.125rem var(--abt-spacing-x-large);
      overflow: hidden;
    }

    .main-area-wrapper {
      padding-left: var(--shell-left-sidebar-width);
      padding-top: var(--shell-main-area-viewport-top);
      height: 100%;

      .main-area {
        position: relative;
        height: 100%;
        overflow: auto;
      }
    }
  }
</style>

<style>
  /* Scrollbar styling */

  /* Firefox and other browsers in the future (W3C spec) */
  * {
    scrollbar-width: thin;
    scrollbar-color: var(--abt-color-gray-300) transparent;
  }

  /* Webkit-based browsers */
  ::-webkit-scrollbar {
    width: 16px;
  }

  ::-webkit-scrollbar-track,
  ::-webkit-scrollbar-corner {
    background-color: transparent;
  }

  ::-webkit-scrollbar-thumb {
    background-color: var(--abt-color-gray-300);
    border-radius: 20px;
    border: 5px solid transparent;
    background-clip: content-box;
  }

  ::-webkit-scrollbar-thumb:hover {
    background-color: var(--abt-color-gray-500);
  }
</style>
