<template>
  <div class="my-micro-frontend-app">
    <router-view></router-view>
  </div>
</template>

<script lang="ts">
  import { defineComponent } from 'vue';

  export default defineComponent({
    name: '@abax/central/users/help-centre', // Give it a name (console messages)
  });
</script>

<style lang="scss" scoped>
  .my-micro-frontend-app {
    height: 100%;
  }
</style>
