/* eslint-disable @typescript-eslint/explicit-module-boundary-types */
/* eslint-disable @typescript-eslint/no-explicit-any */
import { configure } from 'vee-validate';
import { localize, setLocale } from '@vee-validate/i18n';

export default function configurePlugin(i18n: any): void {
  const mappedDictionary: any = Object.keys(i18n.messages).reduce(
    (dict: { [key: string]: string }, lang) => {
      // eslint-disable-next-line no-param-reassign
      dict[lang] = { ...i18n.messages[lang]?.$veeValidate };
      return dict;
    },
    {},
  );

  const generateDefaultMessage = localize(mappedDictionary);

  configure({
    generateMessage: (ctx) => {
      let translatedMessage = generateDefaultMessage(ctx);

      // fallback
      if (!translatedMessage) {
        translatedMessage = generateDefaultMessage({
          ...ctx,
          rule: {
            name: '_default',
          },
        });

        // _default is missing for current locale, fallback to hard coded message.
        if (!translatedMessage) {
          translatedMessage = `The field ${ctx.field} is invalid`;
          // TODO: report missing translation to datadog?
        }
      }

      return translatedMessage;
    },
  });

  setLocale(i18n.locale);
}

export function setVeeValidateLocale(locale: string) {
  setLocale(locale);
}
