import { createI18n } from 'vue-i18n';
import shellApi from 'shell/api';
import configureVueValidatePlugin, { setVeeValidateLocale } from './plugins/vee-validate';
import enGB from './en.json';
import no from './no.json';
import be from './be.json';
import de from './de.json';
import dk from './dk.json';
import fi from './fi.json';
import fr from './fr.json';
import nl from './nl.json';
import pl from './pl.json';
import se from './se.json';
import it from './it.json';

const i18n = createI18n({
  locale: shellApi.i18n.getLocale(),
  fallbackLocale: 'en', // set fallback locale
  messages: {
    en: enGB,
    no: no,
    vls: be,
    de: de,
    da: dk,
    fi: fi,
    fr: fr,
    nl: nl,
    pl: pl,
    sv: se,
    it: it
  },
});

configureVueValidatePlugin(i18n.global);

export const i18nPlugin = i18n;

// can be used in conjunction with locale changed event from shell
export function setLocale(locale: string): void {
  i18n.global.locale = locale;
  setVeeValidateLocale(locale);
}

export default i18n.global;
