import { createRouter, createWebHistory } from 'vue-router';
import HelpCentre from '@/views/HelpCentre.vue';
import api from 'shell/api';

const routes = [
  {
    path: '/help-centre',
    component: HelpCentre,
  }
  // todo: add not found route
];

const routerBasePath = api.app.getRouterBasePath('@abax/central/users/help-centre');

const router = createRouter({
  history: createWebHistory(routerBasePath),
  routes,
});

export default router;
