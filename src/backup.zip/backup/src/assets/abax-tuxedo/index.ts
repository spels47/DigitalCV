import { watch, ref, computed } from 'vue';
import { Department } from '@abax/tuxedo';

export interface AppliedFiltersDialog {
  // departmentFilter: {
  //   activeDepartments: Department[];
  // } | null;

  customFilter: {
    userTags: Array<string>,
    installationTags: Array<string>,
    types: Array<string>
  }
}

// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
export default function useCustomFilterState(initialValues: {
    userTags: Array<string>,
    installationTags: Array<string>,
    types: Array<string>
}) {
  const isDirty = ref(false);
  const customFilter = ref(initialValues);

  const lastCommittedState = ref(customFilter.value);

  watch(customFilter, (newValues) => {
    if(lastCommittedState.value.installationTags.length != newValues.installationTags.length ||
      lastCommittedState.value.types.length != newValues.types.length ||
      lastCommittedState.value.userTags.length != newValues.userTags.length) {
        isDirty.value = true;
        return;
      }
    for (let i = 0; i < newValues.installationTags.length; i++) {
      const newInstallationTag = newValues.installationTags[i];
      if(lastCommittedState.value.installationTags.includes(newInstallationTag)) continue;
      isDirty.value = true;
      return;
    }
    for (let i = 0; i < newValues.types.length; i++) {
      const newType = newValues.types[i];
      if(lastCommittedState.value.types.includes(newType)) continue;
      isDirty.value = true;
      return;
    }
    for (let i = 0; i < newValues.userTags.length; i++) {
      const newUserTag = newValues.userTags[i];
      if(lastCommittedState.value.userTags.includes(newUserTag)) continue;
      isDirty.value = true;
      return;
    }
    isDirty.value = false;
  });

  const isDefault = computed(
    () => customFilter.value.installationTags.length === 0 && customFilter.value.types.length === 0 && customFilter.value.userTags.length === 0,
  );

  return {
    customFilter,
    isDefault,
    isDirty,
    lastCommittedState,
    commit() {
      isDirty.value = false;
      lastCommittedState.value = customFilter.value;
    },
    reset() {
      customFilter.value = {userTags: [], installationTags: [], types: []};
    },
  };
}
