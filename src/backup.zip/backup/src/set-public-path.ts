/* eslint-disable camelcase */

// Set/override the public path dynamically (initially done (hardcoded) in webpack.config.js)
// This allows the federated module to be hosted anywhere (eg. behind rev proxies) without
// having to be rebuilt.
__webpack_public_path__ = `${(document.currentScript as HTMLScriptElement).src}/../`;
