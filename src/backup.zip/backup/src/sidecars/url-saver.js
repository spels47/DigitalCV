let running = false;
let popStateHandler = () => {
  updateUrlInLocalStorage();
};

export async function start() {
  if (!running) {
    running = true;
    window.addEventListener('popstate', popStateHandler);
  }
}

export function stop() {
  if (running) {
    window.removeEventListener('popstate', popStateHandler);
    running = false;
  }
}

function updateUrlInLocalStorage(){
  if(location.href.toLowerCase().includes("help-centre")) return;
  localStorage.setItem("HelpCentreFilterPage", location.href);
}