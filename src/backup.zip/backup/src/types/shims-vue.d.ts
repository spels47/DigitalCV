/* eslint-disable */
declare module '*.vue' {
  import type { DefineComponent } from 'vue';
  const component: DefineComponent<{}, {}, any>;
  export default component;
}
declare module 'shell/api' {
  export default api as import('@abax/dev-shell/dist/types/lib/src/shell-api').LatestApiVersion;
}