interface ApiV1UserProfile {
  id: string;
  name: string;
  username: string;
  countryCode: string;
}
interface ApiV1User {
  getProfile: () => ApiV1UserProfile;
}
interface ApiV1Auth {
  getAccessToken: () => Promise<string>;
}
interface ApiV1I18n {
  getLocale: () => string;
  setLocale: (newLocale: string) => void;
}
interface ApiV1AppMeta {
  getRouterBasePath: (remoteAppId: string) => string;
  getApiBasePath: (api: string) => string;
}
interface ApiV1 {
  user: ApiV1User;
  auth: ApiV1Auth;
  i18n: ApiV1I18n;
  app: ApiV1AppMeta;
}
declare module 'shell/api' {
  export default {} as ApiV1;
}