export interface CustomizableTableColumn {
  id: string;
  caption: string;
  selected: boolean;
}
