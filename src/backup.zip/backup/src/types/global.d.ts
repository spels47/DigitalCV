/* eslint-disable @typescript-eslint/naming-convention */
/* eslint-disable no-underscore-dangle */

declare let __webpack_public_path__: string;
