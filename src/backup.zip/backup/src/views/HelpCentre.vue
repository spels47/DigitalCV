<template>
<CreateTicketForm :loadingStart="loading" v-if="showCreateForm" :AktorId="AktorId" :CompanyName="Aktor" :EmailData="Email" :FirstNameData="FirstName" :LastNameData="LastName" :PhoneData="Phone" :countryCodeProp="countryCode" @close="disableForms" @error="disableForms(); errorToast($t('createTicketError'));" @create="getGuides(); disableForms(); createToast();"></CreateTicketForm>
  <div class="main" v-show="!showCreateForm">
    <div class="flexbox">
      <AddTicketButton class="showMobile mobile-create-ticket" @create="enableCreateForm" :buttonState="buttonState"></AddTicketButton>
      <div class="header-div">
        <h1 class="abt-text-header1 hideMobile">{{$t("headerTitle")}}</h1>
        <SearchBar :guides="guides" :loading="loading" :searchPlaceHolder="searchPlaceholder" :clearSearchCounter="clearSearchCounter" :overrideSearchValue="getPreFilterSearchValue" @SearchResult="SearchResult = $event" @ResetSearch="SearchResult = []; SearchText = ''; SearchActive = false" @SearchActive="SearchActive = $event" @searchText="SearchText = $event"></SearchBar>
        <FilterDialog :title="'filter'" :locale="locale" :customFilterData="guides" :appliedFilters="appliedFiltersValues" :isLoadingData="loading" @update="applyFiltersMethod($event)"></FilterDialog>
      </div>
      <AddTicketButton class="hideMobile" @create="enableCreateForm" :buttonState="buttonState"></AddTicketButton>
    </div>
    <div class="context-textbar" v-if="!SearchActive && !FilterActive && guides?.length > 0">
      <h3 class="abt-text-header3">{{$t("showAllContent")}}</h3>
    </div>
    <div class="context-textbar" v-if="SearchActive && !FilterActive && filteredGuides?.length > 0">
      <h3 class="abt-text-header3">{{$t("showingAll")}} "{{SearchText}}" {{$t("relatedContent")}} <span class="clear-search-link" @click="clearSearchCounter += 1">{{$t("clearSearch")}}</span> {{$t("toViewAll")}}</h3>
    </div>
    <div class="outer-container" v-if="!SearchActive && !FilterActive && guides?.length > 0">
      <Guide v-for="(guide, index) in guides" :key="index" :title="guide.title" :type="guide.type" :tags="guide.tags" :description="guide.description" :link="guide.link"></Guide>
    </div>
    <div class="outer-container" v-if="(SearchActive == false && FilterActive == true || SearchActive == true && FilterActive == true) && filteredGuides?.length > 0">
      <Guide v-for="(guide, index) in filteredGuides" :key="index" :title="guide.title" :type="guide.type" :tags="guide.tags" :description="guide.description" :link="guide.link" :highlightText="SearchText"></Guide>
    </div>
    <div class="filtered-outer-container filtered-guide-list" v-if="(SearchActive == true && FilterActive == false) && filteredGuides?.length > 0">
      <Guide v-for="(guide, index) in filteredGuides" :key="index" :title="guide.title" :type="guide.type" :tags="guide.tags" :description="guide.description" :link="guide.link" :highlightText="SearchText"></Guide>
    </div>
    <div class="spinner-container" v-if="(((SearchActive || FilterActive) && filteredGuides?.length == 0) || (!SearchActive && !FilterActive && (guides?.length == 0 || guides?.length == null))) && (loading == true || loading == null)">
      <abt-spinner style="font-size: 3rem;" class="spinner"></abt-spinner>
    </div>
    <div class="spinner-container" v-if="((filteredGuides?.length == 0 && SearchActive && !FilterActive)) && loading == false">
      <NoResult :title="$t('noResult.title.search')" :description="$t('noResult.description.search')" :showButton="SearchActive && !FilterActive" type="search" @clearSearch="clearSearch()"></NoResult>
    </div>
    <div class="spinner-container" v-if="((filteredGuides?.length == 0 && SearchActive && FilterActive)) && loading == false">
      <NoResult :title="$t('noResult.title.search')" :description="$t('noResult.description.searchAndFilter')" :showButton="false" type="search" @clearSearch="clearSearch()"></NoResult>
    </div>
    <div class="spinner-container" v-if="((filteredGuides?.length == 0 && !SearchActive && FilterActive)) && loading == false">
      <NoResult :title="$t('noResult.title.search')" :description="$t('noResult.description.filter')" :showButton="false" type="search" @clearSearch="clearSearch()"></NoResult>
    </div>
    <div class="spinner-container" v-if="((guides?.length == 0 && !SearchActive && !FilterActive)) && loading == false">
      <NoResult :title="$t('noResult.title.noDataFound')" :description="$t('noResult.description.noDataFound')" :showButton="false" type="data" @clearSearch="clearSearch()"></NoResult>
    </div>
    <div id="backendSuccessDialog" class="alert">
      <abt-alert id="success-alert" v-on:abt-after-hide="showBackendSuccessDialog = false;" v-on:abt-hide="showBackendSuccessDialog = false;" :open="showBackendSuccessDialog" duration="3000" type="success">
        <abt-icon slot="icon" name="far-check-circle"></abt-icon>
        {{backendSuccessMessage}}
      </abt-alert>
    </div>
    <div id="backendErrorDialog" class="alert">
      <abt-alert id="error-alert" v-on:abt-after-hide="showBackendErrorDialog = false;" v-on:abt-hide="showBackendErrorDialog = false;" :open="showBackendErrorDialog" duration="5000" type="danger">
        <abt-icon slot="icon" name="far-exclamation-circle"></abt-icon>
        {{backendErrorMessage}}
      </abt-alert>
    </div>
  </div>
</template>

<script>
import AddTicketButton from '../components/AddTicketButton.vue';
import CreateTicketForm from '../components/CreateTicketForm.vue';
import SearchBar from '../components/SearchBar.vue';
import Guide from '../components/Guide.vue';
import FilterDialog from '../components/FilterDialog2.vue';
import NoResult from '../components/NoResult.vue';
import axios from 'axios';
import api from 'shell/api';

export default {
  name: 'HelpCentre',
  components: {
    AddTicketButton,
    CreateTicketForm,
    SearchBar,
    Guide,
    FilterDialog,
    NoResult
  },
  data(){
    return {
      filteredGuides: [],
      guides: [],
      SearchResult: [],
      SearchText: "",
      clearSearchCounter: 0,
      SearchActive: false,
      FilterActive: false,
      loading: false,
      searchPlaceholder: this.$t("searchPlaceHolder"),
      token: "",
      showCreateForm: false,
      countryCode: "",
      showBackendSuccessDialog: false,
      backendSuccessMessage: this.$t("backendSuccessMessage"),
      showBackendErrorDialog: false,
      backendErrorMessage: this.$t("backendErrorMessageDefault"),
      buttonState: "enabled",
      locale: "",
      AktorId: "",
      Aktor: "",
      Email: "",
      Phone: "",
      FirstName: "",
      LastName: "",
      filteredInstallationTags: [],
      filteredUserTags: [],
      filteredTypes: [],
      loadingProfile: false,
      loadingMainOfficeName: false,
      preFilterPage: "",
    }
  },
  methods: {
    async getToken(){
      try{
        this.token = await api.auth.getAccessToken();
      }
      catch(error){
        console.error("failed to get login token" ,error.response);
        this.errorToast(this.$t("failedLoginError"));
      }
    },
    async getBasePath(){
      let url = await api.app.getApiBaseUrl("triplogwebapi");
      return url + "/api";
    },
    async getGuides(){
      if(this.AccessPage == false) return;
      var self = this;
      this.loading = true;

      axios.get(`/HelpCentre/GetAllGuides`)
      .then(function (response) {
        self.guides = response.data;
        console.log("get guides from stavanger api response", self.guides);
        self.loading = false;
      })
      .catch(function (error) {
        console.error("failed to get guides from stavanger api",error?.response);
        self.loading = false;
        if(error?.response?.status == 401) self.errorToast(self.$t("loginExpiredError"));
        else self.errorToast(self.$t("guideFetchError"));
      });
    },
    errorToast(message){
      if(message == null) this.backendErrorMessage = this.$t("backendErrorMessageDefault");
      else this.backendErrorMessage = message;
      document.getElementById('backendErrorDialog').innerHTML = `
        <abt-alert id="error-alert" v-on:abt-after-hide="showBackendErrorDialog = false;" v-on:abt-hide="showBackendErrorDialog = false;" :open="showBackendErrorDialog" duration="5000" type="danger">
          <abt-icon slot="icon" name="far-exclamation-circle"></abt-icon>
          ${this.backendErrorMessage}
        </abt-alert>`;
      this.showBackendErrorDialog = true;
      document.getElementById('error-alert').toast({position: 'top-center'});
    },
    saveToast(){
      this.backendSuccessMessage = this.$t("backendSuccessMessage");
      document.getElementById('backendSuccessDialog').innerHTML = `
        <abt-alert id="success-alert" v-on:abt-after-hide="showBackendSuccessDialog = false;" v-on:abt-hide="showBackendSuccessDialog = false;" :open="showBackendSuccessDialog" duration="3000" type="success">
          <abt-icon slot="icon" name="far-check-circle"></abt-icon>
          ${this.backendSuccessMessage}
        </abt-alert>`;
      this.showBackendSuccessDialog = true;
      document.getElementById('success-alert').toast({position: 'bottom-left'});
    },
    deleteToast(){
      this.backendSuccessMessage = this.$t("backendDeleteSuccessMessage");
      document.getElementById('backendSuccessDialog').innerHTML = `
        <abt-alert id="success-alert" v-on:abt-after-hide="showBackendSuccessDialog = false;" v-on:abt-hide="showBackendSuccessDialog = false;" :open="showBackendSuccessDialog" duration="3000" type="success">
          <abt-icon slot="icon" name="far-check-circle"></abt-icon>
          ${this.backendSuccessMessage}
        </abt-alert>`;
      this.showBackendSuccessDialog = true;
      document.getElementById('success-alert').toast({position: 'bottom-left'});
    },
    createToast(){
      this.backendSuccessMessage = this.$t("backendCreateSuccessMessage");
      document.getElementById('backendSuccessDialog').innerHTML = `
        <abt-alert id="success-alert" v-on:abt-after-hide="showBackendSuccessDialog = false;" v-on:abt-hide="showBackendSuccessDialog = false;" :open="showBackendSuccessDialog" duration="3000" type="success">
          <abt-icon slot="icon" name="far-check-circle"></abt-icon>
          ${this.backendSuccessMessage}
        </abt-alert>`;
      this.showBackendSuccessDialog = true;
      document.getElementById('success-alert').toast({position: 'bottom-left'});
    },
    enableEditForm(guide){
      this.selectedGuide = guide;
      this.showCreateForm = false;
    },
    disableForms(){
      this.selectedGuide = null;
      this.showCreateForm = false;
    },
    enableCreateForm(){
      this.disableForms();
      this.showCreateForm = true;
    },
    closeEditor(){
        this.$emit("close", null);
    },
    applyFiltersMethod(event){
      this.filteredUserTags = event?.customFilter?.userTags ?? [];
      this.filteredInstallationTags = event?.customFilter?.installationTags ?? [];
      this.filteredTypes = event?.customFilter?.types ?? [];

      this.combineSearchAndFilterLists();
    },
    combineSearchAndFilterLists(){
      var searchList = [].concat(this.SearchResult);
      var resultList = [];
      this.FilterActive = this.filteredUserTags?.length > 0 || this.filteredInstallationTags?.length > 0 || this.filteredTypes?.length > 0;
      if(!this.FilterActive && this.SearchActive) resultList = searchList;
      else if(this.FilterActive && !this.SearchActive){
        for (let i = 0; i < this.guides?.length; i++) {
          const guide = this.guides[i];
          if(this.filteredTypes?.length == 0 || this.filteredTypes.includes('User guide') && this.filteredTypes.includes('Installation guide')){
            for (let k = 0; k < guide.tags?.length; k++) {
              const tag = guide.tags[k];
              if((this.filteredUserTags.includes(tag.name.trim()) || this.filteredInstallationTags.includes(tag.name.trim())) && !this.guideExistsInList(guide, resultList)) resultList.push(guide);
            }
          }
          else if(this.filteredTypes.includes('User guide') && this.filteredUserTags?.length == 0){
            if(guide?.type == 'User guide') resultList.push(guide);
          }
          else if(this.filteredTypes.includes('User guide') && this.filteredUserTags?.length > 0){
            for (let k = 0; k < guide.tags?.length; k++) {
              const tag = guide.tags[k];
              if(this.filteredUserTags.includes(tag.name.trim()) && guide?.type == 'User guide' && !this.guideExistsInList(guide, resultList)) resultList.push(guide);
            }
          }
          else if(this.filteredTypes.includes('Installation guide') && this.filteredInstallationTags?.length == 0){
            if(guide?.type == 'Installation guide') resultList.push(guide);
          }
          else if(this.filteredTypes.includes('Installation guide') && this.filteredInstallationTags?.length > 0){
            for (let k = 0; k < guide.tags?.length; k++) {
              const tag = guide.tags[k];
              if(this.filteredInstallationTags.includes(tag.name.trim()) && guide?.type == 'Installation guide' && !this.guideExistsInList(guide, resultList)) resultList.push(guide);
            }
          }
        }
      }
      else if(this.FilterActive && this.SearchActive){
        for (let i = 0; i < searchList?.length; i++) {
          const guide = searchList[i];
          if(this.filteredTypes?.length == 0 || this.filteredTypes.includes('User guide') && this.filteredTypes.includes('Installation guide')){
            for (let k = 0; k < guide.tags?.length; k++) {
              const tag = guide.tags[k];
              if((this.filteredUserTags.includes(tag.name.trim()) || this.filteredInstallationTags.includes(tag.name.trim())) && !this.guideExistsInList(guide, resultList)) resultList.push(guide);
            }
          }
          else if(this.filteredTypes.includes('User guide') && this.filteredUserTags?.length == 0){
            if(guide?.type == 'User guide') resultList.push(guide);
          }
          else if(this.filteredTypes.includes('User guide') && this.filteredUserTags?.length > 0){
            for (let k = 0; k < guide.tags?.length; k++) {
              const tag = guide.tags[k];
              if(this.filteredUserTags.includes(tag.name.trim()) && guide?.type == 'User guide' && !this.guideExistsInList(guide, resultList)) resultList.push(guide);
            }
          }
          else if(this.filteredTypes.includes('Installation guide') && this.filteredInstallationTags?.length == 0){
            if(guide?.type == 'Installation guide') resultList.push(guide);
          }
          else if(this.filteredTypes.includes('Installation guide') && this.filteredInstallationTags?.length > 0){
            for (let k = 0; k < guide.tags?.length; k++) {
              const tag = guide.tags[k];
              if(this.filteredInstallationTags.includes(tag.name.trim()) && guide?.type == 'Installation guide' && !this.guideExistsInList(guide, resultList)) resultList.push(guide);
            }
          }
        }
      }
      this.filteredGuides = resultList;
    },
    guideExistsInList(guide, list){
      if(!list) return false;
      for (let i = 0; i < list.length; i++) {
        const guideInList = list[i];
        if(guideInList.id == guide.id) return true;
      }
      return false;
    },
    getProfile(){
      var self = this;
      this.loadingProfile = true;
      this.buttonState = "loading";

      axios.get("/UserProfile")
      .then(function (response) {
        console.log("user profile get response", response);
        self.countryCode = response.data.CustomerCountry;
        self.AktorId = response.data.CustomerId;
        self.Email = response.data.Email;
        self.Phone = response.data.Mobile
        self.loadingProfile = false;
        if(self.loadingMainOfficeName == false) self.buttonState = "enabled";
        var nameArray = response.data.Name.split(' ');
        self.FirstName = nameArray[0];
        if(nameArray?.length > 1) self.LastName = nameArray[nameArray?.length - 1];
      })
      .catch(function (error) {
        console.error("failed to get the users profile", error);
        self.loadingProfile = false;
        self.buttonState = "enabled";
      });
    },
    getMainOfficeName(){
      var self = this;
      this.buttonState = "loading";
      this.loadingMainOfficeName = true;

      axios.get("/HelpCentre/GetMainOfficeName")
      .then(function (response) {
        console.log("get mainoffice name response", response);
        self.Aktor = response.data;
        if(self.loadingProfile == false) self.buttonState = "enabled";
        self.loadingMainOfficeName = false;
      })
      .catch(function (error) {
        console.error("get mainoffice name failed",error);
        self.buttonState = "enabled";
        self.loadingMainOfficeName = false;
      });
    },
    correctLanguageCode(language){
      switch(language){
        case "sv": return "SE";
        case "da": return "DK";
        case "en": return "UK";
        case "vls": return "BE";
        default: return language;
      }
    },
    clearSearch(){
      this.clearSearchCounter += 1;
    }
  },
  computed: {
    appliedFiltersValues: function () {
      let value = {
        customFilter: {
          userTags: this.filteredUserTags,
          installationTags: this.filteredInstallationTags,
          types: this.filteredTypes
        }
      };
      return value;
    },
    getPreFilterSearchValue: function () {
      if(this.preFilterPage?.includes("departments")) return this.$t("preFilter.department");
      if(this.preFilterPage?.includes("admin")) return this.$t("preFilter.admin");
      if(this.preFilterPage?.includes("purpose")) return this.$t("preFilter.purpose");
      if(this.preFilterPage?.includes("RFIDLog")) return this.$t("preFilter.rfidLog");
      if(this.preFilterPage?.includes("idling-settings")) return this.$t("preFilter.idlingSettings");
      if(this.preFilterPage?.includes("notifications-settings")) return this.$t("preFilter.notificationsSettings");
      if(this.preFilterPage?.includes("privacy-assistant")) return this.$t("preFilter.privacyAssistant");
      if(this.preFilterPage?.includes("notifications")) return this.$t("preFilter.notifications");
      if(this.preFilterPage?.includes("profile/profile")) return this.$t("preFilter.profile");
      if(this.preFilterPage?.includes("change-password")) return this.$t("preFilter.changePassword");
      if(this.preFilterPage?.includes("assets/vehicles")) return this.$t("preFilter.vehicles");
      if(this.preFilterPage?.includes("drivers")) return this.$t("preFilter.drivers");
      if(this.preFilterPage?.includes("units")) return this.$t("preFilter.units");
      if(this.preFilterPage?.includes("smart-connect")) return this.$t("preFilter.smartConnect");
      if(this.preFilterPage?.includes("export/export-landing")) return this.$t("preFilter.integrations");
      if(this.preFilterPage?.includes("workhours")) return this.$t("preFilter.workHours");
      if(this.preFilterPage?.includes("triplog-settings")) return this.$t("preFilter.triplogSettings");
      if(this.preFilterPage?.includes("equipment-settings")) return this.$t("preFilter.equipmentSettings");
      if(this.preFilterPage?.includes("autorates")) return this.$t("preFilter.autorates");
      if(this.preFilterPage?.includes("trips")) return this.$t("preFilter.trips");
      if(this.preFilterPage?.includes("triplog-claims/submitted-triplogs")) return this.$t("preFilter.submittedTriplogs");
      if(this.preFilterPage?.includes("triplog-claims/pending")) return this.$t("preFilter.submittedTriplogsPending");
      if(this.preFilterPage?.includes("exported-triplogs")) return this.$t("preFilter.exportedTriplogs");
      if(this.preFilterPage?.includes("send-multi-sms")) return this.$t("preFilter.sendMultiSms");
      if(this.preFilterPage?.includes("spot")) return this.$t("preFilter.spot");
      if(this.preFilterPage?.includes("map")) return this.$t("preFilter.map");
      if(this.preFilterPage?.includes("assets/equipment")) return this.$t("preFilter.equipment");
      if(this.preFilterPage?.includes("assets/minis")) return this.$t("preFilter.minis");
      if(this.preFilterPage?.includes("driving-behaviour")) return this.$t("preFilter.drivingBehaviour");
      if(this.preFilterPage?.includes("tollroad/transactions/transactions")) return this.$t("preFilter.tollroadTransactions");
      if(this.preFilterPage?.includes("tollroad/invoice-overview/invoices")) return this.$t("preFilter.tollroadInvoices");
      if(this.preFilterPage?.includes("tollroad/subscriptions/subscriptions")) return this.$t("preFilter.tollroadSubscriptions");
      if(this.preFilterPage?.includes("tollroad/transactions-report/trareport")) return this.$t("preFilter.tollroadTraReport");
      if(this.preFilterPage?.includes("tollroad/summary/trasummary")) return this.$t("preFilter.tollroadTraSummary");
      if(this.preFilterPage?.includes("trip")) return this.$t("preFilter.trip");
      if(this.preFilterPage?.includes("privatecorptax")) return this.$t("preFilter.privateCorpTax");
      if(this.preFilterPage?.includes("toll-road-by-vehicle")) return this.$t("preFilter.tollRoadByVehicle");
      if(this.preFilterPage?.includes("toll-road-by-driver")) return this.$t("preFilter.tollRoadByDriver");
      if(this.preFilterPage?.includes("worktrip")) return this.$t("preFilter.workTrip");
      if(this.preFilterPage?.includes("driver")) return this.$t("preFilter.driver");
      if(this.preFilterPage?.includes("status-delivered-triplogs")) return this.$t("preFilter.statusDeliveredTriplogs");
      if(this.preFilterPage?.includes("time-in-area")) return this.$t("preFilter.timeInArea");
      if(this.preFilterPage?.includes("tripstop")) return this.$t("preFilter.tripStop");
      if(this.preFilterPage?.includes("mileage-driver")) return this.$t("preFilter.mileageDriver");
      if(this.preFilterPage?.includes("mileage")) return this.$t("preFilter.mileage");
      if(this.preFilterPage?.includes("vehicle-utilization")) return this.$t("preFilter.vehicleUtilization");
      if(this.preFilterPage?.includes("invoice-basis")) return this.$t("preFilter.invoiceBasis");
      if(this.preFilterPage?.includes("reports/service")) return this.$t("preFilter.serviceReport");
      if(this.preFilterPage?.includes("reports/insurance")) return this.$t("preFilter.insuranceReport");
      if(this.preFilterPage?.includes("reports/environment")) return this.$t("preFilter.environmentReport");
      if(this.preFilterPage?.includes("reports/driving-behaviour-score")) return this.$t("preFilter.drivingBehaviourScoreReport");
      if(this.preFilterPage?.includes("reports/driving-events")) return this.$t("preFilter.drivingEventsReport");
      if(this.preFilterPage?.includes("reports/idling")) return this.$t("preFilter.idlingReport");
      if(this.preFilterPage?.includes("reports/eq/usage")) return this.$t("preFilter.usageReport");
      if(this.preFilterPage?.includes("reports/eq/area-in-and-out")) return this.$t("preFilter.areaInAndOutReport");
      if(this.preFilterPage?.includes("reports/eq/notification")) return this.$t("preFilter.eqNotificationReport");
      if(this.preFilterPage?.includes("reports/eq/usage-status")) return this.$t("preFilter.usageStatusReport");
      if(this.preFilterPage?.includes("reports/maintenance")) return this.$t("preFilter.maintenanceReport");
      if(this.preFilterPage?.includes("reports/eq/geofence-now")) return this.$t("preFilter.geofenceNowReport");
      if(this.preFilterPage?.includes("reports/eq/eq-environment")) return this.$t("preFilter.eqEnvironmentReport");
      if(this.preFilterPage?.includes("schedule")) return this.$t("preFilter.schedule");
      if(this.preFilterPage?.includes("dashboard")) return this.$t("preFilter.dashboard");
    }
  },
  watch: {
    SearchText: function (newValue, oldValue){
      if(newValue != oldValue) {
        this.combineSearchAndFilterLists();
      }
    },
    loading: function (oldValue, newValue){
      if(oldValue == true && newValue == false && this.preFilterPage?.trim()?.length == 0){
        this.preFilterPage = localStorage.getItem("HelpCentreFilterPage");
        console.log("the pre filter page is:", this.preFilterPage);
      }
    }
  },
  mounted: async function () {
      this.locale = api.i18n.getLocale();
      await this.getToken();
      axios.defaults.baseURL = await this.getBasePath();
      axios.defaults.headers.common["Authorization"] = `Bearer ${await api.auth.getAccessToken()}`;
      axios.defaults.headers.common["Access-Control-Allow-Origin"] = "*";
      axios.defaults.headers.common["Accept"] = "application/json";
      this.$nextTick(async function () {
        await this.getProfile();
        await this.getMainOfficeName();
        await this.getGuides();
      })
  }
}
</script>

<style scoped>
.main{
  padding: 32px;
  height: 100%;
}
.outer-container{
  margin-top: 0.5rem;
  display:flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  height: calc(100% - 75px);
  width: 100%;
  overflow: auto;
}
.flexbox{
    align-items: center;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
}
.header-div{
    align-items: center;
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
}
.alert{
  position: absolute;
  bottom: 1rem;
  left: 50%;
  transform:translate(-50%, -1rem);
  z-index: 1;
}
.context-textbar{
  margin-top: 2rem;
}
.filtered-guide-list{
  margin-top: 4rem;
}
.filtered-outer-container{
  display:flex;
  flex-direction: column;
  justify-content: flex-start;
  align-items: center;
  height: calc(100% - 75px - 4rem);
  width: 100%;
  overflow: auto;
}
.no-content{
  position: relative;
  text-align:center;
  margin-top: 1rem;
}
.spinner-container{
  display:flex;
  flex-direction: row;
  justify-content: center;
  align-content: center;
  width: 100%;
}
.spinner{
  margin-top: 1rem;
}
.clear-search-link{
  text-decoration-line: underline;
  text-decoration-color: var(--abt-color-primary);
  color: var(--abt-color-primary);
  font-weight: var(--abt-text-title-font-weight);
  font-family: var(--abt-text-title-font-family);
  cursor: pointer;
}
@media only screen and (max-width: 768px) {
  .main{
    padding: 16px;
    height: 100%;
  }
  .outer-container{
    height: calc(100vh - 330px);
  }
  .hideMobile{
    display: none !important;
  }
  .header-div{
    align-items: center;
    display: flex;
    flex-direction: row;
    justify-content: flex-start;
    max-width: 100%;
    padding-bottom: 0;
  }
  .flexbox{
    align-items: center;
    display: flex;
    flex-direction: column;
    justify-content: stretch;
  }
  .divider{
    margin-top: 1.5rem;
    padding-right: 1rem;
    padding-bottom: 12;
    width: 100%;
  }
  .form{
    margin-top: 0;
    margin-left: 0;
    align-self: center;
  }
  .right-padding{
    padding-right: 16px;
    width: 100%;
    display: flex;
    flex-direction: row;
    justify-content: space-between;
  }
  .mobile-print{
    width: calc(100vw - 32px);
    margin-left: -16px;
  }
  .mobile-create-ticket{
    padding-bottom: 1.5rem;
    width: 100%;
  }
}
@media only screen and (min-width: 769px) {
  .showMobile{
    display: none;
  }
}
@media only screen and (max-width: 360px) {
  .main{
    padding: 8px;
    height: 100%;
  }
  .outer-container{
    height: calc(100vh - 316px);
  }
  .hideMobile{
    display: none !important;
  }
  .header-div{
    align-items: flex-start;
    max-width: 100%;
    padding-bottom: 0;
  }
  .flexbox{
    align-items: center;
    display: flex;
    flex-direction: column;
    justify-content: stretch;
  }
  .divider{
    margin-top: 1.5rem;
    padding-right: 0.5rem;
    padding-bottom: 8px;
    width: 100%;
  }
  .form{
    margin-top: 0;
    margin-left: 0;
    align-self: center;
  }
  .right-padding{
    padding-right: 8px;
    width: 100%;
  }
  .mobile-print{
    width: calc(100vw - 16px);
    margin-left: -8px;
  }
}
</style>
