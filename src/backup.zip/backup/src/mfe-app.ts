import { h, createApp } from 'vue';
import singleSpaVue from 'single-spa-vue';
import router from '@/router';
import App from './app.vue';
import { i18nPlugin, setLocale } from './i18n';
import api from 'shell/api';
import './app-startup';

const vueLifecycles = singleSpaVue({
  createApp,
  appOptions: {
    render() {
      return h(App, {});
    },
  },
  handleInstance: (app) => {
    app.config.compilerOptions.hoistStatic = false;
    app.config.compilerOptions.isCustomElement = (tag: string) => tag.startsWith('abt-');
    app.use(router);
    setLocale(api.i18n.getLocale());
    app.use(i18nPlugin);
  },
});

export const { bootstrap } = vueLifecycles;
export const { mount } = vueLifecycles;
export const { unmount } = vueLifecycles;
