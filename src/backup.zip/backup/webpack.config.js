// eslint-disable-next-line import/no-extraneous-dependencies
const path = require('path');
const webpack = require('webpack');
const { VueLoaderPlugin } = require('vue-loader');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const CopyPlugin = require('copy-webpack-plugin');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const { ModuleFederationPlugin } = require('webpack').container;
const ForkTsCheckerWebpackPlugin = require('fork-ts-checker-webpack-plugin');
const deps = require('./package.json').dependencies;

module.exports = (_, { mode }) => {
  const isProd = mode === 'production';

  // "Domain name" of the service you are developing.
  // NB! needs to be camelCased (no dashes etc.). It should follow the same
  //     naming rules as a javascript property. Eg. window.myMicroFrontend
  const packageId = '@abax/central/users/help-centre'; //todo: read from conf

  return {
    // HMR stops working when target is browserlist (https://github.com/webpack/webpack-dev-server/issues/2812)
    // Applying workaround for development.
    target: isProd ? 'browserslist' : 'web',
    devtool: 'source-map',
    entry: {
      ...(isProd ? {} : { app: './src/dev/entry.ts' }), // index.html and entry.ts is only for development
      ...(isProd
        ? {
            [packageId]: [
              './src/set-public-path.ts', // will replace hardcoded publicPath with correct path runtime (eg. when served behind a reverse proxy)
            ],
          }
        : {}),
    },
    externals: {
      'shell/api': 'window shell/v1/api',
    },
    output: {
      path: path.resolve(__dirname, 'dist'),
      // used during dev, will be replace runtime (see set-public-path)
      // we use absolute path here so that the federated module can be accessible from anywhere during development.
      publicPath: 'http://localhost:8080/',
      filename: isProd ? 'js/[name].[contenthash:8].js' : 'js/[name].js',
      chunkFilename: isProd ? 'js/[name].[contenthash:8].js' : 'js/[name].js',
      uniqueName: packageId
    },
    devServer: {
      contentBase: path.join(__dirname, 'public'),
      port: 8080,
      historyApiFallback: true,
      hot: !isProd,

      // Allow all so the federated module can be accessible from anywhere during development.
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, PATCH, OPTIONS',
        'Access-Control-Allow-Headers': 'X-Requested-With, content-type, Authorization',
      },
      proxy: {
        '/triplogwebapi': {
          logLevel: 'debug',
          target: 'http://staging-web01.abax.local',
        },
      },
    },
    resolve: {
      extensions: ['.mjs', '.js', '.jsx', '.tsx', '.ts', '.vue', '.json'],
      alias: {
        '@': path.resolve(__dirname, './src/'),
        vue$: 'vue/dist/vue.esm-bundler.js',
      },
      modules: ['node_modules'],
    },
    module: {
      noParse: /^(vue|vue-router|vuex|vuex-router-sync)$/,
      rules: [
        {
          test: /\.(m?js|jsx)$/,
          type: 'javascript/auto',
          exclude: /node_modules/,
          use: {
            loader: 'babel-loader',
          },
        },
        {
          test: /\.tsx?$/,
          exclude: /node_modules/,
          use: {
            loader: 'ts-loader',
            options: {
              appendTsSuffixTo: ['\\.vue$'],
              // disable type checker - we will use it in fork plugin
              transpileOnly: true
            },
          },
        },
        {
          test: /\.vue$/,
          use: {
            loader: 'vue-loader',
            options: {
              compilerOptions: {
                hoistStatic: false,
                isCustomElement: (tag) => /^abt-/.test(tag),
              },
            },
          },
        },
        {
          test: /\.css$/,
          use: [
            {
              loader: isProd ? MiniCssExtractPlugin.loader : 'style-loader',
            },
            'css-loader',
            'postcss-loader',
          ],
        },
        {
          test: /\.scss$/,
          use: [
            {
              loader: isProd ? MiniCssExtractPlugin.loader : 'style-loader',
            },
            'css-loader',
            'postcss-loader',
            'sass-loader',
          ],
        },
        {
          test: /\.(png|gif|jpe?g|svg|cur|woff|woff2|eot|ttf|otf)$/i,
          type: 'asset/resource',
        },
      ],
    },
    plugins: [
      new MiniCssExtractPlugin({
        filename: isProd ? 'css/[name].[contenthash:8].css' : 'css/[name].css',
        chunkFilename: isProd ? 'css/[name].[contenthash:8].css' : 'css/[name].css',
      }),
      new ModuleFederationPlugin({
        name: packageId,
        filename: 'remoteEntry.js',
        library: { type: 'window', name: packageId },
        exposes: {
          './micro-help-centre-frontend-app': './src/mfe-app.ts',
          './url-saver': './src/sidecars/url-saver.js',
        },
        // we want to participate in the library sharing part of module federation. This means that
        // the same version (semver) of libraries are shared between micro-services and/or shell.
        // NOTE! But we need to be careful with what we share, if the library has side effects (state) we
        // should probably not add it to the list. Functional/pure frameworks on the other hand should
        // definitly be candidates for sharing.
        shared: {
          vue: deps.vue,
        },
      }),
      ...(!isProd ? [new CopyPlugin({
        patterns: [
          {
            from: 'public',
            info: { minimized: true }, // Skip minimization of all files (terser will ignore these files)
            globOptions: {
              dot: true,
              ignore: ['**/.DS_Store', '**/index.html'],
            },
          },
          {
            from: path.resolve(__dirname, 'node_modules/@abax/dev-shell/dist/silent-signin.html'),
            to: path.resolve(__dirname, 'dist'),
          },
          {
            from: path.resolve(__dirname, 'node_modules/@abax/dev-shell/dist/silent-signin'),
            to: path.resolve(__dirname, 'dist/silent-signin'),
          },
          {
            from: "**/*",
            context: path.resolve(__dirname, "node_modules/@abax/dev-shell/dist/bow-tie-assets"),
            to: path.resolve(__dirname, 'dist'),
          },
        ],
      })] : [] ),
      new HtmlWebpackPlugin({
        title: 'app',
        template: './public/index.html',
        filename: 'index.html',
        excludeChunks: [
          packageId // HMR stops working otherwise
        ]
      }),
      new VueLoaderPlugin(),
      new webpack.DefinePlugin({
        __VUE_OPTIONS_API__: 'true',
        __VUE_PROD_DEVTOOLS__: 'false',
      }),
      new ForkTsCheckerWebpackPlugin({
        eslint: {
          files: './**/*.{ts,tsx,js,jsx,vue}'
        }
      }),
    ],
  };
};
