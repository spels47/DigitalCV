import { sum } from './example';

describe('example', () => {
  it('adds numbers', () => {
    expect(sum(1, 2)).toBe(3);
  });
});
