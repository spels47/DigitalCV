const jsonServer = require('json-server');
const path = require('path');

const config = { port: 3000, delay: 1000 };

const router = jsonServer.router(path.join(__dirname, 'db.json'));
const r = router.render;
router.render = (req, res) => {
  switch (req.url) {
    case '/pets':
      // modify response to give a smaller set of data, have to load individual item to get the full data
      res.locals.data = res.locals.data.map((value) => ({
        id: value.id,
        name: value.name,
        owner: value.owner,
      }));
      break;
    default:
    // NIL
  }
  r(req, res);
};

const server = jsonServer.create();
server.use(jsonServer.defaults());

// simulate some delay
server.use((_, __, next) => {
  setTimeout(next, config.delay);
});

server.use('/api', router);
server.listen(config.port, () => {
  console.log(`json-server for example api is now running on port ${config.port}`);
});
