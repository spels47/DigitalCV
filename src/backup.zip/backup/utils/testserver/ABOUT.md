# Test server for use in the sample

This is a small fake rest api using json-server, to quicly have some endpoints to use for demoing concepts

json-server automatically gives us a rest api based on its db.json file and could have been run as
just `json-server --watch utils/testserver/db.json` but we want to override the data included in some of the responses so
we created testserver.js to do this
