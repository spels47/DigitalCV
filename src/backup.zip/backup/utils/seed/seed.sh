#!/usr/bin/env bash

# Set directory to directory of this script
cd "$(dirname "$0")"

# if variable isn't set we use defaults
SEED_HOST="${SEED_HOST:-localhost:27017}"
SEED_DATABASE="${SEED_DATABASE:-shell-backend}"

if [[ -v SEED_DELAY ]] ; then sleep $SEED_DELAY ; fi

mongoimport --host $SEED_HOST --authenticationDatabase admin --username $SEED_USERNAME --password $SEED_PASSWORD --db $SEED_DATABASE --collection FederatedPackages --file FederatedPackages.json --jsonArray --mode=upsert
mongoimport --host $SEED_HOST --authenticationDatabase admin --username $SEED_USERNAME --password $SEED_PASSWORD --db $SEED_DATABASE --collection TopLevelMenus --file TopLevelMenus.json --jsonArray --mode=upsert
mongoimport --host $SEED_HOST --authenticationDatabase admin --username $SEED_USERNAME --password $SEED_PASSWORD --db $SEED_DATABASE --collection SubMenus --file SubMenus.json --jsonArray --mode=upsert

for file in i18n/*.json ; do
  LANGUAGE_CODE=$(echo "$file" |  sed -E 's|^i18n/(.*)\.json$|\1|')
  jq "._id = \"$LANGUAGE_CODE\"" "$file" | mongoimport --host $SEED_HOST --authenticationDatabase admin --username $SEED_USERNAME --password $SEED_PASSWORD --db $SEED_DATABASE --collection Translations --mode=upsert
done
