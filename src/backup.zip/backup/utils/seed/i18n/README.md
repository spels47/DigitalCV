These are the temporary translations of the menu texts, and should not be mixed in with the translations of the micro
frontend itself.