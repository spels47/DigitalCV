# Format for the seed json files

This will probably be moved from this file into the docs sometime in the future.

## `Applications.json`

Contains an array of application definitions with the following fields:

- `_id` id for the object in mongodb. May be removed if we change the import process or switch storage, should normally
  be the same as `remoteAppId`
- `remoteAppId` id of the application. This needs to be unique across all of ABAX micro frontends. The same as
  the `appId` in `webpack.config.js`
- `remote-module-name` The name of the federated module. (the same as what we have in `exposes`
  of `ModuleFederationPlugin` in `webpack.config.js`)
- `friendlyName` human readable name of the application. Can show up in console log messages and the like
- `remoteEntryUrl` the url where shell should load the module from
- `basePath` Where the application lives in the url structure. E.g. if the shell runs at `https://domain/central` and
  this is set to `examplePath` then the microfrontend will be expacted to handle any url that starts
  with `https://domain/central/examplePath/`

## TopLevelMenus.json

Contains an array of top level menus. A top level menu can contain items from multiple micro frontends maintained by
multiple teams, so it is not "owned" by any team, and this file is only used to seed local and review environments. Once
staging and prod is in place it is recommended to copy from there so that group ids will match, enabling us to use same
submenu definitions.

- `_id` id for the object in mongodb. May be removed if we change the seeding process or switch storage
- `titleKey` Translation file key for the title
- `remoteAppId` optional, usually not present. Application to show, for top level menus that have no submenus like "Map"
  micro frontend
- `subRoute` mandatory when `remoteAppId` is set, should be left out when it isn't.
- `includeIfEmpty` boolean. Tells backend not to filter away the toplevel menu item if there are no submenus left after
  filtering for user permissions. Normally only `true` when `remoteAppId` is set, but can also be useful for debugging.
- `requiredPermissions` array of strings. Permissions required to see this toplevelmenu. Usually only `AbaxAdmin` since
  the menu items should have more specific permissions listed on them
- `subMenuGroups` array of submenu groups. Objects with the properties:
  - `titleKey` optional. Not all groups have a visible name.
  - `groupType` optional. Reserved for future use.
  - `subMenuGroupId` unique key for the group. Used referenced in sub menus
- `order` integer. Sort order of the toplevel meny items. Does not need to be continuous, and we intend to go leave some
  room "between" items so that we can make a few additions in the future without having to change the values on existing
  items.

## SubMenus.json

Contains an array of menu items.

- `_id` id for the object in mongodb. May be removed if we change the seeding process or switch storage
- `groupId` the sub menu group this menu item should be placed in
- `groupOrder` the items position in the group. Duplicate values could make the order might change between runs.
- `titleKey` Translation file key for the title
- `remoteAppId` the application that should be used
- `subRoute` used together with base path from application to set the route this menu item should send the user to
- `requiredPermissions` array of strings. Permissions required to see this menu. Remember this is not a security
  feature, only to not show users UI they can use anyway.