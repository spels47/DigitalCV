<p align="center">
  <a href="" rel="noopener">
 <img width=300px height=300px src="https://images.huffingtonpost.com/2016-06-20-1466456551-7541513-Askforhelp.jpg" alt="Project logo"></a>
</p>

<h3 align="center">micro-help-centre-frontend</h3>

<div align="center">

[![Status](https://img.shields.io/badge/status-active-success.svg)]()

</div>

---

<p align="center"> this is the micro frontend help centre page
    <br> 
</p>

## 📝 Table of Contents

- [About](#about)
- [Dependencies](#dependencies)
- [Getting Started](#getting_started)
- [Prerequisites](#prerequisites)
- [Deployment](#deployment)
- [Built Using](#built_using)
- [NPM Command Notes](#npm_command_notes)

## 🧐 About <a name = "about"></a>

this project is for the user interface that contains the help centre page intended to be displayed
through the micro frontend shell.
changes and maintenance that are to be done to the help centre page should be done within this project.
the scope of this project should not be extended past that of its initial design in order to maintain the "micro-frontend" architecture.
<br>
<br>
This project is written in the vue options api style with javascript and any future changes to this project should maintain that style of coding found in this project, as to avoid having a mixture of coding styles, patterns and programming languages as far as this is possible. Because it is more difficult to learn and maintain a project when there is multiple styles, languages and patterns of coding in the same project. so regardless of how you feel about the vue options api or javascript or the folder/file structuring. please maintain it to avoid introducing several conflicting patterns of code.
<br>
<br>
If you need to make changes that affects the menu structure in any way, then you will need to create a merge request on the <a href="https://gitlab.planetabax.com/core/ui/bloom">bloom</a> repo aswell, since that repo is responsible for mapping applications and their routing paths to menu buttons aswell as what those menu items should be called and where in the menu they should show up, and what user rights are required to see the menu item.

## 👨‍🦽 Dependencies <a name = "dependencies"></a>

this project currently has no dependencies on other micro frontends, and is not a dependency of other micro frontends.

## 🏁 Getting Started <a name = "getting_started"></a>

These instructions will get you a copy of the project up and running on your local machine for development and testing help centre. See [deployment](#deployment) for notes on how to deploy the project on a live system.<br>
- run npm install
- run npm run serve<br>
project should now be running locally with hot reload <a href="http://localhost:8080/help-centre/help-centre">here</a><br>
if you need to go to the pre filtered version of the page then you can find that <a href="http://localhost:8080/help-centre/pre-filtered-help-centre">here</a>

however when running with hot reload the micro frontend isnt really being rendered in the real app shell, it runs in a mocked version of the shell.
you are therefore highly adviced to test both before deployment and during development as well as before finishing that the project works in the real shell.
this can be done as follows.
- run docker login harbor.planetabax.com (only necessary if its been a considerable amount of time since last time you worked on the project)
- run docker-compose pull (only necessary if its been a considerable amount of time since last time you worked on the project)
- run npm ci (only necessary if its been a considerable amount of time since last time you worked on the project)
- run npm run build
- run docker-compose up -d<br>
you should know that if you have issues with ports already being occupied you might have a hard time switching wich port this uses as it needs to use port 80 because of identity server.<br>
project should now be running locally in the real shell <a href="http://localhost/central/help-centre/help-centre">here</a><br>
if you need to go to the pre filtered version of the page then you can find that <a href="http://localhost/central/help-centre/pre-filtered-help-centre">here</a>

### Prerequisites <a name = "prerequisites"></a>

Node<br>
Docker Desktop<br>
VS Code or a different IDE of your choice (could also read/write the code in notepad if thats your thing)

## 🚀 Deployment <a name = "deployment"></a>

- create a branch from the master branch on <a href="https://gitlab.planetabax.com/micro-front-end/micro-help-centre-service">GitLab</a> (you may need to ask someone to add you as a member of the project in order to create branches)
- commit your changes to that branch.
- create a Merge Request on that branch with minimum 2 reviewers.
- get approvals for your change.
- register a deployment window in <a href="https://backstage.abax.cloud/release-management">Backstage Release Management</a> for this project.
- during your release window you may Merge your branch to master.
- after all the automatically executed pipeline steps are finished you will have access to the staging manual step, start this process in order to deploy to staging.
- test that your stuff works along with a QA resource.
- if QA and you approve that your stuff works you may start the next manual pipeline step which will deploy your changes to production
- test that your stuff works again on the production environment along with QA.
- if QA and you approve that your stuff works on the production environment you may end your release window / close the release window as a successfull release in <a href="https://backstage.abax.cloud/release-management">Backstage Release Management</a>
<br><br>
thats it now it should be deployed

<br><br><br>

if you need to deploy changes related to User rights / access to the page or other menu related stuff you will need to do that in a separate branch on the <a href="https://gitlab.planetabax.com/core/ui/bloom">bloom</a> repo.

## ⛏️ Built Using <a name = "built_using"></a>

- [VueJs](https://vuejs.org/) - Web Framework
- [Template](https://gitlab.planetabax.com/core/ui/sample-micro-frontend) - Sample Project

## 🛠️ NPM Command Notes <a name = "npm_command_notes"></a>

- **npm run serve** in addition to running the application locally, it will attempt to update the **dev-shell** and **tuxedo** packages (which is internal packages) to the **latest** version.
- **npm run serve:no-update** runs the application as normal with hot reload, think of it as how **npm run serve** normally works out of the box without the extra i have added to this project
- **npm run update:abax** will try to update the **dev-shell** and **tuxedo** packages to the **latest** version.